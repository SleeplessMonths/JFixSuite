package java_6.problem_83D.subId_485844;

import java.util.*; 
import java.io.*;
import java.math.BigInteger;

public class Main implements Runnable
{
   int getCount(int n, int k) {
      if (k == 2) return n/2;
      if (k == 3) return n/3 - n/2/3;
      if (k == 5) return n/5 - n/5/2 - n/5/3 + n/5/2/3;
      if (k == 7) return n/7 - n/7/2 - n/7/3 - n/7/5 + n/7/2/3 + n/7/2/5 + n/7/3/5 - n/7/2/3/5;
      if (k <= 10) return 0;
      n /= k;
      boolean[] used = new boolean[n+2];
      for (int i = 2; i <= n && i < k; i++) if (!used[i])
         for (int j = i; j <= n; j+=i)
            used[j] = true;
      int ret = 0;
      for (int i = 1; i <= n; i++)
         if (!used[i])
            ret++;
      return ret;
   }
   
   void solution() throws Exception
   {
      int l = nextInt();
      int r = nextInt();
      int k = nextInt();
      int ret = getCount(r, k) - getCount(l-1, k);
      out.println(ret);
   }
   
   ///////////////////// Template definitions //////////////////////////
   int nextInt() throws IOException { return Integer.parseInt(next()); }
   long nextLong() throws IOException { return Long.parseLong(next()); }
   double nextDouble() throws IOException { return Double.parseDouble(next()); }
   
   String next() throws IOException {
      while (st == null || !st.hasMoreTokens()) {
         String l = in.readLine();
         if (l == null) return null;
         st = new StringTokenizer(l);
      }
      return st.nextToken();
   }
   
   public static void main(String args[]) {
      Locale.setDefault(Locale.UK);
      new Thread(new Main()).start();
   }
   
   public void run() {
      try {
         boolean online = System.getProperty("ONLINE_JUDGE") != null; 
         Reader reader = online
            ? new InputStreamReader(System.in)
            : new FileReader("my.in");
         in = new BufferedReader(reader);
         out = new PrintWriter(System.out);
         solution();
         out.flush();
         out.close();
      }
      catch (Exception e) {
         e.printStackTrace();
         System.exit(202);
      }
   }
   
   BufferedReader in;
   StringTokenizer st;
   PrintWriter out;
}