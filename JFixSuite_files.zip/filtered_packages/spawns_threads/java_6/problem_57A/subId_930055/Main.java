package java_6.problem_57A.subId_930055;

import java.awt.Point;
import java.io.*;
import java.math.BigInteger;
    import java.text.*;
    import java.util.*;
import java.util.regex.*;

    public class Main{
        static class Run implements Runnable{
            //TODO parameters
            final boolean consoleIO = true;
            final String inFile = "input.txt";
            final String outFile = "output.txt";
            
            int n;
            Point st, fn;
            int[][] steps = {{0,1},{1,0},{0,-1},{-1,0}};
            LinkedList<Point> queue;
            boolean[][] visited;
            int[][] field;
            
            int wave() {
                visited = new boolean[n+1][n+1];
                field = new int[n+1][n+1];
                queue = new LinkedList<Point>();
                visited[st.y][st.x] = true;
                queue.add(st);
                
                while(!queue.isEmpty()) { 
                    Point cur = queue.removeFirst();
                    
                    for(int i = 0; i < steps.length; ++i) {
                        Point tmp = new Point(cur.x+steps[i][0],cur.y+steps[i][1]);
                        
                        if(ok(tmp)&&!visited[tmp.y][tmp.x]) {
                            queue.add(tmp);
                            field[tmp.y][tmp.x] = field[cur.y][cur.x]+1;
                            visited[tmp.y][tmp.x] = true;
                            
                            if(tmp.equals(fn))
                                return field[tmp.y][tmp.x];
                        }
                    }
                }
                
                return -1;
            }
            
            boolean ok(Point p) {
                boolean ok = p.y>=0 && p.x>=0 && p.y<=n && p.x<=n;
                boolean ok1 = p.y==0||p.y==n||p.x==0||p.x==n;
                return ok1&&ok;
            }
            
            @Override
            public void run() {
                n = nextInt();
                st = new Point(nextInt(),nextInt());
                fn = new Point(nextInt(),nextInt());
                
                print(wave());
                close();
            }
        //=========================================================================================================================
            BufferedReader in;
            PrintWriter out;
            StringTokenizer strTok;
           
            Run() {
                if (consoleIO) {
                    initConsoleIO();
                }
                else {
                    initFileIO();
                }
            }
           
            void initConsoleIO() {
                in = new BufferedReader(new InputStreamReader(System.in));
                out = new PrintWriter(new OutputStreamWriter(System.out));
            }
           
            void initFileIO() {
                try {
                    in = new BufferedReader(new FileReader(inFile));
                    out = new PrintWriter(new FileWriter(outFile));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
           
            void close() {
                try {
                    in.close();
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
           
            int nextInt() {
                return Integer.parseInt(nextToken());
            }
           
            double nextDouble() {
                return Double.parseDouble(nextToken());
            }
           
            float nextFloat() {
                return Float.parseFloat(nextToken());
            }
           
            long nextLong() {
                return Long.parseLong(nextToken());
            }
           
            String nextLine() {
                try {
                    return in.readLine();
                } catch (IOException e) {
                    return "__NULL";
                }
            }
           
            boolean hasMoreTokens() {
                return (strTok == null) || (strTok.hasMoreTokens());
            }
           
            String nextToken() {
                while (strTok == null || !strTok.hasMoreTokens()) {
                    String line;
                    try {
                        line = in.readLine();
                        strTok = new StringTokenizer(line);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
               
                return strTok.nextToken();
            }
           
            void cout(Object o){
                System.out.println(o);
            }
           
            void print(Object o) {
                out.write(o.toString());
            }
            
            void println(Object o) {
                out.write(o.toString() + '\n');
            }
           
            void printf(String format, Object... args) {
                out.printf(format, args);
            }
           
            String sprintf(String format, Object... args) {
            return MessageFormat.format(format, args);
        }
        }
       
        static class Pair<A, B> {
            A a;
            B b;
           
            A f() {
                return a;
            }
           
            B s() {
                return b;
            }
           
            Pair(A a, B b) {
                this.a = a;
                this.b = b;
            }
           
            Pair(Pair<A, B> p) {
                a = p.f();
                b = p.s();
            }
        }
       
        public static void main(String[] args) throws IOException {
            Run run = new Run();
            Thread thread = new Thread(run);
            thread.run();
        }
    }