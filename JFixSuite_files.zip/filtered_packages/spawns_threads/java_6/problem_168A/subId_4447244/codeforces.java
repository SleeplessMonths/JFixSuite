package java_6.problem_168A.subId_4447244;

import java.io.*;
import java.lang.reflect.Field;
import java.math.BigInteger;
import java.util.*;

public class codeforces implements Runnable {

    private BufferedReader br = null;
    private PrintWriter pw = null;
    private StringTokenizer stk = new StringTokenizer("");

    public static void main(String[] args) {
        new Thread(new codeforces()).run();
    }

    public void run() { /*
                         * try { // br = new BufferedReader(new
                         * FileReader("input.txt")); pw = new
                         * PrintWriter("output.txt"); } catch
                         * (FileNotFoundException e) { e.printStackTrace(); }
                         */
        br = new BufferedReader(new InputStreamReader(System.in));
        pw = new PrintWriter(new OutputStreamWriter(System.out));
        solver();
        pw.close();

    }

    private void nline() {
        try {
            if (!stk.hasMoreTokens())
                stk = new StringTokenizer(br.readLine());
        } catch (IOException e) {
            throw new RuntimeException("KaVaBUnGO!!!", e);
        }
    }

    private String nstr() {
        while (!stk.hasMoreTokens())
            nline();
        return stk.nextToken();
    }

    private int ni() {
        return Integer.valueOf(nstr());

    }

    private long nl() {
        return Long.valueOf(nstr());

    }

    private double nd() {
        return Double.valueOf(nstr());

    }

    String nextLine() {
        try {
            return br.readLine();
        } catch (IOException e) {
        }
        return null;
    }

    private void solver() {
        int n = ni(), x = ni();
        double y = nd()/100;
        System.out.println((int)Math.ceil((n * y) - x));

    }

    private BigInteger nbi() {
        return new BigInteger(nstr());
    }

    void exit() {

        System.exit(0);
    }
}