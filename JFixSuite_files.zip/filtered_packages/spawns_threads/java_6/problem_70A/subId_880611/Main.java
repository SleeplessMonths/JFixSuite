package java_6.problem_70A.subId_880611;

import java.io.*;
    import java.text.*;
    import java.util.*;
import java.util.regex.*;

    public class Main{
        static class Run implements Runnable{
            //TODO parameters
            final boolean consoleIO = true;
            final String inFile = "input.txt";
            final String outFile = "output.txt";
            
            boolean[][] f;
            int n;
            
            boolean ok(int x, int y, int sz) { 
                for(int j = 0; j < sz; ++j) {
                    int tx = x + j;
                    int ty = y + j;
                    
                    if(tx >= n || ty >= n || f[ty][n-tx-1])
                        return false;
                }
                
                return true;
            }
           
            void cook(int x, int y, int sz) {
                if(ok(x, y, sz)) {
                    int c = 0;
                        
                    for(int i = y; i < y+sz; ++i, ++c)
                        for(int j = x; j < x+sz-c; ++j)
                            f[i][n-j-1] = true;
                }
            }
            
            int solve(int m) {
//              n = (int)Math.pow(2,nextInt());
                n = (int)Math.pow(2,m);
                f = new boolean[n][n];
                
                int sz = n;
                while(sz != 1) {
                    for(int i = 0; i < n; ++i)
                        for(int j = 0; j < n; ++j)
                            cook(i, j, sz);
                            
                    sz /=2;
                }
                
                int c = 0;
                for(boolean[] b1:f) 
                    for(boolean b:b1)
                        if(!b)
                            ++c;
                return c;
            }
            
            void print() {
                for(boolean[] b1:f) {
                    for(boolean b:b1)
                        print((b?"_":"O")+" ");
                    print("\n");
                }
            }
            
            /*
             * для тех у кого проблемы - внимательнее читаем абзац 
             * Выходные данные
             */
            
            @Override
            public void run() {
//              for(int i = 0; i <= 10; ++i)
//                  print(i + "----"+ solve(i)+"\n");
//              print();
                int n = nextInt();
                int res;
                
                if(n==0||n==1)
                    res = n;
                else {
                    res = 3;
                    for(int i = 2; i < n; ++i) {
                        res *= 3;
                        res %= 1000003;
                    }
                }
                    
                print(res);
                close();
            }
        //=========================================================================================================================
            BufferedReader in;
            PrintWriter out;
            StringTokenizer strTok;
           
            Run() {
                if (consoleIO) {
                    initConsoleIO();
                }
                else {
                    initFileIO();
                }
            }
           
            void initConsoleIO() {
                in = new BufferedReader(new InputStreamReader(System.in));
                out = new PrintWriter(new OutputStreamWriter(System.out));
            }
           
            void initFileIO() {
                try {
                    in = new BufferedReader(new FileReader(inFile));
                    out = new PrintWriter(new FileWriter(outFile));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
           
            void close() {
                try {
                    in.close();
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
           
            int nextInt() {
                return Integer.parseInt(nextToken());
            }
           
            double nextDouble() {
                return Double.parseDouble(nextToken());
            }
           
            float nextFloat() {
                return Float.parseFloat(nextToken());
            }
           
            long nextLong() {
                return Long.parseLong(nextToken());
            }
           
            String nextLine() {
                try {
                    return in.readLine();
                } catch (IOException e) {
                    return "__NULL";
                }
            }
           
            boolean hasMoreTokens() {
                return (strTok == null) || (strTok.hasMoreTokens());
            }
           
            String nextToken() {
                while (strTok == null || !strTok.hasMoreTokens()) {
                    String line;
                    try {
                        line = in.readLine();
                        strTok = new StringTokenizer(line);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
               
                return strTok.nextToken();
            }
           
            void cout(Object o){
                System.out.println(o);
            }
           
            void print(Object o) {
                out.write(o.toString());
            }
            
            void println(Object o) {
                out.write(o.toString() + '\n');
            }
           
            void printf(String format, Object... args) {
                out.printf(format, args);
            }
           
            String sprintf(String format, Object... args) {
            return MessageFormat.format(format, args);
        }
        }
       
        static class Pair<A, B> {
            A a;
            B b;
           
            A f() {
                return a;
            }
           
            B s() {
                return b;
            }
           
            Pair(A a, B b) {
                this.a = a;
                this.b = b;
            }
           
            Pair(Pair<A, B> p) {
                a = p.f();
                b = p.s();
            }
        }
       
        public static void main(String[] args) throws IOException {
            Run run = new Run();
            Thread thread = new Thread(run);
            thread.run();
        }
    }