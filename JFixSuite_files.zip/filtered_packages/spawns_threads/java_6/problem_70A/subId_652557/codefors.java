package java_6.problem_70A.subId_652557;

import java.io.*;
import java.math.*;
import java.util.*;
import java.util.List;
import java.util.Queue;
import java.awt.*;

public class codefors implements Runnable {

    private BufferedReader br = null;
    private PrintWriter pw = null;
    private StringTokenizer stk = new StringTokenizer("");

    public static void main(String[] args) {
        new Thread(new codefors()).run();
    }

    public void run() {
        /*
         * try { // br = new BufferedReader(new FileReader("input.txt")); pw =
         * new PrintWriter("output.txt"); } catch (FileNotFoundException e) {
         * e.printStackTrace(); }
         */
        br = new BufferedReader(new InputStreamReader(System.in));
        pw = new PrintWriter(new OutputStreamWriter(System.out));
        solver();
        pw.close();

    }

    private void nline() {
        try {
            if (!stk.hasMoreTokens())
                stk = new StringTokenizer(br.readLine());
        } catch (IOException e) {
            throw new RuntimeException("KaVaBUnGO!!!", e);
        }
    }

    private String nstr() {
        while (!stk.hasMoreTokens())
            nline();
        return stk.nextToken();
    }

    private int ni() {
        return Integer.valueOf(nstr());

    }

    private double nd() {
        return Double.valueOf(nstr());

    }

    private BigInteger nbi() {
        return new BigInteger(nstr());
    }

    String nextLine() {
        try {
            return br.readLine();
        } catch (IOException e) {
        }
        return null;
    }

    private void solver() {
        int n = ni();
        int ans = 1;
        for(int i =1 ; i<n; i++){
            ans*=3%1000003;
        }
        System.out.println(ans);
    }

    void exit() {
        System.exit(0);
    }
}