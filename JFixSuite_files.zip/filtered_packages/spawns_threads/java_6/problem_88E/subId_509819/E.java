package java_6.problem_88E.subId_509819;

import java.io.*;
import java.util.*;

public class E implements Runnable{

	BufferedReader in;
	StringTokenizer token = null;
	
	public int nextInt(){
		try{
			while (token==null || !token.hasMoreElements())
					token = new StringTokenizer(in.readLine());
			return Integer.parseInt(token.nextToken());
		} catch (Exception ex){
			ex.printStackTrace(System.err);
			return Integer.MIN_VALUE;
		}
	}
	
	public String nextWord(){
		try{
			while (token==null || !token.hasMoreElements())
					token = new StringTokenizer(in.readLine());
			return token.nextToken();
		} catch (Exception ex){
			ex.printStackTrace(System.err);
			return null;
		}	
	}
		
	int[] f, a;
	Set<Integer> set = new TreeSet<Integer>();
	
	@Override
	public void run() {
		try{
			in = new BufferedReader(new InputStreamReader(System.in));
			int n = nextInt();
			f = new int[n + 1];
			a = new int[n + 1];
			f[1] = f[2] = 0;
			
			for (int i=3; i<=n; ++i){
				int max = -1;
				set.clear();
				for (int k=2; k<i; ++k){
					int sum = k * (k + 1) / 2;
					if (sum > i) break;
					if ((i - sum) % k != 0) continue;
					int left = 1 + (i - sum) / k;
					int right = k + (i - sum) / k;
					int res = 0;
					for (int j=left; j<=right; ++j)
						res = res ^ f[j];
					set.add(res);
					if (res==0 && max==-1) max = k;
				}
				if (max == -1){
					f[i] = 0;
					continue;
				}
				set.add(1000000);
				int res = 0, prev=-1;
				for (Integer x : set){
					if (x != prev + 1){
						res = prev + 1;
					} else prev = x;
				}
				f[i] = res;
				a[i] = max;
			}
			
			if (f[n]==0)
				System.out.println(-1); else
				System.out.println(a[n]);
			in.close();
		}catch (Exception ex){
			
		}
	}

	public static void main(String[] args) {
		(new Thread(new E())).start();
	}	
}