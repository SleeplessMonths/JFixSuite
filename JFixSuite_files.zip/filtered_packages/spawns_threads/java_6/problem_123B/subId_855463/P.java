package java_6.problem_123B.subId_855463;

import java.io.*;
import java.util.*;
import java.math.*;

public class P implements Runnable {

    public void run() {
        long startTime = System.nanoTime();

        long a = nextInt();
        long b = nextInt();
        long x1 = nextInt();
        long y1 = nextInt();
        long x2 = nextInt();
        long y2 = nextInt();

        long da = (long) 6e8 * 2 * a;
        long db = (long) 6e8 * 2 * b;
        long i1 = (x1 + y1 + da) / 2 / a;
        long j1 = (x1 - y1 + db) / 2 / b;

        long i2 = (x2 + y2 + da) / 2 / a;
        long j2 = (x2 - y2 + db) / 2 / b;

        println(Math.abs(i1 - i2));
        println(Math.abs(j1 - j2));
        println(Math.abs(i1 - i2) + Math.abs(j1 - j2));
    
        if (fileIOMode) {
            System.out.println((System.nanoTime() - startTime) / 1e9);
        }
        out.close();
    }

    int get(int a, int b) {
        return b == 0 ? a : get(b, a % b);
    }

    //-----------------------------------------------------------------------------------

    private static boolean fileIOMode;
    private static String problemName = "a";
    private static BufferedReader in;
    private static PrintWriter out;
    private static StringTokenizer tokenizer;

    public static void main(String[] args) throws Exception {
        fileIOMode = args.length > 0 && args[0].equals("!");
        if (fileIOMode) {
            in = new BufferedReader(new FileReader(problemName + ".in"));
            out = new PrintWriter(problemName + ".out");
        } else {
            in = new BufferedReader(new InputStreamReader(System.in));
            out = new PrintWriter(System.out);
        }
        tokenizer = new StringTokenizer("");

        new Thread(new P()).start();
    }

    private static String nextLine() {
        try {
            return in.readLine();
        } catch (IOException e) {
            return null;
        }
    }

    private static String nextToken() {
        while (!tokenizer.hasMoreTokens()) {
            tokenizer = new StringTokenizer(nextLine());
        }
        return tokenizer.nextToken();
    }

    private static int nextInt() {
        return Integer.parseInt(nextToken());
    }

    private static long nextLong() {
        return Long.parseLong(nextToken());
    }

    private static double nextDouble() {
        return Double.parseDouble(nextToken());
    }

    private static BigInteger nextBigInteger() {
        return new BigInteger(nextToken());
    }

    private static void print(Object o) {
        if (fileIOMode) {
            System.out.print(o);
        }
        out.print(o);
    }

    private static void println(Object o) {
        if (fileIOMode) {
            System.out.println(o);
        }
        out.println(o);
    }

    private static void printf(String s, Object... o) {
        if (fileIOMode) {
            System.out.printf(s, o);
        }
        out.printf(s, o);
    }
}