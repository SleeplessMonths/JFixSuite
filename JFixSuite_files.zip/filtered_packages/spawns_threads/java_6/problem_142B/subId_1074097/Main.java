package java_6.problem_142B.subId_1074097;

import java.io.*;
import java.util.*;
import java.math.*;

public class Main implements Runnable{

    FastScanner sc;
    BufferedReader reader;
    PrintWriter out;
    
    void solve() throws IOException {
        int n = sc.nextInt();
        int m = sc.nextInt();
        if (n > m) {
            int tmp = n;
            n = m;
            m = tmp;
        }
        if (n == 2) {
            boolean x = true;
            int ans = 0;
            for (int i = 1; i <= m; ++ i) {
                if (x) ans += 2;
                if (i % 2 == 0) {
                    x ^= true;
                }
            }
            out.println(ans);
        } else {
            out.println((n * m) / 2  + (n * m) % 2);
        }
    }
    
    public static void main(String[] argv) {
        new Thread(null, new Main(), "", 16 * 1024 * 1024).start();
    }

    public void run() {
        try {
            reader = new BufferedReader(new InputStreamReader(System.in));
            sc = new FastScanner(reader);
            //System.setOut(new PrintStream("out.txt"));
            out = new PrintWriter(new OutputStreamWriter(System.out));
            solve();
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            out.close();
        }
    }
    
    
    class FastScanner {
        BufferedReader reader;
        StringTokenizer strtok;
        
        public FastScanner(BufferedReader reader) {
            this.reader = reader;
        }
        
        String nextToken() throws IOException {
            if (strtok == null || !strtok.hasMoreElements()) {
                strtok = new StringTokenizer(reader.readLine());
            }
            
            return strtok.nextToken(); 
        }
        
        double nextDouble() throws IOException {
            return Double.parseDouble(nextToken());
        }
        
        int nextInt() throws IOException {
            return Integer.parseInt(nextToken());
        }
        
        long nextLong() throws IOException {
            return Long.parseLong(nextToken());
        }
    }
}