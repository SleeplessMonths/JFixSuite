package java_6.problem_68A.subId_378153;

import java.io.*;
import java.math.*;
import java.util.*;
import java.util.List;
import java.util.Queue;
import java.awt.*;

public class CodeForces_66 implements Runnable {

    private BufferedReader br = null;
    private PrintWriter pw = null;
    private StringTokenizer stk = new StringTokenizer("");

    public static void main(String[] args) {
        new Thread(new CodeForces_66()).run();
    }

    public void run() {
        /*
         * try { // br = new BufferedReader(new FileReader("input.txt")); pw =
         * new PrintWriter("output.txt"); } catch (FileNotFoundException e) {
         * e.printStackTrace(); }
         */
        br = new BufferedReader(new InputStreamReader(System.in));
        pw = new PrintWriter(new OutputStreamWriter(System.out));
        solver();
        pw.close();

    }

    private void nline() {
        try {
            if (!stk.hasMoreTokens())
                stk = new StringTokenizer(br.readLine());
        } catch (IOException e) {
            throw new RuntimeException("KaVaBUnGO!!!", e);
        }
    }

    private String nstr() {
        while (!stk.hasMoreTokens())
            nline();
        return stk.nextToken();
    }

    private int ni() {
        return Integer.valueOf(nstr());

    }

    private double nd() {
        return Double.valueOf(nstr());

    }

    String nextLine() {
        try {
            return br.readLine();
        } catch (IOException e) {
        }
        return null;
    }

    void task_A() {
        BigInteger bi = nbi();
        BigInteger lb = new BigInteger("-128");
        BigInteger rb = new BigInteger("127");
        BigInteger ls = new BigInteger("-32768");
        BigInteger rs = new BigInteger("32767");
        BigInteger li = new BigInteger("-2147483648");
        BigInteger ri = new BigInteger("2147483647");
        BigInteger ll = new BigInteger("-9223372036854775808");
        BigInteger rl = new BigInteger("9223372036854775807");

        if (rb.equals(bi.max(rb)) && lb.equals(bi.min(lb))) {
            System.out.println("byte");
            return;
        }
        ;
        if (rs.equals(bi.max(rs)) && ls.equals(bi.min(ls))) {
            System.out.println("short");
            return;
        }
        ;
        if (ri.equals(bi.max(ri)) && li.equals(bi.min(li))) {
            System.out.println("int");
            return;
        }
        ;
        if (rl.equals(bi.max(rl)) && ll.equals(bi.min(ll))) {
            System.out.println("long");
            return;
        }
        ;

        System.out.println("BigInteger");
    }

    void task_B() {
        int n = ni();
        int a[] = new int[n + 1];
        for (int i = 0; i < n; i++) {
            a[i] = ni();
        }
        int dpl[] = new int[n];
        int dpr[] = new int[n];
        dpl[0] = 0;
        dpr[n - 1] = 0;
        for (int i = 1; i < n; i++) {
            if (a[i] >= a[i - 1])
                dpl[i] = dpl[i - 1] + 1;
        }
        for (int i = n - 2; i >= 0; i--) {
            if (a[i] >= a[i + 1])
                dpr[i] = dpr[i + 1] + 1;
        }
        int f = 0;
        int max = 0;
        for (int i = 0; i < n; i++) {
            if (dpl[i] + dpr[i] > max) {
                max = dpl[i] + dpr[i];
                f = i;
            }
        }
        System.out.println(max + 1);
    }

    int nod(int a, int b) {
        if (a % b == 0)
            return b;
        return nod(b, a % b);
    }

    void task_C() {
        int n = ni();
        int a[] = new int[n];
        for (int i = 0; i < n; i++)
            a[i] = ni();
        for (int i = 1; i < n; i++)
            System.out.println(nod(a[i - 1], a[i]));
    }

    
    
    public static int n,m;
    
    private void solver() {
        
        int a=ni(),b=ni(),c=ni(),d=ni(), l=ni(), r=ni();
        int min = Math.min(d,Math.min(c,Math.min(a, b)));
        int ans=Math.min(r+1, min)-l;
        if(ans<0)ans=0;
        if(l==0 && r ==0)++ans;
        System.out.println(ans);
        
        
        
        /*
        n = ni();
        m = ni();
        
        int mas[][] = new int[n][m];
        int map[][] = new int[n][m];
        for(int i=0; i<n; i++){
            for(int j =0; j<m; j++){
                mas[i][j]=ni();
                map[i][j]=10000;
                
            }
        }
        
        int x = ni(), y =ni();
        
        map[0][0]=0;
        Stack<Point> st = new Stack<Point>();
        Point p = new Point();
        p.x = 0;
        p.y = 0;
        
        st.add(p);
        
        while(!st.isEmpty()){
            Point p0 = st.pop();
            Point p1 = new Point(p0.x+2,p0.y);
            Point p2 = new Point(p0.x,p0.y+2);
            Point p3 = new Point(p0.x-2,p0.y);
            Point p4 = new Point(p0.x,p0.y-2);
            if(check(p1) && mas[p0.y][p0.x+1]==mas[p0.y][p0.x+2] &&  ((map[p0.y][p0.x]+1) <map[p0.y][p0.x+2])){
            
                st.push(p1);
                map[p0.y][p0.x+2]=map[p0.y][p0.x]+1;
            }
            if(check(p2) && mas[p0.y+1][p0.x]==mas[p0.y+2][p0.x] &&  ((map[p0.y][p0.x]+1) < map[p0.y+2][p0.x])){
                st.push(p2);
                map[p0.y+2][p0.x]=map[p0.y][p0.x]+1;
            }
            if(check(p3) && mas[p0.y][p0.x-1]==mas[p0.y][p0.x-2] &&  map[p0.y][p0.x]+1 <map[p0.y][p0.x-2]){
                st.push(p3);
                map[p0.y][p0.x-2]=map[p0.y][p0.x]+1;
            }
            if(check(p4) && mas[p0.y-1][p0.x]==mas[p0.y-2][p0.x] &&  map[p0.y][p0.x]+1 <map[p0.y-2][p0.x]){
                st.push(p4);
                map[p0.y-2][p0.x]=map[p0.y][p0.x]+1;
            }
            
        }
        
       System.out.println(map[x-1][y-1]);
        

       Point t = new Point(x-1,y-1);
       int u = map[x-1][y-1];
       
       while(true){
           System.out.println(mas[t.x][t.y]);
        if(u==0)break;   
        Point t1 = new Point(t.x+2, t.y);
        Point t2 = new Point(t.x, t.y+2);
        Point t3 = new Point(t.x-2, t.y);
        Point t4 = new Point(t.x, t.y-2);
        if(check(t1) && (map[t1.y][t1.x]-u) ==1){
            t = (Point) t1.clone();
            --u;
            continue;
        }
        if(check(t2) && map[t2.y][t2.x]-u==1){
            t = (Point) t2.clone();
            --u;
            continue;
        }if(check(t3) && map[t3.y][t3.x]-u==1){
            t = (Point) t3.clone();
            --u;
            continue;
        }if(check(t4) && map[t4.y][t4.x]-u==1){
            t = (Point) t4.clone();
            --u;
            continue;
        }
        
        
        
       }
       
        /*BigInteger bi = new BigInteger("2");
        BigInteger max = new BigInteger("1000000000000000");
        BigInteger r = new BigInteger("1");
        int k = 1;
        while (true) {
            r = bi.pow(k++);
            if (r.compareTo(max) > 0)
                break;

        }

        System.out.println(k);
        System.out.println("1000000000000000");
        System.out.println(bi.pow(49));
        System.out.println( max.add(bi.pow(49).negate()) );*/

    }

    boolean check(Point p){
        if(p.x <0 || p.y<0 || p.x>=m || p.y >=n) return false;
        
        
        
        return true;
    }
    
    private BigInteger nbi() {
        return new BigInteger(nstr());
    }

    void exit() {

        System.exit(0);
    }
}