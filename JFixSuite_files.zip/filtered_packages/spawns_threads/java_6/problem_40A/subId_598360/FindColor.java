package java_6.problem_40A.subId_598360;

/**
 * Created by IntelliJ IDEA.
 * User: Taras_Brzezinsky
 * Date: 8/8/11
 * Time: 1:30 PM
 * To change this template use File | Settings | File Templates.
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.FileReader;
import java.util.StringTokenizer;
import java.io.IOException;
import java.util.Arrays;

public class FindColor extends Thread {

    public FindColor() {
        this.input = new BufferedReader(new InputStreamReader(System.in));
        this.output = new PrintWriter(System.out);
        this.setPriority(Thread.MAX_PRIORITY);
    }

    public void run() {
        try {
            int x = nextInt(), y = nextInt();
            boolean inverse = false;
            if (x == 0 || y == 0) {
                output.println("black");
            } else {
                if ((x < 0 && y > 0) || (x > 0 && y < 0)) {
                    inverse = true;
                }
                int where = x * x + y * y;
                int max = 1;
                for(; where > max * max; ++max);

                if (where == max) {
                    output.println("black");
                } else {
                    boolean ans = max % 2 == 0;
                    if (inverse) {
                        ans = ! ans;
                    }
                    output.println(ans ? "white" : "black");
                }
            }

            output.flush();
            output.close();

        } catch (Throwable e) {
            System.err.println(e.getMessage());
            System.err.println(Arrays.deepToString(e.getStackTrace()));
        }
    }


    public static void main(String[] args) {
        new FindColor().start();
    }

    private String nextToken() throws IOException {
        while (tokens == null || !tokens.hasMoreTokens()) {
            tokens = new StringTokenizer(input.readLine());
        }
        return tokens.nextToken();
    }

    private int nextInt() throws IOException {
        return Integer.parseInt(nextToken());
    }

    private double nextDouble() throws IOException {
        return Double.parseDouble(nextToken());
    }

    private long nextLong() throws IOException {
        return Long.parseLong(nextToken());
    }


    private BufferedReader input;
    private PrintWriter output;
    private StringTokenizer tokens = null;
}