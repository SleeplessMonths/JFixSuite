package java_6.problem_65A.subId_339583;

import java.io.*;
import java.util.*;
import java.math.*;


public class Main implements Runnable {

	
	private void solve() throws IOException {
		int a = 1;
		int b = 1;
		for (int i = 0; i < 3; ++i) {
			a *= nextInt();
			b *= nextInt();
		}
		if (b > a) {
			out.println("Ron");
		} else {
			out.println("Hermione");
		}
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new Thread(new Main()).start();

	}

	private BufferedReader br;
	private StringTokenizer st;
	private PrintWriter out;

	@Override
	public void run() {
		try {
			Locale.setDefault(Locale.US);
			br = new BufferedReader(new InputStreamReader(System.in));
			st = new StringTokenizer("");
			out = new PrintWriter(System.out);
			solve();
			out.close();			
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}
		
	}

	
	
	String next() throws IOException {
		while (!st.hasMoreTokens()) {
			String temp = br.readLine();
			if (temp == null) {
				return null;
			}
			st = new StringTokenizer(temp);
		}
		return st.nextToken();
	}

	int nextInt() throws IOException {
		return Integer.parseInt(next());
	}
	double nextDouble() throws IOException {
		return Double.parseDouble(next());
	}
	long nextLong() throws IOException {
		return Long.parseLong(next());
	}
	
}