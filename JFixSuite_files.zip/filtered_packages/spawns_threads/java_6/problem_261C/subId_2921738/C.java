package java_6.problem_261C.subId_2921738;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class C implements Runnable {

	public void solve() throws IOException {
        long n = in.nextLong() + 1;
        long t = in.nextLong();
        int td = 0;
        while ( ( 1l << td ) < t ) {
            td ++;
        }
        if ( ( 1l << td ) != t ) {
            out.println( 0 );
            return;
        }
        long[][] c = new long[43][43];
        for ( int i = 0; i < c.length; i ++ ) {
            c[i][0] = 1;
            for ( int j = 1; j <= i; j ++ ) {
                c[i][j] = c[i - 1][j - 1] + c[i - 1][j];
            }
        }
        long[][] s = new long[43][43];
        s[0][0] = 1;
        for ( int i = 1; i < c.length; i ++ ) {
            for ( int j = 0; j <= i; j ++ ) {
                s[i][j] = c[i][j] + s[i - 1][j];
            }
        }
        int pow = 42;
        long r = 0;
        while ( n < ( 1l << pow ) ) {
            pow --;
        }
        r += s[pow - 1][td];
        while ( pow > 0 && td >= 0 ) {
            if ( n < ( 1l << ( pow - 1 ) ) ) {
            } else {
                if ( n < ( 1l << pow ) + ( 1l << ( pow - 1 ) ) ) {
                    n -= 1l << ( pow - 1 );
                } else {
                    r += c[pow - 1][td];
                    n -= 1l << pow;
                    td --;
                }
            }
            pow --;
        }
        if ( td > 0 && n > 0 ) {
            r += c[0][td];
        }
        if ( t == 1 ) {
            r --;
        }
        out.println( r );
    }

	public Scanner in;

	public PrintWriter out;

	C() throws IOException {
		in = new Scanner( System.in );
		// in = new StreamTokenizer( new InputStreamReader( System.in ) );
		out = new PrintWriter( System.out );
	}

//    int nextInt() throws IOException {
//        in.nextToken();
//        return ( int ) in.nval;
//    }

    void check( boolean f, String msg ) {
        if ( ! f ) {
            out.close();
            throw new RuntimeException( msg );
        }
    }

    void close() throws IOException {
		out.close();
	}

	public void run() {
		try {
			solve();
			close();
		} catch ( Exception e ) {
            e.printStackTrace( out );
            out.flush();
            throw new RuntimeException( e );
		}
	}

	public static void main( String[] args ) throws IOException {
		new Thread( new C() ).start();
	}
}