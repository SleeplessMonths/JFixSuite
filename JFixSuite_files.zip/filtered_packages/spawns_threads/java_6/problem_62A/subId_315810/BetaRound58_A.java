package java_6.problem_62A.subId_315810;

import java.io.*;
import java.util.*;
import static java.lang.Math.*;

public class BetaRound58_A implements Runnable {

    final boolean ONLINE_JUDGE = System.getProperty("ONLINE_JUDGE") != null;
    BufferedReader in;
    PrintWriter out;
    StringTokenizer tok = new StringTokenizer("");

    void init() throws IOException {
        if (ONLINE_JUDGE) {
            in = new BufferedReader(new InputStreamReader(System.in));
            out = new PrintWriter(System.out);
        } else {
            in = new BufferedReader(new FileReader("input.txt"));
            out = new PrintWriter("output.txt");
        }
    }

    String readString() throws IOException {
        while (!tok.hasMoreTokens()) {
            tok = new StringTokenizer(in.readLine());
        }
        return tok.nextToken();
    }

    int readInt() throws IOException {
        return Integer.parseInt(readString());
    }

    @Override
    public void run() {
        try {
            long t1 = System.currentTimeMillis();
            init();
            solve();
            out.close();
            long t2 = System.currentTimeMillis();
            System.err.println("Time = " + (t2 - t1));
        } catch (Exception e) {
            e.printStackTrace(System.err);
            System.exit(-1);
        }
    }

    public static void main(String[] args) {
        new Thread(new BetaRound58_A()).start();
    }
    
    boolean can(int boy, int girl) {
        return boy - 1 <= girl && girl <= 2*boy + 2;
    }
    
    void solve() throws IOException {
        int g1 = readInt();
        int g2 = readInt();
        int b1 = readInt();
        int b2 = readInt();
        boolean ans = can(b1, g2) || can(b2, g1);
        out.print(ans ? "YES" : "NO");
    }

}