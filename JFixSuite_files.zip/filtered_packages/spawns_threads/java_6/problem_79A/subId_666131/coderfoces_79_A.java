package java_6.problem_79A.subId_666131;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.StringTokenizer;

public class coderfoces_79_A implements Runnable {

    private BufferedReader br = null;
    private PrintWriter pw = null;
    private StringTokenizer stk = new StringTokenizer("");

    public static void main(String[] lala) {
        (new Thread(new coderfoces_79_A())).run();
    }

    public void nline() {
        try {
            while (!stk.hasMoreTokens()) {
                stk = new StringTokenizer(br.readLine());
            }
        } catch (Throwable e) {
            throw new RuntimeException("I wanna be cousmonout", e);
        }

    }

    public String nstr() {
        nline();
        return stk.nextToken();
    }

    public int ni() {
        nline();
        return Integer.valueOf(nstr());
    }

    public double nd() {
        nline();
        return Double.valueOf(nstr());
    }

    public BigInteger nbi() {
        nline();
        return new BigInteger(nstr());
    }

    public void run() {

        br = new BufferedReader(new InputStreamReader(System.in));
        pw = new PrintWriter(System.out);

        solve();
        pw.close();
    }

    public void solve() {
        int n = ni(), m = ni();
        int p1 = 1, p2 = 0;
        while (true) {
            if (p1 == 1) {
                if (n >= 2 & m >= 2) {
                    n -= 2;
                    m -= 2;
                    p1 = 0;
                    p2 = 1;
                    continue;
                }

                if (n == 1 & m >= 12) {
                    n -= 1;
                    m -= 12;
                    p1 = 0;
                    p2 = 1;
                    continue;

                }
                if (n == 0 & m >= 22) {
                    m -= 22;
                    p1 = 0;
                    p2 = 1;
                    continue;

                }
                System.out.println("Hanako");
                exit();
            }
            if (p2 == 1) {
                if (m >= 22) {
                    m -= 22;
                    p1 = 1;
                    p2 = 0;
                    continue;
                }
                if (m >= 12 & n >= 2) {
                    m -= 12;
                    n -= 2;
                    p1 = 1;
                    p2 = 0;
                    continue;
                }
                if (m >= 2 & n >= 2) {
                    m -= 2;
                    n -= 2;
                    p1 = 1;
                    p2 = 0;
                    continue;
                }
                System.out.println("Ciel");
                exit();
            }
        }

    }

    public void exit() {
        System.exit(0);
    }
}