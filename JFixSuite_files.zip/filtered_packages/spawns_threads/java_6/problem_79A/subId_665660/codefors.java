package java_6.problem_79A.subId_665660;

import java.io.*;
import java.math.*;
import java.util.*;
import java.util.List;
import java.util.Queue;
import java.awt.*;

public class codefors implements Runnable {

    private BufferedReader br = null;
    private PrintWriter pw = null;
    private StringTokenizer stk = new StringTokenizer("");

    public static void main(String[] args) {
        new Thread(new codefors()).run();
    }

    public void run() {
        /*
         * try { // br = new BufferedReader(new FileReader("input.txt")); pw =
         * new PrintWriter("output.txt"); } catch (FileNotFoundException e) {
         * e.printStackTrace(); }
         */
        br = new BufferedReader(new InputStreamReader(System.in));
        pw = new PrintWriter(new OutputStreamWriter(System.out));
        solver();
        pw.close();

    }

    private void nline() {
        try {
            if (!stk.hasMoreTokens())
                stk = new StringTokenizer(br.readLine());
        } catch (IOException e) {
            throw new RuntimeException("KaVaBUnGO!!!", e);
        }
    }

    private String nstr() {
        while (!stk.hasMoreTokens())
            nline();
        return stk.nextToken();
    }

    private int ni() {
        return Integer.valueOf(nstr());

    }

    private double nd() {
        return Double.valueOf(nstr());

    }

    private BigInteger nbi() {
        return new BigInteger(nstr());
    }

    String nextLine() {
        try {
            return br.readLine();
        } catch (IOException e) {
        }
        return null;
    }

    private void solver() {
        int n = ni(), m = ni();

        int t = Math.min(n, m) / 4;
        n = n - t * 4;
        m = m - t * 4;

        int p1 = 1, p2 = 0;

        while (true) {
            if (p1 == 1) {
                if (n >= 2 && m >= 2) {
                    n -= 2;
                    m -= 2;
                    p1 = 0;
                    p2 = 1;
                    continue;
                }
                if (n == 1 && m >= 12) {
                    n -= 1;
                    m -= 12;
                    p1 = 0;
                    p2 = 1;
                    continue;
                }
                if (n == 0 && m >= 22) {
                    m -= 22;
                    p1 = 0;
                    p2 = 1;
                    continue;
                }
                System.out.println("Hanako");
                exit();

            }

            if (p2 == 1) {
                if (m >= 22) {
                    m -= 22;
                    p1 = 1;
                    p2 = 0;
                    continue;
                }
                if (m >= 12 && n >= 1) {
                    n -= 1;
                    m -= 12;
                    p1 = 1;
                    p2 = 0;
                    continue;
                }
                if (m >= 2 && n >= 2) {
                    n -= 2;
                    m -= 2;
                    p1 = 1;
                    p2 = 0;
                    continue;
                }
                System.out.println("Ciel");
                exit();

            }

        }

    }

    void exit() {
        System.exit(0);
    }
}