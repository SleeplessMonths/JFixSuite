package java_6.problem_42A.subId_199377;

import java.io.*;
import java.util.*;

public class Main implements Runnable {

	void solve() throws IOException {
		int n, V;
		
		n = nextInt(); V = nextInt();
		
		int[] a = new int[n];
		int Sa = 0;
		for(int i = 0; i < n; ++i) {
			a[i] = nextInt();
			Sa += a[i];
		}
		
		double r = (double)V;
		
		for(int i = 0; i < n; ++i) {
			int b = nextInt();
			double c = (double)b / (double)a[i];
			if(c < r)
				r = c;
		}
		
		output.println(r * Sa);
	}
	
	public void run() {
		try {
			input = new BufferedReader(new InputStreamReader(System.in));
			output = new PrintWriter(System.out);
			solve();
			input.close();
			output.close();
		} catch(Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
	
	BufferedReader input;
	PrintWriter output;
	StringTokenizer tok;
	
	String nextToken() throws IOException {
		while(tok == null || !tok.hasMoreElements())
			tok = new StringTokenizer(input.readLine());
		
		return tok.nextToken();
	}
	
	int nextInt() throws IOException {
		return Integer.valueOf(nextToken());
	}
	
	double nextDouble() throws IOException {
		return Double.valueOf(nextToken());
	}
	
	long nextLong() throws IOException {
		return Long.valueOf(nextToken());
	}
	
	public static void main(String[] args) {
		new Thread(new Main()).start();
	}
}