package java_6.problem_87C.subId_528141;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.*;
import static java.lang.Math.*;

public class Main extends Thread {
    public Main() {
        this.tokens = null;
        this.setPriority(Thread.MAX_PRIORITY);
        this.input = new BufferedReader(new InputStreamReader(System.in));
        this.output = new PrintWriter(System.out);
    }


    public void run() {
        try {
            int n = nextInt(), temp;
            int F[] = new int [n + 5];
            int was[] = new int [2 * n];
            int best[] = new int [n + 5];
            int min;
            if (n > 1000 && n % 2 == 0){
                output.println(-1);
                return;
            }
            Arrays.fill(best, Integer.MAX_VALUE);
            Arrays.fill(was, Integer.MIN_VALUE);
            for (int cur = 0; cur <= n; ++cur){
                for (int cnt = 2; cnt * (cnt + 1) / 2 <= cur; ++cnt){
                    int t = cnt * (cnt - 1) / 2;
                    if ((min = cur - t) % cnt != 0){
                        continue;
                    }
                    min /= cnt;
                    int curF = 0;
                    curF = F[min + cnt -1] ^ F[min - 1];
                    if (curF == 0){
                        best[cur] = min(best[cur], cnt);
                    }
                    was[curF] = cur;
                }
                temp = 0;
                while (was[temp] == cur){
                    ++temp;
                }
                F[cur] = temp;
                if (cur != 0){
                    F[cur] ^= F[cur - 1];
                }
            }
            output.println((best[n] == Integer.MAX_VALUE )? "-1" : best[n]);
            output.flush();
            output.close();

        } catch (Throwable e) {
            System.err.println(e.getMessage());
            System.err.println(Arrays.deepToString(e.getStackTrace()));
        }
    }


    public static void main(String[] args) {
        new Main().start();
    }


    private String nextToken() throws IOException {
        while (tokens == null || !tokens.hasMoreTokens()) {
            tokens = new StringTokenizer(input.readLine());
        }
        return tokens.nextToken();
    }
    private int nextInt() throws IOException {
        return Integer.parseInt(nextToken());
    }
    private long nextLong() throws IOException{
        return Long.parseLong(nextToken());
    }
    private double nextDouble() throws IOException{
        return Double.parseDouble(nextToken());
    }

    private BufferedReader input;
    private PrintWriter output;
    private StringTokenizer tokens;
}