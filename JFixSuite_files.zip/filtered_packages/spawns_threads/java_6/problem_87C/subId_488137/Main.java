package java_6.problem_87C.subId_488137;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;
import java.util.Set;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.TreeSet;

import static java.lang.Double.*;
import static java.math.BigInteger.*;
import static java.lang.Math.*;
import static java.util.Arrays.*;
import static java.util.Collections.*;

public class Main implements Runnable {

	// private long start;

	private void solve() throws IOException {
		// start = System.currentTimeMillis();
		init();
		readData();
		processing();
	}
	
	private void init() {
	}
	
	HashSet<Integer> si = new HashSet<Integer>();
	
	private int mex(List<Integer> lst) {
		si.clear();
		si.addAll(lst);
		int ret = 0;
		while (si.contains(ret)) {
			++ret;
		}
		return ret;
	}
	
	private void processing() {
		nim = new int[100001];
		nim[0] = 0;
		nim[1] = 0;
		nim[2] = 0;
		nim[3] = 1;
		List<Integer> fg = new ArrayList<Integer>();
		int[] firstTurn = new int[100001];
		firstTurn[3] = 2;
		for (int i = 4; i < 100001; ++i) {
			fg.clear();
			int memo = -1;
			for (int j = 2; j*j < i; ++j) {
				if (2*i%j == 0) {
					int n = 2*i/j - 1 + j;
					if (n%2 == 0) {
						n /= 2;
						if (n - j + 1 > 0) {
							int xor = 0;
							for (int l = n; l >= n - j + 1; --l) {
								xor ^= nim[l];
							}
							if (xor == 0 && memo == -1) {
								memo = j;
							}
							fg.add(xor);
						}
					}
				}
			}
			nim[i] = mex(fg);
			firstTurn[i] = memo;
		}
		if (nim[nn] == 0) {
			println(-1);
		}
		else {
			println(firstTurn[nn]);
		}
	}

	private void readData() throws IOException {
		nn = nextInt();
	}

	private int nn;
	
	private int[] nim;
	
	public static void main(String[] args) throws InterruptedException {
		new Thread(null, new Runnable() {
			public void run() {
				new Main().run();
			}
		}, "1", 1 << 24).start();
	}

	// @Override
	public void run() {
		try {
			boolean onlineJudge = System.getProperty("ONLINE_JUDGE") != null;
			reader = onlineJudge ? new BufferedReader(new InputStreamReader(
					System.in)) : new BufferedReader(
					new FileReader("input.txt"));
			writer = onlineJudge ? new PrintWriter(new BufferedWriter(
					new OutputStreamWriter(System.out))) : new PrintWriter(
					new BufferedWriter(new FileWriter("output.txt")));
			Locale.setDefault(Locale.US);
			tokenizer = null;
			solve();
			writer.flush();
		} catch (Exception error) {
			error.printStackTrace();
			System.exit(1);
		}
	}

	class InputReader {

		public InputReader(InputStream stream) {
			this.stream = stream;
		}

		public int read() {
			if (numChars == -1)
				throw new InputMismatchException();
			if (curChar >= numChars) {
				curChar = 0;
				try {
					numChars = stream.read(buf);
				} catch (IOException e) {
					throw new InputMismatchException();
				}
				if (numChars <= 0)
					return -1;
			}
			return buf[curChar++];
		}

		public int readInt() {
			int c = read();
			while (isSpaceChar(c))
				c = read();
			int sgn = 1;
			if (c == '-') {
				sgn = -1;
				c = read();
			}
			int res = 0;
			do {
				if (c < '0' || c > '9')
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = read();
			} while (!isSpaceChar(c));
			return res * sgn;
		}

		public long readLong() {
			int c = read();
			while (isSpaceChar(c))
				c = read();
			int sgn = 1;
			if (c == '-') {
				sgn = -1;
				c = read();
			}
			long res = 0;
			do {
				if (c < '0' || c > '9')
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = read();
			} while (!isSpaceChar(c));
			return res * sgn;
		}

		public String readString() {
			int c = read();
			while (isSpaceChar(c))
				c = read();
			StringBuffer res = new StringBuffer();
			do {
				res.appendCodePoint(c);
				c = read();
			} while (!isSpaceChar(c));
			return res.toString();
		}

		private boolean isSpaceChar(int c) {
			return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
		}

		private String readLine0() {
			StringBuffer buf = new StringBuffer();
			int c = read();
			while (c != '\n' && c != -1) {
				if (c != '\r')
					buf.appendCodePoint(c);
				c = read();
			}
			return buf.toString();
		}

		public String readLine() {
			String s = readLine0();
			while (s.trim().length() == 0)
				s = readLine0();
			return s;
		}

		public String readLine(boolean ignoreEmptyLines) {
			if (ignoreEmptyLines)
				return readLine();
			else
				return readLine0();
		}

		public char readCharacter() {
			int c = read();
			while (isSpaceChar(c))
				c = read();
			return (char) c;
		}

		public double readDouble() {
			int c = read();
			while (isSpaceChar(c))
				c = read();
			int sgn = 1;
			if (c == '-') {
				sgn = -1;
				c = read();
			}
			double res = 0;
			while (!isSpaceChar(c) && c != '.') {
				if (c == 'e' || c == 'E')
					return res * Math.pow(10, readInt());
				if (c < '0' || c > '9')
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = read();
			}
			if (c == '.') {
				c = read();
				double m = 1;
				while (!isSpaceChar(c)) {
					if (c == 'e' || c == 'E')
						return res * Math.pow(10, readInt());
					if (c < '0' || c > '9')
						throw new InputMismatchException();
					m /= 10;
					res += (c - '0') * m;
					c = read();
				}
			}
			return res * sgn;
		}

		private InputStream stream;
		private byte[] buf = new byte[1 << 16];
		private int curChar;
		private int numChars;
	}

	private class Parser {

		public Parser(InputStream in) {
			din = new DataInputStream(in);
			buffer = new byte[BUFFER_SIZE];
			bufferPointer = bytesRead = 0;
		}

		public byte c;

		public int nextInt() throws IOException {
			int value = 0;
			c = read();
			while (c <= ' ')
				c = read();
			boolean neg = c == '-';
			if (neg)
				c = read();
			do {
				value = value * 10 + c - 48;
				c = read();
			} while (c > ' ');
			if (neg) {
				return -value;
			} else {
				return value;
			}
		}

		private void fillBuffer() throws IOException {
			bytesRead = din.read(buffer, bufferPointer = 0, BUFFER_SIZE);
			if (bytesRead == -1)
				buffer[0] = -1;
		}

		public byte read() throws IOException {
			if (bufferPointer == bytesRead)
				fillBuffer();
			return buffer[bufferPointer++];
		}

		private DataInputStream din;
		private byte[] buffer;
		private int bufferPointer, bytesRead;

		final private int BUFFER_SIZE = 1 << 16;
	}

	private BufferedReader reader;
	private PrintWriter writer;
	private StringTokenizer tokenizer;

	private void println() {
		writer.println();
	}

	private void print(Object obj) {
		writer.print(obj);
	}

	private void println(Object obj) {
		writer.println(obj);
	}

	private void printf(String f, Object... obj) {
		writer.printf(f, obj);
	}

	private int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	private long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	private double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	private String nextToken() throws IOException {
		while (tokenizer == null || !tokenizer.hasMoreTokens()) {
			tokenizer = new StringTokenizer(reader.readLine());
		}
		return tokenizer.nextToken();
	}
}