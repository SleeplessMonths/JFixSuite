package java_6.problem_74B.subId_406980;

import java.io.*;
import java.util.*;
import static java.lang.Math.*;
import static java.util.Arrays.fill;
import static java.util.Arrays.binarySearch;
import static java.util.Arrays.sort;

public class Main {
	public static void main(String[] args) throws IOException {
		new Thread(null, new Runnable() {
			public void run() {
				try {
					try {
						if (new File("input.txt").exists())
							System.setIn(new FileInputStream("input.txt"));
					} catch (SecurityException e) {}
					new Main().run();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}, "1", 1L << 24).start(); 
	}

	BufferedReader in;
	PrintWriter out;
	StringTokenizer st = new StringTokenizer("");
	
	void run() throws IOException {
		in = new BufferedReader(new InputStreamReader(System.in));
		out = new PrintWriter(System.out);
		
		int n = nextInt();
		int m = nextInt();
		int k = nextInt();
		nextToken();
		boolean toHead = nextToken().equals("head");
		char[] seq = nextToken().toCharArray();
		
		int t = -1;
		int x = 0;
		for (char c : seq) {
			x++;
			if (c == '0') {
				m = max(1, min(n, m + (m < k ? -1 : 1)));
				if (k == 1 && toHead || k == n && !toHead) toHead = !toHead;
				k += toHead ? -1 : 1;
				if (k == m) { t = x; break; } 
			} else {
				if (k == 1 && toHead || k == n && !toHead) toHead = !toHead;
				k += toHead ? -1 : 1;
				if (k - 1 > n - k)
					m = 1;
				else
					m = n;
				if (k == m) { t = x; break; }
			}
		}
		out.println(t == -1 ? "Stowaway" : ("Controller " + t));
			
		
		out.close();
	}
	
	
	/*************************************************************** 
	 * Input 
	 **************************************************************/
	String nextToken() throws IOException {
		while (!st.hasMoreTokens())
			st = new StringTokenizer(in.readLine());
		return st.nextToken();
	}
	
	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}
	
	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}
	
	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}
	
	String nextLine() throws IOException {
		st = new StringTokenizer("");
		return in.readLine();
	}
	
	boolean EOF() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = in.readLine();
			if (s == null)
				return true;
			st = new StringTokenizer(s);
		}
		return false;
	}
}