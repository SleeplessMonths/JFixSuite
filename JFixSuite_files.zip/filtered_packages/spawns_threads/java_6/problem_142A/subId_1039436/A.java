package java_6.problem_142A.subId_1039436;

import java.awt.Point;
import java.io.*;
import java.math.BigInteger;
import java.util.*;

import static java.lang.Math.*;

public class A implements Runnable{
    
    final boolean ONLINE_JUDGE = System.getProperty("ONLINE_JUDGE") != null;
    
    BufferedReader in;
    PrintWriter out;
    StringTokenizer tok = new StringTokenizer("");
    
    void init() throws FileNotFoundException{
        if (ONLINE_JUDGE){
            in = new BufferedReader(new InputStreamReader(System.in));
            out = new PrintWriter(System.out);
        }else{
            in = new BufferedReader(new FileReader("input.txt"));
            out = new PrintWriter("output.txt");
        }
    }
    
    String readString() throws IOException{
        while(!tok.hasMoreTokens()){
            try{
                tok = new StringTokenizer(in.readLine());
            }catch (Exception e){
                return null;
            }
        }
        return tok.nextToken();
    }
    
    int readInt() throws IOException{
        return Integer.parseInt(readString());
    }
    
    long readLong() throws IOException{
        return Long.parseLong(readString());
    }
    
    double readDouble() throws IOException{
        return Double.parseDouble(readString());
    }
    
    public static void main(String[] args){
        new Thread(null, new A(), "", 256 * (1L << 20)).start();
    }
    
    long timeBegin, timeEnd;

    void time(){
        timeEnd = System.currentTimeMillis();
        System.err.println("Time = " + (timeEnd - timeBegin));
    }
    
    long memoryTotal, memoryFree;
    

    void memory(){
        memoryFree = Runtime.getRuntime().freeMemory();
        System.err.println("Memory = " + ((memoryTotal - memoryFree) >> 10) + " KB");
    }
    
    void debug(Object... objects){
        if (DEBUG){
            for (Object o: objects){
                System.err.println(o.toString());
            }
        }
    }
    
    public void run(){
        try{
            timeBegin = System.currentTimeMillis();
            memoryTotal = Runtime.getRuntime().totalMemory();
            init();
            solve();
            out.close();
            time();
            memory();
        }catch (Exception e){
            e.printStackTrace(System.err);
            System.exit(-1);
        }
    }
    
    boolean DEBUG = false;
    
    void solve() throws IOException{
        long n = readLong();
        
        long max = 0, min = Integer.MAX_VALUE;
        
        ArrayList<Integer> list = new ArrayList<Integer>();
        
        for (int i = 1; i * i <= n; i++){
            if (n % i == 0){
                list.add(i);
                if (i * i != n){
                    list.add((int) n / i);
                }
            }
        }
        
        Collections.sort(list);
        
        int len = list.size();
        
        for (int i = 0; i < len; i++){
            long a = list.get(i);
            long x = n / a;
            for (int j = 1; j * j <= x; j++){
                long b = j;
                if(x % b == 0){
                    long c = x / b;
                    long count = (a + 1) * (b + 2) * (c + 2) - n;
                    
                    max = max(max, count);
                    min = min(min, count);
                    if (j * j != x){
                        b = x / j;
                        c = n / a / b;
                        count = (a + 1) * (b + 2) * (c + 2) - n;
                        
                        max = max(max, count);
                        min = min(min, count);
                    }
                }
                
                    
            }
        }
        
        out.print(min + " " + max);
    }
}