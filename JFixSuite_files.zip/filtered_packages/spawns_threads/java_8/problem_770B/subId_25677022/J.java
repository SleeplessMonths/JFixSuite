package java_8.problem_770B.subId_25677022;

import java.io.*;
import java.util.*;
import java.util.stream.Collector;

public class J implements Runnable {

    private static final boolean ONLINE_JUDGE = System.getProperty("ONLINE_JUDGE") != null;

    private BufferedReader in;
    private PrintWriter out;
    private StringTokenizer tok = new StringTokenizer("");

    private void init() throws FileNotFoundException {
        Locale.setDefault(Locale.US);
        String fileName = "";
        if (ONLINE_JUDGE && fileName.isEmpty()) {
            in = new BufferedReader(new InputStreamReader(System.in));
            out = new PrintWriter(System.out);
        } else {
            if (fileName.isEmpty()) {
                in = new BufferedReader(new FileReader("input.txt"));
                out = new PrintWriter("output.txt");
            } else {
                in = new BufferedReader(new FileReader(fileName + ".in"));
                out = new PrintWriter(fileName + ".out");
            }
        }
    }

    String readString() throws IOException {
        while (!tok.hasMoreTokens()) {
            tok = new StringTokenizer(in.readLine());

        }
        return tok.nextToken();
    }

    int readInt() throws IOException {
        return Integer.parseInt(readString());
    }

    long readLong() throws IOException {
        return Long.parseLong(readString());
    }

    double readDouble() throws IOException {
        return Double.parseDouble(readString());
    }

    int[] readIntArray(int size) throws IOException {
        int[] a = new int[size];
        for (int i = 0; i < size; i++) {
            a[i] = readInt();
        }
        return a;
    }

    public static void main(String[] args) {
        //new Thread(null, new _Solution(), "", 128 * (1L << 20)).start();
        new J().run();
    }

    long timeBegin, timeEnd;

    void time() {
        timeEnd = System.currentTimeMillis();
        System.err.println("Time = " + (timeEnd - timeBegin));
    }

    @Override
    public void run() {
        try {
            timeBegin = System.currentTimeMillis();
            init();
            solve();
            out.close();
            time();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }
    }

    String now = "";

    void update(String s) {
        if (s.charAt(0) == '0') return;
        if (calc(now) < calc(s)) {
            now = s;
        }
    }

    int calc(String s) {
        int res = 0;
        for (char x : s.toCharArray()) {
            res += x - '0';
        }
        return res;
    }

    void brut(int pos, String x, String target, boolean alreadyLower) {
        if (pos == target.length()) {
            update(x);
            return;
        }
        if (alreadyLower) {
            brut(pos + 1, x + "9", target, true);
            return;
        }
        brut(pos + 1, x + target.charAt(pos), target, false);
        if (target.charAt(pos) != '0') {
            brut(pos + 1, x + (char)(target.charAt(pos) - 1), target, true);
        }
    }

    private void solve() throws IOException {
        String s = readString();
        if (s.length() == 1) {
            out.println(s);
            return;
        }
        while (now.length() + 1 < s.length()) now += "9";
        brut(0, "", s, false);
        out.println(now);
    }

}