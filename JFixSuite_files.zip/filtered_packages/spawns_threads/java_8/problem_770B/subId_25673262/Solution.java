package java_8.problem_770B.subId_25673262;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

public class Solution implements Runnable {
  BufferedReader in;
  PrintWriter out;
  StringTokenizer tok = new StringTokenizer("");

  @Override
  public void run() {
    try {
      init();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    long time = System.currentTimeMillis();
    try {
      solve();
    } catch (Exception e) {
      e.printStackTrace();
      System.exit(-1);
    }
    out.close();
    //System.err.println(System.currentTimeMillis() - time);
  }

  private void init() throws FileNotFoundException {
    String file = "";
    if (!file.equals("")) {
      in = new BufferedReader(new FileReader("road.in"));
      out = new PrintWriter("road.out");
    } else {
      in = new BufferedReader(new InputStreamReader(System.in));
      out = new PrintWriter(System.out);
    }
  }

  public static void main(String[] args) {
    new Thread(new Solution()).start();
  }

  private String readString() {
    while (!tok.hasMoreTokens()) {
      try {
        tok = new StringTokenizer(in.readLine());
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    return tok.nextToken();
  }

  private int readInt() {
    return Integer.parseInt(readString());
  }

  private long readLong() {
    return Long.parseLong(readString());
  }

  private double readDouble() {
    return Double.parseDouble(readString());
  }

  private void solve() throws IOException {
    char[] ar = readString().toCharArray();
    int sum = 0;
    StringBuilder ans = new StringBuilder();
    for (int i = 0; i < ar.length; i++) {
      sum += (ar[i] - '0');
      ans.append(ar[i]);
    }

    for (int i = ar.length - 2; i >= 0; i--) {
      if(ar[i]=='0') continue;
      ar[i]--;
      int currSum = 0;
      StringBuilder currAns = new StringBuilder();
      for (int j = 0; j <= i; j++) {
        currSum += (ar[i]-'0');
        currAns.append(ar[i]);
      }
      for(int j=i+1; j<ar.length; j++) {
        currSum += 9;
        currAns.append('9');
      }
      if(currSum > sum) {
        sum = currSum;
        ans = currAns;
      }

      ar[i]++;
    }
    int start = 0;
    for (int i = 0; i < ans.length(); i++) {
      if(ans.charAt(i)=='0') start++;
      else break;
    }
    for (int i = start ; i<ans.length(); i++) {
      out.print(ans.charAt(i));
    }
  }


}