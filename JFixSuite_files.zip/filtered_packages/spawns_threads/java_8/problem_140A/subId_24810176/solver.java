package java_8.problem_140A.subId_24810176;

import java.awt.Point;
import java.io.*;
import java.math.BigInteger;
import java.util.*;

import static java.lang.Math.*;

public class solver implements Runnable {

    BufferedReader in;
    PrintWriter out;
    StringTokenizer tok = new StringTokenizer("");

    void init() throws FileNotFoundException {
        in = new BufferedReader(new InputStreamReader(System.in));
        out = new PrintWriter(System.out);
    }

    String readString() {
        try {
            while (!tok.hasMoreTokens()) {
                try {
                    tok = new StringTokenizer(in.readLine());
                } catch (Exception e) {
                    return null;
                }
            }
            return tok.nextToken();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    int readInt() {
        return Integer.parseInt(readString());
    }

    long readLong() {
        return Long.parseLong(readString());
    }

    double readDouble() {
        return Double.parseDouble(readString());
    }

    public static void main(String[] args) {
        new Thread(null, new solver(), "", 256 * (1L << 20)).start();
    }

    long timeBegin, timeEnd;

    void time() {
        timeEnd = System.currentTimeMillis();
        System.err.println("Time = " + (timeEnd - timeBegin));
    }

    public void run() {
        try {
            timeBegin = System.currentTimeMillis();
            init();
            solve();
            out.close();
            // time();
        } catch (Exception e) {
            e.printStackTrace(System.err);
            System.exit(-1);
        }
    }
    
    int cntm(int[] a, int x) {
        int l = 0;
        int r = a.length - 1;
        int ans = -1;
        while (l <= r) {
            int mid = (l + r) / 2;
            if (a[mid] > x) {
                r = mid - 1;
            } else {
                ans = mid;
                l = mid + 1;
            }
        }
        return ans + 1;
    }

    void no() {
        out.println("NO");
        out.close();
        System.exit(0);
    }
    
    void yes() {
        out.println("YES");
        out.close();
        System.exit(0);
    }
    
    void solve() {
        int n = readInt();
        int R = readInt();
        int r = readInt();
        
        if (R < r) no();
        if (n == 1) {if (R < r) no(); else yes();}
        double sector = Math.asin((double)r / (R - r)) * 2;
        double all = n * sector;
        if (all < 2 * Math.PI) 
            yes();
        else
            no();
    }
}