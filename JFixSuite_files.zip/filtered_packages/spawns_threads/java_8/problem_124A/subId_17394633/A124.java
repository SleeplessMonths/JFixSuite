package java_8.problem_124A.subId_17394633;

import java.util.*;
import java.io.PrintWriter;

public class A124 implements Runnable {
	private Scanner in = new Scanner(System.in);
	private PrintWriter out = new PrintWriter(System.out);
	private int n;
	private int a;
	private int b;
	
	private int ans;
	
	public static void main(String[] args) {
		new Thread(new A124()).start();
	}

	private void read() {
		n = in.nextInt();
		a = in.nextInt();
		b = in.nextInt();
		
	}

	private void solve() {

		ans = n - a;

	}

	

	private void write() {

		out.println(ans);
		
	}


	public void run() {
		read();
		solve();
		write();
		out.close();
	} 
}