package java_8.problem_118A.subId_29038602;

import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Queue;
import java.util.Scanner;

import static com.sun.jmx.snmp.ThreadContext.contains;
import static com.sun.jmx.snmp.ThreadContext.push;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static PrintWriter out = new PrintWriter(System.out);

    public static void solve() {
    String s = sc.next();
    String res = "";
        for (int i = 0; i < s.length(); i++) {
            if(s.charAt(i) == 'A' || s.charAt(i) == 'O' || s.charAt(i) == 'Y' || s.charAt(i) == 'E' || s.charAt(i) == 'U' || s.charAt(i) == 'I' ||
            s.charAt(i) == 'a' || s.charAt(i) == 'o' || s.charAt(i) == 'y' || s.charAt(i) == 'e' || s.charAt(i) == 'u' || s.charAt(i) == 'i'){

            } else if(s.charAt(i) < 90){
                res = res + "." + (char) (s.charAt(i) + 32);
            } else{
                res = res + "." + s.charAt(i);
            }
        }
        out.print(res);
    }


    public static void main(String[] args) {
        solve();
        out.flush();
    }
}