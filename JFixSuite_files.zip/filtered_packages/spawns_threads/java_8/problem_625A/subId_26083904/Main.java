package java_8.problem_625A.subId_26083904;

import java.io.*;
     
        import java.math.BigInteger;
    import java.text.DecimalFormat;
    import java.util.*;
     
    //import Submatrix.InputReader;
         
         
         
         public class Main {
        	public static InputReader in;
            public static PrintWriter pw;
         
         
         
        	public static void main(String args[]) {
        		new Thread(null, new Runnable() {
                    public void run() {
                        try{
                            solve();
                        }
                        catch(Exception e){
                            e.printStackTrace();
                        }
                    }
                }, "1", 1 << 26).start();
            }
        	static ArrayList<Integer> g[];
        	static ArrayList<Integer> h[];
        	static boolean visited[];
        	static boolean visit[];
        	static int par[];
        	static int degree[];
        	static int edjes=0;
        	static int start=-1;
        	static int end=-1;
        	static int Total=0;
        	static int time1[];
        	static int time2[];
        	static int glob=0;
        	static long ans[]=new long[1000000];
        	static boolean vis2[][];
        	//static long sum1=0;
        	//static long val[];
            static ArrayList<Integer> levels[];
            static int max=0;
            static int lev=1;
            static ArrayList<Integer> nodes[];
            static ArrayList<Integer> values[];
            static int depth[];
            static boolean found=false;
           // static long sm[];
            static int sum1=0;
            static int pre[][];
            static int subtree[];
           static  int cnt=0;
           static  HashMap<String,Integer> hm;
           static int sm[];
           static int prime[];
           static long mul[];
           static long d[]=new long[1000000];
           static int tot=0;
           static long highest=(long)1e9;
           static int count=0;
            static Stack<Integer> tt=new Stack();
            static long Cardinality[];
            static int k;
            public static void solve(){
        		
        	
        		 in = new InputReader(System.in);
        		 pw = new PrintWriter(System.out);
                 long n=in.nextLong();
                 long a=in.nextLong();
                 long b=in.nextLong();
                 long c=in.nextLong();
                 long ans=0;
                 if(a<b)
                 {
                	 long x=n/a;
                	 n-=(x*a);
                	 ans=x;
                 }
                 long ans1=0;
                 while(n>0)
                 {
                 long x=(n/b);
                 if(x==0)
                	 break;
                 ans+=x;
                 n-=(x*b);
                 n+=(x*c);
                 }
                 ans1+=(n/a);
                 System.out.println(Math.max(ans, ans1));
            }

             static class Pair implements Comparable<Pair>{
            	int now;
            		int aft;
            		//int index;
            		Pair(int ver,int weight){
            	     	this.now=ver;
            			this.aft=weight;
            			//this.index=index;
            			
            		}
            		@Override
            		public int compareTo(Pair o) {
                            
            				return (int)(o.now-now);
            		}
            				
            	}
        	static class InputReader {
         
        		private InputStream stream;
        		private byte[] buf = new byte[8192];
        		private int curChar, snumChars;
        		private SpaceCharFilter filter;
         
        		public InputReader(InputStream stream) {
        			this.stream = stream;
        		}
         
        		public int snext() {
        			if (snumChars == -1)
        				throw new InputMismatchException();
        			if (curChar >= snumChars) {
        				curChar = 0;
        				try {
        					snumChars = stream.read(buf);
        				} catch (IOException e) {
        					throw new InputMismatchException();
        				}
        				if (snumChars <= 0)
        					return -1;
        			}
        			return buf[curChar++];
        		}
         
        		public   int nextInt() {
        			int c = snext();
        			while (isSpaceChar(c))
        				c = snext();
        			int sgn = 1;
        			if (c == '-') {
        				sgn = -1;
        				c = snext();
        			}
        			int res = 0;
        			do {
        				if (c < '0' || c > '9')
        					throw new InputMismatchException();
        				res *= 10;
        				res += c - '0';
        				c = snext();
        			} while (!isSpaceChar(c));
        			return res * sgn;
        		}
         
        		public long nextLong() {
        			int c = snext();
        			while (isSpaceChar(c))
        				c = snext();
        			int sgn = 1;
        			if (c == '-') {
        				sgn = -1;
        				c = snext();
        			}
        			long res = 0;
        			do {
        				if (c < '0' || c > '9')
        					throw new InputMismatchException();
        				res *= 10;
        				res += c - '0';
        				c = snext();
        			} while (!isSpaceChar(c));
        			return res * sgn;
        		}
         
        		public int[] nextIntArray(int n) {
        			int a[] = new int[n];
        			for (int i = 0; i < n; i++)
        				a[i] = nextInt();
        			return a;
        		}
         
        		public String readString() {
        			int c = snext();
        			while (isSpaceChar(c))
        				c = snext();
        			StringBuilder res = new StringBuilder();
        			do {
        				res.appendCodePoint(c);
        				c = snext();
        			} while (!isSpaceChar(c));
        			return res.toString();
        		}
         
        		public boolean isSpaceChar(int c) {
        			if (filter != null)
        				return filter.isSpaceChar(c);
        			return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
        		}
         
        		public interface SpaceCharFilter {
        			public boolean isSpaceChar(int ch);
        		}
        	}
        }