package java_8.problem_611A.subId_19783917;

import java.io.*;
import java.math.BigInteger;
import java.util.*;

public class Codeforces implements Runnable {
    private BufferedReader br = null;
    private PrintWriter pw = null;
    private StringTokenizer stk = new StringTokenizer("");

    public static void main(String[] args) {
        new Thread(new Codeforces()).run();
    }

    public void run() {
        br = new BufferedReader(new InputStreamReader(System.in));
        pw = new PrintWriter(new OutputStreamWriter(System.out));
        /*try {
            pw = new PrintWriter("output.txt");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }*/
        solver();
        pw.close();
    }

    private void nline() {
        try {
            if (!stk.hasMoreTokens()) {
                stk = new StringTokenizer(br.readLine());
            }
        } catch (IOException e) {
            throw new RuntimeException("KaVaBUnGO!!!", e);
        }
    }

    private String nstr() {
        while (!stk.hasMoreTokens()) {
            nline();
        }
        return stk.nextToken();
    }

    private int ni() {
        return Integer.valueOf(nstr());
    }

    private long nl() {
        return Long.valueOf(nstr());
    }

    private double nd() {
        return Double.valueOf(nstr());
    }

    private BigInteger nbi() {
        return new BigInteger(nstr());
    }

    String nextLine() {
        try {
            return br.readLine();
        } catch (IOException e) {
        }
        return null;
    }

    private void solver() {
        int k = ni();
        nstr();
        int monthHash[] = new int[32];
        int weekHash[] = new int[8];
        Calendar cal = GregorianCalendar.getInstance();
        cal.set(2016, 0, 1);
        while (cal.get(Calendar.YEAR) != 2017) {
            monthHash[cal.get(Calendar.DAY_OF_MONTH)]++;
            weekHash[cal.get(Calendar.DAY_OF_WEEK)]++;
            cal.add(Calendar.DATE, 1);
        }
        if (nstr().equals("month")){
            System.out.println(monthHash[k]);
        } else {
            System.out.println(weekHash[k]);
        }
    }

    private void bad() {
        System.out.println("No");
        exit();
    }

    private void good() {
        System.out.println("Yes");
        exit();
    }

    void exit() {
        pw.close();
        System.exit(0);
    }
}