package java_8.problem_741D.subId_22857604;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.StringTokenizer;
import java.util.List;
import java.util.ArrayList;

public class D {
	public static void main(String[] args) {
		/*try {
			//InputReader in = new InputReader(new File("test.inp"));
			//PrintWriter out = new PrintWriter(new File("test.out"));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}*/
		Thread thread = new Thread(null, null, "task", Runtime.getRuntime().maxMemory()) {
			public void run() {
				//try {
					InputStream inputStream = System.in;					
					InputReader in = new InputReader(inputStream);
					OutputStream outputStream = System.out;
					PrintWriter out = new PrintWriter(outputStream);
					//InputReader in = new InputReader(new File("test.inp"));
					//PrintWriter out = new PrintWriter(new File("test.out"));
					Task solver = new Task();
					solver.solve(in,out);
					out.close();
				//} catch (Exception e) {
				//	throw new RuntimeException(e);
				//}
				
			}
		};
		try {
			thread.run();
			thread.join();
		} catch (Exception e) {
			throw (new RuntimeException(e));
		}
	}
	
	static class Task {
		static int MAXN = 500005;
		static int MAXM = 5000006;
		class Edge {
			public int v, c;
			Edge(int _v, int _c) {
				v = _v;
				c = _c;
			}	
		}
		class MyAns {
			public int res;
			MyAns() { 
				res = 0;
			}
			MyAns(int v) {
				res = v;
			}
			void getMax(int v) {
				res = Math.max(res, v);
			}
		}
		
		int n;
		List <Edge> ke[] = new ArrayList[MAXN];
		int sz[] = new int[MAXN];
		int mask[] = new int[MAXN];
		int f[] = new int[MAXM];
		int h[] = new int[MAXN];
		int kq[] = new int[MAXN];
		
		void nhap(InputReader in) {
			n = in.readInt();
			for(int i=1; i<=n; i++)
				ke[i] = new ArrayList <Edge> ();
			for(int u=2; u<=n; u++) {
				int cha = in.readInt();
				String c = in.next();
				ke[cha].add(new Edge(u, c.charAt(0) - 'a'));
			}
		}
		
		public void solve(InputReader in, PrintWriter out) {
			nhap(in);
			for(int i=1; i<=n; i++) {
				f[i] = (int)(-1e9);
			}
			h[1] = 0;
			mask[1] = 0;
			dfsCallSize(1);
			dfs(1, true);
			for(int i=1; i<=n; i++)
				out.print(kq[i] + " ");
		}
		
		void dfsCallSize(int u) {
			sz[u] = 1;
			for(Edge e : ke[u]) {
				mask[e.v] = mask[u] ^ (1 << e.c);
				h[e.v] = h[u] + 1;
				dfsCallSize(e.v);
				sz[u] += sz[e.v];
			}
		}
		
		void add(int u) {
			f[mask[u]] = Math.max(f[mask[u]], h[u]);
			for(Edge e : ke[u])
				add(e.v);
		}
		
		int batBit(int u, int j) {
			return (u | (1 << j));
		}
		
		int tatBit(int u, int j) {
			return (u & (~ (1 << j)));
		}
		
		void UpdateAns(int u, int root, MyAns ans) {
			for(int j=0; j<22; j++) {
				int nmask = batBit(mask[u], j);
				ans.getMax(h[u] + f[nmask] - 2 * h[root]);
				nmask = tatBit(mask[u], j);
				ans.getMax(h[u] + f[nmask] - 2 * h[root]);
			}
			for(Edge e : ke[u]) {
				UpdateAns(e.v, root, ans);
			}
		}
		
		void clear(int u) {
			f[mask[u]] = (int)(-1e9);
			for(Edge e : ke[u])
				clear(e.v);
		}
		
		void dfs(int u, boolean keep) {
			//System.out.println(mask[u]);
			int bigChild = -1, mChild = 0;
			for(Edge e : ke[u]) {
				if (sz[e.v] > mChild) {
					bigChild = e.v;
					mChild = sz[e.v];
				}
			}
			for(Edge e : ke[u]) {
				if (e.v != bigChild)
					dfs(e.v, false);
			}
			if (bigChild != -1) {
				dfs(bigChild, true);
			}
			MyAns res = new MyAns((int)(-1e9));
			for(Edge e : ke[u]) 
			if (e.v != bigChild) {
				UpdateAns(e.v, u, res);
				add(e.v);
			}
			f[mask[u]] = Math.max(f[mask[u]], h[u]);
			for(int j=0; j<22; j++) {
				int nmask = batBit(mask[u], j);
				res.getMax(f[nmask] - h[u]);
				nmask = tatBit(mask[u], j);
				res.getMax(f[nmask] - h[u]);
			}
			kq[u] = res.res;
			for(Edge e : ke[u]) 
				kq[u] = Math.max(kq[u], kq[e.v]);
			if (!keep)
				clear(u);
		}
	}
	
	static class InputReader {
		BufferedReader reader;
		StringTokenizer tokenizer;
		
		public InputReader(InputStream stream) {
			reader = new BufferedReader(new InputStreamReader(stream), 32768);
			tokenizer = null;
		}
		
		public InputReader(File f) {
			try {
				reader = new BufferedReader(new FileReader(f));
			} catch (FileNotFoundException e) {
				throw new RuntimeException(e);
			}
		}
		
		public String next() {
			while (tokenizer == null || !tokenizer.hasMoreTokens()) {
				try {
					tokenizer = new StringTokenizer(reader.readLine());
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}
			return tokenizer.nextToken();
		}
		
		public int readInt() {
			return Integer.parseInt(next());
		}
		
		public long readLong() {
			return Long.parseLong(next());
		}
		
		public double readDouble() {
			return Double.parseDouble(next());
		}
		
		String readln() {
			String s = "";
			try {
				s = reader.readLine();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
			return s;
		}
	}
}