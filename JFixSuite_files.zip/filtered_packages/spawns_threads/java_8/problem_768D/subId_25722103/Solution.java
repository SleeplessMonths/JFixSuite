package java_8.problem_768D.subId_25722103;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

public class Solution implements Runnable {
  BufferedReader in;
  PrintWriter out;
  StringTokenizer tok = new StringTokenizer("");

  @Override
  public void run() {
    try {
      init();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    long time = System.currentTimeMillis();
    try {
      solve();
    } catch (Exception e) {
      e.printStackTrace();
      System.exit(-1);
    }
    out.close();
    //System.err.println(System.currentTimeMillis() - time);
  }

  private void init() throws FileNotFoundException {
    String file = "";
    if (!file.equals("")) {
      in = new BufferedReader(new FileReader("road.in"));
      out = new PrintWriter("road.out");
    } else {
      in = new BufferedReader(new InputStreamReader(System.in));
      out = new PrintWriter(System.out);
    }
  }

  public static void main(String[] args) {
    new Thread(new Solution()).start();
  }

  private String readString() {
    while (!tok.hasMoreTokens()) {
      try {
        tok = new StringTokenizer(in.readLine());
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    return tok.nextToken();
  }

  private int readInt() {
    return Integer.parseInt(readString());
  }

  private long readLong() {
    return Long.parseLong(readString());
  }

  private double readDouble() {
    return Double.parseDouble(readString());
  }

  private void solve() throws IOException {
    double k = readInt();
    int q = readInt();
    int n = 1001;
    double[][] dp = new double[n + 1][(int) (k + 1)];
    dp[0][0] = 1;
    for (int i = 1; i <= n; i++) {//days
      for (int j = 1; j <= k; j++) {//count
        dp[i][j] = dp[i - 1][j - 1] * (k - j + 1) / k + dp[i - 1][j] * (j) / k;
      }
    }
    while (q-- > 0) {
      double x = readInt();
      for (int i = 0; i <= n; i++) {
        if (dp[i][(int) k] * 2000 >= (x - 1e-7)) {
          out.println(i);
          break;
        }
      }
    }
  }


}