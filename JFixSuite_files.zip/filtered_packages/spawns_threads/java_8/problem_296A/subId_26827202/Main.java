package java_8.problem_296A.subId_26827202;

import java.io.*;
    import java.math.BigInteger;
import java.text.DecimalFormat;
import java.util.*;
     
     
     
     public class Main {
    	public static InputReader in;
        public static PrintWriter pw;
     
     
     
    	public static void main(String args[]) {
    		new Thread(null, new Runnable() {
                public void run() {
                    try{
                        solve();
                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                }
            }, "1", 1 << 26).start();
        }
    	static ArrayList<Integer> g[];
    	static ArrayList<Integer> h[];
    	static boolean visited[];
    	static boolean parent[];
    	static int par[];
    	static int degree[];
    	static int edjes=0;
    	static int start=-1;
    	static int end=-1;
    	static int Total=0;
    	static int time1[];
    	static int time2[];
    	static int glob=0;
    	static long ans[]=new long[1000000];
    	static boolean vis2[][];
    	//static long sum1=0;
    	//static long val[];
        static ArrayList<Integer> levels[];
        static int max=0;
        static int lev=1;
        static ArrayList<Integer> nodes[];
        static ArrayList<Integer> values[];
        static int depth[];
        static boolean found=false;
       // static long sm[];
        static int sum1=0;
        static int pre[][];
        static int subtree[];
       static  int cnt=0;
       static  HashMap<String,Integer> hm;
       static int sm[];
       static int prime[];
       static long mul[];
       static long d[]=new long[1000000];
       static int tot=0;
       static long highest=(long)1e9;
       static boolean bit=false;
        static Stack<Integer> tt=new Stack();
       static HashSet<String> set=new HashSet<String>();
 	   static long fact[];
 	   static long MOD=1000000007;
        public static void solve(){
    		
    	
    		 in = new InputReader(System.in);
    		 pw = new PrintWriter(System.out);
             int n=in.nextInt();
             int a[]=in.nextIntArray(n);
             for(int i=0;i<n;i++)
             {
            	 int x=a[i];int c=0;
            	 while(i<n&&a[i]==x)
            	 {
            		 i++;
            		 c++;
            	 }
            	 if(c>2)
            	 {
            		 System.out.println("NO");
            		 System.exit(0);
            	 }
            	 
             }
             System.out.println("YES");
          }
        static long ncr(long a, long b){
			if(b>a || b<0) return 0;
			long f = (fact[(int) a]*modInverse(((fact[(int) b]*fact[(int) (a-b)])%MOD), MOD))%MOD;
			return f;
		}
		static long modInverse(long a, long mOD2){
            return  power(a, mOD2-2, mOD2);
}
static long power(long x, long y, long m)
{
    if (y == 0)
        return 1;
    long p = power(x, y/2, m) % m;
    p = (p * p) % m;
 
    return (y%2 == 0)? p : (x * p) % m;
}

        public static int gcd(int x, int y) {
    		if (x == 0)
    			return y;
    		else
    			return gcd( y % x,x);
    	}	
        public static long power(long a,long b)
		{
			long result=1;
			while(b>0)
			{
				if(b%2==1)
					result*=a;
				a=a*a;
				b/=2;
			}
			return result;
		}
        static class Pair implements Comparable<Pair>{
        	int a;
        		int b;
        		int c;
        		//int index;
        		Pair(int a,int b,int c){
        	     	this.a=a;
        			this.b=b;
                    this.c=c;        			
        		}
        		@Override
        		public int compareTo(Pair o) {

        				return 1;
        		}
        				
        	}
    	static class InputReader {
     
    		private InputStream stream;
    		private byte[] buf = new byte[8192];
    		private int curChar, snumChars;
    		private SpaceCharFilter filter;
     
    		public InputReader(InputStream stream) {
    			this.stream = stream;
    		}
     
    		public int snext() {
    			if (snumChars == -1)
    				throw new InputMismatchException();
    			if (curChar >= snumChars) {
    				curChar = 0;
    				try {
    					snumChars = stream.read(buf);
    				} catch (IOException e) {
    					throw new InputMismatchException();
    				}
    				if (snumChars <= 0)
    					return -1;
    			}
    			return buf[curChar++];
    		}
     
    		public   int nextInt() {
    			int c = snext();
    			while (isSpaceChar(c))
    				c = snext();
    			int sgn = 1;
    			if (c == '-') {
    				sgn = -1;
    				c = snext();
    			}
    			int res = 0;
    			do {
    				if (c < '0' || c > '9')
    					throw new InputMismatchException();
    				res *= 10;
    				res += c - '0';
    				c = snext();
    			} while (!isSpaceChar(c));
    			return res * sgn;
    		}
     
    		public long nextLong() {
    			int c = snext();
    			while (isSpaceChar(c))
    				c = snext();
    			int sgn = 1;
    			if (c == '-') {
    				sgn = -1;
    				c = snext();
    			}
    			long res = 0;
    			do {
    				if (c < '0' || c > '9')
    					throw new InputMismatchException();
    				res *= 10;
    				res += c - '0';
    				c = snext();
    			} while (!isSpaceChar(c));
    			return res * sgn;
    		}
     
    		public int[] nextIntArray(int n) {
    			int a[] = new int[n];
    			for (int i = 0; i < n; i++)
    				a[i] = nextInt();
    			return a;
    		}
     
    		public String readString() {
    			int c = snext();
    			while (isSpaceChar(c))
    				c = snext();
    			StringBuilder res = new StringBuilder();
    			do {
    				res.appendCodePoint(c);
    				c = snext();
    			} while (!isSpaceChar(c));
    			return res.toString();
    		}
     
    		public boolean isSpaceChar(int c) {
    			if (filter != null)
    				return filter.isSpaceChar(c);
    			return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
    		}
     
    		public interface SpaceCharFilter {
    			public boolean isSpaceChar(int ch);
    		}
    	}
    }