package java_8.problem_6D.subId_19936264;

import java.io.*;
import java.util.*;

public class Template implements Runnable {

    BufferedReader in;
    PrintWriter out;
    StringTokenizer tok = new StringTokenizer("");

    void init() throws FileNotFoundException {
        try {
            in = new BufferedReader(new FileReader("input.txt"));
            out = new PrintWriter("output.txt");
        } catch (Exception e) {
            in = new BufferedReader(new InputStreamReader(System.in));
            out = new PrintWriter(System.out);
        }
    }

    String readString() throws IOException {
        while (!tok.hasMoreTokens()) {
            try {
                tok = new StringTokenizer(in.readLine(), " :");
            } catch (Exception e) {
                return null;
            }
        }
        return tok.nextToken();
    }

    int readInt() throws IOException {
        return Integer.parseInt(readString());
    }

    int[] readIntArray(int size) throws IOException {
        int[] res = new int[size];
        for (int i = 0; i < size; i++) {
            res[i] = readInt();
        }
        return res;
    }

    long readLong() throws IOException {
        return Long.parseLong(readString());
    }

    double readDouble() throws IOException {
        return Double.parseDouble(readString());
    }

    <T> List<T>[] createGraphList(int size) {
        List<T>[] list = new List[size];
        for (int i = 0; i < size; i++) {
            list[i] = new ArrayList<>();
        }
        return list;
    }

    public static void main(String[] args) {
        new Thread(null, new Template(), "", 1l * 200 * 1024 * 1024).start();
    }

    long timeBegin, timeEnd;

    void time() {
        timeEnd = System.currentTimeMillis();
        System.err.println("Time = " + (timeEnd - timeBegin));
    }

    long memoryTotal, memoryFree;

    void memory() {
        memoryFree = Runtime.getRuntime().freeMemory();
        System.err.println("Memory = " + ((memoryTotal - memoryFree) >> 10)
                + " KB");
    }

    public void run() {
        try {
            timeBegin = System.currentTimeMillis();
            memoryTotal = Runtime.getRuntime().freeMemory();
            init();
            solve();
            out.close();
            if (System.getProperty("ONLINE_JUDGE") == null) {
                time();
                memory();
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }
    }

    int[] count;
    int[] hp;
    ArrayList<Integer> list = new ArrayList<>();
    int best = 10000;

    int a, b;

    void brut(int pos, int already) {
        if (already >= best) return;
        if (pos == count.length - 1) {
            for (int i = 0; i < count.length; i++) {
                if (hp[i] >= 0) return;
            }
            best = already;
            list.clear();
            for (int i = 1; i < count.length - 1; i++) {
                for (int j = 0; j < count[i]; j++) list.add(i + 1);
            }
            return;
        }

        int from = hp[pos - 1] < 0 ? 0 : (hp[pos - 1] + b - 1) / b;
        int to = count.length == 3 ? 16 : 8;
        for (int i = from; i <= to; i++) {
            count[pos] = i;

            hp[pos] -= a * i;
            hp[pos - 1] -= b * i;
            hp[pos + 1] -= b * i;
            boolean needBreak = hp[pos] < 0 && hp[pos - 1] < 0 && hp[pos + 1] < 0;
            brut(pos + 1, already + i);
            hp[pos] += a * i;
            hp[pos - 1] += b * i;
            hp[pos + 1] += b * i;
            if (needBreak) break;
        }
    }

    void solve() throws IOException {
        int n = readInt();
        a = readInt();
        b = readInt();
        hp = readIntArray(n);
        count = new int[n];
        brut(1, 0);
        out.println(best);
        for (int x : list) out.print(x + " ");
    }

}