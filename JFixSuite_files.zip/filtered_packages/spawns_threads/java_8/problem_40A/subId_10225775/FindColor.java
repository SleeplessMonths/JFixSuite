package java_8.problem_40A.subId_10225775;

import java.util.Scanner;

public class FindColor implements Runnable {

    private final Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        new Thread(new FindColor()).start();
    }

    @Override
    public void run() {
        int x = in.nextInt();
        int y = in.nextInt();

        if (x == 0 || y == 0) {
            System.out.println("black");
            return;
        }
        if (x > 0 && y > 0 && Math.max(x, y) % 2 == 0) {
            System.out.println("black");
        } else {
            System.out.println("black");
            return;
        }
        if (x < 0 && y > 0 && y % 2 == 0) {
            System.out.println("black");
        } else {
            System.out.println("white");
            return;
        }
        if (x > 0 && y < 0 && x % 2 != 0) {
            System.out.println("black");
        } else {
            System.out.println("white");
            return;
        }
        if (x < 0 && y < 0 && Math.min(x, y) % 2 != 0) {
            System.out.println("black");
        } else {
            System.out.println("white");
        }
    }
}