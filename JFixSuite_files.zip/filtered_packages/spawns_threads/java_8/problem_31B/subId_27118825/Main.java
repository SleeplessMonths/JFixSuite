package java_8.problem_31B.subId_27118825;

import java.io.*;
    import java.math.BigInteger;
import java.text.DecimalFormat;
import java.util.*;

 
    

     
     
     public class Main {
    	public static InputReader in;
        public static PrintWriter pw;
     
     
     
    	public static void main(String args[]) {
    		new Thread(null, new Runnable() {
                public void run() {
                    try{
                        solve();
                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                }
            }, "1", 1 << 26).start();
        }
    	static ArrayList<Integer> g[];
    	static ArrayList<Integer> h[];
    	static boolean visited[];
    	static int[] parent;
    	static int par[];
    	static int degree[];
    	static int edjes=0;
    	static int start=-1;
    	static int end=-1;
    	static int Total=0;
    	static int time1[];
    	static int time2[];
    	static int glob=0;
    	static long ans[]=new long[1000000];
    	static boolean vis2[][];
    	//static long sum1=0;
    	//static long val[];
        static ArrayList<Integer> levels[];
        static int max=0;
        static int lev=1;
        static ArrayList<Integer> nodes[];
        static ArrayList<Integer> values[];
        static int depth[];
        static boolean found=false;
       // static long sm[];
        static int sum1=0;
        static int pre[][];
        static int subtree[];
       static  int cnt=0;
       static  HashMap<String,Integer> hm;
       static int sm[];
       static int size[];
       static long mul[];
       static long d[]=new long[1000000];
       static int tot=0;
       static long highest=(long)1e9;
       static boolean bit=false;
        static Stack<Integer> tt=new Stack();
       static HashSet<String> set=new HashSet<String>();
 	   static long fact[],num[];
 	   static long MOD=1000000007;
 	   static int value[];static int premen[];
 	   static int count=0,index=0;
 	   static double ans11[];
 	   static int price[];
 	   static ArrayList<String> hp[][];
 	   static boolean visit[][];
 	   static int cnu[]=new int[1000001];
 	   static int label=1;
 	   static int his[][];
 	   static int size1=0;
 	   static int up[],down[];
 	   static int TotalUp=0;
 	   static long dist[];
 	   static HashMap<String,Integer> hm1=new HashMap();
 	   static HashMap<Integer,Integer> hm2=new HashMap();
 	   static TreeSet<Long> set1=new TreeSet();
 	 public static void solve() throws FileNotFoundException{
    		
    	
    		 in = new InputReader(System.in);
    		 pw = new PrintWriter(System.out);  
             String s=in.readString();
             
             if(s.charAt(0)=='@')
             {
            	 System.out.println("No solution");
            	 return;
             }
             ArrayList<Integer> set=new ArrayList();
             for(int i=0;i<s.length();i++)
             {
            	 if(s.charAt(i)=='@')set.add(i);
             }
             if(set.size()==0)
             {
            	 System.out.println("No solution");
            	 return;
            
             }
             Collections.sort(set);
             for(int i=0;i<set.size()-1;i++)
             {
            	 if(set.get(i+1)-set.get(i)<=2)
            	 {
            		 System.out.println("No solution");
            		 System.exit(0);
            	 }
             }
             int cnt=0;
             StringBuilder ans=new StringBuilder();
             for(int i=0;i<s.length();i++)
             {
            	 
            	 if(s.charAt(i)=='@')cnt++;
            	 if(cnt>1&&s.charAt(i)=='@')
            	 {
            		 ans.deleteCharAt(ans.length()-1);
            		 ans.append(',');
            		 ans.append(s.charAt(i-1));
            	 }
            	 ans.append(s.charAt(i));
             }
             System.out.println(ans);
        }
 	 public static boolean ok(char c)
 	 {
 		 if(c>='a'&&c<='z')return true;
 		 return false;
 	 }
 	 
 	

 	  public static void dfs1(int curr,int parent)
 	  {
 		  visited[curr]=true;
 		  
 		  for(int x:g[curr])
 		  {
 			  
 			  if(x==parent)continue;
 			  depth[x]=depth[curr]+1;
 			  up[x]=up[curr];
 			  if(h[x].contains(curr)){
 				  up[x]++;
 				  TotalUp++;
 			  }
 			  dfs1(x,curr);
 		  }
 	  }
 	 
        
        
        public static void dfs(int curr,int Parent)
        {
        	visited[curr]=true;
        	size[curr]=1;
        	parent[curr]=Parent;
        	count++;
        	if(value[curr]>0)
        	{
        		index=value[curr];
        	}
        	for(int x:g[curr])
        	{
        		if(!visited[x])
        		{
        			dfs(x,curr);
        			size[curr]+=size[x];
        		}
        	}
        }
        static long ncr(long a, long b){
			if(b>a || b<0) return 0;
			long f = (fact[(int) a]*modInverse(((fact[(int) b]*fact[(int) (a-b)])%MOD), MOD))%MOD;
			return f;
		}
		static long modInverse(long a, long mOD2){
            return  power(a, mOD2-2, mOD2);
}
static long power(long x, long y, long m)
{
    if (y == 0)
        return 1;
    long p = power(x, y/2, m) % m;
    p = (p * p) % m;
 
    return (y%2 == 0)? p : (x * p) % m;
}

        public static long gcd(long x, long y) {
    		if (x == 0)
    			return y;
    		else
    			return gcd( y % x,x);
    	}	
        public static long power(long a,long b)
		{
			long result=1;
			while(b>0)
			{
				if(b%2==1)
					result*=a;
				a=a*a;
				b/=2;
			}
			return result;
		}
        static class Pair implements Comparable<Pair>{
        	//int index;
        		int beauty;
        		int cost;
        		//int index;
        		Pair(int index,int value){
        	     	this.beauty=index;
        			this.cost=value;
                    	
        		}
        		@Override
        		public int compareTo(Pair o) {
                      return cost-o.cost;
        		}
        				
        	}
    	static class InputReader {
     
    		private InputStream stream;
    		private byte[] buf = new byte[8192];
    		private int curChar, snumChars;
    		private SpaceCharFilter filter;
     
    		public InputReader(InputStream stream) {
    			this.stream = stream;
    		}
     
    		public int snext() {
    			if (snumChars == -1)
    				throw new InputMismatchException();
    			if (curChar >= snumChars) {
    				curChar = 0;
    				try {
    					snumChars = stream.read(buf);
    				} catch (IOException e) {
    					throw new InputMismatchException();
    				}
    				if (snumChars <= 0)
    					return -1;
    			}
    			return buf[curChar++];
    		}
     
    		public   int nextInt() {
    			int c = snext();
    			while (isSpaceChar(c))
    				c = snext();
    			int sgn = 1;
    			if (c == '-') {
    				sgn = -1;
    				c = snext();
    			}
    			int res = 0;
    			do {
    				if (c < '0' || c > '9')
    					throw new InputMismatchException();
    				res *= 10;
    				res += c - '0';
    				c = snext();
    			} while (!isSpaceChar(c));
    			return res * sgn;
    		}
     
    		public long nextLong() {
    			int c = snext();
    			while (isSpaceChar(c))
    				c = snext();
    			int sgn = 1;
    			if (c == '-') {
    				sgn = -1;
    				c = snext();
    			}
    			long res = 0;
    			do {
    				if (c < '0' || c > '9')
    					throw new InputMismatchException();
    				res *= 10;
    				res += c - '0';
    				c = snext();
    			} while (!isSpaceChar(c));
    			return res * sgn;
    		}
     
    		public int[] nextIntArray(int n) {
    			int a[] = new int[n];
    			for (int i = 0; i < n; i++)
    				a[i] = nextInt();
    			return a;
    		}
     
    		public String readString() {
    			int c = snext();
    			while (isSpaceChar(c))
    				c = snext();
    			StringBuilder res = new StringBuilder();
    			do {
    				res.appendCodePoint(c);
    				c = snext();
    			} while (!isSpaceChar(c));
    			return res.toString();
    		}
     
    		public boolean isSpaceChar(int c) {
    			if (filter != null)
    				return filter.isSpaceChar(c);
    			return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
    		}
     
    		public interface SpaceCharFilter {
    			public boolean isSpaceChar(int ch);
    		}
    	}
    }