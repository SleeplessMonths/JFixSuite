package java_8.problem_139A.subId_25457079;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class Solution implements Runnable {
  BufferedReader in;
  PrintWriter out;
  StringTokenizer tok = new StringTokenizer("");

  @Override
  public void run() {
    try {
      init();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    long time = System.currentTimeMillis();
    try {
      solve();
    } catch (Exception e) {
      e.printStackTrace();
    }
    out.close();
    System.err.println(System.currentTimeMillis() - time);
  }

  private void init() throws FileNotFoundException {
    String file = "";
    if (!file.equals("")) {
      in = new BufferedReader(new FileReader("input.txt"));
      out = new PrintWriter("output.txt");
    } else {
      in = new BufferedReader(new InputStreamReader(System.in));
      out = new PrintWriter(System.out);
    }
  }

  public static void main(String[] args) {
    new Thread(new Solution()).start();
  }

  private String readString() {
    while (!tok.hasMoreTokens()) {
      try {
        tok = new StringTokenizer(in.readLine());
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    return tok.nextToken();
  }

  private int readInt() {
    return Integer.parseInt(readString());
  }

  private long readLong() {
    return Long.parseLong(readString());
  }

  private void solve() {
    int n = readInt();
    int k = 7;
    int[] ar = new int[k];
    for (int i = 0; i < k; i++) {
      ar[i] = readInt();
    }
    while(true) {
      for (int i = 0; i < k; i++) {
        n-=ar[i];
        if(n<0) {
          out.print(i+1);
          return;
        }
      }
    }
  }


}