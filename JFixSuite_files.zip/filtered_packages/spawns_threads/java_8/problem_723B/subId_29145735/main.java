package java_8.problem_723B.subId_29145735;

import java.lang.reflect.Array;
    import java.util.Scanner;
    import java.io.*;
    import java.util.*;
    import java.math.*;
    import java.lang.*;
    import static java.lang.Math.*;
    public class main implements Runnable {

        static ArrayList<Integer> adj[];

        static void Check2(int n) {
            adj = new ArrayList[n + 1];
            for (int i = 0; i <= n; i++) {
                adj[i] = new ArrayList<>();
            }

        }

        static void add(int i, int j) {
    adj[i].add(j);
    adj[j].add(i);
        }

        public static void main(String[] args) {
            new Thread(null, new main(), "Check2", 1 << 26).start();// to increse stack size in java
        }

        static long mod = (long) (1e9 + 7);

        public void run() {
                        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
            //Scanner in=new Scanner(System.in);

            InputReader in = new InputReader(System.in);
            PrintWriter w = new PrintWriter(System.out);


                int n=in.nextInt();
                char c[]=in.next().toCharArray();

                int maxin=0;
                int maxout=0;
                int flag=0;
                int co=0;
                int flag2=0;
                for(int i=0;i<c.length;i++){

                    if(c[i]=='_'&&flag==0){
                        continue;
                    }

                    else if(c[i]=='('){
                        flag=1;
                    }
                    else if(c[i]==')'){
                          if(flag2==1)co++;
                        flag=0;
                        flag2=0;
                    }
                    else if(flag==1){
                        if(c[i]=='_'&&flag2==1){
                            flag2=0;

                            co++;

                        }
                        else if(c[i]!='_'){
                            flag2=1;

                        }

                    }


//                    w.println(c[i]+" "+co+" "+flag2);
                }
                maxin=co;
                co=0;
            for(int i=0;i<c.length;i++){


                    if(c[i]=='_')co=0;
                if(c[i]=='('){
                    flag=1;
                }
                else if(c[i]!=')'&&flag==0){
                    if(c[i]=='_')co=0;
                    else co++;
                }
                else if(c[i]==')'){
                    flag=0;
                }
                maxout=max(maxout,co);


            }
            w.println(maxout+" "+maxin);












            w.close();
        }

            static class pair{

            int a,b,dis,time;

            pair(int c,int d){
                a=c;
                b=d;
            }


        }





        static long power(long x,long y){
            if(y==0)return 1%mod;
            if(y==1)return x%mod;


            long res=1;
            x=x%mod;
            while(y>0){


                if((y%2)!=0){
                    res=(res*x)%mod;
                }


                y=y/2;
                x=(x*x)%mod;
            }


            return res;



        }


        static  int gcd(int a,int b){

            if(b==0)return a;
            return gcd(b,a%b);
        }

        static  void sev(int a[],int n){

            for(int i=2;i<=n;i++)a[i]=i;
            for(int i=2;i<=n;i++){

                if(a[i]!=0){
                    for(int j=2*i;j<=n;){

                        a[j]=0;
                        j=j+i;
                    }
                }

            }

        }


        static class node{

            int y;
            int val;

            node(int a,int b){

                y=a;
                val=b;

            }


        }

        static class InputReader
        {
            private InputStream stream;
            private byte[] buf = new byte[1024];
            private int curChar;
            private int numChars;
            private SpaceCharFilter filter;

            public InputReader(InputStream stream)
            {
                this.stream = stream;
            }

            public int read()
            {
                if (numChars==-1)
                    throw new InputMismatchException();

                if (curChar >= numChars)
                {
                    curChar = 0;
                    try
                    {
                        numChars = stream.read(buf);
                    }
                    catch (IOException e)
                    {
                        throw new InputMismatchException();
                    }

                    if(numChars <= 0)
                        return -1;
                }
                return buf[curChar++];
            }

            public String nextLine()
            {
                BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
                String str = "";
                try
                {
                    str = br.readLine();
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
                return str;
            }
            public int nextInt()
            {
                int c = read();

                while(isSpaceChar(c))
                    c = read();

                int sgn = 1;

                if (c == '-')
                {
                    sgn = -1;
                    c = read();
                }

                int res = 0;
                do
                {
                    if(c<'0'||c>'9')
                        throw new InputMismatchException();
                    res *= 10;
                    res += c - '0';
                    c = read();
                }
                while (!isSpaceChar(c));

                return res * sgn;
            }

            public long nextLong()
            {
                int c = read();
                while (isSpaceChar(c))
                    c = read();
                int sgn = 1;
                if (c == '-')
                {
                    sgn = -1;
                    c = read();
                }
                long res = 0;

                do
                {
                    if (c < '0' || c > '9')
                        throw new InputMismatchException();
                    res *= 10;
                    res += c - '0';
                    c = read();
                }
                while (!isSpaceChar(c));
                return res * sgn;
            }

            public double nextDouble()
            {
                int c = read();
                while (isSpaceChar(c))
                    c = read();
                int sgn = 1;
                if (c == '-')
                {
                    sgn = -1;
                    c = read();
                }
                double res = 0;
                while (!isSpaceChar(c) && c != '.')
                {
                    if (c == 'e' || c == 'E')
                        return res * Math.pow(10, nextInt());
                    if (c < '0' || c > '9')
                        throw new InputMismatchException();
                    res *= 10;
                    res += c - '0';
                    c = read();
                }
                if (c == '.')
                {
                    c = read();
                    double m = 1;
                    while (!isSpaceChar(c))
                    {
                        if (c == 'e' || c == 'E')
                            return res * Math.pow(10, nextInt());
                        if (c < '0' || c > '9')
                            throw new InputMismatchException();
                        m /= 10;
                        res += (c - '0') * m;
                        c = read();
                    }
                }
                return res * sgn;
            }

            public String readString()
            {
                int c = read();
                while (isSpaceChar(c))
                    c = read();
                StringBuilder res = new StringBuilder();
                do
                {
                    res.appendCodePoint(c);
                    c = read();
                }
                while (!isSpaceChar(c));

                return res.toString();
            }

            public boolean isSpaceChar(int c)
            {
                if (filter != null)
                    return filter.isSpaceChar(c);
                return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
            }

            public String next()
            {
                return readString();
            }

            public interface SpaceCharFilter
            {
                public boolean isSpaceChar(int ch);
            }
        }







    }