package java_8.problem_122A.subId_28179851;

//package com.company;
import java.io.*;
import java.util.*;
import java.math.*;

public class Solution implements Runnable {
    static String filename = "";
    static boolean fromFile = false;
    BufferedReader in;
    PrintWriter out;
    FastScanner sc;

    public static void main(String[] args) {
        new Thread(null, new Solution(), "", 1 << 25).start();
    }

    public void solve() throws Exception {
        int n = sc.nextInt();
        int[] dividers = {4, 7, 47, 74, 77, 444, 447, 474, 744, 747, 774, 777};
        int flag = 0;
        for (int i = 0; i < dividers.length; i++) {
            if (n % dividers[i] == 0) {
                flag = 1;
                break;
            }
        }
        String[] result = {"NO", "YES"};
        System.out.println(result[flag]);
    }

    public void run() {
        try {
            init();
            solve();
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            out.close();
        }
    }

    void init() throws Exception {
        if (fromFile) {
            in = new BufferedReader(new FileReader(filename+".in"));
            out = new PrintWriter(new FileWriter(filename+".out"));
        } else {
            in = new BufferedReader(new InputStreamReader(System.in));
            out = new PrintWriter(System.out);
        }
        sc = new FastScanner(in);
    }
}

class FastScanner {

    BufferedReader reader;
    StringTokenizer strTok;

    public FastScanner(BufferedReader reader) {
        this.reader = reader;
    }

    public String nextToken() throws IOException {
        while (strTok == null || !strTok.hasMoreTokens()) {
            strTok = new StringTokenizer(reader.readLine());
        }

        return strTok.nextToken();
    }

    public int nextInt() throws IOException {
        return Integer.parseInt(nextToken());
    }

    public long nextLong() throws IOException {
        return Long.parseLong(nextToken());
    }

    public double nextDouble() throws IOException {
        return Double.parseDouble(nextToken());
    }

    public BigInteger nextBigInteger() throws IOException {
        return new BigInteger(nextToken());
    }

    public BigDecimal nextBigDecimal() throws IOException {
        return new BigDecimal(nextToken());
    }
}