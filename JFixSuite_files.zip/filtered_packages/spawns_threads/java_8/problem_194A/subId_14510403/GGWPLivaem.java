package java_8.problem_194A.subId_14510403;

import java.io.*;
import java.util.*;
import java.math.*;

public class GGWPLivaem implements Runnable{
    boolean withFiles = false;
    class cc implements Comparable<cc>{
        public int x, y;
        cc(int x, int y) {
            this.x = x;
            this.y = y;
        }
        public int compareTo(cc other) {
            if (this.x == other.x) {
                return Integer.compare(this.y, other.y);
            }
            return Integer.compare(this.x, other.x);
        }
    }

    private void solve() throws IOException {
        int n = in.nextInt(), k = in.nextInt();
        for (int i = 1; i <= n; ++i) {
            int cur = 2 * i;
            int last = 5 * (n - i);
            if (cur + last >= k && cur + (3 * (n - i)) <= k) {
                out.printf("%d", i);
                return;
            }
        }
    }

    private static class FastScanner{
        private BufferedReader reader;
        private StringTokenizer tokenizer;
        String cache;
        int cur;

        FastScanner(Reader r) throws IOException{
            reader = new BufferedReader(r);
            tokenizer = new StringTokenizer("");
            cache = null;
            cur = 0;
        }

        public boolean hasNext(){
            if (cache != null && cur < cache.length())
                return true;
            try {
                while (!tokenizer.hasMoreTokens()){
                    String line = reader.readLine();
                    if (line == null)
                        return false;
                    tokenizer = new StringTokenizer(line);
                }
                cache = tokenizer.nextToken();
                cur = 0;
            }
            catch(IOException e) {
                return false;
            }
            return true;
        }

        public char nextChar() throws IOException{
            if (!hasNext())
                throw new EOFException();
            return cache.charAt(cur++);
        }

        public String next() throws IOException{
            if (!hasNext())
                throw new EOFException();
            String result = (cur == 0) ? cache : cache.substring(cur);
            cache = null;
            return result;
        }

        public int nextInt() throws IOException{
            return Integer.parseInt(this.next());
        }

        public long nextLong() throws IOException{
            return Long.parseLong(this.next());
        }

        public double nextDouble() throws IOException{
            return Double.parseDouble(this.next());
        }

        public BigInteger nextBigInteger() throws IOException{
            return new BigInteger(this.next());
        }

        public void close() throws IOException{
            reader.close();
            tokenizer = new StringTokenizer("");
        }
    }


    public static void main(String args[]) throws IOException{
        new Thread(null, new GGWPLivaem(), "Thread #228", 64 * 1024 * 1024).start();
    }

    public void run(){
        try{
            if (withFiles) {
                in = new FastScanner(new FileReader("input.txt"));
                out = new PrintWriter(new FileWriter("output.txt"));
            }
            else {
                in = new FastScanner(new InputStreamReader(System.in));
                out = new PrintWriter(System.out);
            }
            solve();
            in.close();
            out.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

    FastScanner in;
    PrintWriter out;
}