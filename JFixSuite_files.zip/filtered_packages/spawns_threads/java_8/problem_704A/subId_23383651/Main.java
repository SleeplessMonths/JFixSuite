package java_8.problem_704A.subId_23383651;

import java.io.*;
import java.math.BigInteger;
import java.util.*;


 public class Main {
	public static InputReader in;
    public static PrintWriter pw;



	public static void main(String args[]) {
		new Thread(null, new Runnable() {
            public void run() {
                try{
                    solve();
                }
                catch(Exception e){
                    e.printStackTrace();
                }
            }
        }, "1", 1 << 26).start();
    }
	static TreeSet<Integer> set;
	static ArrayList<Integer> g[];
	static boolean visited[];
	static long edje=0;
    static boolean vis[];
	static int parent[];
	static int col[];
	static int val[];
	static boolean[] vis1;
	static int Ans=0;
	static int min=Integer.MAX_VALUE;
	static int depth[];
	public static void solve(){
	
		 in = new InputReader(System.in);
		 pw = new PrintWriter(System.out);
	     int n=in.nextInt();
	     int q=in.nextInt();
	     Queue Q[]=new Queue[400001];
	     for(int i=1;i<=100000;i++)
	    	 Q[i]=new LinkedList<Integer>();
	     int current=0;
	     HashSet<Integer> ans=new HashSet<Integer>();
	     int last=0;
	     while(q-->0)
	     {
	    	 int type=in.nextInt();
	    	 int x=in.nextInt();
	    	 if(type==1)
	    	 {
	    		 current++;
	    		 Q[x].add(current);
	    		 ans.add(current);
	    		 
	    	 }
	    	 else if(type==2)
	    	 {
	    		 while(!Q[x].isEmpty())
	    		 {
	    			 int temp=(int)Q[x].peek();
	    			 Q[x].poll();
	    			 ans.remove(temp);
	    		 }
	    	}
	    	 else
	    	 {
	    		while(last<x)
	    		{
	    			last++;
	    			ans.remove(last);
	    			
	    		}
	    	 }
	    	 System.out.println(ans.size());
	     }
	   }
	public static void dfs(int curr)
	{
	vis[curr]=true;
	int tree=0;
	for(int x:g[curr])
	{
		depth[x]+=depth[curr]+1;
		if(!vis[x])
		{
			tree++;
			
		}
	}
	
	}
    
/*    public static void dfs2(int curr)
    {
    if(st[col[curr]].isEmpty())
    {
    ans[curr]=-1;	
    }
    else
    {
    	ans[curr]=st[col[curr]].peek();
    }
    st[col[curr]].push(curr);
    for(int x:g[curr])
    {
    	dfs2(x);
    }
    st[col[curr]].pop();
    	
    }
    
  
	public static void dfs1(int curr)
	{
		visited[curr]=true;
		for(int next:g[curr])
		{
			edje++;
			if(!visited[next])
				dfs1(next);
		}
	}
	
	public static void dfs(int curr,int prev)
		{
		val[curr]=1;
			for(int x:g[curr])
			{
				if(x!=prev)
				{
		            dfs(x,curr);
		            val[curr]+=val[x];
					
			    }
			}
		}*/
	
		public static long power(long a,long b)
		{
			long result=1;
			while(b>0)
			{
				if(b%2==1)
					result*=a;
				a=a*a;
				b/=2;
			}
			return result;
		}
				public static long pow(long n,long p,long m)
	{
		 long  result = 1;
		  if(p==0)
		    return 1;
		if (p==1)
		    return n;
		while(p!=0)
		{
		    if(p%2==1)
		        result *= n;
		    if(result>=m)
		    result%=m;
		    p >>=1;
		    n*=n;
		    if(n>=m)
		    n%=m;
		}
		return result;
	}
	static class Pair implements Comparable<Pair>{
		int t;
		int w;
		Pair(int mr,int er){
	     	t=mr;
			w=er;
			
		}
		@Override
		public int compareTo(Pair o) {
			return 1;
			}
	}
	public static long gcd(long a, long b) {
		  if (b == 0) return a;
		  return gcd(b, a%b);
		}
	static class InputReader {
 
		private InputStream stream;
		private byte[] buf = new byte[8192];
		private int curChar, snumChars;
		private SpaceCharFilter filter;
 
		public InputReader(InputStream stream) {
			this.stream = stream;
		}
 
		public int snext() {
			if (snumChars == -1)
				throw new InputMismatchException();
			if (curChar >= snumChars) {
				curChar = 0;
				try {
					snumChars = stream.read(buf);
				} catch (IOException e) {
					throw new InputMismatchException();
				}
				if (snumChars <= 0)
					return -1;
			}
			return buf[curChar++];
		}
 
		public   int nextInt() {
			int c = snext();
			while (isSpaceChar(c))
				c = snext();
			int sgn = 1;
			if (c == '-') {
				sgn = -1;
				c = snext();
			}
			int res = 0;
			do {
				if (c < '0' || c > '9')
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = snext();
			} while (!isSpaceChar(c));
			return res * sgn;
		}
 
		public long nextLong() {
			int c = snext();
			while (isSpaceChar(c))
				c = snext();
			int sgn = 1;
			if (c == '-') {
				sgn = -1;
				c = snext();
			}
			long res = 0;
			do {
				if (c < '0' || c > '9')
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = snext();
			} while (!isSpaceChar(c));
			return res * sgn;
		}
 
		public int[] nextIntArray(int n) {
			int a[] = new int[n];
			for (int i = 0; i < n; i++)
				a[i] = nextInt();
			return a;
		}
 
		public String readString() {
			int c = snext();
			while (isSpaceChar(c))
				c = snext();
			StringBuilder res = new StringBuilder();
			do {
				res.appendCodePoint(c);
				c = snext();
			} while (!isSpaceChar(c));
			return res.toString();
		}
 
		public boolean isSpaceChar(int c) {
			if (filter != null)
				return filter.isSpaceChar(c);
			return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
		}
 
		public interface SpaceCharFilter {
			public boolean isSpaceChar(int ch);
		}
	}
}