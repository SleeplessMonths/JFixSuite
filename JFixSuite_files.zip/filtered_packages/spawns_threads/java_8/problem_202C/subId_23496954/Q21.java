package java_8.problem_202C.subId_23496954;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.PriorityQueue;
import java.util.TreeMap;
import java.util.TreeSet;

public class Q21 {
	static long MOD = 1000000007;
	static TreeSet<Long> hs = new TreeSet<>();
	static ArrayList<Pair>[][] amp;
	static ArrayList<Pair> amp2;
	static boolean b[][];
	static int comp[][],dist[][];
	static int ans = 0;
	static PriorityQueue<Long> pq=  new PriorityQueue<Long>(Collections.reverseOrder());
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		new Thread(null ,new Runnable(){
            public void run(){
                try{
                    solve();
                } catch(Exception e){
                    e.printStackTrace();
                }
            }
        },"1",1<<26).start();
	}
	public static void solve() throws IOException{
		FasterScanner sc = new FasterScanner();
		BufferedWriter log = new BufferedWriter(new OutputStreamWriter(System.out));
		int x = sc.nextInt();
		if(x==1) System.out.println(1);
		else if(x==2||x==4||x==5) System.out.println(3);
		else if(x==3) System.out.println(3);
		else{
			int y = (int)Math.ceil(Math.sqrt(2*x-1));
			if(y%2==0) y++;
			System.out.println(y);
		}
		log.close();
	}
	public static void dfs(int x,int y){
		b[x][y] = true;
		comp[x][y] = ans;
		amp2.add(new Pair(x,y));
		for(int i = 0;i<amp[x][y].size();i++){
			Pair p = amp[x][y].get(i);
			if(!b[p.u][p.v]){
				dfs(p.u,p.v);
			}
		}
	}
	static void findFactors(long[] primeDivisors, long[] multiplicity, long currentDivisor, long currentResult) {
	    if (currentDivisor == primeDivisors.length) {
	        hs.add(currentResult);
	        return;
	    }
	    for (int i = 0; i <= multiplicity[(int)currentDivisor]; ++i) {
	        findFactors(primeDivisors, multiplicity, currentDivisor + 1, currentResult);
	        currentResult *= primeDivisors[(int)currentDivisor];
	    }
	}
	static long modInverse(long a, long mOD2){
	            return  power(a, mOD2-2, mOD2);
	}
	static long power(long x, long y, long m)
	{
	    if (y == 0)
	        return 1;
	    long p = power(x, y/2, m) % m;
	    p = (p * p) % m;
	 
	    return (y%2 == 0)? p : (x * p) % m;
	}
	static long power2(long x,char y[],long m){
		long ans = 1;
		int i = y.length-1;
		while(i>=0){
			if(y[i]=='1'){
				ans = (ans%m*x%m)%m;
				x = (x%m*x%m)%m;
			}
			else{
				x = (x%m*x%m)%m;
			}
			i--;
		}
		return ans;
	}
	static long d,x,y;
	public static void extendedEuclidian(long a, long b){
		if(b == 0) {
	        d = a;
	        x = 1;
	        y = 0;
	    }
	    else {
	        extendedEuclidian(b, a%b);
	        int temp = (int) x;
	        x = y;
	        y = temp - (a/b)*y;
	    }
	}
	
	public static long gcd(long n, long m){
		if(m!=0) return gcd(m,n%m);
		else return n;
	}
	
	static class Pair implements Comparable<Pair> {
		int u;
		int v;
		public Pair(){
			
		}
		public Pair(int u, int v) {
			this.u = u;
			this.v = v;
		}
		
		public int hashCode() {
			int hu = (int) (u ^ (u >>> 32));
			int hv = (int) (v ^ (v >>> 32));
			return 31*hu + hv;
		}

		public boolean equals(Object o) {
			Pair other = (Pair) o;
			return (u == other.u && v == other.v);
		}

		public int compareTo(Pair other) {
			return Long.compare(u, other.u) != 0 ? (Long.compare(u, other.u)) : (Long.compare(v, other.v));
		}

		public String toString() {
			return "[u=" + u + ", v=" + v + "]";
		}
	}
	public static class FasterScanner {
		private byte[] buf = new byte[1024];
		private int curChar;
		private int numChars;
 
		public int read() {
			if (numChars == -1)
				throw new InputMismatchException();
			if (curChar >= numChars) {
				curChar = 0;
				try {
					numChars = System.in.read(buf);
				} catch (IOException e) {
					throw new InputMismatchException();
				}
				if (numChars <= 0)
					return -1;
			}
			return buf[curChar++];
		}
 
		public String nextLine() {
			int c = read();
			while (isSpaceChar(c))
				c = read();
			StringBuilder res = new StringBuilder();
			do {
				res.appendCodePoint(c);
				c = read();
			} while (!isEndOfLine(c));
			return res.toString();
		}
 
		public String nextString() {
			int c = read();
			while (isSpaceChar(c))
				c = read();
			StringBuilder res = new StringBuilder();
			do {
				res.appendCodePoint(c);
				c = read();
			} while (!isSpaceChar(c));
			return res.toString();
		}
 
		public long nextLong() {
			int c = read();
			while (isSpaceChar(c))
				c = read();
			int sgn = 1;
			if (c == '-') {
				sgn = -1;
				c = read();
			}
			long res = 0;
			do {
				if (c < '0' || c > '9')
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = read();
			} while (!isSpaceChar(c));
			return res * sgn;
		}
 
		public int nextInt() {
			int c = read();
			while (isSpaceChar(c))
				c = read();
			int sgn = 1;
			if (c == '-') {
				sgn = -1;
				c = read();
			}
			int res = 0;
			do {
				if (c < '0' || c > '9')
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = read();
			} while (!isSpaceChar(c));
			return res * sgn;
		}
	        
	    public int[] nextIntArray(int n) {
	        return nextIntArray(n, 0);
	    }
	    
	    public int[] nextIntArray(int n, int off) {
	    	int[] arr = new int[n + off];
	    	for (int i = 0; i < n; i++) {
	    		arr[i + off] = nextInt();
	    	}
	    	return arr;
	    }
	    
	    public long[] nextLongArray(int n) {
	    	return nextLongArray(n, 0);
	    }
        
		public long[] nextLongArray(int n, int off) {
		    long[] arr = new long[n + off];
		    for (int i = 0; i < n; i++) {
		        arr[i + off] = nextLong();
		    }
		    return arr;
		}
 
	    private boolean isSpaceChar(int c) {
			return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
		}
 
		private boolean isEndOfLine(int c) {
			return c == '\n' || c == '\r' || c == -1;
		}
	}
}