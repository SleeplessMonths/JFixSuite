package java_8.problem_245B.subId_18868338;

import java.util.*;
import java.lang.*;
import java.io.*;
import java.math.*;
import java.util.concurrent.*;

public class Main {
    //---------------------------------------------------------------------------

    public static void main(String[] args) throws Exception {
        InputReader in = new InputReader(System.in);
        PrintWriter out = new PrintWriter(System.out);
        //-----------------------------------------------------------------------
        char[] a = in.nextCharArray();
        String s = "";
        int i = 0;
        if (a[0] == 'f') {
            s += "ftp://";
            i = 3;
        } else {
            s += "http://";
            i = 4;
        }
        for (i = i; i < a.length - 1; i++) {
            if (a[i] == 'r' && a[i + 1] == 'u') {
                s += ".ru";
                if (i != a.length - 2) {
                    s += '/';
                    for (i = i + 2; i < a.length; i++) {
                        s += a[i];
                    }
                    break;
                }
            } else {
                s += a[i];
            }
        }
        out.println(s);
        //-----------------------------------------------------------------------
        out.close();
    }

    //---------------------------------------------------------------------------
    static void shuffleArray(int[] ar) {
        Random rnd = ThreadLocalRandom.current();
        for (int i = ar.length - 1; i > 0; i--) {
            int index = rnd.nextInt(i + 1);
            int a = ar[index];
            ar[index] = ar[i];
            ar[i] = a;
        }
    }

    static class Pair<F, S> implements Comparable<Pair<F, S>> {

        F first;
        S second;

        public Pair() {

        }

        public Pair(F f, S s) {
            this.first = f;
            this.second = s;
        }

        public int compareTo(Pair<F, S> p) {
            int ret = ((Comparable<F>) first).compareTo(p.first);
            return ret;
        }
    }

    static class InputReader {

        public BufferedReader reader;
        public StringTokenizer tokenizer;

        public InputReader(InputStream stream) {
            reader = new BufferedReader(new InputStreamReader(stream), 32768);
            tokenizer = null;
        }

        public String next() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    tokenizer = new StringTokenizer(reader.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return tokenizer.nextToken();
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        public long nextLong() {
            return Long.parseLong(next());
        }

        public double nextDouble() {
            return Double.parseDouble(next());
        }

        public char[] nextCharArray() {
            return next().toCharArray();
        }

        public boolean hasNext() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    String s = reader.readLine();
                    if (s == null) {
                        return false;
                    }
                    tokenizer = new StringTokenizer(s);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return true;
        }

        public void skipLine() {
            try {
                tokenizer = null;
                reader.readLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}