package java_8.problem_760B.subId_27618370;

import java.util.Scanner;
	import java.io.*;
	import java.util.*;
	import java.math.*;
	import java.lang.*;
	import static java.lang.Math.*;
	 
	public class TestClass implements Runnable
	{
		public static void main(String args[])
		{
			new Thread(null, new TestClass(),"TESTCLASS",1<<26).start();
		}
		public void run()
		{
			//Scanner scan=new Scanner(System.in);
			InputReader hb=new InputReader(System.in);
			PrintWriter w=new PrintWriter(System.out);
			
			int n=hb.nextInt();
			int m=hb.nextInt();
			int k=hb.nextInt();
			
			int start=1;
			int end=m;
			long count=0;
			int x=0;
			int max=0;
			while(start<end)
			{
				int left=k-1;
				int right=n-k;
				
				x=start + (end-start)/2;
				count=x;
				//w.println(start+" "+end);
				//w.print(count+" ");
				if(left>x-1)
					count+= x*(x-1)/2  +  left  -  (x-1);
				else
					count+= left*(x-1 + x-left)/2;
				//w.print(count+" ");
				if(right>x-1)
					count+= x*(x-1)/2  +  right  -  (x-1);
				else
					count+= right*(x-1 + x-right)/2;
				//w.println(count);
				if(count>m)
					end=x;
				else
				{
					start=x+1;
					if(x>max)
						max=x;
				}
				if(count==m)
					break;
			}
			w.print(max);
			w.close();
		}
		
		private void shuffle(char[] arr)
		{
			Random ran = new Random();
			for (int i = 0; i < arr.length; i++) {
				int i1 = ran.nextInt(arr.length);
				int i2 = ran.nextInt(arr.length);

				char temp = arr[i1];
				arr[i1] = arr[i2];
				arr[i2] = temp;
			}
		}
		static class InputReader
		{
			private InputStream stream;
			private byte[] buf = new byte[1024];
			private int curChar;
			private int numChars;
			private SpaceCharFilter filter;
			
			public InputReader(InputStream stream)
			{
				this.stream = stream;
			}
			
			public int read()
			{
				if (numChars==-1) 
					throw new InputMismatchException();
				
				if (curChar >= numChars)
				{
					curChar = 0;
					try 
					{
						numChars = stream.read(buf);
					}
					catch (IOException e)
					{
						throw new InputMismatchException();
					}
					
					if(numChars <= 0)				
						return -1;
				}
				return buf[curChar++];
			}
		 
			public String nextLine()
			{
				BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
				String str = "";
				try
				{
					str = br.readLine();
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
				return str;
			}
			public int nextInt()
			{
				int c = read();
				
				while(isSpaceChar(c)) 
					c = read();
				
				int sgn = 1;
				
				if (c == '-') 
				{
					sgn = -1;
					c = read();
				}
				
				int res = 0;
				do 
				{
					if(c<'0'||c>'9') 
						throw new InputMismatchException();
					res *= 10;
					res += c - '0';
					c = read();
				}
				while (!isSpaceChar(c)); 
				
				return res * sgn;
			}
			
			public long nextLong() 
			{
				int c = read();
				while (isSpaceChar(c))
					c = read();
				int sgn = 1;
				if (c == '-') 
				{
					sgn = -1;
					c = read();
				}
				long res = 0;
				
				do 
				{
					if (c < '0' || c > '9')
						throw new InputMismatchException();
					res *= 10;
					res += c - '0';
					c = read();
				}
				while (!isSpaceChar(c));
					return res * sgn;
			}
			
			public double nextDouble() 
			{
				int c = read();
				while (isSpaceChar(c))
					c = read();
				int sgn = 1;
				if (c == '-') 
				{
					sgn = -1;
					c = read();
				}
				double res = 0;
				while (!isSpaceChar(c) && c != '.') 
				{
					if (c == 'e' || c == 'E')
						return res * Math.pow(10, nextInt());
					if (c < '0' || c > '9')
						throw new InputMismatchException();
					res *= 10;
					res += c - '0';
					c = read();
				}
				if (c == '.') 
				{
					c = read();
					double m = 1;
					while (!isSpaceChar(c)) 
					{
						if (c == 'e' || c == 'E')
							return res * Math.pow(10, nextInt());
						if (c < '0' || c > '9')
							throw new InputMismatchException();
						m /= 10;
						res += (c - '0') * m;
						c = read();
					}
				}
				return res * sgn;
			}
			
			public String readString() 
			{
				int c = read();
				while (isSpaceChar(c))
					c = read();
				StringBuilder res = new StringBuilder();
				do 
				{
					res.appendCodePoint(c);
					c = read();
				} 
				while (!isSpaceChar(c));
				
				return res.toString();
			}
		 
			public boolean isSpaceChar(int c) 
			{
				if (filter != null)
					return filter.isSpaceChar(c);
				return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
			}
		 
			public String next() 
			{
				return readString();
			}
			
			public interface SpaceCharFilter 
			{
				public boolean isSpaceChar(int ch);
			}
		}
	 
		static class Pair implements Comparable<Pair>
		{
			int a;
			int b;
			String str;
			public Pair(int a,int b)
			{
				this.a=a;
				this.b=b;
				str=min(a,b)+" "+max(a,b);
			}
	 
			public int compareTo(Pair pair)
			{
				if(Integer.compare(a,pair.a)==0)
					return Integer.compare(b,pair.b);
	 
				return Integer.compare(a,pair.a);
			}
		}
	 
		
	}