package java_8.problem_758B.subId_27662369;

import java.util.Scanner;
import java.io.*;
import java.util.*;
import java.math.*;
import java.lang.*;
import static java.lang.Math.*;

public class main implements Runnable{

    static LinkedList <Integer> adj[];
    static int co=0,f=0;

    static void Check2(int n){
        adj=new LinkedList[n+1];
        for(int i=0;i<=n;i++){
            adj[i]=new LinkedList();
        }

    }
    static void add(int i,int j){
        adj[i].add(j);
    }
    public static void main(String[] args) throws Exception {
        new Thread(null, new main(), "Check2", 1<<26).start();// to increse stack size in java
    }
    static long mod=(long)(1e9+7);
    static  int r,g,y,b;
    static long le[];
    public void run(){
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        //Scanner in=new Scanner(System.in);
        InputReader in=new InputReader(System.in);
        PrintWriter w=new PrintWriter(System.out);


        String s=in.next();
        char c[]=s.toCharArray();
        int a[]=new int[4];

        int n=c.length;
        if(n==4){
            r=0;
            b=0;
            y=0;
            g=0;
            for(int i=0;i<n;i++){
                ch(c[i]);
            }


            if(r==0)a[0]++;
            if(b==0)a[1]++;
            if(y==0)a[2]++;
            if(g==0)a[3]++;

        }

        else {
            for (int i = 0; i <= n - 4; i++) {
                r = 0;
                b = 0;
                g = 0;
                y = 0;
                int j = 0;
                if (c[i] == '!') j = i;
                if (c[i + 1] == '!') j = i + 1;
                if (c[i + 2] == '!') j = i + 2;
                if (c[i + 3] == '!') j = i + 3;
                ch(c[i]);
                ch(c[i + 1]);
                ch(c[i + 2]);
                ch(c[i + 3]);

                if (r + b + g + y == 3) {

                    if (r + b + g == 3) {
                        a[2]++;
                        c[j] = 'Y';
                    }
                    if (r + y + g == 3) {
                        a[1]++;
                        c[j] = 'B';
                    }
                    if (r + b + y == 3) {
                        a[3]++;
                        c[j] = 'G';
                    }
                    if (y + b + g == 3) {
                        a[0]++;
                        c[j] = 'R';
                    }


                }

            }

            for (int i = n - 1; i >= 3; i--) {
                r = 0;
                b = 0;
                g = 0;
                y = 0;
                int j = 0;
                if (c[i] == '!') j = i;
                if (c[i - 1] == '!') j = i + -1;
                if (c[i - 2] == '!') j = i - 2;
                if (c[i - 3] == '!') j = i - 3;
                ch(c[i]);
                ch(c[i - 1]);
                ch(c[i - 2]);
                ch(c[i - 3]);

                if (r + b + g + y == 3) {

                    if (r + b + g == 3) {
                        a[2]++;
                        c[j] = 'Y';
                    }
                    if (r + y + g == 3) {
                        a[1]++;
                        c[j] = 'B';
                    }
                    if (r + b + y == 3) {
                        a[3]++;
                        c[j] = 'G';
                    }
                    if (y + b + g == 3) {
                        a[0]++;
                        c[j] = 'R';
                    }


                }


            }

        }
        for (int i = 0; i < 4; i++)
            w.print(a[i] + " ");

        w.close();
    }

    static  void ch(char d){

        if(d=='R')r++;
        if(d=='G')g++;
        if(d=='B')b++;
        if(d=='Y')y++;


    }
   /* static void dfs(int i,int lvl,int v[]){



        v[i]=1;
        //   System.out.println(i);
        le[1]=(long)(le[1])+1l;
        if(lvl+1<=n){
            le[lvl+1]-=1l;
        }
        Iterator <Integer> ne=adj[i].iterator();
        while(ne.hasNext()){
            int k=ne.next();

            if(v[k]==0){
                v[k]=1;
                dfs(k,lvl+1,v);
            }


        }


    }*/
    static class node{

        int y;
        int val;

        node(int a,int b){

            y=a;
            val=b;

        }


    }
    static  void rec(String s,int a,int b,int n){

        if(b==n){
            System.out.println(s);
            return ;
        }
        String p=s;
        if(a>b){
            s=p+")" ;
            rec(s,a,b+1,n);
        }
        if(a<n){
            s=p+"(";
            rec(s,a+1,b,n);
        }




    }

    static class InputReader
    {
        private InputStream stream;
        private byte[] buf = new byte[1024];
        private int curChar;
        private int numChars;
        private SpaceCharFilter filter;

        public InputReader(InputStream stream)
        {
            this.stream = stream;
        }

        public int read()
        {
            if (numChars==-1)
                throw new InputMismatchException();

            if (curChar >= numChars)
            {
                curChar = 0;
                try
                {
                    numChars = stream.read(buf);
                }
                catch (IOException e)
                {
                    throw new InputMismatchException();
                }

                if(numChars <= 0)
                    return -1;
            }
            return buf[curChar++];
        }

        public String nextLine()
        {
            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
            String str = "";
            try
            {
                str = br.readLine();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
            return str;
        }
        public int nextInt()
        {
            int c = read();

            while(isSpaceChar(c))
                c = read();

            int sgn = 1;

            if (c == '-')
            {
                sgn = -1;
                c = read();
            }

            int res = 0;
            do
            {
                if(c<'0'||c>'9')
                    throw new InputMismatchException();
                res *= 10;
                res += c - '0';
                c = read();
            }
            while (!isSpaceChar(c));

            return res * sgn;
        }

        public long nextLong()
        {
            int c = read();
            while (isSpaceChar(c))
                c = read();
            int sgn = 1;
            if (c == '-')
            {
                sgn = -1;
                c = read();
            }
            long res = 0;

            do
            {
                if (c < '0' || c > '9')
                    throw new InputMismatchException();
                res *= 10;
                res += c - '0';
                c = read();
            }
            while (!isSpaceChar(c));
            return res * sgn;
        }

        public double nextDouble()
        {
            int c = read();
            while (isSpaceChar(c))
                c = read();
            int sgn = 1;
            if (c == '-')
            {
                sgn = -1;
                c = read();
            }
            double res = 0;
            while (!isSpaceChar(c) && c != '.')
            {
                if (c == 'e' || c == 'E')
                    return res * Math.pow(10, nextInt());
                if (c < '0' || c > '9')
                    throw new InputMismatchException();
                res *= 10;
                res += c - '0';
                c = read();
            }
            if (c == '.')
            {
                c = read();
                double m = 1;
                while (!isSpaceChar(c))
                {
                    if (c == 'e' || c == 'E')
                        return res * Math.pow(10, nextInt());
                    if (c < '0' || c > '9')
                        throw new InputMismatchException();
                    m /= 10;
                    res += (c - '0') * m;
                    c = read();
                }
            }
            return res * sgn;
        }

        public String readString()
        {
            int c = read();
            while (isSpaceChar(c))
                c = read();
            StringBuilder res = new StringBuilder();
            do
            {
                res.appendCodePoint(c);
                c = read();
            }
            while (!isSpaceChar(c));

            return res.toString();
        }

        public boolean isSpaceChar(int c)
        {
            if (filter != null)
                return filter.isSpaceChar(c);
            return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
        }

        public String next()
        {
            return readString();
        }

        public interface SpaceCharFilter
        {
            public boolean isSpaceChar(int ch);
        }
    }







}