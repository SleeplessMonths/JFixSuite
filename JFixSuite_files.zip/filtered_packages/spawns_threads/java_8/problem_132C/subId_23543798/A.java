package java_8.problem_132C.subId_23543798;

import java.io.*;
import java.util.Locale;
import java.util.StringTokenizer;

public class A implements Runnable {

    private static final boolean ONLINE_JUDGE = System.getProperty("ONLINE_JUDGE") != null;

    private BufferedReader in;
    private PrintWriter out;
    private StringTokenizer tok = new StringTokenizer("");

    private void init() throws FileNotFoundException {
        Locale.setDefault(Locale.US);
        String fileName = "";
        if (ONLINE_JUDGE && fileName.isEmpty()) {
            in = new BufferedReader(new InputStreamReader(System.in));
            out = new PrintWriter(System.out);
        } else {
            if (fileName.isEmpty()) {
                in = new BufferedReader(new FileReader("input.txt"));
                out = new PrintWriter("output.txt");
            } else {
                in = new BufferedReader(new FileReader(fileName + ".in"));
                out = new PrintWriter(fileName + ".out");
            }
        }
    }

    String readString() {
        while (!tok.hasMoreTokens()) {
            try {
                tok = new StringTokenizer(in.readLine());
            } catch (Exception e) {
                return null;
            }
        }
        return tok.nextToken();
    }

    int readInt() {
        return Integer.parseInt(readString());
    }

    long readLong() {
        return Long.parseLong(readString());
    }

    double readDouble() {
        return Double.parseDouble(readString());
    }

    int[] readIntArray(int size) {
        int[] a = new int[size];
        for (int i = 0; i < size; i++) {
            a[i] = readInt();
        }
        return a;
    }

    public static void main(String[] args) {
        //new Thread(null, new A(), "", 128 * (1L << 20)).start();
        new A().run();
    }

    long timeBegin, timeEnd;

    void time() {
        timeEnd = System.currentTimeMillis();
        System.err.println("Time = " + (timeEnd - timeBegin));
    }

    @Override
    public void run() {
        try {
            timeBegin = System.currentTimeMillis();
            init();
            solve();
            out.close();
            time();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }
    }

    final int OFFSET = 100;
    final int MAX_ANSWER = 200;

    void solve() throws IOException {
        char[] s = readString().toCharArray();
        int n = readInt();
        boolean[][][][] dp = new boolean[s.length + 1][n + 1][2][MAX_ANSWER + 1];
        dp[0][0][0][OFFSET] = true;
        for (int i = 1; i <= s.length; i++) {
            for (int j = 0; j < n; j++) {
                for (int d = 0; d < MAX_ANSWER; d++) {
                    if (dp[i - 1][j][0][d]) {
                        if (s[i - 1] == 'T') {
                            for (int changes = j; changes <= n; changes++) {
                                if (j % 2 == changes % 2) {
                                    dp[i][changes][1][d] = true;
                                } else {
                                    dp[i][changes][0][d + 1] = true;
                                }
                            }
                        } else {
                            for (int changes = j; changes <= n; changes++) {
                                if (j % 2 == changes % 2) {
                                    dp[i][changes][0][d + 1] = true;
                                } else {
                                    dp[i][changes][1][d] = true;
                                }
                            }
                        }
                    }

                    if (dp[i - 1][j][1][d]) {
                        if (s[i - 1] == 'T') {
                            for (int changes = j; changes <= n; changes++) {
                                if (j % 2 == changes % 2) {
                                    dp[i][changes][0][d] = true;
                                } else {
                                    dp[i][changes][1][d - 1] = true;
                                }
                            }
                        } else {
                            for (int changes = j; changes <= n; changes++) {
                                if (j % 2 == changes % 2) {
                                    dp[i][changes][1][d - 1] = true;
                                } else {
                                    dp[i][changes][0][d] = true;
                                }
                            }
                        }
                    }
                }
            }
        }
        int answer = 0;
        for (int d = 0; d <= MAX_ANSWER; d++) {
            if (dp[s.length][n][0][d] || dp[s.length][n][1][d]) {
                answer = Math.max(answer, Math.abs(OFFSET - d));
            }
        }
        out.println(answer);
    }
}