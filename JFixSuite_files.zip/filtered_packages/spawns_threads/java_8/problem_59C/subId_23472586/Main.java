package java_8.problem_59C.subId_23472586;

import java.io.*;
import java.math.BigInteger;
import java.util.*;


 public class Main {
	public static InputReader in;
    public static PrintWriter pw;



	public static void main(String args[]) {
		new Thread(null, new Runnable() {
            public void run() {
                try{
                    solve();
                }
                catch(Exception e){
                    e.printStackTrace();
                }
            }
        }, "1", 1 << 26).start();
    }
	static TreeSet<Integer> set;
	static ArrayList<Pair> g[];
	static boolean visited[];
	static long edje=0;
    static boolean vis[];
	static int parent[];
	static int col[];
	static boolean[] vis1;
	static int Ans=0;
	static int min=Integer.MAX_VALUE;
	static int val[];
	static int degree[];
	static int a[];
	static int f[];
	static  long total=0;
	static HashSet<String> s;
	static int distance[];
	public static void solve(){
	
		 in = new InputReader(System.in);
		 pw = new PrintWriter(System.out);
	     int k=in.nextInt();
	     String s=in.readString();
	     char a[]=s.toCharArray();
	     for(int i=0;i<(s.length()/2);i++)
	     {
	    	 if(a[i]!=a[s.length()-1-i]&&a[i]!='?'&&a[s.length()-1-i]!='?')
	    	 {
	    		 System.out.println("IMPOSSIBLE");
	    		 System.exit(0);
	    	 }
	     }
	     for(int i=0;i<s.length();i++)
	     {
	    	 if(a[i]!='?')
	    	 {
	    		 if((a[i]-'a')>k)
	    		 {
	    			 System.out.println("IMPOSSIBLE");
		    		 System.exit(0);
	    		 }
	    	 }
	     }
	     int Que=0;
	     for(int i=0;i<(s.length());i++)
	     {
	    	 if(a[i]=='?')
	    		 Que++;
	     }
	     if(Que==0)
	     {
	    	 StringBuilder sb=new StringBuilder(s);
	    	 if(sb.reverse().toString().equals(s))
	    	 {
	    		 int p=0;
	    		 boolean bool[]=new boolean[26];
	    		 for(int i=0;i<s.length();i++)
	    		 {
	    			 if((a[i]-'a')<k&&!bool[a[i]-'a']){
	    				 p++;bool[a[i]-'a']=true;
	    			 }
	    		 }
	    		 if(p==k)
	    		 {
	    			 System.out.println(s);
	    		 }
	    		 else
	    			 System.out.println("IMPOSSIBLE");
	    		 System.exit(0);
	    	 }
	    	 else
	    		 System.out.println("IMPOSSIBLE");
	    	 System.exit(0);
	     }
	     if(s.length()%2==0)
	     {
	     boolean ar[]=new boolean[26];	 
	     int Used=0;
	     for(int i=0;i<s.length();i++)
	     {
	    	   if(a[i]=='?'&&a[s.length()-1-i]!='?')
	    	   {
	    		   a[i]=a[s.length()-1-i];
	    		   
	    		   if(!ar[a[s.length()-1-i]-'a'])
	    		   {
	    		   ar[a[s.length()-1-i]-'a']=true;
	    		   Used++;
	    		   }
	    	   }
	    	   else if(a[s.length()-1-i]=='?'&&a[i]!='?')
	    	   {
	    		   
	    		   a[s.length()-1-i]=a[i];
	    		   if(!ar[a[i]-'a'])
	    		   {
	    		   ar[a[i]-'a']=true;
	    		   Used++;
	    		   }
	    	   }
	    	   else if(a[i]!='?')
	    	   {
	    		   ar[a[i]-'a']=true;
	    	   }
	     }
	     TreeSet<Character> st=new TreeSet<Character>();
	     for(char c='a';c<('a'+k);c++)
	     {
	    	 if(!ar[c-'a'])
	    		 st.add(c);
	     }
	     for(int i=((s.length()/2)-1);i>=0;i--)
	     {
	    	 if(a[i]=='?'&&a[s.length()-1-i]=='?')
	    	 {
	    		 a[i]=st.last();
	    		 a[s.length()-1-i]=st.last();
	    		 st.remove(st.last());
	    	 }
	    	 if(st.size()==0)
	    		 break;
	     }
	     for(int i=0;i<s.length();i++)
	     {
	    	 if(a[i]=='?'&&a[s.length()-1-i]=='?')
	    	 {
	    		 a[i]='a';
	    		 a[s.length()-1-i]='a';
	    	 }
	     }
	     HashSet<Character> set=new HashSet<Character>();
	     for(int i=0;i<s.length();i++)
	     {
	    	 if((a[i]-'a')<k)
	    		 set.add(a[i]);
	     }
	     if(set.size()==k)
	     System.out.println(new String(a));
	     else
	    	 System.out.println("IMPOSSIBLE");
	     System.exit(0);
	     }
	     else
	     {
	    	// System.out.println("ODD");
	    	 boolean ar[]=new boolean[26];	 
		     int Used=0;
		     for(int i=0;i<(s.length()/2);i++)
		     {
		    	   if(a[i]=='?'&&a[s.length()-1-i]!='?')
		    	   {
		    		   a[i]=a[s.length()-1-i];
		    		   
		    		   if(!ar[a[s.length()-1-i]-'a'])
		    		   {
		    		   ar[a[s.length()-1-i]-'a']=true;
		    		   Used++;
		    		   }
		    	   }
		    	   else if(a[s.length()-1-i]=='?'&&a[i]!='?')
		    	   {
		    		   
		    		   a[s.length()-1-i]=a[i];
		    		   if(!ar[a[i]-'a'])
		    		   {
		    		   ar[a[i]-'a']=true;
		    		   Used++;
		    		   }
		    	   }
		    	   else if(a[i]!='?')
		    	   {
		    		   ar[a[i]-'a']=true;
		    	   }
		     }
		     TreeSet<Character> st=new TreeSet<Character>();
		     for(char c='a';c<('a'+k);c++)
		     {
		    	 if(!ar[c-'a'])
		    		 st.add(c);
		     }
		     if(a[s.length()/2]=='?'&&st.size()>0)
		     {
		    	 a[s.length()/2]=st.last();
		    	 st.remove(st.last());
		     }
		     for(int i=((s.length()/2)-1);i>=0;i--)
		     {
		    	 if(a[i]=='?'&&a[s.length()-1-i]=='?')
		    	 {
		    		 a[i]=st.last();
		    		 a[s.length()-1-i]=st.last();
		    		 st.remove(st.last());
		    	 }
		    	 if(st.size()==0)
		    		 break;
		     }
		     
		     for(int i=0;i<s.length();i++)
		     {
		    	 if(a[i]=='?'&&a[s.length()-1-i]=='?')
		    	 {
		    		 a[i]='a';
		    		 a[s.length()-1-i]='a';
		    	 }
		     }
		     HashSet<Character> set=new HashSet<Character>();
		     for(int i=0;i<s.length();i++)
		     {
		    	 if((a[i]-'a')<k)
		    		 set.add(a[i]);
		     }
		     if(set.size()==k)
		     System.out.println(new String(a));
		     else
		    	 System.out.println("IMPOSSIBLE");
		    
		     System.exit(0);

	     }
    }

	/*public static void dfs(int curr)
	{
		vis[curr]=true;
		int trees=0;
		for(int x:g[curr])
		{
			if(!vis[x]&&x!=1)
			{
			trees++;
			if(!s.contains(curr+" "+x))
				total+=cost[curr][x];
			dfs(x);
			}
	    }
		if(trees==0)
		{
			if(!s.contains(curr+" "+1))
				total+=cost[1][curr];
		}
	}
	public static void dfs1(int curr,int parent)
	{
	val[curr]=a[curr];
	for(int x:g[curr])
	{
	       if(x!=parent)
	       {
	    	   dfs1(x,curr);
	    	   val[curr]+=val[x];
	      }
	
	}
	}
	public static void dfs2(int curr,int parent)
	{
		f[curr]=val[curr];
		for(int x:g[curr])
		{
			if(x!=parent)
			{
				dfs2(x,curr);
				f[curr]+=f[x];
			}
		}
	}
	
	
	 
/*    public static void dfs2(int curr)
    {
    if(st[col[curr]].isEmpty())
    {
    ans[curr]=-1;	
    }
    else
    {
    	ans[curr]=st[col[curr]].peek();
    }
    st[col[curr]].push(curr);
    for(int x:g[curr])
    {
    	dfs2(x);
    }
    st[col[curr]].pop();
    	
    }
    
  
	public static void dfs1(int curr)
	{
		visited[curr]=true;
		for(int next:g[curr])
		{
			edje++;
			if(!visited[next])
				dfs1(next);
		}
	}
	
	public static void dfs(int curr,int prev)
		{
		val[curr]=1;
			for(int x:g[curr])
			{
				if(x!=prev)
				{
		            dfs(x,curr);
		            val[curr]+=val[x];
					
			    }
			}
		}*/
	
		public static long power(long a,long b)
		{
			long result=1;
			while(b>0)
			{
				if(b%2==1)
					result*=a;
				a=a*a;
				b/=2;
			}
			return result;
		}
				public static long pow(long n,long p,long m)
	{
		 long  result = 1;
		  if(p==0)
		    return 1;
		if (p==1)
		    return n;
		while(p!=0)
		{
		    if(p%2==1)
		        result *= n;
		    if(result>=m)
		    result%=m;
		    p >>=1;
		    n*=n;
		    if(n>=m)
		    n%=m;
		}
		return result;
	}
	static class Pair implements Comparable<Pair>{
	int fir;
		int sec;
		Pair(int mr,int i){
	     	fir=mr;
			sec=i;
			
		}
		@Override
		public int compareTo(Pair o) {
		//	if(o.val<this.val)
		
			return 1;
			
			//else 
				//return -1;
			
			}
		
	}
	public static long gcd(long a, long b) {
		  if (b == 0) return a;
		  return gcd(b, a%b);
		}
	static class InputReader {
 
		private InputStream stream;
		private byte[] buf = new byte[8192];
		private int curChar, snumChars;
		private SpaceCharFilter filter;
 
		public InputReader(InputStream stream) {
			this.stream = stream;
		}
 
		public int snext() {
			if (snumChars == -1)
				throw new InputMismatchException();
			if (curChar >= snumChars) {
				curChar = 0;
				try {
					snumChars = stream.read(buf);
				} catch (IOException e) {
					throw new InputMismatchException();
				}
				if (snumChars <= 0)
					return -1;
			}
			return buf[curChar++];
		}
 
		public   int nextInt() {
			int c = snext();
			while (isSpaceChar(c))
				c = snext();
			int sgn = 1;
			if (c == '-') {
				sgn = -1;
				c = snext();
			}
			int res = 0;
			do {
				if (c < '0' || c > '9')
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = snext();
			} while (!isSpaceChar(c));
			return res * sgn;
		}
 
		public long nextLong() {
			int c = snext();
			while (isSpaceChar(c))
				c = snext();
			int sgn = 1;
			if (c == '-') {
				sgn = -1;
				c = snext();
			}
			long res = 0;
			do {
				if (c < '0' || c > '9')
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = snext();
			} while (!isSpaceChar(c));
			return res * sgn;
		}
 
		public int[] nextIntArray(int n) {
			int a[] = new int[n];
			for (int i = 0; i < n; i++)
				a[i] = nextInt();
			return a;
		}
 
		public String readString() {
			int c = snext();
			while (isSpaceChar(c))
				c = snext();
			StringBuilder res = new StringBuilder();
			do {
				res.appendCodePoint(c);
				c = snext();
			} while (!isSpaceChar(c));
			return res.toString();
		}
 
		public boolean isSpaceChar(int c) {
			if (filter != null)
				return filter.isSpaceChar(c);
			return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
		}
 
		public interface SpaceCharFilter {
			public boolean isSpaceChar(int ch);
		}
	}
}