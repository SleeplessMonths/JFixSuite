package java_8.problem_770A.subId_25783533;

import java.io.OutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;
import java.util.stream.Stream;
import java.util.concurrent.ThreadLocalRandom;
import java.util.Collection;
import java.util.Scanner;
import java.util.ArrayList;

/**
 * Built using CHelper plug-in
 * Actual solution is at the top
 *
 * @author vsocolov
 */
public class Main {
    public static void main(String[] args) {
        InputStream inputStream = System.in;
        OutputStream outputStream = System.out;
        Scanner in = new Scanner(inputStream);
        PrintWriter out = new PrintWriter(outputStream);
        TaskA solver = new TaskA();
        solver.solve(1, in, out);
        out.close();
    }

    static class TaskA {
        public void solve(int testNumber, Scanner in, PrintWriter out) {
            final int passwordLength = in.nextInt();//nr of members
            final int nrDistinctSymbols = in.nextInt();//nr of pairs

            final List<Character> distinctSymbols = new ArrayList<>();
            for (int i = 0; i < nrDistinctSymbols; i++) {
                int randomNum;
                do {
                    randomNum = ThreadLocalRandom.current().nextInt(97, 123);//lowercase characters in ASCII table
                }
                while (distinctSymbols.contains((char) randomNum));

                distinctSymbols.add((char) randomNum);
            }

            int nrNonDistinctSymbols = passwordLength - nrDistinctSymbols;

            if (nrNonDistinctSymbols <= nrDistinctSymbols) {
                for (int i = 0; i < nrNonDistinctSymbols; i++) {
                    distinctSymbols.add(distinctSymbols.get(i));
                }
            } else {
                for (int i = 0; i < nrDistinctSymbols; i++) {
                    distinctSymbols.add(distinctSymbols.get(i));
                }

                int remaining = nrNonDistinctSymbols % nrDistinctSymbols;
                for (int i = 0; i < remaining; i++) {
                    distinctSymbols.add(distinctSymbols.get(i));
                }
            }

            out.println(distinctSymbols.stream().map(Object::toString).reduce("", (n1, n2) -> n1 + n2));
        }

    }
}