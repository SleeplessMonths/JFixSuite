package java_8.problem_106A.subId_25439931;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class Solution implements Runnable {
  BufferedReader in;
  PrintWriter out;
  StringTokenizer tok = new StringTokenizer("");

  @Override
  public void run() {
    try {
      init();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    long time = System.currentTimeMillis();
    try {
      solve();
    } catch (Exception e) {
      e.printStackTrace();
    }
    out.close();
    System.err.println(System.currentTimeMillis() - time);
  }

  private void init() throws FileNotFoundException {
    String file = "";
    if (!file.equals("")) {
      in = new BufferedReader(new FileReader("input.txt"));
      out = new PrintWriter("output.txt");
    } else {
      in = new BufferedReader(new InputStreamReader(System.in));
      out = new PrintWriter(System.out);
    }
  }

  public static void main(String[] args) {
    new Thread(new Solution()).start();
  }

  private String readString() {
    while (!tok.hasMoreTokens()) {
      try {
        tok = new StringTokenizer(in.readLine());
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    return tok.nextToken();
  }

  private int readInt() {
    return Integer.parseInt(readString());
  }

  private long readLong() {
    return Long.parseLong(readString());
  }

  private void solve() {
    char[] base = new char[]{'6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A'};
    char c = readString().toCharArray()[0];
    char[] first = readString().toCharArray();
    char[] second = readString().toCharArray();
    int posFirst = 0;
    int posSecond = 0;
    for (int i = 0; i < base.length; i++) {
      if(base[i]==first[0]) posFirst = i;
      if(base[i]==second[0]) posSecond = i;
    }
    if(first[1]==second[1] && posFirst>posSecond) {
      out.print("YES");
      return;
    }
    if(c==first[1]) {
      out.print("YES");
      return;
    }
    out.print("NO");
  }


}