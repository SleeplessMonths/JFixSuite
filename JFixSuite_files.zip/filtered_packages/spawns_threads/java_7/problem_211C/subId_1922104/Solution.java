package java_7.problem_211C.subId_1922104;

import java.io.*; 
import java.util.*;
import java.math.*;
import java.awt.geom.*;

import static java.lang.Math.*;

public class Solution implements Runnable {
	

	public void solve () throws Exception {
		char c [] = nextToken().toCharArray();
		
		int n = c.length;
		
		int e [] = new int [n];
		for (int i = 0; i < n; i++) {
			if (c[i] == 'B') e [i] = 1;
		}
		
		long d [][][][][] = new long [n + 1][2][2][2][2];
		
		if (c[0] == 'A') {
			d[1][0][0][0][0] = 1;
			d[1][0][1][1][1] = 1;
		} else {
			d[1][0][1][0][1] = 1;
			d[1][0][0][1][0] = 1;
		}
		
		long res = 0;
		
		for (int i = 1; i < n; i++) {
			for (int first = 0; first < 2; first++) {
				for (int last = 0; last < 2; last++) {
					for (int matchedLast = 0; matchedLast < 2; matchedLast++) {
						for (int invertedFirst = 0; invertedFirst < 2; invertedFirst++) {
							if (d[i][invertedFirst][first][last][matchedLast] == 0) continue;
							if (i == 1) {
								if (last == 0) {
									// put 0
									if (e[i] != 0) {
										d[i + 1][invertedFirst][first][0][1] += d[i][invertedFirst][first][last][matchedLast];
									} else {
										d[i + 1][invertedFirst][first][0][0] += d[i][invertedFirst][first][last][matchedLast];
									}
									
									// put 1
									if (e[1] == 0 && first == 1) {
										d[i + 1][1][0][1][0] += d[i][invertedFirst][first][last][matchedLast];
									}
									
								} else {
									// put 0
									if (e[i] != 0) {
										d[i + 1][invertedFirst][first][0][1] += d[i][invertedFirst][first][last][matchedLast];
									} else {
										d[i + 1][invertedFirst][first][0][0] += d[i][invertedFirst][first][last][matchedLast];
									}
									// put 1
									if (e[i] != 1) {
										d[i + 1][invertedFirst][first][1][1] += d[i][invertedFirst][first][last][matchedLast];
									} else {
										d[i + 1][invertedFirst][first][1][0] += d[i][invertedFirst][first][last][matchedLast];
									}
								}
							} else if (i != n - 1) {
								if (matchedLast == 0) { // yes
									
									// put 0
									if (e[i] == 1) {
										d[i + 1][invertedFirst][first][0][1] += d[i][invertedFirst][first][last][matchedLast];
									} else {
										d[i + 1][invertedFirst][first][0][0] += d[i][invertedFirst][first][last][matchedLast];
									}
									
									// put 1
									if (last == 1) {
										if (e[i] == 0) {
											//d[i + 1][first][1][1] += d[i][first][last][matchedLast];
										} else {
											d[i + 1][invertedFirst][first][1][0] += d[i][invertedFirst][first][last][matchedLast];
										}
									}
									
								} else { // no
									
									// put 1
									if (last == 0 && e[i] == 0) {
										d[i + 1][invertedFirst][first][1][0] += d[i][invertedFirst][first][last][matchedLast];
									}
								}
							} else {
								if (matchedLast == 0) { // yes
									
									// put 0
									if (first == 0) {
										if ((e[0] == 0 && e[i] == 0 && invertedFirst == 0) || (invertedFirst == 1)) {
											res += d[i][invertedFirst][first][last][matchedLast];
										}
									} else {
										if (e[0] == 0 && e[i] == 1) {
											res += d[i][invertedFirst][first][last][matchedLast];
										}
									}
									
									// put 1
									if (first == 0 && last != 0 && e[i] == 1) {
										res += d[i][invertedFirst][first][last][matchedLast];
									}
									
								} else { // no
									
									// put 1
									if (first == 0 && e[i] == 0 && last == 0) {
										res += d[i][invertedFirst][first][last][matchedLast];
									}
								}
							}
						}
					}
				}
			}
		}
		
		out.println(res);
		
	}
	
	static final String fname = "";
	static long stime = 0;
	
	BufferedReader in;
	PrintWriter out;
	StringTokenizer st;
	
	private String nextToken () throws Exception {
		while (st == null || !st.hasMoreTokens()) {
			st = new StringTokenizer(in.readLine());
		}
		return st.nextToken();
	}
	
	private int nextInt () throws Exception {
		return Integer.parseInt(nextToken());
	}
	
	private long nextLong () throws Exception {
		return Long.parseLong(nextToken());
	}
	
	private double nextDouble () throws Exception {
		return Double.parseDouble(nextToken());
	}
	
	@Override
	public void run() {
		try {
			in = new BufferedReader(new InputStreamReader(System.in));
			out = new PrintWriter(System.out);
			solve ();
		} catch (Exception e) {
			throw new RuntimeException(e);
		} finally {
			out.close();
		}
	}
	
	public static void main(String[] args) {
		new Thread(null, new Solution(), "", 1<<26).start();
	}

}