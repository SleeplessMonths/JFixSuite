package java_7.problem_293C.subId_3607633;

import java.io.*;

import static java.lang.Math.*;
import java.util.*;
import static java.util.Arrays.fill;
import static java.util.Arrays.sort;

public class Main {
	public static void main(String[] args) {
		if(new File("input.txt").exists())
			try {
				System.setIn(new FileInputStream("input.txt"));
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		new Thread(null, new Runnable() {
			public void run() {
				try {
					new Main().run();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}, "kek", 1 << 23).start();
	}

	BufferedReader in;
	PrintWriter out;
	StringTokenizer st = new StringTokenizer("");
	
	
	void run() throws IOException {
		in = new BufferedReader(new InputStreamReader(System.in));
		out = new PrintWriter(System.out);
		Locale.setDefault(Locale.US);
//		long t = System.currentTimeMillis();
		solve();
//		System.err.println(System.currentTimeMillis() - t);
		in.close();
		out.close();
	}

	long prev[];
	
	void solve() throws IOException{
		long r = nextLong();
		if(r % 3 != 0) {
			out.println(0);
			return;
		}
		long n = r / 3;
		long ans = 0;
		for(long x = 1; x * x * x < n; x++){
			if(n % x == 0){
				for(long a = 1; a <= x / 2 ; a++){
					long b = x - a;
					long f = a + b;
					long e = a * b - n / (a + b);
					long D = f * f - 4 * e;
					double z = sqrt(D);
					z = (-f + z) / 2;
					long c = Math.round(z);
					if(c <= 0 || (a + b) > (a + c) || (a + b) > (b + c) || (a + c) > (b + c)) continue;
					
					if( (a + b) * (a + c) * (b + c) == n){
						int k = 0;
						if(a != b) k++;
						if(a != c) k++;
						if(b != c) k++;
						if(k == 0)
							ans += 1;
						if(k == 2){
							ans += 3;
						}
						if(k == 3){
							ans += 6;
						}
					}
				}
			}
		}
		out.println(ans);
	}

	
	
	
	
	String nextToken() throws IOException{
		while(!st.hasMoreTokens())
			st = new StringTokenizer(in.readLine());
		return st.nextToken();
	}
	long nextLong() throws IOException{
		return Long.parseLong(nextToken());
	}
	int nextInt() throws IOException{
		return Integer.parseInt(nextToken());
	}
	double nextDouble() throws IOException{
		return Double.parseDouble(nextToken());
	}
}