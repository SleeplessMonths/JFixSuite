package java_7.problem_293C.subId_3607537;

import static java.lang.Math.*;
import static java.lang.System.currentTimeMillis;
import static java.lang.System.exit;
import static java.lang.System.arraycopy;
import static java.util.Arrays.sort;
import static java.util.Arrays.binarySearch;
import static java.util.Arrays.fill;
import java.util.*;
import java.awt.geom.QuadCurve2D;
import java.io.*;

public class Main {

	public static void main(String[] args) throws IOException {
		try {
			if (new File("input.txt").exists())
				System.setIn(new FileInputStream("input.txt"));
		} catch (SecurityException e) {
		}
		new Thread(null, new Runnable() {
			public void run() {
				try {
					long time1 = System.currentTimeMillis();
					new Main().run();
					long time2 = System.currentTimeMillis();
					System.err.println("Time " + (time2 - time1) + " ms");
				} catch (Throwable e) {
					e.printStackTrace();
					exit(999);
				}
			}
		}, "1", 1 << 23).start();
	}

	BufferedReader in;
	PrintWriter out;
	StringTokenizer st = new StringTokenizer("");

	private void run() throws IOException {
		in = new BufferedReader(new InputStreamReader(System.in));
		out = new PrintWriter(System.out);
		solve();
		in.close();
		out.close();
	}

	private void solve() throws IOException {
		long n = nextLong();
		if (n % 3 != 0) {
			out.println(0);
			return;
		}
		
		n /= 3;
		
		Set<long[]> set = new TreeSet<long[]>(new Comparator<long[]>() {

			@Override
			public int compare(long[] o1, long[] o2) {
				for (int i = 0; i < o1.length; i++)
					if (o1[i] != o2[i])
						return o1[i] < o2[i] ? -1 : 1;
				return 0;
			}
		});
		
		for (long x = 1L; x * x * x <= n; x++) {
			if (n % x != 0)
				continue;
			long m = n / x;
			for (long a = 1; 2 * a < x; a++) {
				double[] w = new double[3];
				long b = x - a;
				w[0] = a * b - m;
				w[1] = a + b;
				w[2] = 1;
				int sl = QuadCurve2D.solveQuadratic(w);
				for (int i = 0; i < sl; i++) {
					long c = (long)(w[i] + 0.001);
					if (c > 0 && (a + c) * (b + c) == m) {
						long[] q = new long[] { a, b, c };
						sort(q);
						set.add(q);
					}
				}
			}
		}
		
		long[] f = {1, 1, 3, 6};
		
		long ans = 0;
		for (long[] t : set) {
			int count = 1;
			if (t[0] != t[1])
				count++;
			if (t[1] != t[2])
				count++;
			ans += f[count];
		}
		
//		System.err.println(set.size());
//		System.err.println(ans / 39090.);
		
		out.println(ans);
	}
	
	long pw3(long a) {
		return a * a * a;
	}

	class T implements Comparable<T> {
		long a, b, c;

		public T(long... x) {
			sort(x);
			this.a = x[0];
			this.b = x[1];
			this.c = x[2];
		}

		@Override
		public int compareTo(T t) {
			int cmp1 = Long.compare(a, t.a);
			if (cmp1 != 0)
				return cmp1;
			int cmp2 = Long.compare(b, t.b);
			if (cmp2 != 0)
				return cmp2;
			return Long.compare(c, t.c);
		}
		
	}
	
	void chk(boolean b) {
		if (b)
			return;
		System.out.println(new Error().getStackTrace()[1]);
		exit(999);
	}
	void deb(String fmt, Object... args) {
		System.out.printf(Locale.US, fmt + "%n", args);
	}
	String nextToken() throws IOException {
		while (!st.hasMoreTokens())
			st = new StringTokenizer(in.readLine());
		return st.nextToken();
	}
	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}
	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}
	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}
	String nextLine() throws IOException {
		st = new StringTokenizer("");
		return in.readLine();
	}
	boolean EOF() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = in.readLine();
			if (s == null)
				return true;
			st = new StringTokenizer(s);
		}
		return false;
	}
}