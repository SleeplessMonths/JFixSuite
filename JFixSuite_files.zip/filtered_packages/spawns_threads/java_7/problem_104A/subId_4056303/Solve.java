package java_7.problem_104A.subId_4056303;

import java.awt.Point;
import java.util.regex.*;
import java.io.*;
import java.math.BigInteger;
import java.util.*;
import java.util.Map.Entry;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.omg.PortableServer.ImplicitActivationPolicyValue;

import static java.lang.Math.*;

public class Solve implements Runnable{

    
final boolean ONLINE_JUDGE = System.getProperty("ONLINE_JUDGE") != null;
    //final boolean ONLINE_JUDGE = !(System.getSecurityManager() == null); 
    
    BufferedReader in;
    static PrintWriter out;
    StringTokenizer tok = new StringTokenizer("");
    
    void init() throws FileNotFoundException{
        if (ONLINE_JUDGE){
            in=new BufferedReader(new InputStreamReader(System.in));
            out = new PrintWriter(System.out);
            
        }else{  
            in = new BufferedReader(new FileReader("input.txt"));
            out = new PrintWriter("output.txt");
           
        }
    }
    
    String readString() throws IOException{
        while(!tok.hasMoreTokens()){
            try{
                tok = new StringTokenizer(in.readLine());
            }catch (Exception e){
                return null;
            }
        }
        return tok.nextToken();
    }
    
    int readInt() throws IOException{
        return Integer.parseInt(readString());
    }
    
    long readLong() throws IOException{
        return Long.parseLong(readString());
    }
    
    double readDouble() throws IOException{
        return Double.parseDouble(readString());
    }
    
    public static void main(String[] args){
        new Thread(null, new Solve(), "", 256 * (1L << 20)).start();
    }
    
    long timeBegin, timeEnd;

    void time(){
        timeEnd = System.currentTimeMillis();
        System.err.println("Time = " + (timeEnd - timeBegin));
    }
    
    void debug(Object... objects){
        if (!ONLINE_JUDGE){
            for (Object o: objects){
                System.err.println(o.toString());
            }
        }
    }
    
    int sm(int x){
        if (x==1) return 0;else return 1;
    }
    
    static int gcd(int a,int b){
        if (b==0) return a;
        else{
            return gcd(b,a%b);
        }
    }
    
     void iMas(int[] a)throws IOException{
        int n=a.length;
        for (int i=0;i<n;i++){
            a[i]=readInt();         
        }       
    }
    void oMas(int[] a) throws IOException{
        int n=a.length;
        for (int i=0;i<n;i++){
            out.println(a[i]);
        }       
    }
    void oMas1(int[] a) throws IOException{
        int n=a.length;
        for (int i=0;i<n;i++){
            out.print(a[i]+" ");
        }       
    }
    
    
    static ArrayList<Integer>[] graph;  
    static boolean[] vis;
    static int[] ll;
    
    static void dfs(int x,int l){  
        ll[x]=l;
        vis[x]=true;
        for (int y:graph[x]){
            if (!vis[y]) {
                dfs(y,l);
            }
        }       
    }
   
    
    
    
    
    
    
    
   
    
    
    
    public void solve() throws IOException, ParseException{
        int n=readInt();
        if (n<=10 || n>22){
            out.println("0");
            return;
        }
        if (n!=20){
            out.println(4);
            return;
        }
        out.println(15);
        
        
        
        
        
        
        
        
        
        
      
        
        
        
        
    }
    
    public void run(){
        try{
            timeBegin = System.currentTimeMillis();         
            init();
            
            
            
            
            solve();
            
            out.close();
            time();
        }catch (Exception e){
            e.printStackTrace(System.err);
            System.exit(-1);
        }
    }
    
    
}