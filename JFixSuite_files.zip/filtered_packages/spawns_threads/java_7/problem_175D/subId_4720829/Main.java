package java_7.problem_175D.subId_4720829;

import javax.swing.plaf.multi.MultiTreeUI;
import java.util.*;
import java.io.*;
import java.math.BigInteger;


import static java.lang.Character.*;
import static java.lang.Math.max;
import static java.lang.Math.min;
import static java.util.Collections.*;
import static java.lang.Math.*;
import static java.util.Arrays.*;
import static java.math.BigInteger.*;

public class Main {

    void run(){
        boolean oj = System.getProperty("ONLINE_JUDGE") != null;
        try {
            if( oj ){
                br  = new BufferedReader(new InputStreamReader(System.in));
                out = new PrintWriter(new OutputStreamWriter(System.out));
            } else{
                br  = new BufferedReader(new FileReader("javanese.in"));
                out = new PrintWriter   (new FileWriter("javanese.out"));
            }
        } catch (Exception e) {
            MLE();
        }
        long tB = System.currentTimeMillis();
        solve();
//        out.println("Time: " + (System.currentTimeMillis() - tB) / 1e3);
        exit(0);
    }

    void exit( int val ){
        out.flush();
//        err.flush();
        System.exit( val );
    }

    StringTokenizer st;
    BufferedReader br;
    PrintWriter out, err;

    String next(){
        while( st==null || !st.hasMoreElements() )
            try {
                st = new StringTokenizer(br.readLine());
            } catch (Exception e) {
                return null;
            }
        return st.nextToken();
    }

    int nextInt(){ return Integer.parseInt(next()); }
    long nextLong(){ return Long.parseLong(next()); }
    double nextDouble(){ return Double.parseDouble(next()); }
    String nextLine(){
        try {
            return br.readLine();
        } catch (IOException e) {
            return null;
        }
    }

    public static void main(String[] args) {
        new Main().run();
//        new Thread( null, new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    new Main().run();
//                } catch (Exception e) {
//                    System.exit(-1);
//                }
//            }
//        }, "myThread", 1L<<30 ).run();
    }

    void TLE(){ for(;;); }

    void MLE(){
        int[][] arr = new int[1024*1024][];
        for( int i = 0; i <   1024*1024; ++i )
            arr[i] =  new int[1024*1024];
    }









    int[]
            hp = new int[2],
            dt = new int[2],
            l  = new int[2],
            r   = new int[2],
            pr  = new int[2];
    final int maxCnt = 2000;
    double ans = 0;
    double[][][] dp = new double[2][201][maxCnt+1];


    void solve(){
        for( int player = 0; player < 2; ++player ){
            hp[player] = nextInt();
            dt[player] = nextInt();
             l[player] = nextInt();
             r[player] = nextInt();
            pr[player] = nextInt();
        }
        if( pr[0]==100 ){
            out.println(0);
            return;
        }
        else if( pr[1]==100 ){
            out.println(1);
            return;
        }

        for( int p = 0; p < 2; ++p ) dp[p][hp[p]][0] = 1;

        for( int cnt = 1; cnt <= maxCnt; ++cnt ){
            for( int p = 0; p < 2; ++p ){
                double coef0 = 1.0 / (r[p^1]-l[p^1]+1) * (100-pr[p^1])*0.01;
                double coef1 = 1.0 / (r[p^1]-l[p^1]+1) * (    pr[p^1])*0.01;
                double[][] dpp = dp[p];
                for( int h = 1; h <= 200; ++h ){
                for( int x = l[p^1]; x <= r[p^1]; ++x ){
                    dpp[max(0,h-x)][cnt] += dpp[h][cnt-1] * coef0;
                    dpp[      h   ][cnt] += dpp[h][cnt-1] * coef1;
                }
                }
            }
        }

        for( int cnt0 = 1; cnt0 <= maxCnt; ++cnt0 ){
            int time = (cnt0-1)*dt[0];
            int cnt1 = time / dt[1] + 1;
            if( cnt1 <= maxCnt ){
                if( time%dt[0]==0 && time%dt[1]==0 )
                    ans += dp[1][0][cnt0] * dp[0][0][cnt1];

                for( int h = 1; h <= 200; ++h ){
                    if( 0 < dp[1][0][cnt0] * dp[0][h][cnt1] ){
                        ans += dp[1][0][cnt0] * dp[0][h][cnt1];
//                        out.printf( "cnt0,cnt1,h: %d %d %d\n", cnt0,cnt1,h );
                    }
                }
            }
        }

        out.printf( Locale.US, "%.7f\n", ans );
    }


}