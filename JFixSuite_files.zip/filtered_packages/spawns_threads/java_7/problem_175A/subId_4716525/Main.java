package java_7.problem_175A.subId_4716525;

import javax.swing.plaf.multi.MultiTreeUI;
import java.util.*;
import java.io.*;
import java.math.BigInteger;


import static java.lang.Character.*;
import static java.lang.Math.max;
import static java.lang.Math.min;
import static java.util.Collections.*;
import static java.lang.Math.*;
import static java.util.Arrays.*;
import static java.math.BigInteger.*;

public class Main {

    void run(){
        boolean oj = System.getProperty("ONLINE_JUDGE") != null;
        try {
            if( oj ){
                br  = new BufferedReader(new InputStreamReader(System.in));
                out = new PrintWriter(new OutputStreamWriter(System.out));
            } else{
                br  = new BufferedReader(new FileReader("javanese.in"));
                out = new PrintWriter   (new FileWriter("javanese.out"));
            }
        } catch (Exception e) {
            MLE();
        }
//        long tB = System.currentTimeMillis();
        solve();
//        out.println("Time: " + (System.currentTimeMillis() - tB) / 1e3);
        exit(0);
    }

    void exit( int val ){
        out.flush();
//        err.flush();
        System.exit( val );
    }

    StringTokenizer st;
    BufferedReader br;
    PrintWriter out, err;

    String next(){
        while( st==null || !st.hasMoreElements() )
            try {
                st = new StringTokenizer(br.readLine());
            } catch (Exception e) {
                return null;
            }
        return st.nextToken();
    }

    int nextInt(){ return Integer.parseInt(next()); }
    long nextLong(){ return Long.parseLong(next()); }
    double nextDouble(){ return Double.parseDouble(next()); }
    String nextLine(){
        try {
            return br.readLine();
        } catch (IOException e) {
            return null;
        }
    }

    public static void main(String[] args) {
        new Main().run();
//        new Thread( null, new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    new Main().run();
//                } catch (Exception e) {
//                    System.exit(-1);
//                }
//            }
//        }, "myThread", 1L<<30 ).run();
    }

    void TLE(){ for(;;); }

    void MLE(){
        int[][] arr = new int[1024*1024][];
        for( int i = 0; i <   1024*1024; ++i )
            arr[i] =  new int[1024*1024];
    }












    void solve(){
        String s = next();
        int ans = -1;
        if( s == null ) MLE();
        for( int l0 = 1; l0 < min(9,s.length()); ++l0 )
        for( int l1 = 1; l1 < min(9,s.length()); ++l1 )
        for( int l2 = 1; l2 < min(9,s.length()); ++l2 )
            if( l0 + l1 + l2 == s.length() ){
                int a = Integer.parseInt(s.substring(0 ,l0));
                int b = Integer.parseInt(s.substring(l0,l0+l1));
                int c = Integer.parseInt(s.substring(l0+l1));
                if(
                    s.charAt(0    )=='0'&&1<l0 ||
                    s.charAt(l0   )=='0'&&1<l1 ||
                    s.charAt(l0+l1)=='0'&&1<l2 ||
                    a < 1_000_000 ||
                    b < 1_000_000 ||
                    c < 1_000_000
                ) continue;

                ans = max( ans, a + b + c );
            }
        out.println(ans);
    }

}