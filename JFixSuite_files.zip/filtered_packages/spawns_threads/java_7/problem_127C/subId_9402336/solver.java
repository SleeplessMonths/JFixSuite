package java_7.problem_127C.subId_9402336;

import java.awt.*;
import java.io.*;
import java.math.*;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;

import static java.lang.Math.*;

public class solver implements Runnable {
    final boolean ONLINE_JUDGE = System.getProperty("ONLINE_JUDGE") != null;
    BufferedReader in;
    PrintWriter out;
    StringTokenizer tok = new StringTokenizer("");
    String delim = " ";

    String readString() throws IOException {
        try {
            while (!tok.hasMoreTokens()) {
                tok = new StringTokenizer(in.readLine());
            }
            return tok.nextToken(delim);
        } catch (Exception e) {
            return null;
        }
    }

    int readInt() throws IOException {
        return Integer.parseInt(readString());
    }

    long readLong() throws IOException {
        return Long.parseLong(readString());
    }

    double readDouble() throws IOException {
        return Double.parseDouble(readString());
    }

    Point readPoint() throws IOException {
        return new Point(readInt(), readInt());
    }

    // ----------------------------------   
    
    int ans1;
    int ans2;
    int t1;
    int t2;
    int t0;
    
    void check(int y1, int y2) {
        long num1 = (long) ans1 * t1 + (long) ans2 * t2;
        long num2 = (long) y1 * t1 + (long) y2 * t2;
        long denum1 = ans1 + ans2;
        long denum2 = y1 + y2;
        if (num1 * denum2 > num2 * denum1){
            ans1 = y1;
            ans2 = y2;
        } else{
            if (num1 * denum2 == num2 * denum1 && ans1 + ans2 < y1 + y2){
                ans1 = y1;
                ans2 = y2;                          
            }
        }
    }
    
    boolean correct(int y1, int y2){
        long z = (long) y1 * t1 + (long) y2 * t2;
        return (z >= (long)t0 * (y1 + y2));             
    }
        
    
    // ----------------------------------------
    void solve() throws NumberFormatException, IOException {
        t1 = readInt();
        t2 = readInt();
        int x1 = readInt();
        int x2 = readInt();
        t0 = readInt();
        
        ans1 = 0;
        ans2 = x2;
        
        for (int i=1;i<=x1;i++) {
            if (correct(i, x2)){
                check(i,x2);
            }
            double searched = (double)(t0 - t1) * i;
            searched /= t2 - t0;
            int start = Math.max(0, (int)searched - 2);
            for (int j = 0;j<5;j++){
                int y2 = start + j;
                if (correct(i, y2)){
                    check(i, y2);
                }
            }
        }
        out.println(ans1+" "+ans2);
    }

    // ----------------------------------------

    public static void main(String[] args) {
        new Thread(null, new solver(), "", 256 * (1L << 20)).start();
    }

    public void run() {
        try {
            timeBegin = System.currentTimeMillis();

            try {
                if (ONLINE_JUDGE) {
                    in = new BufferedReader(new InputStreamReader(System.in));
                    out = new PrintWriter(System.out);
                } else {
                    in = new BufferedReader(new FileReader("input.txt"));
                    out = new PrintWriter("output.txt");
                }
            } catch (Throwable e) {
                in = new BufferedReader(new InputStreamReader(System.in));
                out = new PrintWriter(System.out);
            }

            solve();
            out.close();

            timeEnd = System.currentTimeMillis();
            if (!ONLINE_JUDGE) System.err.println("Time = " + (timeEnd - timeBegin));
        } catch (Exception e) {
            e.printStackTrace(System.err);
            System.exit(-1);
        }
    }

    long timeBegin, timeEnd;
}