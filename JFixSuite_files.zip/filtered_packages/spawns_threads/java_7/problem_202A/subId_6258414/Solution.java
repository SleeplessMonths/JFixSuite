package java_7.problem_202A.subId_6258414;

import java.awt.Point;
import java.io.*;
import java.lang.reflect.Array;
import java.math.BigInteger;
import java.util.*;

import static java.lang.Math.*;
     
public class Solution implements Runnable {
 
        BufferedReader in;
        PrintWriter out;
        StringTokenizer tok = new StringTokenizer("");
 
        public static void main(String[] args) {
                new Thread(null, new Solution(), "", 256 * (1L << 20)).start();
        }
 
        public void run() {
                try {
                        long t1 = System.currentTimeMillis();
                        if (System.getProperty("ONLINE_JUDGE") != null) {
                                in = new BufferedReader(new InputStreamReader(System.in));
                                out = new PrintWriter(System.out);
                        } else {
                                in = new BufferedReader(new FileReader("input.txt"));
                                //out = new PrintWriter("output.txt");
                                out = new PrintWriter(System.out);
                        }
                        Locale.setDefault(Locale.US);
                        solve();
                        in.close();
                        out.close();
                        long t2 = System.currentTimeMillis();
                        System.err.println("Time = " + (t2 - t1));
                } catch (Throwable t) {
                        t.printStackTrace(System.err);
                        System.exit(-1);
                }
        }
 
        String readString() throws IOException {
                while (!tok.hasMoreTokens()) {
                        tok = new StringTokenizer(in.readLine());
                }
                return tok.nextToken();
        }
 
        int readInt() throws IOException {
                return Integer.parseInt(readString());
        }
 
        long readLong() throws IOException {
                return Long.parseLong(readString());
        }
 
        double readDouble() throws IOException {
                return Double.parseDouble(readString());
        }
 
        // solution        
        
        boolean lucky(int x)
        {
        	if(x == 0) return false;
        	
        	for(;x>0;x/=10)
        	{
        		int l = x%10;
        		if(!( (l == 4 || l == 7) ))
        			return false;
        	}
        	
        	return true;
        }
        
        void solve() throws IOException {
        	String str = readString();
        	char[] s = str.toCharArray();
        	char[] buffer = new char[s.length];
        	int len = 0;
        	
        	String answer = null;
        	
        	for(int st = 1; st<(1<<s.length); st++)
        	{
        		len = 0;
        		for(int i = 0; i<s.length; i++)
        			if((st & (1<<i)) > 0)
        				buffer[len++] = s[i];
        		
        		boolean good = true;
        		for(int i = 0; i<len/2 && good; i++)
        			if(buffer[i] != buffer[len-1 -i])
        				good = false;
        		
        		StringBuilder sb = new StringBuilder();
        		for(int i = 0; i<len; i++)
        			sb.append(buffer[i]);
        		
        		String ans = sb.toString(); 
        		
        		if(answer == null || answer.compareTo(ans) < 0)
        			answer = ans;        			
        	}
        	
        	out.println(answer);
        }
    }