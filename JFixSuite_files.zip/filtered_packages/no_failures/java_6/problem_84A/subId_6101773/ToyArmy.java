package java_6.problem_84A.subId_6101773;

/*
http://codeforces.com/problemset/problem/84/A
input
2
output
3
input
4
output
6
 */

import java.util.Scanner;

public class ToyArmy {
    public static void main(String[] args) {
        System.out.println((new Scanner(System.in)).nextInt()*1.5);
    }
}