package java_6.problem_84A.subId_2040287;

import java.util.Scanner;

public class Project {
	
	public static void main(String[] args) {	
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		sc.close();
		
		System.out.println(1.5 * n);
	}
}