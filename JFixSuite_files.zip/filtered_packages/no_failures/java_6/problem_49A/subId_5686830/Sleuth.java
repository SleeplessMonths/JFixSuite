package java_6.problem_49A.subId_5686830;

import java.io.BufferedReader;
import java.io.InputStreamReader;
public class Sleuth {

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        
        try {
            
            String s=br.readLine();
            int l=s.length();
            
            if(s.charAt(l-2)!=' '){
                if(voule(s.charAt(l-2))){
                    System.out.println("YES");
                }
                else
                    System.out.println("NO");
            }
            else
                if(voule(s.charAt(l-3))){
                    System.out.println("YES");
                }
                else
                    System.out.println("NO");
            
            
        } catch (Exception e) {
            // TODO: handle exception
        }

    }
    
    
public static boolean voule(char c){
        
        if(c=='A' || c=='a')
            return true;
        else
            if(c=='O' || c=='o')
                return true;
            else
                if(c=='Y' || c=='y')
                    return true;
                else
                    if(c=='E' || c=='e')
                        return true;
                    else
                        if(c=='U' || c=='u')
                            return true;
                        else
                            if(c=='I' || c=='i')
                                return true;
            
        
        return false;
            
        
    }

}