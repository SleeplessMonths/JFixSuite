package java_8.problem_1A.subId_29254634;

import java.util.Scanner;
public class theater{
    public static void main(String[] args){
        Scanner input= new Scanner(System.in);
        long n= input.nextInt();
        long m= input.nextInt();
        long a=input.nextInt();
        long hang = 0;
        long cot = 0;
        double kq=0;
        if(a>=1&&m>=1&&n>=1){
            if(m%a==0)hang = m/a; 
            else hang = m/a+1;
            if(n%a==0) cot = n/a;
            else cot = n/a+1;
        }
        kq=hang*cot;
        System.out.println(kq);
    }
}