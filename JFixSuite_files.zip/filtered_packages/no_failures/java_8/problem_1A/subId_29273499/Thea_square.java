package java_8.problem_1A.subId_29273499;

/**
 * Created by xeshi on 7/26/2017.
 */
import java.util.Scanner;

public class Thea_square {
    public static void main(String args[]){
        Scanner input= new Scanner(System.in);
        int n= input.nextInt();
        int m= input.nextInt();
        int a= input.nextInt();
        double len=Math.ceil(((double) n)/a);
        double wid=Math.ceil(((double) m)/a);
        System.out.println((int)len*wid);

    }

}