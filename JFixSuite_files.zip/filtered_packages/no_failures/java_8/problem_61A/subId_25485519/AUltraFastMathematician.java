package java_8.problem_61A.subId_25485519;

import java.util.Scanner;

/**
 *
 * @author Muhammad Bahaa
 */
public class AUltraFastMathematician {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        String s1 ,s2 ;
        Scanner in = new Scanner(System.in);
        
        s1 = in.nextLine();
        s2 = in.nextLine();
        char []s = new char[100];
        
        for ( int i = 0 ;  i <s1.length()  ; i++){
            s[i] = s1.charAt(i) == s2.charAt(i) ? '0' :'1';
        }
        System.out.println(s);
    }
    
}