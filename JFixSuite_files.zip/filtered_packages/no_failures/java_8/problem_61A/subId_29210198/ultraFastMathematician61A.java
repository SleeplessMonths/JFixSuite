package java_8.problem_61A.subId_29210198;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;

public class ultraFastMathematician61A {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String a=br.readLine();
		String b=br.readLine();
		BigInteger b1 = new BigInteger(a, 2);
		BigInteger b2 = new BigInteger(b, 2);
//		System.out.println("b1:"+b1);
//		System.out.println("b2:"+b2);
		int x=14,y=10,z=x^y;
//		System.out.println("ans:"+z);
		BigInteger an=b1.xor(b2);
		int n=a.length()-an.bitLength();
		for(int i=0;i<n;i++)
			System.out.print("0");
		System.out.println(an.toString(2));
	
	}

}