package java_8.problem_112A.subId_27119687;

import java.util.Scanner;
public class Test{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String m=sc.next();
        String n=sc.next();
        m=m.toLowerCase();n=n.toLowerCase();
        System.out.println(Math.signum(m.compareTo(n)));
    }
}