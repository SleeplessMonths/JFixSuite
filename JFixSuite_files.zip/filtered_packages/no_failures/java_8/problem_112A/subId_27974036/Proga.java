package java_8.problem_112A.subId_27974036;

import java.util.Scanner;

/**
 * Created by Mayakov Stanislav on 23.06.2017.
 */
public class Proga {
    static String result = "";
    static String StrEquils(String str1, String str2){
            for(int i = 0; i < str1.length(); i++ ) {
               int j = (int) str1.charAt(i);
               int k = (int) str2.charAt(i);
               if(j > k) {result = "+1"; break;}
               if(j < k) {result = "-1"; break;}
               if(j == k) {result = "0"; continue;}
               }
        return result;
    }
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        //System.out.println("First string: ");
        String str1 = in.nextLine();
        //System.out.println("Second string: ");
        String str2 = in.nextLine();
        str1 = str1.toLowerCase();
        str2 = str2.toLowerCase();
        System.out.println( StrEquils(str1, str2) );
    }
}