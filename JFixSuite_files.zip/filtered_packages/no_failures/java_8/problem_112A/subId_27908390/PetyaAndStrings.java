package java_8.problem_112A.subId_27908390;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class PetyaAndStrings {
    
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        PrintWriter out = new PrintWriter(System.out);
                        
        out.println( Math.signum( sc.next().compareToIgnoreCase( sc.next() ) ) );
        
        out.flush();
        out.close();
        sc.close();
    }
    
}