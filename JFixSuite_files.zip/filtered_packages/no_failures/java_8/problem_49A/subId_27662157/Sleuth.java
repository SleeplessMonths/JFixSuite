package java_8.problem_49A.subId_27662157;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package sleuth;

import java.util.Scanner;

/**
 *
 * @author usuario
 */
public class Sleuth {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner (System. in);

        String valor = teclado.nextLine();
        
        int longitud= valor.length();
        int a=-2;
        
        do{
        
        if (valor.charAt(longitud+a)=='A' || valor.charAt(longitud+a)=='a' || valor.charAt(longitud+a)=='E' || valor.charAt(longitud+a)=='e'|| valor.charAt(longitud+a)=='I'|| valor.charAt(longitud+a)=='i'|| valor.charAt(longitud+a)=='O' || valor.charAt(longitud+a)=='o' || valor.charAt(longitud+a)=='U'|| valor.charAt(longitud+a)=='u' || valor.charAt(longitud+a)=='Y'|| valor.charAt(longitud+a)=='y')
        {
            System.out.println("YES");
            break;
        }
        else if(valor.charAt(longitud+a)==' ')
        {
            a-=1;
        }
        else
        {
            System.out.println("NO");
            break;
        }
        }
        while(valor.charAt(longitud+a)!=' ');
    }
    
}