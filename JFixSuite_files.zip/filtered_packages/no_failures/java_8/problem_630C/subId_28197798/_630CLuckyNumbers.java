package java_8.problem_630C.subId_28197798;

import java.io.IOException;

public class _630CLuckyNumbers {
    public static void main(String[] args) throws IOException {
        int lim = 0;
        int c = System.in.read();
        while (c > '\n'){
            lim = (lim << 3) + (lim <<1);
            lim += c - '0';
            c = System.in.read();
        }
        lim++;
        System.out.println((1L << lim) - 2);
    }
}