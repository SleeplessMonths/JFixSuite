package java_8.problem_630C.subId_29023455;

import java.util.Scanner;

public class Luckynumbers {

	public static void main(String[] args){
	Scanner input = new Scanner(System.in);
	int n = input.nextInt();
    long sum = 0;
	
	
	for(int i=1; i<=n;i++){
		sum+=Math.pow(2,i);
	}
	System.out.println(sum);
}

}