package java_8.problem_630C.subId_25937234;

import java.util.Scanner;

public class Dorra {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		long o = 0;
		for (int i = 1; i <= n; i++)
			o += Math.pow(2, i);
		System.out.println(o);
	}

}