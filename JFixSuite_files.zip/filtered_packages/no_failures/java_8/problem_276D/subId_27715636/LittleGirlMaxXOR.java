package java_8.problem_276D.subId_27715636;

import java.util.Scanner;

public class LittleGirlMaxXOR {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		long l = scan.nextLong();
		long r = scan.nextLong();
		if(l == r){
			System.out.println(0);
			return;
		}
		String a = Long.toBinaryString(l);
		String b = Long.toBinaryString(r);
		while(a.length() < 64){
			a = "0"+a;
		}
		while(b.length() < 64){
			b = "0"+b;
		}
		int idx = 0;
		for(int i = 0; i < 64; i++){
			if(a.charAt(i) != b.charAt(i)){
				idx = 64-i;
				break;
			}
		}
		long ans = (long) (Math.pow(2, idx)-1);
		System.out.println(ans);
	}
}