package java_8.problem_581A.subId_28781776;

import java.util.Scanner;


public class VasyaHipster3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt(); //n�mero calcetines rojos
		int b = sc.nextInt(); //n�mero calcetines azules
		int diferencia = 0;
		if (a<=b) {
			diferencia = b-a;
			System.out.print(a + " ");
		}
		if (b<a) {
			diferencia= a-b;
			System.out.print(b + " ");
			//Hasta aqu� todo bien
		}
		if (diferencia == 1 || diferencia == 0) {
			System.out.print("0");
		}
		if (diferencia%2 == 0){
			System.out.print(diferencia/2);
		}
		if (diferencia !=1 && diferencia%2 !=0) {
			System.out.print(diferencia/2);
		}
		

	}

}