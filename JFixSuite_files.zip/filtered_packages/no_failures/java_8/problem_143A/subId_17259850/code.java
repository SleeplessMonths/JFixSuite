package java_8.problem_143A.subId_17259850;

import java.util.Scanner;
public class code{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in); 
int r1 = sc.nextInt();
int r2 = sc.nextInt();
int c1 = sc.nextInt();
int c2 = sc.nextInt();
int d1 = sc.nextInt();
int d2 = sc.nextInt();

		
double x1 = (r1-c2+d1)/2.0 ;
double x2 = (r2-c2+d2)/2.0;
double y1 = r1-x1 ;
double y2 = r2- x2 ;
if(x1==x2 ||y1==y2 ||x1==y1 ||x1 ==y2||x2==y1 ||x2 ==y2||x1>=10||x2>=10||y1>=10||y2>=10 ||x1==0 ||x2==0 ||y1==0||y2==0 ||(int)x1!=x1||(int)x2!=x2||(int)y1!=y1||(int)y2!=y2)
	
	System.out.println(-1);else System.out.println(x1+" "+y1+"\n"+x2+" "+y2);
	
	
}

	 
}