package java_8.problem_63C.subId_20025113;

public class Bulls_and_Cows {

    public static void main ( String[] args ) throws Exception {
        input.init ( System.in );
        java.util.HashSet<Integer> hs = new java.util.HashSet<> ( 10000 );
        for ( int i = 123 ; i < 10000 ; i ++ ) {
            if ( i == 83 ) {
                System.out.println ( "xxxxxxxxxxxx" );
            }
            if ( isGood ( i ) ) {
                hs.add ( i );
            }
        }
        for ( int numInputs = input.nextInt () ; numInputs > 0 ; numInputs -- ) {
            hs = check ( hs , input.nextInt () , input.nextInt () , input.nextInt () );
        }
        switch ( hs.size () ) {
            case 0:
                System.out.println ( "Incorrect data" );
                break;
            case 1:
                System.out.println ( hs.iterator ().next () );
                break;
            default:
                System.out.println ( "Need more data" );
        }
    }

    public static boolean isGood ( int num ) {
        String s = String.valueOf ( num );
        if ( s.length () == 3 ) {
            s = "0".concat ( s );
        }
        java.util.HashSet<Integer> hs = new java.util.HashSet<> ( 10 );
        for ( int i = 0 ; i < s.length () ; i ++ ) {
            hs.add ( Integer.parseInt ( "" + s.charAt ( i ) ) );
        }
        return hs.size () == s.length ();
    }

    public static java.util.HashSet<Integer> check ( java.util.HashSet<Integer> hs , int num , int bulls , int cows ) {
        java.util.HashSet<Integer> hs2 = new java.util.HashSet<> ( 10000 );
        int tempBulls, tempCows;
        String s1, s2;
        for ( Integer h : hs ) {
            s1 = String.valueOf ( num );
            if ( s1.length () == 3 ) {
                s1 = "0".concat ( s1 );
            }
            tempBulls = 0;
            tempCows = 0;
            s2 = String.valueOf ( h );
            if ( s2.length () == 3 ) {
                s2 = "0".concat ( s2 );
            }
            for ( int i = 0 ; i < s1.length () ; i ++ ) {
                if ( s1.charAt ( i ) == s2.charAt ( i ) ) {
                    s1 = s1.replace ( "" + s1.charAt ( i ) , "" );
                    s2 = s2.replace ( "" + s2.charAt ( i ) , "" );
                    i --;
                    tempBulls ++;
                }
            }
            for ( int i = 0 ; i < s1.length () ; i ++ ) {
                if ( s2.contains ( "" + s1.charAt ( i ) ) ) {
                    tempCows ++;
                }
            }
            if ( bulls == tempBulls && cows == tempCows ) {
                hs2.add ( h );
            }
        }
        return hs2;
    }
}

class input {

    static java.io.BufferedReader reader;
    static java.util.StringTokenizer tokenizer;

    static void init ( java.io.InputStream input ) {
        reader = new java.io.BufferedReader ( new java.io.InputStreamReader ( input ) );
        tokenizer = new java.util.StringTokenizer ( "" );
    }

    static String next () throws Exception {
        while (  ! tokenizer.hasMoreTokens () ) {
            tokenizer = new java.util.StringTokenizer ( reader.readLine () );
        }
        return tokenizer.nextToken ();
    }

    static int nextInt () throws Exception {
        return Integer.parseInt ( next () );
    }
}