package java_8.problem_656G.subId_26069991;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int f = s.nextInt();
        int i = s.nextInt();
        int t = s.nextInt();
        int[] c = new int[i];

        String l;
        for (int k = 0; k < f; k++) {
            l = s.next();
            for (int m = 0; m < i; m++)
                if (l.charAt(m) == 'Y') c[m]++;
        }
        int ans = 0;
        for (int m = 0; m < i; m++)
            if (c[m] >= t) ans ++;

        System.out.println(ans);
    }
}