package java_8.problem_656G.subId_26069934;

import java.util.Scanner;
public class c656G {
    public static void main(String[] args) {
        Scanner n=new Scanner(System.in);
        int f=n.nextInt();
        int o=n.nextInt();
        int t=n.nextInt();
        int k=0;
        int[] count=new int[o];
        for (int i=0;i<f;i++) {
            String s=n.next();
            for (int j=0;j<o;j++) {
                if (s.charAt(j)=='Y') count[j]++;
            }
        }
        for (int i=0;i<o;i++) {
            if (count[i]>=t) k++;
        }
        System.out.println(k);
    }
}