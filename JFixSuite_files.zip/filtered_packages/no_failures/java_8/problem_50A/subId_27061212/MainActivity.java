package java_8.problem_50A.subId_27061212;

import java.util.Scanner;

public class MainActivity {	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		String w = scanner.nextLine();
		String[] u = w.split("\\s+");

		int n = Integer.valueOf(u[0]);
		int m = Integer.valueOf(u[1]);

		System.out.println(Math.floor((double) (n * m) / 2));
	}
}