package java_8.problem_104A.subId_16827467;

public class Edelpilz {
	public static void main(String[] args) {
		int n = new java.util.Scanner(System.in).nextInt();
		System.out.println((n == 20 ? 15 : ((n > 10 && n < 22 && n != 20) ? 4 : 0)));
	}
}