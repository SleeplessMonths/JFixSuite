package java_8.problem_738A.subId_25681419;

import java.util.Scanner;

public class R380Div2A {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		String s=in.next();
		char[] ans=new char[n];
		int p=0;
		for(int i=0;i<n;i++){
			if(s.charAt(i)=='o'){
				int j;
				for(j=i+1;j<n-1;j+=2){
					if(s.charAt(j)=='g'&&s.charAt(j+1)=='o'){
						
					}else
						break;
				}
				if(j-i>=2){
					i=j-1;
					ans[p++]='*';
					ans[p++]='*';
					ans[p++]='*';
				}else{
					ans[p++]=s.charAt(i);
				}
			}else{
				ans[p++]=s.charAt(i);
			}
		}
		System.out.println(String.valueOf(ans));
	}

}