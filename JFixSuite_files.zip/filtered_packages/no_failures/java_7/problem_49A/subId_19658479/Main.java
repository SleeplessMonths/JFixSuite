package java_7.problem_49A.subId_19658479;

import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		String cad = in.nextLine();
		if (cad.charAt(cad.length()-2) == ' ')
		{
			if (cad.charAt(cad.length()-3) == 'a' || cad.charAt(cad.length()-3) == 'e' || cad.charAt(cad.length()-3) == 'i' || cad.charAt(cad.length()-3) == 'o' || cad.charAt(cad.length()-3) == 'u' || cad.charAt(cad.length()-3) == 'y' || cad.charAt(cad.length()-3) == 'A' || cad.charAt(cad.length()-3) == 'E' || cad.charAt(cad.length()-3) == 'I' || cad.charAt(cad.length()-3) == 'O' || cad.charAt(cad.length()-3) == 'U' || cad.charAt(cad.length()-3) == 'Y')
			{
				System.out.println("YES");
			}
			else 
			{
				System.out.println("NO");
			}
		}
		else
		{
			if (cad.charAt(cad.length()-2) == 'a' || cad.charAt(cad.length()-2) == 'e' || cad.charAt(cad.length()-2) == 'i' || cad.charAt(cad.length()-2) == 'o' || cad.charAt(cad.length()-2) == 'u' || cad.charAt(cad.length()-2) == 'y' || cad.charAt(cad.length()-2) == 'A' || cad.charAt(cad.length()-2) == 'E' || cad.charAt(cad.length()-2) == 'I' || cad.charAt(cad.length()-2) == 'O' || cad.charAt(cad.length()-2) == 'U' || cad.charAt(cad.length()-2) == 'Y')
			{
				System.out.println("YES");
			}
			else 
			{
				System.out.println("NO");
			}
		}
	}
}