package java_7.problem_84A.subId_4715891;

/**
 *
 * Chris Steeves
 */
import java.util.Scanner;
public class Codetest {
     
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        System.out.println(n * 1.5);
    }
}