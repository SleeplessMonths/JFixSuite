package java_7.problem_84A.subId_3292566;

import java.util.Scanner;

public class Prop1 {

	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		int x=input.nextInt();
		if(x%2!=0)
			System.exit(0);
		double y=1.5*x;
		System.out.println(y);
	}

}