package java_7.problem_84A.subId_2893606;

import java.util.Scanner;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner(System.in);
		int n=scan.nextInt();
		System.out.println(n*1.5);

	}

}