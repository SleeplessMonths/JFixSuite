package java_7.problem_120A.subId_7603517;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 *
 * @author Ammar.Eliwat
 */
public class TEST {

    public static void main(String[] args) throws IOException {
        Scanner input = new Scanner(System.in);

        BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
        String str;
       while ((str = buffer.readLine()) != null) {
     
      int n=Integer.parseInt(buffer.readLine());
      if(str.equals("front")&& n==1 )
               System.out.println("L");
      else
          if(str.equals("front")&& n==2)
               System.out.println("R");
      else
              if(str.equals("back") && n==1)
                  System.out.println("R");
      else
                  System.out.println("L");
       }
    }

}