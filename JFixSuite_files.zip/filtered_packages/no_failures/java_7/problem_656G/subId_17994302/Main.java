package java_7.problem_656G.subId_17994302;

import java.util.Scanner;
public class Main{
public static void main(String[] args){
int f,x,t;
Scanner in = new Scanner(System.in);
f=in.nextInt();x=in.nextInt();t=in.nextInt();in.nextLine();int[] a = new int[20];for(int i=0;i<x;i++)
a[i]=0;
for(int i=0;i<f;i++) {
String s;
s=in.nextLine();
for(int j=0;j<x;j++)
if(s.charAt(j)=='Y')
a[j]++;
}
int r=0;
for (int i=0;i<x;i++){
if (a[i] >= t)
r++;
}
System.out.println(""+r);
}
}