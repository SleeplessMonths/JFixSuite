package java_8.problem_108A.subId_18052004;

import java.util.*;
import java.io.*;
	public class Main {
		public static long mod= (long) (1e9 +7);
		public static void main(String args[]){
			InputReader s= new InputReader(System.in);
			OutputStream outputStream= System.out;
			PrintWriter out= new PrintWriter(outputStream);
			String str= s.next();
			String inp[]= str.split(":");
			int hour= Integer.parseInt(inp[0]);
			int min= Integer.parseInt(inp[1]);
			String newhour= inp[0];
			String newmin = inp[1];
			int flag=0;
			for(int i=hour;i<=23 && flag==0;i++){
				for(int j=min;j<=59;j++){
				       inp[1]= "" + (Integer.parseInt(inp[1])+01);
				       if(inp[1].length()==1) inp[1]= "0"+inp[1];
				       String pass= inp[0].concat(inp[1]);
				       boolean ans= palindrome(pass);
				       if(ans==true) {
				    	   out.println(inp[0]+":"+inp[1]);
				    	   flag=1;
				    	   break;
				       }
				}
				min=0;
				inp[1] = "00";
				inp[0]= "" + (Integer.parseInt(inp[0])+1);
				if(inp[0].length()==1) inp[0]= "0"+inp[0];
			}
			if(flag!=1) out.println("00:00");
			out.close();
		}
		
		static boolean palindrome(String str){
			String reverse= new StringBuffer(str).reverse().toString();
			if(reverse.equals(str)) return true;
			else return false;
		}
		static class InputReader {
	
		    public BufferedReader reader;
		    public StringTokenizer tokenizer;
	 
		    public InputReader(InputStream inputstream) {
		      reader = new BufferedReader(new InputStreamReader(inputstream));
		      tokenizer = null;
		    }
		    
		    public String nextLine(){
		    	String fullLine=null;
		    	while (tokenizer == null || !tokenizer.hasMoreTokens()) {
		            try {
		              fullLine=reader.readLine();
		            } catch (IOException e) {
		              throw new RuntimeException(e);
		            }
		            return fullLine;
		          }
		          return fullLine;
		    }
			public String next() {
		      while (tokenizer == null || !tokenizer.hasMoreTokens()) {
		        try {
		          tokenizer = new StringTokenizer(reader.readLine());
		        } catch (IOException e) {
		          throw new RuntimeException(e);
		        }
		      }
		      return tokenizer.nextToken();
		    }
			public long nextLong() {
			      return Long.parseLong(next());
			    }
		    public int nextInt() {
		      return Integer.parseInt(next());
		    }
		  }
		static class Pair implements Comparable<Pair>
		{
			int f,s;
			Pair(int ii, int cc)
			{
				f=ii;
				s=cc;
			}
			
			public int compareTo(Pair o) 
			{
				return Integer.compare(this.f, o.f);
			}
			
		}
		public static int gcd(int number1, int number2) {  
			if(number2 == 0){
				return number1;
			} 
			return gcd(number2, number1%number2); 
		}
		public static int combinations(int n,int r){
			if(n==r) return 1;
			if(r==1) return n;
			if(r==0) return 1;
			return combinations(n-1,r)+ combinations(n-1,r-1);
		}
		public static long binomialCoeff(int n, int k)
		{
		    long C[][]= new long[n+1][k+1];
		    int i, j;
		 
		    // Caculate value of Binomial Coefficient in bottom up manner
		    for (i = 0; i <= n; i++)
		    {
		        for (j = 0; j <= Math.min(i, k); j++)
		        {
		            // Base Cases
		            if (j == 0 || j == i)
		                C[i][j] = 1;
		 
		            // Calculate value using previosly stored values
		            else
		                C[i][j] = C[i-1][j-1] + C[i-1][j];
		        }
		    }
		 
		    return C[n][k];
		}
		public static int expo(int a, int b){
		    if (b==1)
		        return a;
		    if (b==2)
		        return a*a;
	
		    if (b%2==0){
		            return expo(expo(a,b/2),2);
		    }
		    else{
		        return a*expo(expo(a,(b-1)/2),2);
		    }
		}
		
		public static void sieve(int N){
			int arr[]= new int[N+1];
			for(int i=2;i<Math.sqrt(N);i++){
				if(arr[i]==0){
					for(int j= i*i;j<= N;j= j+i){
						arr[j]=1;
					}
				}
			}
			// All the i for which arr[i]==0 are prime numbers.
		}
		public static class company{
			public int money;
			public int factor;
			public company(int m,int f){
				this.money=m;
				this.factor=f;
			}
			public int get_money(){
				return this.money;
			}
			public int get_factor(){
				return this.factor;
			}
		}
		public static class company_comparator implements Comparator<company>{

			@Override
			public int compare(company arg0, company arg1) {
				// TODO Auto-generated method stub
				return arg0.money-arg1.money;
			}
			
		}
	}