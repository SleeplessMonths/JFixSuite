package java_8.problem_109B.subId_20763655;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class A {

	
	static int[] genLucky()
	{
		int[] c = new int[1022];
		for(int len = 1, k = 0; len <= 9; ++len)
			for(int msk = 0; msk < 1<<len; ++msk)
			{
				int a = 0;
				for(int j = 0, b = msk, f = 1; j < len; ++j, b >>= 1, f *= 10)
					if((b & 1) == 0)
						a += f * 4;
					else
						a += f * 7;
				c[k++] = a;
			}
		return c;
	}
	
	static double prob(int x, int y, int l, int r)
	{
		if(x < l) x = l;
		if(y > r) y = r;
		if(x > y) return 0;
		return 1.0 * (y - x + 1) / (r - l + 1);
	}
	
	public static void main(String[] args) throws IOException 
	{
		Scanner sc = new Scanner(System.in);
		PrintWriter out = new PrintWriter(System.out);
		
		int pl = sc.nextInt(), pr = sc.nextInt(), vl = sc.nextInt(), vr = sc.nextInt(), k = sc.nextInt();
		int[] lucky = genLucky();
		double ans = 0;
		for(int i = 0; i + k <= 1022; ++i)
		{
			int xl = i == 0 ? 1 : lucky[i - 1] + 1;
			int xr = lucky[i];
			int yl = lucky[i + k - 1];
			int yr = i + k == 1022 ? (int)1e9 : lucky[i + k] - 1;
			ans += prob(xl, xr, pl, pr) * prob(yl, yr, vl, vr);
			ans += prob(yl, yr, pl, pr) * prob(xl, xr, vl, vr);
		}
		out.println(ans);
		out.close();
	}
	
	static class Scanner 
	{
		StringTokenizer st;
		BufferedReader br;

		public Scanner(InputStream s){	br = new BufferedReader(new InputStreamReader(s));}
		
		public Scanner(FileReader r){	br = new BufferedReader(r);}

		public String next() throws IOException 
		{
			while (st == null || !st.hasMoreTokens()) 
				st = new StringTokenizer(br.readLine());
			return st.nextToken();
		}

		public int nextInt() throws IOException {return Integer.parseInt(next());}

		public long nextLong() throws IOException {return Long.parseLong(next());}

		public String nextLine() throws IOException {return br.readLine();}

		public double nextDouble() throws IOException { return Double.parseDouble(next()); }

		public boolean ready() throws IOException {return br.ready();}


	}
}