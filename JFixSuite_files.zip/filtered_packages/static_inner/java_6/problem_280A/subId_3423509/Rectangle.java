package java_6.problem_280A.subId_3423509;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;


public class Rectangle {

	/**
	 * @param args
	 */
	
	static double w;
	static double h;
	static double alfa;
	static double area;
	
	public static void main(String[] args) {
		Parser p = new Parser(System.in);
		PrintWriter pw = new PrintWriter(System.out);
		
		w = p.nextInt();
		h = p.nextInt();
		alfa = p.nextInt();
		
		if(alfa == 0 || alfa == 180){
			pw.print(w*h);
			pw.close();
			return;
		}
		if( h > w){
			double tmp = h;
			h = w;
			w = tmp;
		}
		if(alfa > 90){
			alfa = 180 - alfa;
		}
		alfa = Math.PI*alfa/180;
		
		double beta = Math.atan(h/w);
	//	System.out.println("beta: "+ beta*180/Math.PI);
		if( alfa <= 2*beta){
			double p1 = getArea(beta, h);
			double p2 = 0;
			if(alfa < 2*beta){
				p2 = getArea(Math.PI/2 - beta, w);

			}
			area = h*w - 2*(p1 + p2);
		//	System.out.println("p1 = " + p1 + "p2 = "+ p2);
		}else{
			area = w*h/Math.sin(alfa);
		}
	
		pw.print(area);
		pw.close();
	}





	private static double getArea(double angle, double len) {
			double r = Math.sqrt(h*h + w*w)/2;
			double hd = r*Math.sin(alfa+angle);
			double hm = hd - len/2;
			double a = hm/Math.sin(alfa);
			double b = a*Math.tan(alfa);
			return a*b/2;
	}


	
	
	static class Parser{
		
		StringTokenizer st;
		BufferedReader br;

		public Parser(InputStream is){
			this.br = new BufferedReader( new InputStreamReader(is));
			
		}
		
		public int nextInt(){
			return Integer.parseInt(nextToken());
		}
		
		public double nextDouble(){
			return Double.parseDouble(nextToken());
		}
		
		public String nextString(){
			return nextToken();
		}
		
		public int[] nextIntArray(int s){
			int[] a = new int[s];
			for(int i=0; i<s; ++i){
				a[i] = nextInt();
			}
			return a;
		}
		
		public int[][] nextIntTable(int r, int c){
			int[][] a = new int[r][c];
			for(int i=0; i<r; ++i){
				a[i] = nextIntArray(c);
			}
			return a;
		}
	
		private String nextToken() {
			if( st == null || ! st.hasMoreTokens() ){
				try{
					st = new StringTokenizer( br.readLine());
				}catch( Exception e){
					e.printStackTrace();
				}
			}
			return st.nextToken();
		}
		
	}
}