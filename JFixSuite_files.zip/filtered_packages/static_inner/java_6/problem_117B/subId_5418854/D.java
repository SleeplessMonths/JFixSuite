package java_6.problem_117B.subId_5418854;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

/**
 *
 *
 *
 *
 *
 * @author pttrung
 */
public class D {

    public static long MOD = 100000000;

    public static void main(String[] args) throws FileNotFoundException {
        PrintWriter out;

        Scanner in = new Scanner();
        //out = new PrintWriter(new FileOutputStream(new File("output.txt")));
        out = new PrintWriter(System.out);
        long a = in.nextInt();
        long b = in.nextInt();
        int mod = in.nextInt();       
        long c = 1000000000 % mod;
        boolean found = false;
        for(long i = 0; i < Math.min(mod , a); i++){
            long val = (i*c)%mod;
           
            if(val != 0 && mod - val > b){
                found = true;
               //  System.out.println(val);
                out.print(1 + " ");
                
                int count = count(i);
               // System.out.println(count);
                for(int j = 0; j < 9 - count; j++){
                    out.print(0);
                }
                out.print(i);
                break;
            }
        }
        if(!found){
            out.println(2);
        }
        out.close();

    }
    
    
    
    public static int count(long val){
        if(val == 0){
            return 1;
        }
        int result = 0;
        while(val > 0){
            result++;
            val/=10;
        }
        return result;
    }

    public static class FT {

        int[] data;

        FT(int n) {
            data = new int[n];
        }

        public void update(int index, int value) {
            while (index < data.length) {
                data[index] += value;
                index += (index & (-index));
            }
        }

        public int get(int index) {
            int result = 0;
            while (index > 0) {
                result += data[index];
                index -= (index & (-index));
            }
            return result;

        }
    }

    public static class Sign {

        char c;
        int x, y;

        public Sign(char c, int x, int y) {
            this.c = c;
            this.x = x;
            this.y = y;
        }
    }

    public static long gcd(long a, long b) {
        if (b == 0) {
            return a;
        }
        return gcd(b, a % b);
    }

    public static long pow(long a, long b) {
        if (b == 0) {
            return 1;
        }
        if (b == 1) {
            return a;
        }
        long val = pow(a, b / 2);
        if (b % 2 == 0) {
            return val * val % MOD;
        } else {
            return val * (val * a % MOD) % MOD;
        }
    }

    static class Scanner {

        BufferedReader br;
        StringTokenizer st;

        public Scanner() throws FileNotFoundException {
            // System.setOut(new PrintStream(new BufferedOutputStream(System.out), true));
            br = new BufferedReader(new InputStreamReader(System.in));
            //br = new BufferedReader(new InputStreamReader(new FileInputStream(new File("input.txt"))));
        }

        public String next() {

            while (st == null || !st.hasMoreTokens()) {
                try {
                    st = new StringTokenizer(br.readLine());
                } catch (Exception e) {
                    throw new RuntimeException();
                }
            }
            return st.nextToken();
        }

        public long nextLong() {
            return Long.parseLong(next());
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        public double nextDouble() {
            return Double.parseDouble(next());
        }

        public String nextLine() {
            st = null;
            try {
                return br.readLine();
            } catch (Exception e) {
                throw new RuntimeException();
            }
        }

        public boolean endLine() {
            try {
                String next = br.readLine();
                while (next != null && next.trim().isEmpty()) {
                    next = br.readLine();
                }
                if (next == null) {
                    return true;
                }
                st = new StringTokenizer(next);
                return st.hasMoreTokens();
            } catch (Exception e) {
                throw new RuntimeException();
            }
        }
    }
}