package java_6.problem_68A.subId_343431;

import java.io.*;
import java.util.Scanner;

public class Main
{
    
    public static void main(String args[]) throws Exception
    {
        Solution sol = new Solution();
        sol.Run();
    }

    static public class Solution
    {
        @SuppressWarnings("unused")
        private Scanner scanner;
        
        void solve(BufferedReader input, PrintStream output) throws Exception
        {
            int p = 10000;
            for (int i = 0; i < 4; i++)
            {
                p = Math.min(p, scanner.nextInt());
            }
            int a = scanner.nextInt();
            int b = scanner.nextInt();
            int x = p - Math.min(a, b);
            System.out.println(Math.max(0, x));
        }

        void Run() throws Exception
        {
            BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
            //BufferedReader buffer = new BufferedReader(new FileReader("test.in"));
            scanner = new Scanner(buffer);
            PrintStream output = System.out;
            solve(buffer, output);
        }
    }
}