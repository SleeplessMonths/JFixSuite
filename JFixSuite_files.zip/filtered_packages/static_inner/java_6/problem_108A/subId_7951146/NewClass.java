package java_6.problem_108A.subId_7951146;

import java.io.BufferedReader;
import java.io.IOException;

import java.io.InputStream;
import java.io.InputStreamReader;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;



 public class NewClass {

     
     static class escaner
       {
           BufferedReader in;
           StringTokenizer st;

        public escaner() {
       
            in=new BufferedReader(new InputStreamReader(System.in));
            st=new StringTokenizer("");
            }
        
        public int nextInt() throws IOException
        {
            if(st.hasMoreTokens())return Integer.parseInt(st.nextToken());
            else
            { st=new StringTokenizer(in.readLine());
            return nextInt();
            
            }
            
        }
             public String next() throws IOException
        {
            if(st.hasMoreTokens())return st.nextToken();
            else
            { st=new StringTokenizer(in.readLine());
            return next();
            
            }
            
        }
       }

  
public static int rev(int x)
{
    String xx=String.valueOf(x);
    String res="";
    for (int i = xx.length()-1; i >=0; i--) {
        res+=xx.charAt(i);
        
        
    }
    if(x<10)
        res+="0";
    
    return Integer.parseInt(res);
    
}

  public static void printing(int x,int y)
  {
      if(x<10&&y<10)
      {
          System.out.println("0"+x+":"+"0"+y);
      }
      else
          if(x<10)
              System.out.println("0"+x+":"+y);
         else if(y<10)
              System.out.println(x+":"+"0"+y);
      else
             System.out.println(x+":"+y);
  }

    public static void main(String[] args) throws Throwable {

       
              
	escaner sc=new escaner();
	//int n=sc.nextInt();
        String s=sc.next();
        String hh=s.charAt(0)+""+s.charAt(1);
        String mm=s.charAt(3)+""+s.charAt(4);
        String hh2=s.charAt(1)+""+s.charAt(0);
        String mm2=s.charAt(4)+""+s.charAt(3);
         
        int  h=Integer.parseInt(hh);
        int  m=Integer.parseInt(mm);
        int  h2=rev(h);
        int  m2=rev(m);
        
        if(m<h2)
            printing(h, h2);
        else
        {
            int k=(h+1)%24;
            
            while(rev(k)>59)
                k=(k+1)%24;
            printing(k, rev(k));
        }
       
        
        
 
        
  

    }
}