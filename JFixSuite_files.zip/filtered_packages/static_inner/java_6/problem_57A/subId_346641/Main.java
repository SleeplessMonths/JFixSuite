package java_6.problem_57A.subId_346641;

import java.io.*;
import java.util.Scanner;

public class Main
{
	
	public static void main(String args[]) throws Exception
	{
		Solution sol = new Solution();
		sol.Run();
	}

	static public class Solution
	{
		@SuppressWarnings("unused")
		private Scanner scanner;
		private int tx, ty;
		private boolean[][] visited;
		
		int dfs(int x, int y, int n, int m)
		{
			if (x == tx && y == ty) return 0;
			if (x == 0 || x == n)
			{
				if (y < 0 || y > m) return -1;
				// OK
			}
			else if (y == 0 || y == m)
			{
				if (x < 0 || x > n) return -1;
				// OK
			}
			else
			{
				return -1;
			}
			if (visited[x][y])
			{
				return -1;
			}
			visited[x][y] = true;
			int di[] = { -1, 1, 0, 0 };
			int dj[] = { 0, 0, 1, -1 };
			for (int i = 0; i < 4; i++)
			{
				int xx = x + di[i];
				int yy = y + dj[i];
				int dist = dfs(xx, yy, n, m);
				if (dist >= 0)
				{
					return dist + 1;
				}
			}
			return -1;
		}
		
		void solve(BufferedReader input, PrintStream output) throws Exception
		{
			int n = scanner.nextInt();
			int x1 = scanner.nextInt();
			int y1 = scanner.nextInt();
			tx = scanner.nextInt();
			ty = scanner.nextInt();
			visited = new boolean[n + 1][n + 1];
			
			int dist = dfs(x1, y1, n, n);
			int total = 4 * n + 1;
			int ans = Math.min(dist, total - dist);
			output.println(ans);
		}

		void Run() throws Exception
		{
			BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
			//BufferedReader buffer = new BufferedReader(new FileReader("test.in"));
			scanner = new Scanner(buffer);
			PrintStream output = System.out;
			solve(buffer, output);
		}
	}
}