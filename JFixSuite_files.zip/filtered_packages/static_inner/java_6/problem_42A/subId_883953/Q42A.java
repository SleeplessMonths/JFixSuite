package java_6.problem_42A.subId_883953;

import java.io.*;
import java.util.StringTokenizer;

public class Q42A implements Runnable {
    private void solve() throws IOException {
        int n = nextInt();
        int V = nextInt();
        int[] a = new int[n];
        int[] b = new int[n];
        int sum = 0;
        for (int i = 0; i < a.length; i++) {
            a[i] = nextInt();
            sum += a[i];
        }
        for (int i = 0; i < b.length; i++) {
            b[i] = nextInt();
        }

        double e = 0.000001;
        double prevTry = 0;
        double nextTry = V;
        while (Math.abs(nextTry - prevTry) > e) {
            boolean isFine = true;
            for (int i = 0; i < n; i++) {
                if (nextTry * a[i] / sum > b[i]) {
                    isFine = false;
                    break;
                }
            }
            double tmp = nextTry;
            if (isFine) {
                nextTry += Math.abs(nextTry - prevTry) / 2;
            } else {
                nextTry -= Math.abs(nextTry - prevTry) / 2;
            }
            prevTry = tmp;
        }
        writer.print(prevTry);


    }

    private static final class Pair {
        int prop;
        int have;

        private Pair(int prop, int have) {
            this.prop = prop;
            this.have = have;
        }
    }

    public static void main(String[] args) {
        new Q42A().run();
    }

    BufferedReader reader;
    StringTokenizer tokenizer;
    PrintWriter writer;

    public void run() {
        try {

            boolean oj = System.getProperty("ONLINE_JUDGE") != null;

            reader = oj ? new BufferedReader(new InputStreamReader(System.in)) :
                    new BufferedReader(new FileReader(new File("input.txt")));


            tokenizer = null;
            writer = new PrintWriter(System.out);
            solve();
            reader.close();
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    int nextInt() throws IOException {
        return Integer.parseInt(nextToken());
    }

    long nextLong() throws IOException {
        return Long.parseLong(nextToken());
    }

    double nextDouble() throws IOException {
        return Double.parseDouble(nextToken());
    }

    String nextToken() throws IOException {
        while (tokenizer == null || !tokenizer.hasMoreTokens()) {
            tokenizer = new StringTokenizer(reader.readLine());
        }
        return tokenizer.nextToken();
    }
}