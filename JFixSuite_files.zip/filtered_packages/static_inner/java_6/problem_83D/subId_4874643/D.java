package java_6.problem_83D.subId_4874643;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.TreeMap;

/**
 *
 *
 *
 * @author pttrung
 */
public class D {

    public static long MOD = 1000000007;
    public static ArrayList<Integer> p;

    public static void main(String[] args) {
        Scanner in = new Scanner();
        PrintWriter out = new PrintWriter(System.out);
        long a = in.nextLong();
        long b = in.nextLong();
        long k = in.nextLong();
        boolean[] prime = new boolean[10000000];
        p = new ArrayList();
        ArrayList<Integer> list = new ArrayList();
        for (int i = 2; i < prime.length; i++) {
            if (!prime[i]) {
                p.add( i);
                if (i < k) {
                    list.add(i);
                }
                for (int j = i * i; j < prime.length; j += i) {
                    if (j < 0) {
                        break;
                    }
                    prime[j] = true;

                }
            }
        }
        boolean ok = true;
        if (k < prime.length) {
            if (prime[(int) k]) {
                out.println(0);
                ok = false;
            }
        } else {
            if (!isPrime(k)) {
                out.println(0);
                ok = false;
            }
        }
//        for(long val : p){
//            System.out.println("Prime " + val);
//        }
        // p.add(k);
        if (ok) {            
            long left = cal(list.size() - 1, list, b);
            long right = cal(list.size() - 1, list, (a - 1));
            //out.println(left + " " + right);
            out.println((left - right));
        }
        out.close();
    }

    public static boolean isPrime(long val) {
        int index = 1;
        int prime = p.get(0);
        while(prime*prime <= val && index < p.size()){
            if(val% prime == 0){
                return false;
            } 
            prime = p.get(index ++);
        }
        return true;
    }

    public static long cal(int index, ArrayList<Integer> val, long n) {

        if (n == 0 || index == -1) {
            return n;
        }
        return cal(index - 1, val, n) - cal(index - 1, val, n / val.get(index));
    }

    public static class Edge implements Comparable<Edge> {

        int x, y;

        public Edge(int x, int y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public int compareTo(Edge o) {
            if (x != o.x) {
                return x - o.x;
            } else {
                return y - o.y;
            }
        }
    }

    public static class FT {

        int[] data;

        FT(int n) {
            data = new int[n];
        }

        public void update(int index, int value) {
            while (index < data.length) {
                data[index] += value;
                index += (index & (-index));
            }
        }

        public int get(int index) {
            int result = 0;
            while (index > 0) {
                result += data[index];
                index -= (index & (-index));
            }
            return result;

        }
    }

    public static long gcd(long a, long b) {
        if (b == 0) {
            return a;
        }
        return gcd(b, a % b);
    }

    public static long pow(long a, long b) {
        if (b == 0) {
            return 1;
        }
        if (b == 1) {
            return a;
        }
        long val = pow(a, b / 2);
        if (b % 2 == 0) {
            return val * val % MOD;
        } else {
            return val * (val * a % MOD) % MOD;
        }
    }

    static class Scanner {

        BufferedReader br;
        StringTokenizer st;

        public Scanner() {
            // System.setOut(new PrintStream(new BufferedOutputStream(System.out), true));
            br = new BufferedReader(new InputStreamReader(System.in));
        }

        public String next() {

            while (st == null || !st.hasMoreTokens()) {
                try {
                    st = new StringTokenizer(br.readLine());
                } catch (Exception e) {
                    throw new RuntimeException();
                }
            }
            return st.nextToken();
        }

        public long nextLong() {
            return Long.parseLong(next());
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        public double nextDouble() {
            return Double.parseDouble(next());
        }

        public String nextLine() {
            st = null;
            try {
                return br.readLine();
            } catch (Exception e) {
                throw new RuntimeException();
            }
        }

        public boolean endLine() {
            try {
                String next = br.readLine();
                while (next != null && next.trim().isEmpty()) {
                    next = br.readLine();
                }
                if (next == null) {
                    return true;
                }
                st = new StringTokenizer(next);
                return st.hasMoreTokens();
            } catch (Exception e) {
                throw new RuntimeException();
            }
        }
    }
}