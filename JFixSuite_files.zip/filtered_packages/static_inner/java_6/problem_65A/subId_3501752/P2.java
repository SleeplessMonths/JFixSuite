package java_6.problem_65A.subId_3501752;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;


public class P2 {
	
	static class Scanner{
		BufferedReader br=null;
		StringTokenizer tk=null;
		public Scanner(){
			br=new BufferedReader(new InputStreamReader(System.in));
		}
		public String next() throws IOException{
			while(tk==null || !tk.hasMoreTokens())
				tk=new StringTokenizer(br.readLine());
			return tk.nextToken();
		}
		public int nextInt() throws NumberFormatException, IOException{
			return Integer.valueOf(next());
		}
	}
	
	
	static class frac{
		long n;
		long d;
		public frac(long nn,long dd){
			n = nn;
			d = dd;
		}
		boolean positive(){
			return (n > d);
		}
	}
	
	public static void main(String args[]) throws NumberFormatException, IOException{
		Scanner sc = new Scanner();
		int A = sc.nextInt();
		int B = sc.nextInt();
		int C = sc.nextInt();
		int D = sc.nextInt();
		int E = sc.nextInt();
		int F = sc.nextInt();
		frac uno = new frac(B,A);
		frac dos = new frac(D,C);
		frac tres = new frac(F,E);
		if (uno.d == 0 && dos.n>0){
			System.out.println("Ron");
			return;
		}
		if (tres.n == 0){
			System.out.println("Hermione");
			return;
		}
		if (dos.n == 0 && tres.d != 0){
			System.out.println("Hermione");
			return;
		}
		if (uno.n == 0 && dos.d != 0){
			System.out.println("Hermione");
			return;
		}
		if (uno.d == 0 || dos.d == 0 || tres.d == 0){
			System.out.println("Ron");
			return;
		}
		long n = uno.n * dos.n * tres.n;
		long d = uno.d * dos.d * tres.d;
		long ans = (n  + d - 1)/ d;
		if (ans == 0 || ans == 1)
			System.out.println("Hermione");
		else
			System.out.println("Ron");
	}

}