package java_6.problem_62A.subId_331361;

import java.io.*;
import java.util.Scanner;

public class Main
{
	public static void main(String args[]) throws Exception
	{
		Solution sol = new Solution();
		sol.Run();
	}

	static class Hand
	{
		public final int left;
		public final int right;
		public Hand(int left, int right)
		{
			this.left = left;
			this.right = right;
		}
		
		public Hand(String hands)
		{
			Scanner scanner = new Scanner(hands);
			this.left = scanner.nextInt();
			this.right = scanner.nextInt();
		}
	}
	
	static public class Solution
	{
		boolean matchHands(int boy, int girl)
		{
			return boy >= girl - 1 && boy <= (girl + 1) * 2;
		}
		
		void Solve(BufferedReader input, PrintStream output) throws Exception
		{
			Hand boy = new Hand(input.readLine());
			Hand girl = new Hand(input.readLine());
			if (matchHands(boy.left, girl.right) ||
				matchHands(boy.right, girl.left))
			{
				output.println("YES");
			}
			else 
			{
				output.println("NO");
			}
		}

		void Run() throws Exception
		{
			BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
			//BufferedReader buffer = new BufferedReader(new FileReader("test.in"));
			PrintStream output = System.out;
			Solve(buffer, output);
		}
	}
}