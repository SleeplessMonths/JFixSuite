package java_6.problem_142A.subId_5496358;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.StringTokenizer;

/**
 * 111118315581
 *
 * -3 3 2 3 2 3 2 3 -3 3 -3 3 -3 3 2 3
 *
 * @author pttrung
 */
public class C {

    //   public static long x, y, gcd;
    //   public static int Mod = 1000000007;
    public static int length, node;

    public static void main(String[] args) throws FileNotFoundException {
        Scanner in = new Scanner();
        PrintWriter out = new PrintWriter(System.out);
        System.out.println(Integer.MAX_VALUE);
        // PrintWriter out = new PrintWriter(new FileOutputStream(new File("output.txt")));
        int n = in.nextInt();
        long min = Long.MAX_VALUE, max = 0;
        for(long i = 1; i*i<= n; i++){
            if(n % i == 0){
                long a = n/i;
                for(long j = 1; j *j <= a; j++){
                    if(a % j == 0){
                        
                        long c = a/j;
                      //  System.out.println(i + " " + j + " " + c);
                        long orgin = (i + 1)*(j + 2)*(c + 2);
                        min = Math.min(min, orgin - n);
                        max = Math.max(max, orgin - n);
                    }
                }
                 for(long j = 1; j *j <= i; j++){
                    if(i % j == 0){
                        long c = i/j;
                        long orgin = (a + 1)*(j + 2)*(c + 2);
                        min = Math.min(min, orgin - n);
                        max = Math.max(max, orgin - n);
                    }
                }
            }
        }
        out.println(min + " " + max);
        out.close();
    }

   

    public static long pow(long a, long b) {
        if (b == 0) {
            return 1;
        }
        long val = pow(a, b / 2);
        if (b % 2 == 0) {
            return val * val;
        } else {
            return val * val * a;
        }
    }

    public static int gcd(int a, int b) {
        if (b == 0) {
            return a;
        }
        return gcd(b, a % b);
    }

//    public static void extendEuclid(long a, long b) {
//        if (b == 0) {
//            x = 1;
//            y = 0;
//            gcd = a;
//            return;
//        }
//        extendEuclid(b, a % b);
//        long x1 = y;
//        long y1 = x - (a / b) * y;
//        x = x1;
//        y = y1;
//
//    }
    static class Scanner {

        BufferedReader br;
        StringTokenizer st;

        public Scanner() throws FileNotFoundException {
            // System.setOut(new PrintStream(new BufferedOutputStream(System.out), true));
            br = new BufferedReader(new InputStreamReader(System.in));
            //  br = new BufferedReader(new InputStreamReader(new FileInputStream(new File("input.txt"))));
        }

        public String next() {

            while (st == null || !st.hasMoreTokens()) {
                try {
                    st = new StringTokenizer(br.readLine());
                } catch (Exception e) {
                    throw new RuntimeException();
                }
            }
            return st.nextToken();
        }

        public long nextLong() {
            return Long.parseLong(next());
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        public double nextDouble() {
            return Double.parseDouble(next());
        }

        public String nextLine() {
            st = null;
            try {
                return br.readLine();
            } catch (Exception e) {
                throw new RuntimeException();
            }
        }

        public boolean endLine() {
            try {
                String next = br.readLine();
                while (next != null && next.trim().isEmpty()) {
                    next = br.readLine();
                }
                if (next == null) {
                    return true;
                }
                st = new StringTokenizer(next);
                return st.hasMoreTokens();
            } catch (Exception e) {
                throw new RuntimeException();
            }
        }
    }
}