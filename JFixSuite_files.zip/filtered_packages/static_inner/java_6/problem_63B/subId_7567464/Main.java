package java_6.problem_63B.subId_7567464;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StreamTokenizer;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Formatter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.TreeSet;

        
        
        public class Main {
             public static class Pers
             {
                 String name, type;
                 public Pers (String n, String t)
                 {
                     name=n;
                     type=t;
                 }
             }
        
            
             public static void main(String[] args) throws IOException {
         PrintWriter pw = new PrintWriter(System.out);
         BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
         StringTokenizer stk=new StringTokenizer (bf.readLine());
         int n=Integer.parseInt(stk.nextToken());
         int k=Integer.parseInt(stk.nextToken());
         int curr[]=new int[k+1];
         stk=new StringTokenizer(bf.readLine());
         for(int i=0; i<n; i++)
         {
             int a=Integer.parseInt(stk.nextToken());
             curr[a]++;
            }
         int cnt=0;
         while (true)
         {
             int nw[]=new int[k+1];
             for(int i=0; i<k; i++)
             {
                 if(curr[i]!=0)
                 {
                     nw[i]+=curr[i]-1;
                     nw[i+1]++;
                 }
             }
             nw[k]+=curr[k];
             curr=nw;
             cnt++;
             if(nw[k]==n)
             {
                 pw.println(cnt);
                 break;
             }
         }
        
                pw.flush();
          }
          
                
                  }
        /*
4 4
1 2 2 3
   *
   */