package java_6.problem_78C.subId_4926153;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.StringTokenizer;

/**
 * 111118315581
 *
 * @author pttrung
 */
public class C {

    public static void main(String[] args) {
        Scanner in = new Scanner();
        PrintWriter out = new PrintWriter(System.out);
        // System.out.println(1 << 24);

        int n = in.nextInt();
        int m = in.nextInt();
        int k = in.nextInt();
        boolean[] p = new boolean[10000000];
        for (int i = 2; i < p.length; i++) {
            if (!p[i]) {
                for (int j = i * i; j < p.length; j += i) {
                    if (j < 0) {
                        break;
                    }
                    p[j] = true;
                }
            }
        }
        boolean ok = false;
        for(int i = 2; i<p.length; i++ ){
            if(!p[i] && m % i == 0){
                if(m/i >= k){
                    ok = true;                    
                    
                }
                break;
            }
        }
        if(!ok){
            out.println("Marsel");
        }else{
            if(n%2 == 0){
                out.println("Marsel");
            }else{
                out.println("Timur");
            }
        }
        


        out.close();
    }

    static int distance(Point a, Point b) {
        int total = (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);
        return total;
    }

    static class Point {

        int x, y;

        public Point(int x, int y) {
            this.x = x;
            this.y = y;

        }
    }

    static class Scanner {

        BufferedReader br;
        StringTokenizer st;

        public Scanner() {
            // System.setOut(new PrintStream(new BufferedOutputStream(System.out), true));
            br = new BufferedReader(new InputStreamReader(System.in));
        }

        public String next() {

            while (st == null || !st.hasMoreTokens()) {
                try {
                    st = new StringTokenizer(br.readLine());
                } catch (Exception e) {
                    throw new RuntimeException();
                }
            }
            return st.nextToken();
        }

        public long nextLong() {
            return Long.parseLong(next());
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        public double nextDouble() {
            return Double.parseDouble(next());
        }

        public String nextLine() {
            st = null;
            try {
                return br.readLine();
            } catch (Exception e) {
                throw new RuntimeException();
            }
        }

        public boolean endLine() {
            try {
                String next = br.readLine();
                while (next != null && next.trim().isEmpty()) {
                    next = br.readLine();
                }
                if (next == null) {
                    return true;
                }
                st = new StringTokenizer(next);
                return st.hasMoreTokens();
            } catch (Exception e) {
                throw new RuntimeException();
            }
        }
    }
}