package java_6.problem_87A.subId_5451248;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.StringTokenizer;

/**
 * 111118315581
 *
 * -3 3 2 3 2 3 2 3 -3 3 -3 3 -3 3 2 3
 *
 * @author pttrung
 */
public class C {

    //   public static long x, y, gcd;
    //   public static int Mod = 1000000007;
    public static long[] dp;

    public static void main(String[] args) {
        Scanner in = new Scanner();
        PrintWriter out = new PrintWriter(System.out);
        // PrintWriter out = new PrintWriter(new FileOutputStream(new File("output.txt")));
        long a = in.nextInt();
        long b = in.nextInt();
        //System.out.println(b / a);
        int gcd = gcd((int)a,(int) b);
        long max = (a / gcd) * b;
       // System.out.println(max/b);
        long left = 0, right = 0;
        long last = 0;
        long c = a;
        long d = b;
        while (last <= max) {
            if (c - last < d - last) {
                //System.out.println("DASHA " + c);
                left += c - last;
                last = c;
                c += a;
            } else if (c - last > d - last) {
              //  System.out.println("MASHA " + d);
                right += d - last;
                last = d;
                d += b;
            } else {
                if (b > a) {
                    right += d - last;
                } else {
                    left += c - last;
                }
                last = d;
                c += a;
                d += b;
            }
            
        }
        //System.out.println(last + " " + left + " " + right);

        if (left == right) {
            out.println("Equal");
        } else if (left > right) {
            out.println("Dasha");
        } else {
            out.println("Masha");
        }
        out.close();
    }

    public static long pow(long a, long b) {
        if (b == 0) {
            return 1;
        }
        long val = pow(a, b / 2);
        if (b % 2 == 0) {
            return val * val;
        } else {
            return val * val * a;
        }
    }

    public static int gcd(int a, int b) {
        if (b == 0) {
            return a;
        }
        return gcd(b, a % b);
    }

//    public static void extendEuclid(long a, long b) {
//        if (b == 0) {
//            x = 1;
//            y = 0;
//            gcd = a;
//            return;
//        }
//        extendEuclid(b, a % b);
//        long x1 = y;
//        long y1 = x - (a / b) * y;
//        x = x1;
//        y = y1;
//
//    }
    static class Scanner {

        BufferedReader br;
        StringTokenizer st;

        public Scanner() {
            // System.setOut(new PrintStream(new BufferedOutputStream(System.out), true));
            br = new BufferedReader(new InputStreamReader(System.in));
            //      br = new BufferedReader(new InputStreamReader(new FileInputStream(new File("basketball_game.txt"))));
        }

        public String next() {

            while (st == null || !st.hasMoreTokens()) {
                try {
                    st = new StringTokenizer(br.readLine());
                } catch (Exception e) {
                    throw new RuntimeException();
                }
            }
            return st.nextToken();
        }

        public long nextLong() {
            return Long.parseLong(next());
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        public double nextDouble() {
            return Double.parseDouble(next());
        }

        public String nextLine() {
            st = null;
            try {
                return br.readLine();
            } catch (Exception e) {
                throw new RuntimeException();
            }
        }

        public boolean endLine() {
            try {
                String next = br.readLine();
                while (next != null && next.trim().isEmpty()) {
                    next = br.readLine();
                }
                if (next == null) {
                    return true;
                }
                st = new StringTokenizer(next);
                return st.hasMoreTokens();
            } catch (Exception e) {
                throw new RuntimeException();
            }
        }
    }
}