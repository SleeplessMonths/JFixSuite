package java_6.problem_17A.subId_8406816;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {
       static class FastScanner{
        BufferedReader s;
        StringTokenizer st;
        
        public FastScanner(){
            st = new StringTokenizer("");
            s = new BufferedReader(new InputStreamReader(System.in));
        }
        
        public FastScanner(File f) throws FileNotFoundException{
            st = new StringTokenizer("");
            s = new BufferedReader (new FileReader(f));
        }
        
        public int nextInt() throws IOException{
            if(st.hasMoreTokens())
                return Integer.parseInt(st.nextToken());
            else{
                st = new StringTokenizer(s.readLine());
                return nextInt();
            }
        }
        
      public double nextDouble() throws IOException{
            if(st.hasMoreTokens())
                return Double.parseDouble(st.nextToken());
            else{
                st = new StringTokenizer(s.readLine());
                return nextDouble();
            }
        }
      
        public long nextLong() throws IOException{
            if(st.hasMoreTokens())
                return Long.parseLong(st.nextToken());
            else{
                st = new StringTokenizer(s.readLine());
                return nextLong();
            }
        }
        
        public String nextString() throws IOException{
            if(st.hasMoreTokens())
                return st.nextToken();
            else{
                st = new StringTokenizer(s.readLine());
                return nextString();
            }
            
        }
        public String readLine() throws IOException{
            return s.readLine();
        }
        
        public void close() throws IOException{
            s.close();
        }
        
    }
      private static FastScanner s = new FastScanner();   
      private static PrintWriter ww = new PrintWriter(new OutputStreamWriter(System.out));
     
  static int count=0;
     public static void main(String[] args) throws IOException 
     {
        
         int n=s.nextInt();
         int k=s.nextInt();
         
         for(int i=2;i<=n;i++){if(isp(i))isd(i,n);}
         if(count>=k)
         ww.println("YES");else
         ww.println("NO ");
         s.close();
         ww.close();
     }
   static  boolean isp(int i)
   {   boolean k=true;
       for(int j=2;j<i;j++)
       {
           if(i%j==0)
            k=false;  
       }
       return k;
   }
   
   
   static int isd(int i,int n)
   { int v=0;
     int a=(i-1)/2;
     int b=(i-1)/2; 
     if(isa(a,b,i,n))
       v=1;  
    
     return v;
   }
   static boolean isa(int a,int b,int i,int n)
   { boolean k= false;
        if(a>=2 && b<n )
        {           if(isp(a)&&isp(b)&& a!=b)
                        k=true;
                    
                     else if(a==b && a!=3)
                        isa(a-1,b+1,i,n);
                     else if((isp(a)&&isp(b))||(isp(a)==false&&isp(b)==false))
                     {isa(a-1,b+1,i,n);}   
                
         }
        if(k &&((a+b+1)==i))
        count++;    
       return k;
   }
    
}