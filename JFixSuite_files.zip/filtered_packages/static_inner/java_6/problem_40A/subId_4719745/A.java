package java_6.problem_40A.subId_4719745;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.StringTokenizer;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Trung Pham
 */
public class A {

    public static void main(String[] args) {
        Scanner in = new Scanner();
        PrintWriter out = new PrintWriter(System.out);
        int x = in.nextInt();
        int y = in.nextInt();
        int max = Math.abs(x) > Math.abs(y) ? x : y;
        int min = Math.abs(x) > Math.abs(y) ? y : x;
        if (max % 2 == 0) {
            if (Math.abs(max) == Math.abs(min)) {
                if (max == min) {
                    if (max >= 0) {
                        out.println("black");
                    } else {
                        out.println("white");
                    }
                } else {
                    if (max > 0) {
                        out.println("white");
                    } else {
                        out.println("black");
                    }
                }
            } else if (max > 0) {
                if (min < 0) {
                    out.println("white");
                } else {
                    out.println("black");
                }
            } else {
                if (min > 0) {
                    out.println("white");
                } else {
                    out.println("black");
                }
            }
        } else {
            if (Math.abs(max) == Math.abs(min)) {
                if (max == min) {
                    if (max >= 0) {
                        out.println("black");
                    } else {
                        out.println("white");
                    }
                } else {
                    if (max > 0) {
                        out.println("white");
                    } else {
                        out.println("black");
                    }
                }
            } else if (max > 0) {
                if (min > 0) {
                    out.println("white");
                } else {
                    out.println("black");
                }
            } else {
                if (min < 0) {
                    out.println("white");
                } else {
                    out.println("black");
                }
            }
        }
        out.close();
    }

    public static class Team implements Comparable<Team> {

        String name;
        int point, scored, dif;

        @Override
        public int compareTo(Team o) {
            if (point != o.point) {
                return point - o.point;
            } else if (dif != o.dif) {
                return dif - o.dif;
            } else {
                return scored - o.scored;
            }
        }
    }

    static class FT {

        int[] data;

        FT(int n) {
            data = new int[n];
        }

        void update(int index, int val) {
            // System.out.println("UPDATE INDEX " + index);
            while (index < data.length) {
                data[index] += val;
                index += index & (-index);

                //    System.out.println("NEXT " +index);
            }
        }

        int get(int index) {
            //  System.out.println("GET INDEX " + index);
            int result = 0;
            while (index > 0) {
                result += data[index];
                index -= index & (-index);
                // System.out.println("BACK " + index);
            }
            return result;
        }
    }

    static int gcd(int a, int b) {
        if (b == 0) {
            return a;
        } else {
            return gcd(b, a % b);
        }
    }

    static int pow(int a, int b) {
        if (b == 0) {
            return 1;
        }
        if (b == 1) {
            return a;
        }
        int val = pow(a, b / 2);
        if (b % 2 == 0) {

            return val * val;
        } else {
            return val * val * a;
        }
    }

//    static Point intersect(Point a, Point b, Point c) {
//        double D = cross(a, b);
//        if (D != 0) {
//            return new Point(cross(c, b) / D, cross(a, c) / D);
//        }
//        return null;
//    }
//
//    static Point convert(Point a, double angle) {
//        double x = a.x * cos(angle) - a.y * sin(angle);
//        double y = a.x * sin(angle) + a.y * cos(angle);
//        return new Point(x, y);
//    }
    static Point minus(Point a, Point b) {
        return new Point(a.x - b.x, a.y - b.y);
    }

    static Point add(Point a, Point b) {
        return new Point(a.x + b.x, a.y + b.y);
    }

    static double cross(Point a, Point b) {
        return a.x * b.y - a.y * b.x;
    }

    static class Point {

        int x, y;

        Point(int x, int y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public String toString() {
            return "Point: " + x + " " + y;
        }
    }

    static class Scanner {

        BufferedReader br;
        StringTokenizer st;

        public Scanner() {
            //System.setOut(new PrintStream(new BufferedOutputStream(System.out), true));
            br = new BufferedReader(new InputStreamReader(System.in));
        }

        public String next() {


            while (st == null || !st.hasMoreTokens()) {
                try {
                    st = new StringTokenizer(br.readLine());
                } catch (Exception e) {
                    throw new RuntimeException();
                }
            }
            return st.nextToken();
        }

        public long nextLong() {
            return Long.parseLong(next());
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        public double nextDouble() {
            return Double.parseDouble(next());
        }

        public String nextLine() {
            st = null;
            try {
                return br.readLine();
            } catch (Exception e) {
                throw new RuntimeException();
            }
        }

        public boolean endLine() {
            try {
                String next = br.readLine();
                while (next != null && next.trim().isEmpty()) {
                    next = br.readLine();
                }
                if (next == null) {
                    return true;
                }
                st = new StringTokenizer(next);
                return st.hasMoreTokens();
            } catch (Exception e) {
                throw new RuntimeException();
            }
        }
    }
}