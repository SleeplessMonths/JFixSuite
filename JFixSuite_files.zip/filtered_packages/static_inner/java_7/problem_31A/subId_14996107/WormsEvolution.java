package java_7.problem_31A.subId_14996107;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Comparator;

public class WormsEvolution {

    public static class Pair {
        int value = -1;
        int index = -1;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                System.in));
        int n = Integer.valueOf(reader.readLine());
        Pair[] pairs = new Pair[n];
        int index = 0;
        for (String line : reader.readLine().split(" ")) {
            Pair pair = new Pair();
            pair.index = index;
            pair.value = Integer.valueOf(line);
            pairs[index++] = pair;
        }
        Arrays.sort(pairs, new Comparator<Pair>() {
            public int compare(Pair p1, Pair p2) {
                return Integer.compare(p1.value, p2.value);
            }
        });
        for (int i = 2; i < pairs.length; i++) {
            for (int j = i; j >= 0; j--) {
                for (int k = j; k >= 0; k--) {
                    if (pairs[j].value + pairs[k].value == pairs[i].value) {
                        System.out.println((pairs[i].index + 1) + " "
                                + (pairs[j].index + 1) + " "
                                + (pairs[k].index + 1));
                        return;
                    }
                }
            }
        }
        System.out.println(-1);
    }
}