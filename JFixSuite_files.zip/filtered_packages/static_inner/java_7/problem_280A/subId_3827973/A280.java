package java_7.problem_280A.subId_3827973;

import static java.lang.Math.PI;
import static java.lang.Math.abs;
import static java.lang.Math.acos;
import static java.lang.Math.cos;
import static java.lang.Math.min;
import static java.lang.Math.sin;
import static java.lang.Math.sqrt;
import static java.lang.System.in;
import static java.lang.System.out;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Comparator;
import java.util.Scanner;

public class A280 {
	public static Scanner sc = new Scanner(in);
	StringBuilder sb = new StringBuilder();
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

	public void run() throws IOException {
		String input;
		String[] inputArray;
		input = br.readLine();
		inputArray = input.split(" ");

		double w = Integer.valueOf(inputArray[0]);
		double h = Integer.valueOf(inputArray[1]);
		double alpha = Integer.valueOf(inputArray[2]);
		if (alpha>90) alpha = 180-alpha;
		alpha *=Math.PI/180;
		if (h>w) {
			double temp=w;
			w=h; 
			h=temp;
		}
		P [] t = new P[4], rt = new P[4];
		t[0] = new P(-w/2,-h/2);
		t[1] = new P(w/2,-h/2);
		t[2] = new P(w/2,h/2);
		t[3] = new P(-w/2,h/2);
		for (int i=0; i<4; i++) {
			rt[i]=t[i];
			rt[i]=rt[i].rotate(P.O, alpha);
		}
		double ans = w*h;
		if (alpha < Math.acos((w-h)/(w+h))){
			P A = S.intersection(new S(t[1],t[2]), new S(rt[0], rt[1]));
			P B = S.intersection(new S(t[1],t[2]), new S(rt[1], rt[2]));
			P C = S.intersection(new S(t[2],t[3]), new S(rt[1], rt[2]));
			P D = S.intersection(new S(t[2],t[3]), new S(rt[2], rt[3]));
			double area = D.dist(rt[2])*C.dist(rt[2]) + B.dist(rt[1])*A.dist(rt[1]);
			ans-=area;
		} else{
			P A = S.intersection(new S(t[2],t[3]), new S(rt[0], rt[1]));
			P B = S.intersection(new S(t[2],t[3]), new S(rt[2], rt[3]));
			double area = (B.dist(rt[2]) + A.dist(rt[1]))*h;
			ans-=area;
		}
		ln(ans);
	}

	public static void main(String[] args) throws IOException {
		new A280().run();
	}
	public static void ln(Object obj) {
		out.println(obj);
	}
	static class P{
		
			static final double EPS=1e-10;
			static int signum(double x){
				return x<-EPS?-1:x>EPS?1:0;
			}
		static Comparator<P> comp=new Comparator<P>(){
			public int compare(P p1, P p2) {
				return signum(p1.x-p2.x)!=0?signum(p1.x-p2.x):signum(p1.y-p2.y);
			}
		};
		public static  final P O=new P(0,0);
		final double x,y;
		P(double _x,double _y){
			x=_x;y=_y;
		}
		
		P add(P a){
			return new P(x+a.x,y+a.y);
		}
		P sub(P a){
			return new P(x-a.x,y-a.y);
		}
		P mul(P a){
			return new P(x*a.x-y*a.y,x*a.y+y*a.x);
		}
		P div(P a){
			double d2=a.dist2(O);
			return new P(dot(a,this)/d2,cross(a,this)/d2);
		}
		
		P conj(){
			return new P(x,-y);
		}
		
		static double dot(P a,P b){
			return  a.x*b.x+a.y*b.y;
		}
		
		static double cross(P a,P b){
			return  a.x*b.y-a.y*b.x;
		}
		
		double dist2(P p){
			return (x-p.x)*(x-p.x)+(y-p.y)*(y-p.y);
		}
		
		double dist(P p){
			return sqrt(dist2(p));
		}
		public double norm(){
			return dist(O);
		}
		
		static int ccw(P a,P b,P c){
			b=b.sub(a);c=c.sub(a);
			if(cross(b,c)>EPS)return 1;
			if(cross(b,c)<-EPS)return -1;
			if(dot(b,c)<-EPS)return 2;
			if(b.norm()<c.norm()-EPS)return -2;
			return 0;
		}
		
		
		
		static double arg(P o,P a){
			P dir=a.sub(o);
			double s=acos(dir.x/dir.norm());
			return dir.y>=0?s:2*PI-s;
		}
		
		static double arg(P a,P b, P c){
			double angleA = P.arg(a,b);
			double angleB = P.arg(b,c);
			double angle =  Math.PI+angleA-angleB;
			if (angle-2*Math.PI>EPS) angle-=2*Math.PI;
			if (angle<EPS) angle+=2*Math.PI;
			return angle;
		}
		
		P rotate(P o,double arg){
			return o.add(this.sub(o).mul(new P(cos(arg),sin(arg))));
		}
		
		static double S2(P a,P b,P o){
			return cross(a.sub(o),b.sub(o));
		}
		static double S(P a,P b,P o){
			return S2(a,b,o)/2;
		}
		
		static P polar(double abs,double arg){
			return new P(abs*cos(arg),abs*sin(arg));
		}
		
		static P proj(P p,P o){
			return o.mul(new P(dot(p,o)/o.norm(),0));
		}
		public boolean equals(Object obj) {
			if(obj instanceof P){
				P p=(P)obj;
				return signum(x-p.x)==0 && signum(y-p.y)==0;
			}
			return false;
		}
		public String toString(){
			return "("+x+","+y+")";
		}
	}
	static class L extends AL{
		L(P _p1, P _p2) {super(_p1, _p2);}

		
		double dist(P p){
			return abs(P.S(p2,p,p1))/p1.sub(p2).norm();
		}
		boolean isIntersect(P p){
			return abs(P.S(p2,p,p1))<EPS;
		}
		boolean isIntersect(L l){
			if(isPoint() && l.isPoint())return p1.equals(l.p1);
			if(isPoint())return l.isIntersect(p1);
			if(l.isPoint())return isIntersect(l.p1);
			return !isParallel(l) || isIntersect(l.p1);
		}

		
		static P FootOfLP(L l,P p){
			return l.p1.add(P.proj(p.sub(l.p1),l.p2.sub(l.p1)));
		}

		
		static P LineSymmetricLP(L l,P p){
			return FootOfLP(l,p).mul(new P(2.0,0)).sub(p);
		}

		public boolean equals(Object obj) {
			if(obj instanceof L){
				L l=(L)obj;
				return isParallel(l) && isIntersect(l.p1);
			}
			return false;
		}
	}
	
	class S extends AL{
		S(P _p1, P _p2) {super(_p1, _p2);}
		boolean isIntersect(P p){
			return p1.sub(p).norm()+p2.sub(p).norm()<=p1.sub(p2).norm()+EPS;
		}
		boolean isIntersect(L l){
			return P.cross(l.p2.sub(l.p1),p1.sub(l.p1))*
				P.cross(l.p2.sub(l.p1),p2.sub(l.p1))<EPS;
		}
		boolean isIntersect(S l){
			return P.ccw(p1,p2,l.p1)*P.ccw(p1,p2,l.p2)<=0
			&& P.ccw(l.p1,l.p2,p1)*P.ccw(l.p1,l.p2,p2)<=0;
		}
		
		double dist(P p){
			if(P.dot(p2.sub(p1),p.sub(p1))<EPS)return p.sub(p1).norm();
			if(P.dot(p1.sub(p2),p.sub(p2))<EPS)return p.sub(p2).norm();
			return abs(P.S(p2,p,p1))/p1.sub(p2).norm();
		}
		
		double dist(L l){
			if(isIntersect(l))return 0;
			return min(l.dist(p1),l.dist(p2));
		}
		
		double dist(S l){
			if(isIntersect(l))return 0;
			return min(min(dist(l.p1),dist(l.p2)),min(l.dist(p1),l.dist(p2)));
		}
	}
	static abstract class AL{
		
			static final double EPS=1e-10;
			static int signum(double x){
				return x<-EPS?-1:x>EPS?1:0;
			}
		public P p1,p2;
		AL(P _p1,P _p2){
			p1=_p1;
			p2=_p2;
		}

		boolean isPoint(){
			return p1.equals(p2);
		}









		
		boolean isParallel(AL l){
			return abs(P.cross(p2.sub(p1),l.p2.sub(l.p1)))<EPS;
		}
		
		boolean isOrthogonal(AL l){
			return abs(P.dot(p2.sub(p1),l.p2.sub(l.p1)))<EPS;
		}

		
		static P intersection(AL l1,AL l2){
			P dl1=l1.p2.sub(l1.p1),dl2=l2.p2.sub(l2.p1);
			double a=P.cross(dl2,l2.p1.sub(l1.p1));
			double b=P.cross(dl2,dl1);
			if(abs(a)<EPS && abs(b) <EPS)return l1.p1;
			return l1.p1.add(dl1.mul(new P(a/b,0.0)));
		}


		public boolean equals(Object obj) {
			if(obj instanceof L){
				L l=(L)obj;
				return this.p1.equals(l.p1) && this.p2.equals(l.p2);
			}
			return false;
		}
		public String toString(){
			return p1+"-"+p2;
		}
	}
}