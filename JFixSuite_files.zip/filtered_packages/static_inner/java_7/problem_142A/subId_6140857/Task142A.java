package java_7.problem_142A.subId_6140857;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;

public class Task142A {

    public static void main(String... args) throws NumberFormatException,
            IOException {
        Solution.main(System.in, System.out);
    }

    static class Scanner {

        private final BufferedReader br;
        private String[] cache;
        private int cacheIndex;

        Scanner(InputStream is) {
            br = new BufferedReader(new InputStreamReader(is));
            cache = new String[0];
            cacheIndex = 0;
        }

        int nextInt() throws IOException {
            if (cacheIndex >= cache.length) {
                cache = br.readLine().split(" ");
                cacheIndex = 0;
            }
            return Integer.parseInt(cache[cacheIndex++]);
        }

        long nextLong() throws IOException {
            if (cacheIndex >= cache.length) {
                cache = br.readLine().split(" ");
                cacheIndex = 0;
            }
            return Long.parseLong(cache[cacheIndex++]);
        }

        String next() throws IOException {
            if (cacheIndex >= cache.length) {
                cache = br.readLine().split(" ");
                cacheIndex = 0;
            }
            return cache[cacheIndex++];
        }

        void close() throws IOException {
            br.close();
        }

    }

    static class Solution {

        public static void main(InputStream is, OutputStream os)
                throws NumberFormatException, IOException {
            PrintWriter pw = new PrintWriter(os);
            Scanner sc = new Scanner(is);

            int n = sc.nextInt();

            long minRetVal = Long.MAX_VALUE;
            long maxRetVal = Long.MIN_VALUE;

            for (long a = 1; a * a * a <= n; a++) {
                if (n % a != 0) {
                    continue;
                }
                for (long b = a; a * b * b <= n; b++) {
                    if (n % (a * b) != 0) {
                        continue;
                    }
                    long c = n / (a * b);

                    minRetVal = Math.min(minRetVal,(a+1)*(b+2)*(c+2));
                    minRetVal = Math.min(minRetVal,(a+2)*(b+1)*(c+2));
                    minRetVal = Math.min(minRetVal,(a+2)*(b+2)*(c+1));

                    maxRetVal = Math.max(maxRetVal,(a+1)*(b+2)*(c+2));
                    maxRetVal = Math.max(maxRetVal,(a+2)*(b+1)*(c+2));
                    maxRetVal = Math.max(maxRetVal,(a+2)*(b+2)*(c+1));
                }
            }

            pw.println(minRetVal + " " + maxRetVal);

            pw.flush();
            sc.close();
        }
    }

}