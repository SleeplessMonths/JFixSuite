package java_7.problem_142A.subId_12919662;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

	
	
public class Solution  {
	
	static class FastScanner{
		BufferedReader s;
		StringTokenizer st;
		
		
		public FastScanner(){
			st = new StringTokenizer("");
			s = new BufferedReader(new InputStreamReader(System.in));
		}
		
		public FastScanner(File f) throws FileNotFoundException{
			st = new StringTokenizer("");
			s = new BufferedReader (new FileReader(f));
		}
		
		public int nextInt() throws IOException{
			if(st.hasMoreTokens())
				return Integer.parseInt(st.nextToken());
			else{
				st = new StringTokenizer(s.readLine());
				return nextInt();
			}
		}
		
		public double nextDouble() throws IOException{
			if(st.hasMoreTokens())
				return Double.parseDouble(st.nextToken());
			else{
				st = new StringTokenizer(s.readLine());
				return nextDouble();
			}
		}
		
		public long nextLong() throws IOException{
			if(st.hasMoreTokens())
				return Long.parseLong(st.nextToken());
			else{
				st = new StringTokenizer(s.readLine());
				return nextLong();
			}
		}
		
		public String nextString() throws IOException{
			if(st.hasMoreTokens())
				return st.nextToken();
			else{
				st = new StringTokenizer(s.readLine());
				return nextString();
			}
			
		}
		public String readLine() throws IOException{
			return s.readLine();
		}
		
		public void close() throws IOException{
			s.close();
		}
		
	}
	
	
	
	
	//FastScanner s = new FastScanner(new File("input.txt"));       copy inside void solve
    //PrintWriter ww = new PrintWriter(new FileWriter("output.txt"));
    static FastScanner s = new FastScanner();   
    static PrintWriter ww = new PrintWriter(new OutputStreamWriter(System.out));
	
    public static void main(String args[])throws IOException{
    	//Main ob=new Main();
    	Solution ob=new Solution();
		ob.solve();
		ww.close();
    }
    /////////////////////////////////////////////
   
    //////////////////////////////////////////////
   
   ///////////////////////////////////////////

    void solve() throws IOException{
    	long  n = s.nextLong();
    	
    	long min = Long.MAX_VALUE;
    	long max = Long.MIN_VALUE;
    	
    	for(long i=1;i*i*i<=n;i++){
    		if(n%i!=0)
    			continue;
    		for(long j=i;j*j<=n/i;j++){
    			if(n%j!=0)
    				continue;
    			long k = n / (i*j);
    			
    			long area = (i+1)*(j+2)*(k+2);
    			min = Math.min(min, area);
    			max = Math.max(max, area);
    			
    			area = (i+2)*(j+1)*(k+2);
    			min = Math.min(min, area);
    			max = Math.max(max, area);
    			
    			area = (i+2)*(j+2)*(k+1);
    			min = Math.min(min, area);
    			max = Math.max(max, area);
    			    			
    		}
    	}
    	
    	ww.println((min-n)+" "+(max-n));
    	
    }
}