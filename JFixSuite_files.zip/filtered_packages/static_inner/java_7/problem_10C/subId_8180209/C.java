package java_7.problem_10C.subId_8180209;

import java.io.*;
import java.util.StringTokenizer;

/**
 * CodeForces 10C - Digital Root
 * Created by Darren on 14-10-11.
 */
public class C {
    Reader in = new Reader(System.in);
    PrintWriter out = new PrintWriter(System.out);

    public static void main(String[] args) throws IOException {
        new C().run();
    }

    int n;

    void run() throws IOException {
        n = in.nextInt();
        int[] cnt = new int[10];
        for (int i = 1; i <= (n-1)%9+1; i++)
            cnt[i] = (n+8) / 9;
        for (int i = (n-1)%9+2; i <= 9; i++)
            cnt[i] = n / 9;

        long result = 0;
        for (int i = 1; i <= 9; i++) {
            for (int j = 1; j <= 9; j++)
                result += cnt[i] * cnt[j] * cnt[(i*j-1)%9+1];
        }
        for (int i = 1; i <= n; i++)
            result -= n / i;
        out.println(result);
        out.flush();
    }

    static class Reader {
        BufferedReader reader;
        StringTokenizer tokenizer;

        public Reader(InputStream input) {
            reader = new BufferedReader(new InputStreamReader(input));
            tokenizer = new StringTokenizer("");
        }

        /** get next word */
        String nextToken() throws IOException {
            while ( ! tokenizer.hasMoreTokens() ) {
                //TODO add check for eof if necessary
                tokenizer = new StringTokenizer( reader.readLine() );
            }
            return tokenizer.nextToken();
        }

        String readLine() throws IOException {
            return reader.readLine();
        }

        int nextInt() throws IOException {
            return Integer.parseInt( nextToken() );
        }

        long nextLong() throws IOException {
            return Long.parseLong( nextToken() );
        }

        double nextDouble() throws IOException {
            return Double.parseDouble( nextToken() );
        }
    }
}