package java_7.problem_21B.subId_4326859;

import java.io.*;
import java.util.*;

public class cf21b {
  public static void main(String[] args) {
    FastIO in = new FastIO(), out = in;
    int[] v = new int[3], w = new int[3], ret = new int[3];
    for(int i=0; i<3; i++)
      v[i] = in.nextInt();
    for(int i=0; i<3; i++)
      w[i] = in.nextInt();
    ret[0] = v[1]*w[2]-w[1]*v[2];
    ret[1] = v[2]*w[0]-w[2]*v[0];
    ret[2] = v[0]*w[1]-w[0]*v[1];
    if(ret[2] == 0) {
      if(ret[0] == 0 && ret[1] == 0) out.println(-1);
      else out.println(0);
    }
    else out.println(1);
    out.close();
  }

  static class FastIO extends PrintWriter {
    BufferedReader br;
    StringTokenizer st;

    public FastIO() {
      this(System.in, System.out);
    }

    public FastIO(InputStream in, OutputStream out) {
      super(new BufferedWriter(new OutputStreamWriter(out)));
      br = new BufferedReader(new InputStreamReader(in));
      scanLine();
    }

    public void scanLine() {
      try {
        st = new StringTokenizer(br.readLine().trim());
      } catch (Exception e) {
        throw new RuntimeException(e.getMessage());
      }
    }

    public int numTokens() {
      if (!st.hasMoreTokens()) {
        scanLine();
        return numTokens();
      }
      return st.countTokens();
    }

    public String next() {
      if (!st.hasMoreTokens()) {
        scanLine();
        return next();
      }
      return st.nextToken();
    }

    public double nextDouble() {
      return Double.parseDouble(next());
    }

    public long nextLong() {
      return Long.parseLong(next());
    }

    public int nextInt() {
      return Integer.parseInt(next());
    }
  }
}