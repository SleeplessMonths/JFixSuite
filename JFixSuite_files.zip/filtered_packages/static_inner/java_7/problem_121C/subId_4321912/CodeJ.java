package java_7.problem_121C.subId_4321912;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.util.Arrays;
import java.util.StringTokenizer;


public class CodeJ
{
	static class Scanner
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer("");
		
		public String nextLine()
		{
			try
			{
				return br.readLine();
			}
			catch(Exception e)
			{
				throw(new RuntimeException());
			}
		}
		
		public String next()
		{
			while(!st.hasMoreTokens())
			{
				String l = nextLine();
				if(l == null)
					return null;
				st = new StringTokenizer(l);
			}
			return st.nextToken();
		}
		
		public int nextInt()
		{
			return Integer.parseInt(next());
		}
		
		public long nextLong()
		{
			return Long.parseLong(next());
		}
		
		public double nextDouble()
		{
			return Double.parseDouble(next());
		}
		
		public int[] nextIntArray(int n)
		{
			int[] res = new int[n];
			for(int i = 0; i < res.length; i++)
				res[i] = nextInt();
			return res;
		}
		
		public long[] nextLongArray(int n)
		{
			long[] res = new long[n];
			for(int i = 0; i < res.length; i++)
				res[i] = nextLong();
			return res;
		}
		
		public double[] nextDoubleArray(int n)
		{
			double[] res = new double[n];
			for(int i = 0; i < res.length; i++)
				res[i] = nextDouble();
			return res;
		}
		public void sortIntArray(int[] array)
		{
			Integer[] vals = new Integer[array.length];
			for(int i = 0; i < array.length; i++)
				vals[i] = array[i];
			Arrays.sort(vals);
			for(int i = 0; i < array.length; i++)
				array[i] = vals[i];
		}
		
		public void sortLongArray(long[] array)
		{
			Long[] vals = new Long[array.length];
			for(int i = 0; i < array.length; i++)
				vals[i] = array[i];
			Arrays.sort(vals);
			for(int i = 0; i < array.length; i++)
				array[i] = vals[i];
		}
		
		public void sortDoubleArray(double[] array)
		{
			Double[] vals = new Double[array.length];
			for(int i = 0; i < array.length; i++)
				vals[i] = array[i];
			Arrays.sort(vals);
			for(int i = 0; i < array.length; i++)
				array[i] = vals[i];
		}

		public String[] nextStringArray(int n) 
		{	
			String[] vals = new String[n];
			for(int i = 0; i < n; i++)
				vals[i] = next();
			return vals;
		}
		
		Integer nextInteger()
		{
			String s = next();
			if(s == null)
				return null;
			return Integer.parseInt(s);
		}
		
		int[][] nextIntMatrix(int n, int m)
		{
			int[][] ans = new int[n][];
			for(int i = 0; i < n; i++)
				ans[i] = nextIntArray(m);
			return ans;
		}
		
		static <T> T fill(T arreglo, int val)
		{
			if(arreglo instanceof Object[])
			{
				Object[] a = (Object[]) arreglo;
				for(Object x : a)
					fill(x, val);
			}
			else if(arreglo instanceof int[])
				Arrays.fill((int[]) arreglo, val);
			else if(arreglo instanceof double[])
				Arrays.fill((double[]) arreglo, val);
			else if(arreglo instanceof long[])
				Arrays.fill((long[]) arreglo, val);
			return arreglo;
		}
		
		<T> T[] nextObjectArray(Class <T> clazz, int size)
		{
			@SuppressWarnings("unchecked")
			T[] result = (T[]) java.lang.reflect.Array.newInstance(clazz, size);
			for(int c = 0; c < 3; c++)
			{
				Constructor <T> constructor;
				try 
				{
					if(c == 0)
						constructor = clazz.getDeclaredConstructor(Scanner.class, Integer.TYPE);
					else if(c == 1)
						constructor = clazz.getDeclaredConstructor(Scanner.class);
					else
						constructor = clazz.getDeclaredConstructor();
				} 
				catch(Exception e)
				{
					continue;
				}
				try
				{
					for(int i = 0; i < result.length; i++)
					{
						if(c == 0)
							result[i] = constructor.newInstance(this, i);
						else if(c == 1)
							result[i] = constructor.newInstance(this);
						else
							result[i] = constructor.newInstance();	
					}
				}
				catch(Exception e)
				{
					throw new RuntimeException(e);
				}
				return result;
			}
			throw new RuntimeException("Constructor not found");
		}
	}
	
	static int factorial(int n)
	{
		if(n == 0) return 1;
		return n * factorial(n - 1);
	}
	
	static int[] permutar(boolean[] usados, int[] numeros, int n, int k)
	{
		if(n == usados.length)
			return numeros;
		int faltantes = usados.length - n;
		int sigFact = factorial(faltantes - 1);
		for(int i = 0; i < usados.length; i++)
		{
			if(!usados[i])
			{
				if(sigFact >= k)
				{
					usados[i] = true;
					numeros[n] = i;
					return permutar(usados, numeros, n + 1, k);
				}
				else
					k -= sigFact;
			}
		}
		return null;
	}
	
	static int contarHasta(int n) 
	{
		int cuenta = 0;
		for(int i = 1; i < 9; i++)
		{
			int limite = 1 << i;
			for(int j = 0; j < limite; j++)
			{
				char[] val = new char[i];
				for(int k = 0; k < i; k++)
				{
					if((j & (1 << k)) != 0)
						val[k] = '4';
					else
						val[k] = '7';
				}
				if(Integer.parseInt(new String(val)) <= n)
					cuenta++;
			}
		}
		return cuenta;
	}
	
	static boolean esLucky(int j) 
	{
		for(char c : (j + "").toCharArray())
			if(c != '4' && c != '7')
				return false;
		return true;
	}
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner();
		int n = sc.nextInt();
		int k = sc.nextInt();
		if(n > 13)
		{
			int total = contarHasta(n - 13);
			int[] vals = permutar(new boolean[13], new int[13], 0, k);
			for(int i = 0; i < 13; i++) vals[i] += n - 12;
			for(int i = 0, j = n - 12; i < 13; i++, j++)
				if(esLucky(vals[i]) && esLucky(j)) total++;
			System.out.println(total);
		}
		else
		{
			if(k > factorial(n))
			{
				System.out.println(-1);
				return;
			}
			int total = 0;
			int[] vals = permutar(new boolean[n], new int[n], 0, k);
			for(int i = 0; i < n; i++) vals[i] += 1;
			for(int i = 0, j = 1; i < n; i++, j++)
				if(esLucky(vals[i]) && esLucky(j)) total++;
			System.out.println(total);
		}
	}
}