package java_7.problem_652A.subId_17393380;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class ProblemA {
	public static void main(String[] args) {
		InputReader in = new InputReader();
		PrintWriter out = new PrintWriter(System.out);

		new ProblemA().solve(in, out);

		out.close();
	}

	public void solve(InputReader in, PrintWriter out) {
		long h1 = in.nextLong();
		long h2 = in.nextLong();

		long a = in.nextLong();
		long b = in.nextLong();

		long dayEnd = h1 + 8 * a;
		if (dayEnd > h2) {
			out.println(0);

			return;
		}

		long d = a - b;

		if (d <= 0) {
			out.println(-1);
		} else {
			long r = h2 - h1 - 8 * a;
			long step = 12 * d;

			out.println((r + step - 1) / step);
		}

	}

	static class InputReader {
		public BufferedReader br;
		public StringTokenizer st;

		public InputReader() {
			br = new BufferedReader(new InputStreamReader(System.in));
		}

		public String next() {
			while (st == null || !st.hasMoreTokens()) {
				try {
					st = new StringTokenizer(br.readLine());
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}
			return st.nextToken();
		}

		public int nextInt() {
			return Integer.parseInt(next());
		}

		long nextLong() {
			return Long.parseLong(next());
		}

		double nextDouble() {
			return Double.parseDouble(next());
		}

		String nextLine() {
			String str = "";
			try {
				str = br.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return str;
		}
	}
}