package java_7.problem_29B.subId_13788000;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class Main {
	
	public static void main(String[] arg) {
		FastScanner scan = new FastScanner(System.in);
		PrintWriter out = new PrintWriter(System.out);
		int l = scan.nextInt();
		int d = scan.nextInt();
		int v = scan.nextInt();
		int g = scan.nextInt();
		int r = scan.nextInt();
		
		double time = (double) d / (double) v;
		
		double t = time;
		while(t - (double)(g + r) >= 0) t -= (double)(g + r);
		if(t > g){
			time += ((double) g + (double) r - t);
		}
		time += ((double) l - (double) d) / (double) v;
		out.println(time);
		out.close();
	}

	static class FastScanner {
		BufferedReader br;
		StringTokenizer st;
 
		FastScanner(InputStream is) {
			try {
				br = new BufferedReader(new InputStreamReader(is));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
 
		String next() {
			while (st == null || !st.hasMoreTokens()) {
				try {
					st = new StringTokenizer(br.readLine());
				} catch (Exception e) {
					return null;
				}
			}
			return st.nextToken();
		}
 
		int nextInt() {
			return Integer.parseInt(next());
		}
 
		long nextLong() {
			return Long.parseLong(next());
		}
 
		double nextDouble() {
			return Double.valueOf(next());
		}
	}
}