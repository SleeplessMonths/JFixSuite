package java_7.problem_606A.subId_16645160;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class R335Div2A {
	static class Pair implements Comparable<Pair>{
		int a,x;
		@Override
		public int compareTo(Pair o) {
			if(this.a-x<o.a-o.x) return 1;
			if(this.a-x==o.a-o.x) return 0;
			return -1;
		}
	}
	public static void main(String[] args) {
		FastScanner in=new FastScanner();
		Pair[] pair=new Pair[3];
		for(int i=0;i<3;i++){
			pair[i]=new Pair();
			pair[i].a=in.nextInt();
		}
		for(int i=0;i<3;i++)
			pair[i].x=in.nextInt();
		
		Arrays.sort(pair);
		
		boolean f=false;
		
		if(pair[0].a>pair[0].x){
			int b=(pair[0].a-pair[0].x)/2;
			if(pair[1].a>=pair[1].x){
				int c=(pair[1].a-pair[1].x)/2;
				if(b+c+pair[2].a-pair[2].x>=0)
					f=true;
			}else{
				b-=pair[1].x-pair[1].a;
				if(b+pair[2].a-pair[2].x>=0)
					f=true;
			}
		}
		
		if(f)
			System.out.println("Yes");
		else
			System.out.println("No");
	}
	static class FastScanner{
		BufferedReader br;
		StringTokenizer st;
		public FastScanner(){br=new BufferedReader(new InputStreamReader(System.in));}
		String nextToken(){
			while(st==null||!st.hasMoreElements())
				try{st=new StringTokenizer(br.readLine());}catch(Exception e){}
			return st.nextToken();
		}
		int nextInt(){return Integer.parseInt(nextToken());}
		long nextLong(){return Long.parseLong(nextToken());}
		double nextDouble(){return Double.parseDouble(nextToken());}
	}

}