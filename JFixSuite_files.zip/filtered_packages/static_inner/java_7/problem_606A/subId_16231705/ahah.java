package java_7.problem_606A.subId_16231705;

import java.io.*;
import java.util.*;
public class ahah {
	static InputReader in;

	public static void main(String args[]) throws Exception {
		in = new InputReader("input23.txt");
		int a = in.nextInt();
		int b = in.nextInt();
		int c = in.nextInt();
		int x = in.nextInt();
		int y = in.nextInt();
		int z = in.nextInt();
		int count = 0;
		if (a < x) count += x - a;
		if (b < y) count += y - b;
		if (c < z) count += z - c;
		if ((a + b + c) - (x + y + z) > count) System.out.println("Yes");
		else System.out.println("No");
	}

	static class InputReader {
		BufferedReader in;
		StringTokenizer tokenizer;

		public InputReader(String s) {
			try {
				in = new BufferedReader(new FileReader(new File(s)));
				tokenizer = null;
			}
			catch (Exception e) {
				in = new BufferedReader(new InputStreamReader(System.in));
				tokenizer = null;
			}
		}

		public String nextLine() throws Exception {
			return in.readLine();
		}

		public String next() throws Exception {
			while (tokenizer == null || !tokenizer.hasMoreTokens()) {
				tokenizer = new StringTokenizer(in.readLine());
			}
			return tokenizer.nextToken();
		}

		public int nextInt() throws Exception {
			return Integer.parseInt(next());
		}

		public double nextDouble() throws Exception {
			return Double.parseDouble(next());
		}

		public long nextLong() throws Exception {
			return Long.parseLong(next());
		}
	}
}