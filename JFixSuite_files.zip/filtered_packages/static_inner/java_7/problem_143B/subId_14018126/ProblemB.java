package java_7.problem_143B.subId_14018126;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class ProblemB {
    public static void main(String[] args) {
        InputReader in = new InputReader();
        PrintWriter out = new PrintWriter(System.out);

        new ProblemB().solve(in, out);

        out.close();
    }

    public void solve(InputReader in, PrintWriter out) {
        String s = in.nextLine();

        boolean hasP = s.indexOf(".") >= 0;
        boolean hasS = s.indexOf("-") >= 0;

        if (hasS) {
            s = s.substring(1);
        }

        String[] t = s.split("\\.");

        if (hasP) {
            if (t[1].length() > 2) {
                t[1] = t[1].substring(0, 2);
            } else if (t[1].length() == 1) {
                t[1] = t[1] + "0";
            }
        }

        StringBuilder sb = new StringBuilder();
        int k = 0;
        for (int i = t[0].length() - 1; i >= 0; i--) {
            sb.append(t[0].charAt(i));

            k++;

            if (k % 3 == 0) {
                sb.append(",");
            }
        }

        t[0] = sb.reverse().toString();

        String res = null;
        if (hasP) {
            res = "$" + t[0] + "." + t[1];
        } else {
            res = "$" + t[0] + ".00";
        }

        if (hasS) {
            res = "(" + res + ")";
        }

        out.print(res);
    }

    static class InputReader {
        public BufferedReader br;
        public StringTokenizer st;

        public InputReader() {
            br = new BufferedReader(new InputStreamReader(System.in));
        }

        public String next() {
            while (st == null || !st.hasMoreTokens()) {
                try {
                    st = new StringTokenizer(br.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return st.nextToken();
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        long nextLong() {
            return Long.parseLong(next());
        }

        double nextDouble() {
            return Double.parseDouble(next());
        }

        String nextLine() {
            String str = "";
            try {
                str = br.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return str;
        }
    }
}