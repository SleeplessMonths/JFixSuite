package java_7.problem_46A.subId_4824678;

import java.io.*;
import java.util.*;
 
 
public class Problem1{
   
	
	
	public static void ball(){
		MyScanner sc = new MyScanner();
		int n = sc.nextInt();
		int temp = 1;
		
		for(int i=1; i<=n-1; i++){
			temp = (temp + i) % n;
			System.out.print(temp + " ");
		}
		
	}
	
	public static void main(String[] args) {
		//System.out.println("Give");
		ball();
	}
     
      
	
	
	
	/* How to read from Scanner
	 *  // Note: Do not pass System.in to the MyScanner() constructor
      MyScanner sc = new MyScanner();   
      
      int n      = sc.nextInt();        // read input as integer
      long k     = sc.nextLong();       // read input as long
      double d   = sc.nextDouble();     // read input as double
      String str = sc.next();           // read input as String
      String s   = sc.nextLine();       // read whole line as String
	 */
	public static class MyScanner {
      BufferedReader br;
      StringTokenizer st;
 
      public MyScanner() {
         br = new BufferedReader(new InputStreamReader(System.in));
      }
 
      String next() {
          while (st == null || !st.hasMoreElements()) {
              try {
                  st = new StringTokenizer(br.readLine());
              } catch (IOException e) {
                  e.printStackTrace();
              }
          }
          return st.nextToken();
      }
 
      int nextInt() {
          return Integer.parseInt(next());
      }
 
      long nextLong() {
          return Long.parseLong(next());
      }
 
      double nextDouble() {
          return Double.parseDouble(next());
      }
 
      String nextLine(){
          String str = "";
	  try {
	     str = br.readLine();
	  } catch (IOException e) {
	     e.printStackTrace();
	  }
	  return str;
      }

   }
}