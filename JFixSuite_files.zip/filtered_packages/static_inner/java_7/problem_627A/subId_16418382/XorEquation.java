package java_7.problem_627A.subId_16418382;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class XorEquation {
	static long sum, xor;
	static Long[][][][] dp = new Long[55][2][2][2];

	public static long go(int index, int carry, int allZerosA, int allZerosB) {
		if (index == 5)
			if (carry == 0 && allZerosA == 1 && allZerosB == 1)
				return 1;
			else
				return 0;
		if (dp[index][carry][allZerosA][allZerosB] != null)
			return dp[index][carry][allZerosA][allZerosB];
		if ((xor & 1L << index) > 0) {
			int s = 1 + carry;
			int v = s % 2;
			if ((sum & 1L << index) > 0) {
				if (v == 0)
					return dp[index][carry][allZerosA][allZerosB] = 0L;
			} else {
				if (v == 1)
					return dp[index][carry][allZerosA][allZerosB] = 0L;
			}
			return dp[index][carry][allZerosA][allZerosB] = go(index + 1,
					s / 2, allZerosA, 1) + go(index + 1, s / 2, 1, allZerosB);
		} else {
			// 0 0
			int s = 0 + carry;
			int v = s % 2;
			long way1 = 0;
			if ((sum & 1L << index) > 0) {
				if (v == 1)
					way1 = go(index + 1, s / 2, allZerosA, allZerosB);
			} else {
				if (v == 0)
					way1 = go(index + 1, s / 2, allZerosA, allZerosB);
			}
			// 1 1
			s = 2 + carry;
			v = s % 2;
			if ((sum & 1L << index) > 0) {
				if (v == 1)
					way1 += go(index + 1, s / 2, 1, 1);
			} else {
				if (v == 0)
					way1 += go(index + 1, s / 2, 1, 1);
			}
			return dp[index][carry][allZerosA][allZerosB] = way1;
		}
	}

	public static void main(String[] args) {
		InputReader r = new InputReader(System.in);
		sum = r.nextLong();
		xor = r.nextLong();
		System.out.println(go(0, 0, 0, 0));
	}

	static class InputReader {
		private BufferedReader reader;
		private StringTokenizer tokenizer;

		public InputReader(InputStream stream) {
			reader = new BufferedReader(new InputStreamReader(stream));
			tokenizer = null;
		}

		public InputReader(FileReader stream) {
			reader = new BufferedReader(stream);
			tokenizer = null;
		}

		public String nextLine() {
			try {
				return reader.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}
		}

		public String next() {
			while (tokenizer == null || !tokenizer.hasMoreTokens()) {
				try {
					tokenizer = new StringTokenizer(reader.readLine());
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}
			return tokenizer.nextToken();
		}

		public int nextInt() {
			return Integer.parseInt(next());
		}

		public long nextLong() {
			return Long.parseLong(next());
		}

		public double nextDouble() {
			return Double.parseDouble(next());
		}
	}
}
// 11
// 11