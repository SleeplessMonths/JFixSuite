package java_7.problem_150A.subId_13076152;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.StringTokenizer;


public class Main {
    public static void main(String[] args) {
        TaskA a = new TaskA();
        
        a.Solve();
    }

    public static class TaskA {
        private long q;
        
        public void Solve() {
            _input();
            
            Pair amount = _divisorsAmount(q);
            
            if(q == 1 || amount.first == 1) {
                _output(true, 0);
                return;
            }
            if(amount.first > 2) {
                _output(true, amount.second);
                return;
            }
            _output(false, 0);
        }
        
        private Pair _divisorsAmount(long x) {
            long[] firstTwoDivizors = new long[2];
            firstTwoDivizors[0] = 1;
            firstTwoDivizors[1] = 1;
            int pos = 0;
            
            long cnt = 0;
            for(long i = 2; i * i <= x; ++i) {
                while(x % i == 0) {
                    x /= i;
                    cnt++;
                    
                    if(pos < 2)
                        firstTwoDivizors[pos++] = i;
                }
            }
            
            if(x != 1) {
                if (pos < 2)
                    firstTwoDivizors[pos++] = x;
                cnt++;
            }
            
            return new Pair(cnt, firstTwoDivizors[0] * firstTwoDivizors[1]);
        }
        
        private void _input() {
            Reader in = new Reader(System.in);

            q = in.nextLong();
            
            in.close();
        }
        
        private void _output(boolean firstWin, long move) {
            Writer out = new Writer(System.out);
            
            if(!firstWin)
                out.Writeln(2);
            else {
                out.Writeln(1);
                out.Writeln(move);
            }
            
            out.close();
        }
        
        public class Pair {
            public long first, second;
            
            public Pair(long a, long b) {
                first = a;
                second = b;
            }
        }
    }

    
    public static class Reader {
        public BufferedReader reader;
        public StringTokenizer tokenizer;

        public Reader(InputStream stream) {
            reader = new BufferedReader(new InputStreamReader(stream), 32768);
            tokenizer = null;
        }

        public String next() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    tokenizer = new StringTokenizer(reader.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return tokenizer.nextToken();
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }
        
        public long nextLong() {
            return Long.parseLong(next());
        }
        
        public double nextDouble() {
            return Double.parseDouble(next());
        }
        
        public void close() {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static class Writer {
        private PrintWriter writer;
        
        public Writer(OutputStream out) {
            writer = new PrintWriter(out);
        }
        
        public void Writeln(String value) {
            writer.println(value);
        }
        
        public void Write(String value) {
            writer.println(value);
        }
        
        public void Writeln(int value) {
            writer.println(value);
        }
        
        public void Write(int value) {
            writer.println(value);
        }
        
        public void Writeln(double value) {
            writer.println(value);
        }
        
        public void Write(double value) {
            writer.println(value);
        }
        
        public void Writeln(BigInteger value) {
            writer.println(value);
        }
        
        public void Write(BigInteger value) {
            writer.println(value);
        }
        
        public void Writeln(BigDecimal value) {
            writer.println(value);
        }
        
        public void Write(BigDecimal value) {
            writer.println(value);
        }
        
        public void close() {
            writer.close();
        }
    }

}