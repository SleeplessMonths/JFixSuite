package java_7.problem_150A.subId_12910459;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.Map.Entry;
import java.util.StringTokenizer;
import java.util.TreeMap;
 
 
public class Solution{
    
    ///////////////////////////////////////////////////////////////////////////
    static class FastScanner{
        BufferedReader s;
        StringTokenizer st;
        
        public FastScanner(InputStream InputStream){
            st = new StringTokenizer("");
            s = new BufferedReader(new InputStreamReader(InputStream));
        }
        
        public FastScanner(File f) throws FileNotFoundException{
            st = new StringTokenizer("");
            s = new BufferedReader (new FileReader(f));
        }
        
        public int nextInt() throws IOException{
            if(st.hasMoreTokens())
                return Integer.parseInt(st.nextToken());
            else{
                st = new StringTokenizer(s.readLine());
                return nextInt();
            }
        }
        
        public BigInteger big() throws IOException{
            if(st.hasMoreTokens())
                return new BigInteger(st.nextToken());
            else{
                st = new StringTokenizer(s.readLine());
                return big();
            }
        }
        
        public double nextDouble() throws IOException{
            if(st.hasMoreTokens())
                return Double.parseDouble(st.nextToken());
            else{
                st = new StringTokenizer(s.readLine());
                return nextDouble();
            }
        }
      
        public long nextLong() throws IOException{
            if(st.hasMoreTokens())
                return Long.parseLong(st.nextToken());
            else{
                st = new StringTokenizer(s.readLine());
                return nextLong();
            }
        }
        
        public String nextString() throws IOException{
            if(st.hasMoreTokens())
                return st.nextToken();
            else{
                st = new StringTokenizer(s.readLine());
                return nextString();
            }
            
        }
        public String readLine() throws IOException{
            return s.readLine();
        }
        
        public void close() throws IOException{
            s.close();
        }
        
    }
    
    ////////////////////////////////////////////////////////////////////
    //      Number Theory
    
    long pow(long a,long b,long mod){
        if(b == 0)  return 1;
        long t = pow(a,b>>1,mod);
        t = (t * t) % mod;
        if((b & 1) == 1)    t = (t * a);
        if(t >= mod)    t %= mod;
        return t;
    }
    
    int divisor(long x,long[] a){
        long limit = x;
        int numberOfDivisors = 0;
 
        for (int i=1; i < limit; ++i) {
            if (x % i == 0) {
                limit = x / i;
                if (limit != i) {
                    numberOfDivisors++;
                }
                numberOfDivisors++;
            }
        }
        return numberOfDivisors;
    }
    
    void findSubsets(int array[]){
        long numOfSubsets = 1 << array.length; 
        for(int i = 0; i < numOfSubsets; i++){    
            @SuppressWarnings("unused")
            int pos = array.length - 1;
            int bitmask = i;
            while(bitmask > 0){     
                if((bitmask & 1) == 1)
//                    ww.print(array[pos]+" ");
                bitmask >>= 1;
                pos--;
            }
//            ww.println();
        }
    }
    
    
    public static long gcd(long a, long b){
        return b == 0 ? a : gcd(b,a%b);
    }
    
  
    public static long lcm(int a,int b, int c){
        return lcm(lcm(a,b),c);
    }
    
    public static long lcm(long a, long b){
        return (a*b/gcd(a,b));
    }
    
    public static long invl(long a, long mod) {
        long b = mod;
        long p = 1, q = 0;
        while (b > 0) {
            long c = a / b;
            long d;
            d = a;
            a = b;
            b = d % b;
            d = p;
            p = q;
            q = d - c * q;
        }
        return p < 0 ? p + mod : p;
    }
    
    ////////////////////////////////////////////////////////////////////
    
    
//     FastScanner s = new FastScanner(new File("a.pdf"));
//   PrintWriter ww = new PrintWriter(new FileWriter("output.txt")); 
    static InputStream inputStream = System.in;
    static FastScanner s = new FastScanner(inputStream); 
    static OutputStream outputStream = System.out;
    static PrintWriter ww = new PrintWriter(new OutputStreamWriter(outputStream));
//      private static Scanner s = new Scanner(System.in);
    @SuppressWarnings("unused")
    private static int[][] states = { {-1,0} , {1,0} , {0,-1} , {0,1} };
    
      
    //////////////////////////////////////////////////////////////////// 
     
    
     
    public static void main(String[] args) throws Exception{
        new Solution().solve();
        s.close();
        ww.close();
    }
    

    ////////////////////////////////////////////////////////////////////
    
    
    void solve() throws IOException  {
        
        long q = s.nextLong();
        long p = q;
        int an = 0;
        
        
        TreeMap<Long,Integer> t = new TreeMap<Long,Integer>();
        
        for(long k=2;k*k<=q;k++){
            an = 0;
            if(q % k == 0){
                while(q % k == 0){
                    an++;
                    q /= k;
                }
                t.put(k, an);
            }
        }
        
        if(q > 1) t.put(q, 1);
        
        
        if(t.size() > 1){
            Entry<Long,Integer> et = t.pollFirstEntry();
            Entry<Long,Integer> te = t.pollFirstEntry();
            if(et.getKey()*te.getKey() == p) ww.println(2);
            else{
                ww.println(1);
                ww.println(et.getKey()*te.getKey());
            }
        }else if(t.size() == 1){
            Entry<Long,Integer> et = t.pollFirstEntry();
            if(et.getValue() > 1){
                if(et.getKey()*et.getKey() == p) ww.println(2);
                else{
                    ww.println(1);
                    ww.println(et.getKey()*et.getKey());
                }
            }else ww.println(2);
        }else ww.println(2);
        
    }
   
}