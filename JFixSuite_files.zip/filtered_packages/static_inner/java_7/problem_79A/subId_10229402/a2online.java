package java_7.problem_79A.subId_10229402;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.StringTokenizer;


public class a2online{

    static class FastScanner{
        BufferedReader s;
        StringTokenizer st;
        
        public FastScanner(){
            st = new StringTokenizer("");
            s = new BufferedReader(new InputStreamReader(System.in));
        }
        
        public FastScanner(File f) throws FileNotFoundException{
            st = new StringTokenizer("");
            s = new BufferedReader (new FileReader(f));
        }
        
        public int nextInt() throws IOException{
            if(st.hasMoreTokens())
                return Integer.parseInt(st.nextToken());
            else{
                st = new StringTokenizer(s.readLine());
                return nextInt();
            }
        }
        
      public double nextDouble() throws IOException{
            if(st.hasMoreTokens())
                return Double.parseDouble(st.nextToken());
            else{
                st = new StringTokenizer(s.readLine());
                return nextDouble();
            }
        }
      
        public long nextLong() throws IOException{
            if(st.hasMoreTokens())
                return Long.parseLong(st.nextToken());
            else{
                st = new StringTokenizer(s.readLine());
                return nextLong();
            }
        }
        
        public String nextString() throws IOException{
            if(st.hasMoreTokens())
                return st.nextToken();
            else{
                st = new StringTokenizer(s.readLine());
                return nextString();
            }
            
        }
        public String readLine() throws IOException{
            return s.readLine();
        }
        
        public void close() throws IOException{
            s.close();
        }
        
    }
      private static FastScanner s = new FastScanner();   
      private static PrintWriter ww = new PrintWriter(new OutputStreamWriter(System.out));
     
   //   static int count=0;
     public static void main(String[] args) throws IOException 
     {
        int h=s.nextInt();int t=s.nextInt();int i=1;
        while(true)
        {
            if(i%2!=0)
            {
                if(h/2>=1)
                {
                    h=h-2;
                    if(t>=2)
                      t=t-2;
                    else
                    {System.out.println("Hanako");break;}
                
                }
                else if(h==1)
                {
                    h--;
                    if(t/12>=1)
                      t=t-12;
                    else
                    {
                        System.out.println("Hanako");break;
                    }  
                }
                else
                { System.out.println("Hanako");break;}
                //System.out.println("frst  "+h+"  "+t);
            }    
               
                if(i%2==0)
              {
                if(t/22>=1)
                {
                    t=t-22;
                   
                }
                else if(h*100+t*10>=220)
                {
                     int cost=t*10;
                     t=0;
                     if(h*100-(220-cost)>=0)
                         h=h*100-220-cost;
                     else
                     {System.out.println("Ciell");break;}  
                }
                else
                {System.out.println("Ciell"); break;} 
              }  
            
            i++;
        }
         s.close();
         ww.close();
     }
     public static int gcd(int a, int b){
        return b == 0 ? a : gcd(b,a%b);
    }
   
    
}
/*zabardast swappimng of sorting
/*
    for(int h=0;h<n;h++)
        {  int temp,temp1,temp2;
             for(int y=h+1;y<n;y++)
           {
             if(a[y][2]>=a[h][2])
             {
              
             temp=a[y][2];                 //////sorting
             a[y][2]=a[h][2]; 
              a[h][2]=temp;
              temp1=a[y][0];
              a[y][0]=a[h][0];
              a[h][0]=temp1;
              temp2=a[y][1];
              a[y][1]=a[h][1];
              a[h][1]=temp2;
           
             }
           }  
        }
*/
/*
static final Point getMinMax(int[] array) {
        int min = array[0];
        int max = array[0];
        
        for (int index = 0, size = array.length; index < size; ++index, ++index) {
            int value = array[index];
            
            if (index == size - 1) {
                min = min(min, value);
                max = max(max, value);
            } else {
                int otherValue = array[index + 1];
                
                if (value <= otherValue) {
                    min = min(min, value);
                    max = max(max, otherValue);
                } else {
                    min = min(min, otherValue);
                    max = max(max, value);
                }
            }
        }
        
        return new Point(min, max);
    }
    
*/
/*

/// Demonstrate several Is... methods.
class IsDemo {
public static void main(String args[]) {
char a[] = {'a', 'b', '5', '?', 'A', ' '};
for(int i=0; i<a.length; i++) {
if(Character.isDigit(a[i]))                                   ///check if digit is present in string
System.out.println(a[i] + " is a digit.");
if(Character.isLetter(a[i]))
    System.out.println(num + " in binary: " +
Integer.toBinaryString(num));
System.out.println(num + " in octal: " +
Integer.toOctalString(num));
System.out.println(num + " in hexadecimal: " +
Integer.toHexString(num));
}
}
*/
/*
private static void findSubsets(int array[])
{
  int numOfSubsets = 1 << array.length; 

  for(int i = 0; i < numOfSubsets; i++)
 {
    int pos = array.length - 1;                                /////bitmask to find all sub sets
   int bitmask = i;

   System.out.print("{");
   while(bitmask > 0)
   {
    if((bitmask & 1) == 1)
     System.out.print(array[pos]+",");
    bitmask >>= 1;
    pos--;
   }
   System.out.print("}");
 }
}
*/

/*   no of DIVISORSSSSSS
 public ArrayList<Integer> get(int x){
            ArrayList<Integer> divisors = new ArrayList<>();
            for(int i = 1; i * i <= x; i++){
                if(x % i == 0){
                    divisors.add(i);
                    if(i * i != x){
                        divisors.add( x / i);
                    }
                }
            }
            
*/
/*  //// find sum of multiple of a value below limit// ----> (l*(n+1))/2
  public static long getSequenceSum(long value, long limit) {
long q = (limit - 1) / value;
long ans = ((value*q)*(1+q) )/ 2;
return ans;
}
*/
/*// largest prime factor of a no
 public static long largestPrimeFactor(long n) {

        // largest composite factor must be smaller than sqrt
        long sqrt = (long)Math.ceil(Math.sqrt((double)n));

        long largest = -1;

        for(long i = 2; i <= sqrt; i++) {
            if(n % i == 0) {
                long test = largestPrimeFactor(n/i);
                if(test > largest) {
                    largest = test;
                }
            }
        }

        if(largest != -1) {
            return largest;
        }

        // number is prime
        return n;
    } 
*/
/*    // prime no using sieve of erostheneses
  public static void prime()
{
  boolean[] isPrime = new boolean[100000000+ 1];
         Arrays.fill(isPrime, true);

        // mark non-primes <= N using Sieve of Eratosthenes
        for (int i = 2; i*i <= 100000000; i++)
        {

             if (isPrime[i])
             {
                for (int j = i; i*j <= 100000000; j++) {
                    isPrime[i*j] = false;
                }
            }
        }
}

*/
/*//// largest common sequences
 public String lcs(String str1, String str2)
    {
        int l1 = str1.length();
        int l2 = str2.length();
 
        int[][] arr = new int[l1 + 1][l2 + 1];
 
        for (int i = l1 - 1; i >= 0; i--)
        {
            for (int j = l2 - 1; j >= 0; j--)
            {
                if (str1.charAt(i) == str2.charAt(j))
                    arr[i][j] = arr[i + 1][j + 1] + 1;
                else 
                    arr[i][j] = Math.max(arr[i + 1][j], arr[i][j + 1]);
            }
        }
 
        int i = 0, j = 0;
        StringBuffer sb = new StringBuffer();
        while (i < l1 && j < l2) 
     
 {
            if (str1.charAt(i) == str2.charAt(j)) 
            {
                sb.append(str1.charAt(i));
                i++;
                j++;
            }
            else if (arr[i + 1][j] >= arr[i][j + 1]) 
                i++;
            else
                j++;
        }
        return sb.toString();
    }
 
*/