package java_7.problem_146B.subId_14051552;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class ProblemB {
    public static void main(String[] args) {
        InputReader in = new InputReader();
        PrintWriter out = new PrintWriter(System.out);

        new ProblemB().solve(in, out);

        out.close();
    }

    public void solve(InputReader in, PrintWriter out) {
        int a = in.nextInt();
        int b = in.nextInt();

        if (b > a) {
            out.print(b);
        } else {
            String sa = Integer.toString(a);
            String sb = Integer.toString(b);

            if (sa.length() == sb.length()) {
                out.print("1" + b);
            } else {
                String t1 = sa.substring(0, sa.length() - sb.length());
                String t2 = sa.substring(sa.length() - sb.length());

                int d = Integer.parseInt(t2);

                if (d < b) {
                    out.print(t1 + sb);
                } else {
                    out.print((Integer.parseInt(t1) + 1) + sb);
                }
            }
        }
    }

    static class InputReader {
        public BufferedReader br;
        public StringTokenizer st;

        public InputReader() {
            br = new BufferedReader(new InputStreamReader(System.in));
        }

        public String next() {
            while (st == null || !st.hasMoreTokens()) {
                try {
                    st = new StringTokenizer(br.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return st.nextToken();
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        long nextLong() {
            return Long.parseLong(next());
        }

        double nextDouble() {
            return Double.parseDouble(next());
        }

        String nextLine() {
            String str = "";
            try {
                str = br.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return str;
        }
    }
}