package java_7.problem_146B.subId_14051957;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class ProblemB {
    public static void main(String[] args) {
        InputReader in = new InputReader();
        PrintWriter out = new PrintWriter(System.out);

        new ProblemB().solve(in, out);

        out.close();
    }

    public void solve(InputReader in, PrintWriter out) {
        int a = in.nextInt();
        int b = in.nextInt();

        if (b > a) {
            out.print(b);
        } else {
            String s = Integer.toString(b);

            for (int i = a + 1; i <= 100000; i++) {
                if (check(i, s)) {
                    out.print(i);

                    return;
                }
            }

        }
    }

    private static boolean check(int a, String b) {
        String s = Integer.toString(a);

        String mask = "";
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '4' || s.charAt(i) == '7') {
                mask += s.charAt(i);
            }
        }

        return mask.equals(b);
    }

    static class InputReader {
        public BufferedReader br;
        public StringTokenizer st;

        public InputReader() {
            br = new BufferedReader(new InputStreamReader(System.in));
        }

        public String next() {
            while (st == null || !st.hasMoreTokens()) {
                try {
                    st = new StringTokenizer(br.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return st.nextToken();
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        long nextLong() {
            return Long.parseLong(next());
        }

        double nextDouble() {
            return Double.parseDouble(next());
        }

        String nextLine() {
            String str = "";
            try {
                str = br.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return str;
        }
    }
}