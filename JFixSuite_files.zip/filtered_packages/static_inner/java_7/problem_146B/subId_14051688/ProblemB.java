package java_7.problem_146B.subId_14051688;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class ProblemB {
    public static void main(String[] args) {
        InputReader in = new InputReader();
        PrintWriter out = new PrintWriter(System.out);

        new ProblemB().solve(in, out);

        out.close();
    }

    public void solve(InputReader in, PrintWriter out) {
        int a = in.nextInt();
        int b = in.nextInt();

        if (b > a) {
            out.print(b);
        } else {
            String sa = Integer.toString(a);
            String sb = Integer.toString(b);

            if (sa.length() == sb.length()) {
                out.print("1" + b);
            } else {
                String t1 = sa.substring(0, sa.length() - sb.length());
                String t2 = sa.substring(sa.length() - sb.length());

                long d = Long.parseLong(t2);

                String res = "";
                if (d < b) {
                    res += t1;
                } else {
                    res += (Long.parseLong(t1) + 1);
                }

                char[] c = res.toCharArray();
                for (int i = 0; i < c.length; i++) {
                    if (c[i] == '4') {
                        c[i] = '5';
                    } else if (c[i] == '7') {
                        c[i] = '8';
                    }
                }

                out.print(new String(c) + sb);
            }
        }
    }

    static class InputReader {
        public BufferedReader br;
        public StringTokenizer st;

        public InputReader() {
            br = new BufferedReader(new InputStreamReader(System.in));
        }

        public String next() {
            while (st == null || !st.hasMoreTokens()) {
                try {
                    st = new StringTokenizer(br.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return st.nextToken();
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        long nextLong() {
            return Long.parseLong(next());
        }

        double nextDouble() {
            return Double.parseDouble(next());
        }

        String nextLine() {
            String str = "";
            try {
                str = br.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return str;
        }
    }
}