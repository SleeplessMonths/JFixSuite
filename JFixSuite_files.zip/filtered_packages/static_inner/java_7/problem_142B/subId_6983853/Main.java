package java_7.problem_142B.subId_6983853;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class Main {
  public static void main(String[] args) {
    MyScanner sc = new MyScanner();
    int n = sc.nextInt(), m = sc.nextInt();
    if (n > m) {
      int temp = n;
      n = m;
      m = temp;
    }
    // Now n < m.
    if (n == 1) {
      System.out.println(m);
    } else if (n == 2) {
      if (m == 2) {
        System.out.println(4);
      } else {
        System.out.println((m % 2 == 0) ? m : m + 1);
      }
    } else {
      System.out.println((m * n + 1) / 2);
    }
  }
  
  public static class MyScanner {
    BufferedReader br;
    StringTokenizer st;
    public MyScanner() { br = new BufferedReader(new InputStreamReader(System.in)); }
    int nextInt() { return Integer.parseInt(next()); }
    long nextLong() { return Long.parseLong(next()); }
    double nextDouble() { return Double.parseDouble(next()); }
    String next() {
      while (st == null || !st.hasMoreElements()) {
        try { st = new StringTokenizer(br.readLine()); }
        catch (IOException e) { e.printStackTrace(); }
      }
      return st.nextToken();
    }
    String nextLine() {
      String str = "";
      try { str = br.readLine(); }
      catch (IOException e) { e.printStackTrace(); }
      return str;
    }
  }
}