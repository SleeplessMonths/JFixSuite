package java_7.problem_186C.subId_19019325;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class ProblemC {
	private final long mod = 1000000007l;
	
	public static void main(String[] args) {
		InputReader in = new InputReader();
		PrintWriter out = new PrintWriter(System.out);

		new ProblemC().solve(in, out);

		out.close();
	}

	public void solve(InputReader in, PrintWriter out) {
		long n = in.nextLong();
		
		long a = pow(2, n - 1, mod);
		long b = (pow(2, n, mod) + 1)% mod;
		
		out.println((a * b) % mod);
	}
	
	private static long pow(long a, long p, long mod) {

		if (p == 0) {
			return 1;
		}

		if (p == 1) {
			return a;

		}

		long x = pow(a, p / 2, mod);

		if (p % 2 != 0) {
			return (x * x * a) % mod;
		}

		return (x * x) % mod;
	}

	static class InputReader {
		public BufferedReader br;
		public StringTokenizer st;

		public InputReader() {
			br = new BufferedReader(new InputStreamReader(System.in));
		}

		public String next() {
			while (st == null || !st.hasMoreTokens()) {
				try {
					st = new StringTokenizer(br.readLine());
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}
			return st.nextToken();
		}

		public int nextInt() {
			return Integer.parseInt(next());
		}

		long nextLong() {
			return Long.parseLong(next());
		}

		double nextDouble() {
			return Double.parseDouble(next());
		}

		String nextLine() {
			String str = "";
			try {
				str = br.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return str;
		}
	}
}