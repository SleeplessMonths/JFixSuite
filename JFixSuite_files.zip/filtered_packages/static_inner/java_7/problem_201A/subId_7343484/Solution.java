package java_7.problem_201A.subId_7343484;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.Scanner;
import java.util.TreeMap;

public class Solution{
	
	///////////////////////////////////////////////////////////////////////////
	static class FastScanner{
		BufferedReader s;
		StringTokenizer st;
		
		public FastScanner(){
			st = new StringTokenizer("");
			s = new BufferedReader(new InputStreamReader(System.in));
		}
		
		public FastScanner(File f) throws FileNotFoundException{
			st = new StringTokenizer("");
			s = new BufferedReader (new FileReader(f));
		}
		
		public int nextInt() throws IOException{
			if(st.hasMoreTokens())
				return Integer.parseInt(st.nextToken());
			else{
				st = new StringTokenizer(s.readLine());
				return nextInt();
			}
		}
		
		public double nextDouble() throws IOException{
			if(st.hasMoreTokens())
				return Double.parseDouble(st.nextToken());
			else{
				st = new StringTokenizer(s.readLine());
				return nextDouble();
			}
		}
		
		public long nextLong() throws IOException{
			if(st.hasMoreTokens())
				return Long.parseLong(st.nextToken());
			else{
				st = new StringTokenizer(s.readLine());
				return nextLong();
			}
		}
		
		public String nextString() throws IOException{
			if(st.hasMoreTokens())
				return st.nextToken();
			else{
				st = new StringTokenizer(s.readLine());
				return nextString();
			}
			
		}
		public String readLine() throws IOException{
			return s.readLine();
		}
		
		public void close() throws IOException{
			s.close();
		}
		
	}
	
	////////////////////////////////////////////////////////////////////
	//		Number Theory
	
	public static int divisor(int x){
	    int limit = x;
	    int numberOfDivisors = 0;

	    for (int i=1; i < limit; ++i) {
	        if (x % i == 0) {
	            limit = x / i;
	            if (limit != i) {
	                numberOfDivisors++;
	            }
	            numberOfDivisors++;
	        }
	    }
	    return numberOfDivisors;
    }
	
	
	public static long gcd(long a, long b){
		return b == 0 ? a : gcd(b,a%b);
	}
	
  
	public static long lcm(long a,long b, long c){
		return lcm(lcm(a,b),c);
	}
	
	public static long lcm(long a, long b){
		return a*b/gcd(a,b);
	}
	
	
	////////////////////////////////////////////////////////////////////
	
	
//	  private static  	FastScanner s = new FastScanner(new File("input.txt"));
//	  private static PrintWriter ww = new PrintWriter(new FileWriter("output.txt"));
	  private static FastScanner s = new FastScanner();   
      private static PrintWriter ww = new PrintWriter(new OutputStreamWriter(System.out));
//      private static Scanner s = new Scanner(System.in);
	@SuppressWarnings("unused")
	private static int[][] states = { {-1,0} , {1,0} , {0,-1} , {0,1} };
	
      
    //////////////////////////////////////////////////////////////////// 
      
     
    public static void main(String[] args) throws IOException{
 		Solution so = new Solution();
 		so.solve();
 	}
    
    ////////////////////////////////////////////////////////////////////
    
   
	void findSubsets(int array[]){
	    	
	    long numOfSubsets = 1 << array.length; 
	    for(int i = 0; i < numOfSubsets; i++){
	    		
	    	int pos = array.length - 1;
	    	int bitmask = i;

	 //      System.out.print("{");

	    	while(bitmask > 0){
	    			
	    		if((bitmask & 1) == 1)
	   				ww.print(array[pos]+" ");
	   			bitmask >>= 1;
	        	pos--;
	    	}
	    		
	   		ww.println();
	   	}
	}
    
	 
    void solve() throws IOException{
    	
    	TreeMap<Integer,Integer> t = new TreeMap<Integer,Integer>();
    	int n = s.nextInt();
    	for(int i=1;i<100;i+=2)
    		t.put((i*i+1)/2,i);
    	if(n == 1) ww.println(-1);
    	else if(n == 2) ww.println(3);
    	else if(n == 3) ww.println(5);
    	else ww.println(t.higherEntry(n-1).getValue());
    	s.close();
 	    ww.close(); 
    
     }
    
}