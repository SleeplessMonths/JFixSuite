package java_7.problem_171D.subId_5740753;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;


public class Problem4_BrokenChecker {
	public static void checker(){
		 MyScanner sc = new MyScanner();  
		 int a = sc.nextInt();
		 
//		 for(int i=1; i<=5; i++)
//	 System.out.println(i%3 + 1);
		 
		 switch (a){
		 case 1: System.out.println(1); break;
		 case 2: System.out.println(3); break;
		 case 3: System.out.println(1); break;
		 case 4: System.out.println(2); break;
		 case 5: System.out.println(3); break;
		 }
		 
		
	}
	
	
	public static void main(String[] args){
		checker();
	}
	
	
	/* How to read from Scanner
     MyScanner sc = new MyScanner();   
     
     int n      = sc.nextInt();        // read input as integer
     long k     = sc.nextLong();       // read input as long
     double d   = sc.nextDouble();     // read input as double
     String str = sc.next();           // read input as String
     String s   = sc.nextLine();       // read whole line as String
	 */
	public static class MyScanner {
     BufferedReader br;
     StringTokenizer st;

     public MyScanner() {
        br = new BufferedReader(new InputStreamReader(System.in));
     }

     String next() {
         while (st == null || !st.hasMoreElements()) {
             try {
                 st = new StringTokenizer(br.readLine());
             } catch (IOException e) {
                 e.printStackTrace();
             }
         }
         return st.nextToken();
     }

     int nextInt() {
         return Integer.parseInt(next());
     }

     long nextLong() {
         return Long.parseLong(next());
     }

     double nextDouble() {
         return Double.parseDouble(next());
     }

     String nextLine(){
         String str = "";
	  try {
	     str = br.readLine();
	  } catch (IOException e) {
	     e.printStackTrace();
	  }
	  return str;
     }

  }

}