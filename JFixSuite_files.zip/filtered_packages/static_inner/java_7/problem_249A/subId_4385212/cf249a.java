package java_7.problem_249A.subId_4385212;

import java.io.*;
import java.util.*;

public class cf249a {
  public static void main(String[] args) {
    FastIO in = new FastIO(), out = in;
    double y1 = in.nextDouble();
    double y2 = in.nextDouble();
    double yw = in.nextDouble();
    double xb = in.nextDouble();
    double yb = in.nextDouble();
    double r = in.nextDouble();
    yw -= r;
    double yt = y1+r;
    yt = 2*yw - yt;
    double dy1 = yt - yb;
    double dy2 = yw - yb;
    double dx1 = xb;
    double dx2 = dy2*dx1/dy1;
    vec2 v1 = new vec2(dx2,yw);
    vec2 v2 = new vec2(0,y1+r);
    vec2 v3 = new vec2(0,y2);
    double dist = new line2(v1,v2).dist(v3);
    if(dist-1e-9 < r) 
      out.println(-1);
    else
      out.printf("%.10f%n", dx2);
    out.close();
  }
  static class GEOM {
    static double eps = 1e-9;
    static boolean eq(double x, double y) {
      return Math.abs(x-y) < eps;
    }
  }
  static class vec2 {
    double x,y;
    vec2(double a, double b) {x=a;y=b;}
    boolean eq(vec2 rhs) {return GEOM.eq(x,rhs.x) && GEOM.eq(y,rhs.y);}
    vec2 add(vec2 rhs) {return new vec2(x+rhs.x,y+rhs.y);}
    vec2 sub(vec2 rhs) {return new vec2(x-rhs.x,y-rhs.y);}
    vec2 scale(double s) {return new vec2(x*s,y*s);}
    vec2 midpoint(vec2 rhs) {return new vec2(.5*(x+rhs.x),.5*(y+rhs.y));}
    double dot(vec2 rhs) {return x*rhs.x+y*rhs.y;}
    double cross(vec2 rhs) {return x*rhs.y-y*rhs.x;}//pos->left,neg->right
    double mag() {return Math.sqrt(x*x+y*y);}
    double mag2() {return x*x+y*y;}
    double dist(vec2 rhs) {return sub(rhs).mag();}
    double dist2(vec2 rhs) {return sub(rhs).mag2();}
    vec2 normalize() {return scale(1./mag());} //assumes mag()!=0
    double angleBtwn(vec2 rhs) {return Math.atan2(cross(rhs),dot(rhs));}
    double angle() {return Math.atan2(y,x);}
    vec2 orthoCW() {return new vec2(y,-x);}
    vec2 orthoCCW() {return new vec2(-y,x);}
    vec2 reflect(vec2 n) {return sub(scale(-2*dot(n)));}//n==surface normal
    //[cos(t)  -sin(t)][x] = [x*cos(t)-y*sin(t)   x*sin(t)+y*cos(t)]
    //[sin(t)   cos(t)][y]
    vec2 rotate(double ang) {
      double nx = x*Math.cos(ang) - y*Math.sin(ang);
      double ny = x*Math.sin(ang) + y*Math.cos(ang);
      return new vec2(nx,ny);
    }
  }

  static class line2 {
    vec2 e1,e2;
    line2(vec2 a, vec2 b) {e1=a;e2=b;}
    vec2 getVec2() {return e2.sub(e1);}
    vec2 intersect(line2 rhs) {
      vec2 v1 = getVec2(), v2 = rhs.getVec2(), v3 = rhs.e1.sub(e1);
      double div = v1.cross(v2), sn = v3.cross(v2);
      double s = sn/div;
      if(Math.abs(div) < 1e-9) return null; //parallel lines
      vec2 p = v1.scale(s).add(e1);
      //segment intersection
      double r = rhs.scaleProj(p);
      if(s < 0 || r < 0 || s > 1 || r > 1) return null; 
      return p;
    }
    double scaleProj(vec2 p) {// 0.0 -> 1.0
      vec2 v1 = getVec2(); return v1.dot(p.sub(e1))/v1.mag2();
    }
    vec2 proj(vec2 p) {
      vec2 v1 = getVec2();
      double k = v1.dot(p.sub(e1))/v1.mag2();
      return v1.scale(k).add(e1);
    }
    boolean isLower(vec2 a, vec2 b, vec2 p) {
      return b.sub(a).dot(p.sub(a)) < 0;
    }
    boolean checkSides(vec2 a, vec2 b, vec2 c, vec2 d) {
      vec2 v1 = b.sub(a);
      return v1.cross(c.sub(a)) * v1.cross(d.sub(a)) <= 0;
    }
    boolean intersects(line2 rhs) { //checks for segment intersection
      vec2[][] v = {{e1,e2},{rhs.e1,rhs.e2}};
      for(int i=0; i<2; i++) for(int j=0; j<2; j++) 
        if(isLower(v[i][j],v[i][1-j],v[1-i][0]) && 
           isLower(v[i][j],v[i][1-j],v[1-i][1])) return false;
      return checkSides(e1,e2,rhs.e1,rhs.e2)&&checkSides(rhs.e1,rhs.e2,e1,e2);
    }
    double dist(vec2 p) {
      vec2 A = getVec2();
      double t = A.dot(p.sub(e1))/A.mag2();
      if(t>=1) return e2.dist(p);
      if(t<=0) return e1.dist(p);
      return p.dist(A.scale(t).add(e1));
    }
    double dist(line2 rhs) {
      if(intersects(rhs)) return 0.;
      return Collections.min(Arrays.asList(dist(rhs.e1),dist(rhs.e2),rhs.dist(e1),rhs.dist(e2)));
    }
  }

  static class FastIO extends PrintWriter {
    BufferedReader br;
    StringTokenizer st;

    public FastIO() {
      this(System.in, System.out);
    }

    public FastIO(InputStream in, OutputStream out) {
      super(new BufferedWriter(new OutputStreamWriter(out)));
      br = new BufferedReader(new InputStreamReader(in));
      scanLine();
    }

    public void scanLine() {
      try {
        st = new StringTokenizer(br.readLine().trim());
      } catch (Exception e) {
        throw new RuntimeException(e.getMessage());
      }
    }

    public int numTokens() {
      if (!st.hasMoreTokens()) {
        scanLine();
        return numTokens();
      }
      return st.countTokens();
    }

    public String next() {
      if (!st.hasMoreTokens()) {
        scanLine();
        return next();
      }
      return st.nextToken();
    }

    public double nextDouble() {
      return Double.parseDouble(next());
    }

    public long nextLong() {
      return Long.parseLong(next());
    }

    public int nextInt() {
      return Integer.parseInt(next());
    }
  }
}