package java_7.problem_249A.subId_3824133;

import static java.lang.Math.PI;
import static java.lang.Math.abs;
import static java.lang.Math.acos;
import static java.lang.Math.cos;
import static java.lang.Math.min;
import static java.lang.Math.sin;
import static java.lang.Math.sqrt;
import static java.lang.System.in;
import static java.lang.System.out;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
public class A249_usingLibrary {
	public static Scanner sc = new Scanner(in);
	StringBuilder sb = new StringBuilder();
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	double eps = 0.000001;

	public void run() throws IOException {
		String input;
		String[] inputArray;
		input = br.readLine();
		inputArray = input.split(" ");
		double y1 = Double.valueOf(inputArray[0]);
		double y2 = Double.valueOf(inputArray[1]);
		double yw = Double.valueOf(inputArray[2]);
		double bx = Double.valueOf(inputArray[3]);
		double by = Double.valueOf(inputArray[4]);
		double r = Double.valueOf(inputArray[5]);
		yw-=r; 
		y1+=r; 
		P ball = new P(bx,by), postUp = new P(0,y2), postDown = new P(0,y1);
		P cornerUp = new P(0,yw), origin = new P(0,0);
		L ceilingL = new L(cornerUp, new P(1,yw));

			
		P ballMirrored = L.LineSymmetricLP(new L(new P(0,yw), new P(1,yw)), ball);
			
		C goalC = new C(postUp, r);
			
		ArrayList<P> tangents = C.contact(goalC, ballMirrored);
		P xmin = tangents.get(0);
		if (tangents.get(1).x > xmin.x) xmin = tangents.get(1);
		xmin = L.intersection(new L(ballMirrored, xmin),ceilingL);
		P xmax = L.intersection(new L(ballMirrored, postDown),ceilingL);
		if (xmax.x < xmin.x) ln("-1");
		else ln((xmin.x + xmax.x)/2);
		
		
	}

	public static void main(String[] args) throws IOException {
		new A249_usingLibrary().run();
	}
	public static void ln(Object obj) {
		out.println(obj);
	}

	static class P{
		
			static final double EPS=1e-10;
			static int signum(double x){
				return x<-EPS?-1:x>EPS?1:0;
			}
		static Comparator<P> comp=new Comparator<P>(){
			public int compare(P p1, P p2) {
				return signum(p1.x-p2.x)!=0?signum(p1.x-p2.x):signum(p1.y-p2.y);
			}
		};
		public static  final P O=new P(0,0);
		final double x,y;
		P(double _x,double _y){
			x=_x;y=_y;
		}
		
		P add(P a){
			return new P(x+a.x,y+a.y);
		}
		P sub(P a){
			return new P(x-a.x,y-a.y);
		}
		P mul(P a){
			return new P(x*a.x-y*a.y,x*a.y+y*a.x);
		}
		P div(P a){
			double d2=a.dist2(O);
			return new P(dot(a,this)/d2,cross(a,this)/d2);
		}
		
		P conj(){
			return new P(x,-y);
		}
		
		static double dot(P a,P b){
			return  a.x*b.x+a.y*b.y;
		}
		
		static double cross(P a,P b){
			return  a.x*b.y-a.y*b.x;
		}
		
		double dist2(P p){
			return (x-p.x)*(x-p.x)+(y-p.y)*(y-p.y);
		}
		
		double dist(P p){
			return sqrt(dist2(p));
		}
		public double norm(){
			return dist(O);
		}
		
		static int ccw(P a,P b,P c){
			b=b.sub(a);c=c.sub(a);
			if(cross(b,c)>EPS)return 1;
			if(cross(b,c)<-EPS)return -1;
			if(dot(b,c)<-EPS)return 2;
			if(b.norm()<c.norm()-EPS)return -2;
			return 0;
		}
		
		
		
		static double arg(P a,P o){
			P dir=a.sub(o);
			double s=acos(dir.x/dir.norm());
			return dir.y>=0?s:2*PI-s;
		}
		
		static double arg(P a,P b, P c){
			double angleA = P.arg(a,b);
			double angleB = P.arg(b,c);
			double angle =  Math.PI+angleA-angleB;
			if (angle-2*Math.PI>EPS) angle-=2*Math.PI;
			return angle;
		}
		
		P rotate(P o,double arg){
			return this.add(this.sub(o).mul(new P(cos(arg),sin(arg))));
		}
		
		static double S2(P a,P b,P o){
			return cross(a.sub(o),b.sub(o));
		}
		static double S(P a,P b,P o){
			return S2(a,b,o)/2;
		}
		
		static P polar(double abs,double arg){
			return new P(abs*cos(arg),abs*sin(arg));
		}
		
		static P proj(P p,P o){
			return o.mul(new P(dot(p,o)/o.norm(),0));
		}
		public boolean equals(Object obj) {
			if(obj instanceof P){
				P p=(P)obj;
				return signum(x-p.x)==0 && signum(y-p.y)==0;
			}
			return false;
		}
		public String toString(){
			return "("+x+","+y+")";
		}
	}
	
	
	
	
	
	
	static class L extends AL{
		L(P _p1, P _p2) {super(_p1, _p2);}

		
		double dist(P p){
			return abs(P.S(p2,p,p1))/p1.sub(p2).norm();
		}
		boolean isIntersect(P p){
			return abs(P.S(p2,p,p1))<EPS;
		}
		boolean isIntersect(L l){
			if(isPoint() && l.isPoint())return p1.equals(l.p1);
			if(isPoint())return l.isIntersect(p1);
			if(l.isPoint())return isIntersect(l.p1);
			return !isParallel(l) || isIntersect(l.p1);
		}

		
		static P FootOfLP(L l,P p){
			return l.p1.add(P.proj(p.sub(l.p1),l.p2.sub(l.p1)));
		}

		
		static P LineSymmetricLP(L l,P p){
			return FootOfLP(l,p).mul(new P(2.0,0)).sub(p);
		}

		public boolean equals(Object obj) {
			if(obj instanceof L){
				L l=(L)obj;
				return isParallel(l) && isIntersect(l.p1);
			}
			return false;
		}
	}
	
	class S extends AL{
		S(P _p1, P _p2) {super(_p1, _p2);}
		boolean isIntersect(P p){
			return p1.sub(p).norm()+p2.sub(p).norm()<=p1.sub(p2).norm()+EPS;
		}
		boolean isIntersect(L l){
			return P.cross(l.p2.sub(l.p1),p1.sub(l.p1))*
				P.cross(l.p2.sub(l.p1),p2.sub(l.p1))<EPS;
		}
		boolean isIntersect(S l){
			return P.ccw(p1,p2,l.p1)*P.ccw(p1,p2,l.p2)<=0
			&& P.ccw(l.p1,l.p2,p1)*P.ccw(l.p1,l.p2,p2)<=0;
		}
		
		double dist(P p){
			if(P.dot(p2.sub(p1),p.sub(p1))<EPS)return p.sub(p1).norm();
			if(P.dot(p1.sub(p2),p.sub(p2))<EPS)return p.sub(p2).norm();
			return abs(P.S(p2,p,p1))/p1.sub(p2).norm();
		}
		
		double dist(L l){
			if(isIntersect(l))return 0;
			return min(l.dist(p1),l.dist(p2));
		}
		
		double dist(S l){
			if(isIntersect(l))return 0;
			return min(min(dist(l.p1),dist(l.p2)),min(l.dist(p1),l.dist(p2)));
		}
	}
	abstract static class AL{
		
			static final double EPS=1e-10;
			static int signum(double x){
				return x<-EPS?-1:x>EPS?1:0;
			}
		public P p1,p2;
		AL(P _p1,P _p2){
			p1=_p1;
			p2=_p2;
		}

		boolean isPoint(){
			return p1.equals(p2);
		}









		
		boolean isParallel(AL l){
			return abs(P.cross(p2.sub(p1),l.p2.sub(l.p1)))<EPS;
		}
		
		boolean isOrthogonal(AL l){
			return abs(P.dot(p2.sub(p1),l.p2.sub(l.p1)))<EPS;
		}

		
		static P intersection(AL l1,AL l2){
			P dl1=l1.p2.sub(l1.p1),dl2=l2.p2.sub(l2.p1);
			double a=P.cross(dl2,l2.p1.sub(l1.p1));
			double b=P.cross(dl2,dl1);
			if(abs(a)<EPS && abs(b) <EPS)return l1.p1;
			return l1.p1.add(dl1.mul(new P(a/b,0.0)));
		}


		public boolean equals(Object obj) {
			if(obj instanceof L){
				L l=(L)obj;
				return this.p1.equals(l.p1) && this.p2.equals(l.p2);
			}
			return false;
		}
		public String toString(){
			return p1+"-"+p2;
		}
	}
	static class C {
		
			static final double EPS=1e-10;
			static int signum(double x){
				return x<-EPS?-1:x>EPS?1:0;
			}
		P p;
		double r;
		C(P _p,double _r){
			p=_p;
			r=_r;
		}

		static  final C Unit=new C(P.O,1);

		
		static double intersectS(C c1,C c2){
			double d=c1.p.sub(c2.p).norm();
			if(c1.r+c2.r<=d+EPS)return 0;
			if(d<=abs(c1.r-c2.r)+EPS){
				double r=min(c1.r,c2.r);
				return r*r*PI;
			}
			double rlcosA=(d*d+c1.r*c1.r-c2.r*c2.r)/(2*d);
			double A=acos(rlcosA/c1.r);
			double B=acos((d-rlcosA)/c2.r);
			return c1.r*c1.r*A+c2.r*c2.r*B-d*c1.r*sin(A);
		}


		
		static ArrayList<P> intersection(C c1,C c2){
			ArrayList<P> res=new ArrayList<P>();
	 		double d=c1.p.dist(c2.p);
			if(d<EPS && abs(c1.r-c2.r)<EPS){
			}else if(abs(c1.r+c2.r-d)<EPS){
				P diff=c2.p.sub(c1.p).div(new P(d,0));
				res.add(c1.p.add(diff.mul(new P(c1.r,0))));
			}else if(d<c1.r+c2.r){
				double rc=(d*d+c1.r*c2.r-c1.r*c1.r)/(2*d);
				double rs=Math.sqrt(c1.r*c1.r-rc*rc);
				P diff=c2.p.sub(c1.p).div(new P(d,0));
				res.add(c1.p.add(diff.mul(new P(rc,rs))));
				res.add(c1.p.add(diff.mul(new P(rc,-rs))));
			}else{
			}
			return res;
		}

		
		static ArrayList<P> intersection(L l,C c){
			ArrayList<P> res=new ArrayList<P>();
			double dist=l.dist(c.p);
			if(abs(dist-c.r)<EPS){
				res.add(L.FootOfLP(l,c.p));
			}else if(dist<c.r){
				P m=L.FootOfLP(l,c.p);
				P dir=l.p2.sub(l.p1);
				P u=dir.div(new P(dir.norm(),0));
				double t=sqrt(sqrt(c.r)-sqrt(dist));
				res.add(m.add(u.mul(new P(t,0))));
				res.add(m.sub(u.mul(new P(t,0))));
			}
			return res;
		}

		
		static ArrayList<P> contact(C c,P p){
			ArrayList<P> res=new ArrayList<P>();
	 		double d2=p.dist2(c.p);
	 		double r2=c.r*c.r;
			if(abs(r2-d2)<EPS){
				res.add(p);
				return res;
			}
			if(r2>d2)return res;
			P q1=p.sub(c.p).mul(new P(r2/d2,0));
			P q2=p.sub(c.p).mul(new P(0,c.r*sqrt(d2-r2)/d2));
			res.add(c.p.add(q1).add(q2));
			res.add(c.p.add(q1).sub(q2));
			return res;
		}

		
		static ArrayList<P> contact(C c1,C c2){
			ArrayList<P> res=new ArrayList<P>();
			double dist=c2.p.dist(c1.p);
			if(c1.r+c2.r>=dist-EPS)return res;
			double th=P.arg(c2.p,c1.p);
			double a1=acos((c1.r-c2.r)/dist);
			double a2=acos((c1.r+c2.r)/dist);

			res.add(c1.p.add(P.polar(c1.r, th+a1)));
			res.add(c2.p.add(P.polar(c2.r, th+a1)));

			res.add(c1.p.add(P.polar(c1.r, th-a1)));
			res.add(c2.p.add(P.polar(c1.r, th-a1)));

			res.add(c1.p.add(P.polar(c1.r, th+a2)));
			res.add(c2.p.add(P.polar(c1.r, th+a2+PI)));

			res.add(c1.p.add(P.polar(c1.r, th-a2)));
			res.add(c2.p.add(P.polar(c1.r, th-a2+PI)));
			return res;
		}
		










	



		C getFromTwoPointsAndRadious(P a,P b,double r){
			P v=b.sub(a);
			double dist=v.norm();
			if(dist>2*r+EPS)return null;

			P mid=a.add(b).div(new P(2,0));
			P nl=v.div(new P(0,dist));
			double x=sqrt(r*r-dist*dist/4);
			P c=mid.add(nl.mul(new P(x,0)));
			return new C(c,r);
		}
		C getFromThreePoints(P a,P b,P c){
			b=b.sub(a);c=c.sub(a);
			P x=new P(b.x,c.x);
			P y=new P(b.y,c.y);
			P p=new P(b.norm()/2,c.norm()/2);
			P center=new P(P.cross(p,y)/P.cross(x,y),P.cross(x, p)/P.cross(x,y)).add(a);
			return new C(center,a.dist(center));
		}
	}
}