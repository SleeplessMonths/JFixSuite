package java_7.problem_150B.subId_7333008;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class Main {
  public final static long MOD = 1000000007;
  public static void main(String[] args) {
    MyScanner sc = new MyScanner();
    int n = sc.nextInt(); // total length of string <= 2000
    int m = sc.nextInt(); // size of alphabet <= 2000
    int k = sc.nextInt(); // size of palindrome <= 2000
    if (k == n) {
      palindrome(n, (long) m);
    } else if (k > n) {
      any(n, (long) m);
    } else if (k % 2 == 0) {  // all homogenous
      System.out.println(m);
    } else {
      System.out.println(m * m);
    }
  }
  
  public static void any(int n, long m) {
    long cur = 1;
    for (int i = 0; i < n; ++i) {
      cur = (cur * m) % MOD;
    }
    System.out.println(cur);
  }
  
  public static void palindrome(int n, long m) {
    long cur = 1;
    int centerIndex = (n - 1) / 2;
    for (int i = 0; i <= centerIndex; ++i) {
      cur = (cur * m) % MOD;
    }
    System.out.println(cur);
  }
  
  public static class MyScanner {
    BufferedReader br;
    StringTokenizer st;
    
    public MyScanner() {
      br = new BufferedReader(new InputStreamReader(System.in));
    }
    
    int nextInt() {
      return Integer.parseInt(next());
    }
    
    long nextLong() {
      return Long.parseLong(next());
    }
    
    double nextDouble() {
      return Double.parseDouble(next());
    }
    
    String next() {
      while (st == null || !st.hasMoreElements()) {
        try {
          st = new StringTokenizer(br.readLine());
        }
        catch (IOException e) {
          e.printStackTrace();
        }
      }
      return st.nextToken();
    }
    
    String nextLine() {
      String str = "";
      try { str = br.readLine(); }
      catch (IOException e) { e.printStackTrace(); }
      return str;
    }
  }
}