package java_7.problem_663A.subId_17425341;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {
	
	static class InputReader {
        public BufferedReader reader;
        public StringTokenizer tokenizer;

        public InputReader(InputStream stream) {
            reader = new BufferedReader(new InputStreamReader(stream), 32768);
            tokenizer = null;
        }

        public String next() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    tokenizer = new StringTokenizer(reader.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return tokenizer.nextToken();
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

    }
	
	public static void main(String[] args) {
		
        Scanner sc = new Scanner(System.in);
		String n;
		int plus=0, minus=0;
		n = sc.nextLine();
		if(n.charAt(0) != '-') {
			plus++;
		}
		for (int i = 0; i < n.length(); i++) {
			if (n.charAt(i) == '+'){
				plus++;
			} else if (n.charAt(i) == '-') {
				minus++;
			}
		}
		int eq = n.indexOf('=');
		//System.out.println(n.substring(eq+2));
		int num = Integer.parseInt(n.substring(eq+2)),y=0,z=0;
		//System.out.println(plus);
		int x = num/plus, bal = num%plus;
		if (minus > 0) {
			bal += minus;
		}
		y = x + bal/plus;
		z = bal%plus;
		if (plus - minus > num) {
			System.out.println("Impossible");
			return;
		}
		if (y + z > num) {
			System.out.println("Impossible");
			return;
		}
		String res = "";
		if (n.charAt(0) != '-') {
			res += Integer.toString(y+z);
			res += n.charAt(1);
		}
		//System.out.println(y+" "+z);
		for (int i = 2; i < n.length(); i++) {
			if (n.charAt(i-2) == '-') {
				res += "1";
			} else if (n.charAt(i-2) == '+') {
				res += Integer.toString(y);
			} else {
				res += n.charAt(i);
			}
		}
		System.out.println(res);
	}
}