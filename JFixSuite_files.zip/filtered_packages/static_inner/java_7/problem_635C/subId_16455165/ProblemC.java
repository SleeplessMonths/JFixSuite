package java_7.problem_635C.subId_16455165;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class ProblemC {

	public static void main(String[] args) {
		InputReader in = new InputReader();
		PrintWriter out = new PrintWriter(System.out);

		new ProblemC().solve(in, out);

		out.close();
	}

	public void solve(InputReader in, PrintWriter out) {
		long s = in.nextLong();
		long x = in.nextLong();

		if (s < x) {
			out.println(0);
			
			return;
		}

		int count = 0;
		long temp = x;
		while (temp > 0) {
			count += temp & 1;
			temp >>= 1;
		}
		
		long res = 1l << count;
		
		if (s == x) {
			res -= 2;
		}

		out.println(res);
	}

	static class InputReader {
		public BufferedReader br;
		public StringTokenizer st;

		public InputReader() {
			br = new BufferedReader(new InputStreamReader(System.in));
		}

		public String next() {
			while (st == null || !st.hasMoreTokens()) {
				try {
					st = new StringTokenizer(br.readLine());
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}
			return st.nextToken();
		}

		public int nextInt() {
			return Integer.parseInt(next());
		}

		long nextLong() {
			return Long.parseLong(next());
		}

		double nextDouble() {
			return Double.parseDouble(next());
		}

		String nextLine() {
			String str = "";
			try {
				str = br.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return str;
		}
	}
}