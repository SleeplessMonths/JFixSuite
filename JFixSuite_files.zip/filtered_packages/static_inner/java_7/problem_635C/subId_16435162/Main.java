package java_7.problem_635C.subId_16435162;

import java.io.OutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Built using CHelper plug-in
 * Actual solution is at the top
 *
 * @author baukaman
 */
public class Main {
    public static void main(String[] args) {
        InputStream inputStream = System.in;
        OutputStream outputStream = System.out;
        Scanner in = new Scanner(inputStream);
        PrintWriter out = new PrintWriter(outputStream);
        TaskC solver = new TaskC();
        solver.solve(1, in, out);
        out.close();
    }

    static class TaskC {
        long rec(long x, long s, int y) {
            if (y < 0)
                return (s == 0L ? 1L : 0L);

            if ((x & (1L << y)) > 0) {
                if (s >= (1L << y))
                    return 2L * rec(x, s - (1L << y), y - 1);
                else
                    return 0L;
            } else {
                if (s >= (2L << y))
                    return rec(x, s - (2L << y), y - 1);
                else
                    return rec(x, s, y - 1);
            }
        }

        public void solve(int testNumber, Scanner in, PrintWriter out) {
            long s = in.nextLong();
            long x = in.nextLong();
            int n = 0;
            while ((1L << n) < s)
                n++;
            out.println(rec(x, s, n) - (x == s ? 2L : 0L));
        }

    }
}