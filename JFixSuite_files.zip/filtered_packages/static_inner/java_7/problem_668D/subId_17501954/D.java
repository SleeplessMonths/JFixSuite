package java_7.problem_668D.subId_17501954;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TreeSet;


public class D {

	static StringTokenizer st;
	static BufferedReader br;
	static PrintWriter pw;
	static int[] f_tree;
	static int n;
	static class Sort implements Comparable<Sort> {
		int a, t, x, id;
		public int compareTo(Sort arg0) {
			if (this.x==arg0.x)
				return this.t-arg0.t;
			return this.x-arg0.x;
		}
	}
	public static void main(String[] args) throws IOException {
		br = new BufferedReader(new InputStreamReader(System.in));
		pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
		n = nextInt();
		f_tree = new int[n+1];
		Sort[]queries = new Sort[n+1];
		for (int i = 1; i <= n; i++) {
			queries[i] = new Sort();
			queries[i].a = nextInt();
			queries[i].t = nextInt();
			queries[i].x = nextInt();
			queries[i].id = i;
		}
		Arrays.sort(queries, 1, n+1);
		int begin = 1;
		int[]ans = new int[n+1];
		Arrays.fill(ans, -1);
		int[]index = new int[n+1], delta = new int[n+1];
		for (int i = 2; i <= n+1; i++) {
			if (i==n+1 || queries[i].x != queries[i-1].x) {
				int cnt_changes = 0;
				for (int j = begin; j < i; j++) {
					if (queries[j].a==1) {
						inc(queries[j].id, 1);
						cnt_changes++;
						index[cnt_changes] = queries[j].id;
						delta[cnt_changes] = 1;
					}
					else if (queries[j].a==2) {
						inc(queries[j].id, -1);
						index[cnt_changes] = queries[j].id;
						delta[cnt_changes] = -1;
					}
					else {
						ans[queries[j].id] = sum(queries[j].id);
					}
				}
				for (int j = 1; j <= cnt_changes; j++) {
					inc(index[j], -delta[j]);
				}
				begin = i;
			}
		}
		for (int i = 1; i <= n; i++) {
			if (ans[i] != -1)
				pw.println(ans[i]);
		}
		pw.close();
	}
	private static int sum(int id) {
		int res = 0;
		for (int i = id; i >= 1; i = (i & (i-1))) {
			res += f_tree[i];
		}
		return res;
	}
	private static void inc(int id, int delta) {
		for (int i = id; i <= n; i = (i | (i-1))+1) {
			f_tree[i] += delta;
		}
	}
	private static int nextInt() throws IOException {
		return Integer.parseInt(next());
	}
	private static long nextLong() throws IOException {
		return Long.parseLong(next());
	}
	private static double nextDouble() throws IOException {
		return Double.parseDouble(next());
	}
	private static String next() throws IOException {
		while (st==null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine());
		return st.nextToken();
	}
}