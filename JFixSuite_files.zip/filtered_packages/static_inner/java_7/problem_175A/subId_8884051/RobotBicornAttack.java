package java_7.problem_175A.subId_8884051;

import java.io.*;
import java.util.*;
public class RobotBicornAttack 
{
    public static void main(String[] args) throws IOException
    {
        //Locale.setDefault (Locale.US);
        Reader in = new Reader();
        StringBuilder out = new StringBuilder();
        String score;
        long a, b, c, max;
        for (int i = 0; i < 1; i++) {
            score = in.next();
            if(score.length() > 21 || score.length() < 3)
                System.out.println("-1");
            else{
                max = -1;
                for (int j = 0; j < score.length() && j < 9; j++) {
                    a = Long.parseLong(score.substring(0, j+1));
                    if( (a == 0 && j > 0) || a > 1000000) break;
                    for (int k = j+1; k+1 < score.length(); k++) {
                        if((k+1)-(j+1) > 9 || score.length()-(k+1) > 9)continue;
                        b = Long.parseLong(score.substring(j+1, k+1));
                        c = Long.parseLong(score.substring(k+1));
                        if ((b+"").length() != (k+1)-(j+1) || (c+"").length()!= score.length()-(k+1) || b > 1000000 || c > 1000000) continue;
                        //System.out.println(a+" "+b+" "+c);
                        max = Math.max(max, a+b+c);
                    }
                }
                System.out.println(max);
            }
        }
    }
    static class  Reader 
    {
        BufferedReader br;
        StringTokenizer st;
        Reader() { // To read from the standard input
            br = new BufferedReader(new InputStreamReader(System.in));
        }
        Reader(int i) throws IOException { // To read from a file
            br = new BufferedReader(new FileReader("Sample Input.txt"));
        }
       String next() throws IOException {
          while (st == null || !st.hasMoreTokens())
             st = new StringTokenizer(br.readLine());
          return st.nextToken();
       }
       int nextInt() throws IOException { return Integer.parseInt(next()); }
       long nextLong() throws IOException { return Long.parseLong(next()); }
       double nextDouble() throws IOException { return Double.parseDouble(next()); }
       String nextLine() throws IOException { return br.readLine(); }
    }

}