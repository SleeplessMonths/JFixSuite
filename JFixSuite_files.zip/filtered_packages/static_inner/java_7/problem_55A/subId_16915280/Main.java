package java_7.problem_55A.subId_16915280;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class Main {
	// 10:41 ~ 
	public static void main(String[] arg) {
		FastScanner scan = null;
		PrintWriter out = null;
		try{
			scan = new FastScanner(new FileInputStream("input.txt"));
			out = new PrintWriter(new FileOutputStream("output.txt"));
		}catch(FileNotFoundException e){
			scan = new FastScanner(System.in);
			out = new PrintWriter(System.out);
		}
		int n = scan.nextInt();
		if(n > 1) out.println("NO");
		else out.println("YES");
		out.close();
	}

	static class FastScanner {
		BufferedReader br;
		StringTokenizer st;
 
		FastScanner(InputStream is) {
			try {
				br = new BufferedReader(new InputStreamReader(is));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
 
		String next() {
			while (st == null || !st.hasMoreTokens()) {
				try {
					st = new StringTokenizer(br.readLine());
				} catch (Exception e) {
					return null;
				}
			}
			return st.nextToken();
		}
	    
		String nextLine() {
	        try {
	            return br.readLine();
	        }
	        catch (Exception e) {
	            return null;
	        }
	    }
		int nextInt() {
			return Integer.parseInt(next());
		}
 
		long nextLong() {
			return Long.parseLong(next());
		}
 
		double nextDouble() {
			return Double.valueOf(next());
		}
	}
}