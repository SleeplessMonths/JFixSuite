package java_7.problem_31B.subId_16085118;

import java.io.*;
import java.util.*;

public class Main {

	public static void main(String[] args) {

		InputStream inputStream = System.in;
		OutputStream outputStream = System.out;
		InputReader in = new InputReader(inputStream);
		PrintWriter out = new PrintWriter(outputStream);
		solve(in, out);
		out.close();
	}

	private static void solve(InputReader in, PrintWriter out) {

		String s = in.next();
		int N = s.length();
		String[] tab = s.split("@");
		
		if(tab.length <= 1 || tab[0].isEmpty() || tab[1].isEmpty()) {
			out.println("No solution");
			return;
		}
		
		for(int i = 1; i < tab.length - 1; i++) {
			if(tab[i].length() <= 1) {
				out.println("No solution");
				return;
			}
		}
	
		tab[0] = tab[0] + "@";
		for(int i = 1; i < tab.length - 1; i++) {
			tab[i] = tab[i].substring(0, tab[i].length() - 1) + "," + tab[i].charAt(tab[i].length()-1) + "@";
		}
		
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < tab.length; i++) {
			sb.append(tab[i]);
		}
		
		out.println(sb);
		return;
	}

	
	
	/*
	 * 
	 */
	// --------------------------------------------------------

	static class InputReader {
		public BufferedReader reader;
		public StringTokenizer tokenizer;

		public InputReader(InputStream stream) {
			reader = new BufferedReader(new InputStreamReader(stream), 32768);
			tokenizer = null;
		}

		public String next() {
			while (tokenizer == null || !tokenizer.hasMoreTokens()) {
				try {
					tokenizer = new StringTokenizer(reader.readLine());
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}
			return tokenizer.nextToken();
		}

		public int nextInt() {
			return Integer.parseInt(next());
		}

		public long nextLong() {
			return Long.parseLong(next());
		}

		public double nextDouble() {
			return Double.parseDouble(next());
		}

		public String nextLine() {
			String str = "";
			try {
				str = reader.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}

			return str;
		}
	}
}