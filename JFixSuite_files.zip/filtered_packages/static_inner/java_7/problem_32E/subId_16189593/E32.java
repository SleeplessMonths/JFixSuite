package java_7.problem_32E.subId_16189593;

import java.io.*;
import java.util.*;
public class E32 {
public static void main(String[] args) throws IOException {
	input.init(System.in);
	PrintWriter out = new PrintWriter(System.out);
	Point a = new Point(input.nextDouble(), input.nextDouble());
	Point b = new Point(input.nextDouble(), input.nextDouble());
	Point w1 = new Point(input.nextDouble(), input.nextDouble());
	Point w2 = new Point(input.nextDouble(), input.nextDouble());
	Point m1 = new Point(input.nextDouble(), input.nextDouble());
	Point m2 = new Point(input.nextDouble(), input.nextDouble());
	if(!segmentIntersect(a, b, w1, w2) && (!segmentIntersect(a, b, w1, w2) || a.minus(m1).cross(m2.minus(m1)) == 0 && b.minus(m1).cross(m2.minus(m1)) == 0))
		out.println("YES");
	else
	{
		Point other = b.reflect(m1, m2);
		//out.println(other.x+" "+other.y);
		//out.println(segmentIntersect(a, other, m1, m2));
		if(segmentIntersect(a, other, m1, m2) && !segmentIntersect(a, other, w1, w2) && !segmentIntersect(a, other, w1.reflect(m1, m2), w2.reflect(m1, m2)))
			out.println("YES");
		else
			out.println("NO");
	}
	out.close();
}
static double EPS = 1e-9;
static boolean segmentIntersect(Point a, Point b, Point c, Point d){
	Point e = b.minus(a);
	Point f = d.minus(c);
	if(Math.abs(c.minus(a).cross(e)) < EPS && Math.abs(d.minus(a).cross(e)) < EPS)
		return (c.minus(a).dot(e) > -EPS && c.minus(b).dot(a.minus(b)) > -EPS) || (d.minus(a).dot(e) > -EPS && d.minus(b).dot(a.minus(b)) > -EPS) ||
		       (a.minus(c).dot(f) > -EPS && a.minus(d).dot(c.minus(d)) > -EPS) || (b.minus(c).dot(f) > -EPS && b.minus(d).dot(c.minus(d)) > -EPS);
	return Math.signum(b.minus(c).cross(f)) != Math.signum(a.minus(c).cross(f)) && Math.signum(c.minus(a).cross(e)) !=  Math.signum(d.minus(a).cross(e));
}
static class Point
{
	double x, y;
	public Point(double xx, double yy){
		x = xx; y = yy;
	}
	Point plus(Point p)
	{
		return new Point(x+p.x, y+p.y);
	}
	Point minus(Point p)
	{
		return new Point(x - p.x, y - p.y);
	}
	double dot(Point p)
	{
		return x * p.x + y*p.y;
	}
	double cross(Point p)
	{
		return x * p.y - y*p.x;
	}
	Point reflect(Point a, Point b)
	{
		Point d = b.minus(a), c = minus(a);
		Point p = a.plus(d.mult(c.dot(d) / d.dot(d)));
		return plus(p.minus(this).mult(2));
	}
	Point mult(double d)
	{
		return new Point(d*x, d*y);
	}
}
public static class input {
	static BufferedReader reader;
	static StringTokenizer tokenizer;

	static void init(InputStream input) {
		reader = new BufferedReader(new InputStreamReader(input));
		tokenizer = new StringTokenizer("");
	}

	static String next() throws IOException {
		while (!tokenizer.hasMoreTokens())
			tokenizer = new StringTokenizer(reader.readLine());
		return tokenizer.nextToken();
	}

	static int nextInt() throws IOException {
		return Integer.parseInt(next());
	}

	static double nextDouble() throws IOException {
		return Double.parseDouble(next());
	}

	static long nextLong() throws IOException {
		return Long.parseLong(next());
	}
}
}