package java_7.problem_596C.subId_18719451;

import java.util.Arrays;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.TreeSet;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.Map;
import java.util.PriorityQueue;
public class Wilbur_and_Points{
	static int mod;
	public static void main(String args[]){
		FasterScanner s=new FasterScanner();
		PrintWriter out=new PrintWriter(System.out);
		int n=s.nextInt();
		ArrayList<Points> t[]=new ArrayList[400005];
		ArrayList<Points> arr=new ArrayList<Points>();
		int o=200000;
		for(int i=0;i<400005;i++)
			t[i]=new ArrayList<Points>();
		//System.out.println(5515);
		for(int i=0;i<n;i++){
			//System.out.println(42);
			int k=s.nextInt();
			int k1=s.nextInt();
			t[k1-k+o].add(new Points(k,k1));
		}
	//	System.out.println(5515);
		int a[]=s.nextIntArray(n);
		boolean b[]=new boolean[n];
		for(int i=0;i<400005;i++){
			Collections.sort(t[i]);
		}
		boolean check=false;
		Points last=new Points(-1,-1);
	//	System.out.println(5515);
		for(int i=0;i<n;i++){
			check=false;
			//System.out.println(a[i]+" "+last.x+" "+last.y+" "+t[a[i]+o].size());
			for(int j=0;j<t[a[i]+o].size();j++){
			//	System.out.println(j);
				if(t[a[i]+o].get(j).x>=last.x || t[a[i]+o].get(j).y>=last.y){
					arr.add(t[a[i]+o].get(j));
					last=t[a[i]+o].get(j);
					t[a[i]+o].remove(j);
					check=true;
					break;
				}
			}
			if(!check){
				out.print("NO");
				out.close();
				return;
			}
		}
		out.println("YES");
		for(int i=0;i<n;i++){
			out.println(arr.get(i).x+" "+arr.get(i).y);
		}
		out.close();
	}
	static class Points implements Comparable<Points>{
		int x;
		int y;
		public Points(int nextInt, int nextInt2) {
			x=nextInt;
			y=nextInt2;
		}
		public int compareTo(Points o) {
			if (Integer.compare(x, o.x)>=0 && Integer.compare(y, o.y)>=0) return 1;
			else return -1;
		}
		
	}
	public static int[][] matrixMul(int[][] a, int[][] b) {
		int n = a.length;
		int m = a[0].length;
		int k = b[0].length;
		int[][] res = new int[n][k];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < k; j++) {
				for (int p = 0; p < m; p++) {
					res[i][j] = (res[i][j] + (a[i][p] * b[p][j])&mod)&mod;
				}
			}
		}
		return res;
	}

	public static int[][] matrixPow(int[][] a, long p) {
		if (p == 0) {
			return matrixUnit(a.length);
		} else if (p % 2 == 0) {
			return matrixPow(matrixMul(a, a), p / 2);
		} else {
			return matrixMul(a, matrixPow(a, p - 1));
		}
	}
	public static int[][] matrixUnit(int n) {
		int[][] res = new int[n][n];
		for (int i = 0; i < n; ++i) {
			res[i][i] = 1;
		}
		return res;
	}
	public static class FasterScanner {
		private byte[] buf = new byte[1024];
		private int curChar;
		private int numChars;
		public int read() {
			if (numChars == -1)
				throw new InputMismatchException();
			if (curChar >= numChars) {
				curChar = 0;
				try {
					numChars = System.in.read(buf);
				} catch (IOException e) {
					throw new InputMismatchException();
				}
				if (numChars <= 0)
					return -1;
			}
			return buf[curChar++];
		}

		public String nextLine() {
			int c = read();
			while (isSpaceChar(c))
				c = read();
			StringBuilder res = new StringBuilder();
			do {
				res.appendCodePoint(c);
				c = read();
			} while (!isEndOfLine(c));
			return res.toString();
		}

		public String nextString() {
			int c = read();
			while (isSpaceChar(c))
				c = read();
			StringBuilder res = new StringBuilder();
			do {
				res.appendCodePoint(c);
				c = read();
			} while (!isSpaceChar(c));
			return res.toString();
		}

		public long nextLong() {
			int c = read();
			while (isSpaceChar(c))
				c = read();
			int sgn = 1;
			if (c == '-') {
				sgn = -1;
				c = read();
			}
			long res = 0;
			do {
				if (c < '0' || c > '9')
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = read();
			} while (!isSpaceChar(c));
			return res * sgn;
		}

		public int nextInt() {
			int c = read();
			while (isSpaceChar(c))
				c = read();
			int sgn = 1;
			if (c == '-') {
				sgn = -1;
				c = read();
			}
			int res = 0;
			do {
				if (c < '0' || c > '9')
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = read();
			} while (!isSpaceChar(c));
			return res * sgn;
		}

		public int[] nextIntArray(int n) {
			int[] arr = new int[n];
			for (int i = 0; i < n; i++) {
				arr[i] = nextInt();
			}
			return arr;
		}

		public long[] nextLongArray(int n) {
			long[] arr = new long[n];
			for (int i = 0; i < n; i++) {
				arr[i] = nextLong();
			}
			return arr;
		}

		private boolean isSpaceChar(int c) {
			return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
		}

		private boolean isEndOfLine(int c) {
			return c == '\n' || c == '\r' || c == -1;
		}
	}

	public static class disjointSet {

		private int[] parent;  // parent[i] = parent of i
		private byte[] rank;   // rank[i] = rank of subtree rooted at i (never more than 31)
		private int count;     // number of components
		public disjointSet(int N) {
			if (N < 0) throw new IllegalArgumentException();
			count = N;
			parent = new int[N];
			rank = new byte[N];
			for (int i = 0; i < N; i++) {
				parent[i] = i;
				rank[i] = 0;
			}
		}

		public int find(int p) {
			if (p < 0 || p >= parent.length) throw new IndexOutOfBoundsException();
			while (p != parent[p]) {
				parent[p] = parent[parent[p]];    // path compression by halving
				p = parent[p];
			}
			return p;
		}
		public int count() {
			return count;
		}

		public boolean connected(int p, int q) {
			return find(p) == find(q);
		}

		public boolean union(int p, int q) {
			int rootP = find(p);
			int rootQ = find(q);
			if (rootP == rootQ) return false;

			// make root of smaller rank point to root of larger rank
			if      (rank[rootP] < rank[rootQ]) parent[rootP] = rootQ;
			else if (rank[rootP] > rank[rootQ]) parent[rootQ] = rootP;
			else {
				parent[rootQ] = rootP;
				rank[rootP]++;
			}
			count--;
			return true;
		}

	}
}