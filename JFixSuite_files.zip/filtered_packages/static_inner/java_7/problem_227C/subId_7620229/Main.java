package java_7.problem_227C.subId_7620229;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;


/**
 *
 * @author Aditya Joshi
 */
public class Main 
{
    
    public static void main(String[] args)
    {
    
        MyScanner sc = new MyScanner();
        long n = sc.nextLong();
        long m = sc.nextLong();
        
        long DP = 2;
        for(long i = n - 1; i > 0; i--)
        {
            DP = (3* DP) + 2;
        
        }
        System.out.println(DP%m);
    
    }
     public static class MyScanner 
       {
      BufferedReader br;
      StringTokenizer st;
 
      public MyScanner() 
      {
         br = new BufferedReader(new InputStreamReader(System.in));
      }
 
      String next() 
      {
          while (st == null || !st.hasMoreElements()) 
          {
              try 
              {
                  st = new StringTokenizer(br.readLine());
              } catch (IOException e) 
              {
                  e.printStackTrace();
              }
          }
          return st.nextToken();
      }
 
      int nextInt() 
      {
          return Integer.parseInt(next());
      }
 
      long nextLong() 
      {
          return Long.parseLong(next());
      }
 
      double nextDouble() 
      {
          return Double.parseDouble(next());
      }
 
      String nextLine()
      {
          String str = "";
	  try 
          {
	     str = br.readLine();
	  } catch (IOException e) 
          {
	     e.printStackTrace();
	  }
	  return str;
      }

   }
}