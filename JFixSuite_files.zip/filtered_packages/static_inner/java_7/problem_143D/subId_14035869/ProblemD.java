package java_7.problem_143D.subId_14035869;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class ProblemD {
    public static void main(String[] args) {
        InputReader in = new InputReader();
        PrintWriter out = new PrintWriter(System.out);

        new ProblemD().solve(in, out);

        out.close();
    }

    public void solve(InputReader in, PrintWriter out) {
        int n = in.nextInt();
        int m = in.nextInt();

        int max = Math.max(m, n);
        int min = Math.min(m, n);

        if (min == 1) {
            out.print(max);
        } else if (min > 2) {
            out.print((n * m + 1) / 2);
        } else {
            if (max % 4 == 2) {
                out.print(max + 2);
            } else if (m % 4 == 0) {
                out.print(max + 2);
            } else {
                out.print(max + 1);
            }
        }
    }

    static class InputReader {
        public BufferedReader br;
        public StringTokenizer st;

        public InputReader() {
            br = new BufferedReader(new InputStreamReader(System.in));
        }

        public String next() {
            while (st == null || !st.hasMoreTokens()) {
                try {
                    st = new StringTokenizer(br.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return st.nextToken();
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        long nextLong() {
            return Long.parseLong(next());
        }

        double nextDouble() {
            return Double.parseDouble(next());
        }

        String nextLine() {
            String str = "";
            try {
                str = br.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return str;
        }
    }
}