package java_7.problem_136A.subId_19204784;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Solution {
    public static void main(String args[]) throws Exception {
    	FastScanner sc = new FastScanner();
    	int n = sc.nextInt();
    	int gifts[] = new int[n];
    	int updated_arr[] = new int[n];
    	for(int i=0;i<n;i++){
    		gifts[i] = sc.nextInt();
    	}
    	for(int i=0;i<n;i++){
    		updated_arr[i] = gifts[gifts[gifts[i]-1]-1]; 
    	}
    	for(int i=0;i<updated_arr.length;i++){
    		System.out.print(updated_arr[i]+" ");
    	}
    		
    }
    
    
    public static class FastScanner {
		BufferedReader br;
		StringTokenizer st;

		public FastScanner(String s) {
			try {
				br = new BufferedReader(new FileReader(s));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		public FastScanner() {
			br = new BufferedReader(new InputStreamReader(System.in));
		}

		String nextToken() {
			while (st == null || !st.hasMoreElements()) {
				try {
					st = new StringTokenizer(br.readLine());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return st.nextToken();
		}

		int nextInt() {
			return Integer.parseInt(nextToken());
		}

		long nextLong() {
			return Long.parseLong(nextToken());
		}

		double nextDouble() {
			return Double.parseDouble(nextToken());
		}
	}
}