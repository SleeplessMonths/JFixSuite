package java_7.problem_104A.subId_4331560;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.StringTokenizer;
 
public class Main{
 
    static class InputReader {
 
        final private int BUFFER_SIZE = 1 << 17;
        private DataInputStream din;
        private byte[] buffer;
        private int bufferPointer, bytesRead;
 
        public InputReader(InputStream in) {
            din = new DataInputStream(in);
            buffer = new byte[BUFFER_SIZE];
            bufferPointer = bytesRead = 0;
        }
 
        public byte next() {
            try {
                return read();
            } catch (Exception e) {
                throw new InputMismatchException();
            }
        }
 
        public String nextString() {
            StringBuilder sb = new StringBuilder("");
            byte c = next();
            while (c <= ' ') {
                c = next();
            }
            do {
                sb.append((char) c);
                c = next();
            } while (c > ' ');
            return sb.toString();
        }
 
        public int nextInt() {
            int ret = 0;
            byte c = next();
            while (c <= ' ') {
                c = next();
            }
            boolean neg = c == '-';
            if (neg) {
                c = next();
            }
            do {
                ret = (ret << 3) + (ret << 1) + c - '0';
                c = next();
            } while (c > ' ');
            if (neg) {
                return -ret;
            }
            return ret;
        }
 
        private void fillBuffer() {
            try {
                bytesRead = din.read(buffer, bufferPointer = 0, BUFFER_SIZE);
            } catch (IOException e) {
                throw new InputMismatchException();
            }
            if (bytesRead == -1) {
                buffer[0] = -1;
            }
        }
 
        private byte read() {
            if (bufferPointer == bytesRead) {
                fillBuffer();
            }
            return buffer[bufferPointer++];
        }
    }
   
    public static void main(String arg[]) throws IOException {
   
        InputReader r=new InputReader(System.in);
      //  BufferedReader r=new BufferedReader(new FileReader("testcase.txt"));
   //     BufferedReader r=new BufferedReader(new InputStreamReader(System.in));
    
    int n=r.nextInt()-10;
    if(n<=0)
        System.out.println(0);
    else if(n==10)
        System.out.println(15);
    else
        System.out.println(4);
   
   
   
    }}