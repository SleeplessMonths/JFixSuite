package java_7.problem_104A.subId_7426769;

import java.io.*;
import java.util.*;
import java.*;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Random;
import java.lang.*;
 



 
 
public class zad {
private static BufferedReader in;
private static StringTokenizer tok;
private static PrintWriter out;
final static boolean ONLINE_JUDGE = System.getProperty("ONLINE_JUDGE") !=null;
 
public static void init() throws FileNotFoundException{
if(ONLINE_JUDGE){
in = new BufferedReader(new InputStreamReader(System.in));
out = new PrintWriter(System.out);
}
else{
in = new BufferedReader(new FileReader("input.txt"));
out = new PrintWriter("out.txt");
}
}
 
private static String readString() throws IOException {
while (tok == null || !tok.hasMoreTokens()) {
tok = new StringTokenizer(in.readLine());
}
return tok.nextToken();
}
 
private static int readInt() throws IOException {
return Integer.parseInt(readString());
}
private static double readDouble() throws IOException {
return Double.parseDouble(readString());
}
private static long readLong() throws IOException {
return Long.parseLong(readString());
}
private static float readFloat() throws IOException{
    return Float.parseFloat(readString());
}
 
 
public static class Point implements Comparable{
    
    private int x;
    private int y;
    
    Point(int x, int mum){
        this.x = x;
        y = mum;
    }
    
    
    public int getX(){
        return x;
    }
    public  void setX(int x){
        this.x = x;
    }
    public int getY(){
        return y;
    }
    public boolean equals(Point b){
        if(this.x == b.getX() && this.y == b.getY())
            return true;
        return false;
    }
    public int compareTo(Object obj)
    {
      Point tmp = (Point)obj;
      if(this.x < tmp.getX())
      {
        /* текущее меньше полученного */
        return -1;
      }   
      else if(this.x > tmp.getX())
      {
        /* текущее больше полученного */
        return 1;
      }
      /* текущее равно полученному */
      return 0;  
    }
    
}



public static void Solve() throws IOException{
    
   int n =readInt();
   if(n<11 || n>21){
       out.print(0);
       return;
   }
   
   int ans =0;
   n-=10;
   
   if(n>0 || n<10){
       out.print(4);
       return;
   }
   else if(n==11)out.print(4);
   else{
       out.print(15);
   }
   
   
  
   
   
   
   
}
    



    
    




public static void main(String[] args) throws IOException {
init();
Solve();
 
 
in.close();
out.close();
}
}