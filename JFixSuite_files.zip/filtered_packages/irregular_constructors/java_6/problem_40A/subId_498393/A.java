package java_6.problem_40A.subId_498393;

import java.util.*;


public class A
{
   public static void main(String[] args)
   {
      new A(new Scanner(System.in));
   }

   public A(Scanner in)
   {
      int a = in.nextInt();
      int b = in.nextInt();
   
      int n = a*b;
      
      int cc = a*a+b*b;

      double c = Math.sqrt(cc);

      if (n < 0)
         c--;

      double cp = Math.rint(c);
      if (Math.abs(cp-c) < 1e-9)
      {
         System.out.println("black");
         return;
      }

      int v = (int)cp;

      if ((v%2) == 0)
      {
         System.out.println("black");
         return;
      }

      System.out.println("white");
   }
}