package java_6.problem_42B.subId_509314;

import java.util.*;


public class B
{
   public static void main(String[] args)
   {
      new B(new Scanner(System.in));
   }

   vect[] dv;

   vect atov(String s)
   {
      return new vect(s.charAt(0)-'a', s.charAt(1)-'1');
   }

   boolean[][] path;
   boolean[][] mark;

   boolean isValid(vect v)
   {
      if (v.x < 0) return false;
      if (v.y < 0) return false;
      if (v.x >= 8) return false;
      if (v.y >= 8) return false;
      return true;
   }

   void markRook(vect v)
   {
      for (vect d : dv)
      {
         vect pp = v.add(d);
         while (isValid(pp))
         {
            path[pp.x][pp.y] = true;
            if (mark[pp.x][pp.y]) break;
            pp = pp.add(d);
         }
      }
   }

   void markKing(vect v)
   {
      for (int y=-1; y<2; y++)
         for (int x=-1; x<2; x++)
         {
            if ((x==0)&&(y==0)) continue;

            vect d = new vect(x, y);
            vect pp = v.add(d);
            if (isValid(pp))
               path[pp.x][pp.y] = true;
         }
   }

   // Determine if a king at v is checkmated
   boolean checkmate(vect v)
   {
      for (int y=-1; y<2; y++)
         for (int x=-1; x<2; x++)
         {
            vect d = new vect(x,y);
            vect pp = v.add(d);
            if (!isValid(pp))
               continue;
            if (!path[pp.x][pp.y]) return false;
         }

      // No moves
      return true;
   }

   public B(Scanner in)
   {
      path = new boolean[8][8];
      mark = new boolean[8][8];
      dv = new vect[4];
      dv[0] = new vect(0, 1);
      dv[1] = new vect(0, -1);
      dv[2] = new vect(1, 0);
      dv[3] = new vect(-1, 0);
   
      vect[] ps = new vect[4];
      for (int i=0; i<4; i++)
         ps[i] = atov(in.next());

      for (vect v : ps)
         mark[v.x][v.y] = true;

      // Mark that the white king cannot be taken
      path[ps[2].x][ps[2].y] = true;

      // Mark each of the rooks
      markRook(ps[0]);
      markRook(ps[1]);
     
      // mark the king
      markKing(ps[2]);

      String res = "OTHER";
      if (checkmate(ps[3]))
         res = "CHECKMATE";
      System.out.println(res);

   }
}

class vect
{
   int x, y;

   public vect(int i, int j)
   {
      x=i; y=j;
   }

   vect add(vect rhs)
   {
      return new vect(x+rhs.x, y+rhs.y);
   }
}