package java_6.problem_134B.subId_917314;

/**
 * Created by IntelliJ IDEA.
 * User: jte
 * Date: 12/2/11
 * Time: 4:59 PM
 * To change this template use File | Settings | File Templates.
 */

import java.io.*;
import java.util.*;

public class TaskBV extends Thread {
    public TaskBV(int what) {
        try {
            if (what == 0) {
                this.input = new BufferedReader(new InputStreamReader(System.in));
                this.output = new PrintWriter(System.out);
            } else {
                this.input = new BufferedReader(new FileReader(INPUT_FILE));
                this.output = new PrintWriter(OUTPUT_FILE);
            }
        } catch (Throwable e) {
            e.printStackTrace();
            System.exit(666);
        }
    }
    private static final int go(int a, int b) {
        if (b == 0 && a == 1) {
            return -1;
        }

        return  b == 0 ? Integer.MAX_VALUE >> 3 : go( b, a % b) +  a / b;
    }

    private void solve() throws Throwable {
        int n = nextInt(), result = Integer.MAX_VALUE;
        for (int i = 1; i < n; ++i) {
            result = Math.min(result, go(n, i));
        }
        output.println(result);

    }

    public void run() {
        try {
            solve();
        } catch (Throwable e) {
            e.printStackTrace();
            System.exit(666);
        } finally {
            output.flush();
            output.close();
        }
    }


    public static void main(String... args) {
        new TaskBV(0).start();
    }

    private String nextToken() throws IOException {
        while (tokens == null || !tokens.hasMoreTokens()) {
            tokens = new StringTokenizer(input.readLine());
        }
        return tokens.nextToken();
    }

    private int nextInt() throws IOException {
        return Integer.parseInt(nextToken());
    }

    private double nextDouble() throws IOException {
        return Double.parseDouble(nextToken());
    }

    private long nextLong() throws IOException {
        return Long.parseLong(nextToken());
    }

    private String INPUT_FILE = null;
    private String OUTPUT_FILE = null;
    private BufferedReader input;
    private PrintWriter output;
    private StringTokenizer tokens = null;
}