package java_6.problem_62A.subId_588689;

import java.util.*;


public class A
{
   public static void main(String[] args)
   {
      new A(new Scanner(System.in));
   }

   public A(Scanner in)
   {
      int[][] vs = new int[2][2];
      for (int j=0; j<2; j++)
         for (int i=0; i<2; i++)
            vs[j][i] = in.nextInt();

      boolean passed = false;
      for (int i=0; i<2; i++)
      {
         int j = (i+1)%2;
         int ladyFingers = vs[0][i];
         int gentFingers = vs[1][j];
         int d = gentFingers-ladyFingers;
         
         if ((-2 < d)&&(d < 3))
            passed = true;
      }

      String res = "NO";
      if (passed)
         res = "YES";
      System.out.println(res);
   }
}