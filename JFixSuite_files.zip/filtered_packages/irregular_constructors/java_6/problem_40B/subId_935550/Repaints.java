package java_6.problem_40B.subId_935550;

import java.util.Scanner;


public class Repaints {
	int n;
	int m;	
	
	int oldNum, newNum;
	
	public Repaints(int n, int m) {
		this.n = n;
		this.m = m;
	}
	
	public int solve(int x) {
		int solution = 0;
		for (int i = 0; i < x; i++) {
			solution = 0;
			
			oldNum = (m * n + 1) / 2;
			
			m -= 2;
			n -= 2;
			
			if (n > 0 && m > 0)
				newNum = (m * n + 1) / 2;		
			else newNum = 0;
			
			solution = oldNum - newNum;			
			
		}
		
		return solution;
	}
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		int m = scanner.nextInt();
		scanner.nextLine();
		int x = scanner.nextInt();
		
		Repaints repaints = new Repaints(n, m);
		int solution = repaints.solve(x);
		
		System.out.println(solution);
	}
}