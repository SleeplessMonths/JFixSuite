package java_6.problem_36A.subId_496715;

import java.util.*;
import java.io.*;


public class A
{
   public static void main(String[] args) throws Exception
   {
      new A(new Scanner(new File("input.txt")));
   }

   public A(Scanner in) throws Exception
   {
      PrintWriter out = new PrintWriter(new File("output.txt"));
      int N = in.nextInt();
      String s = in.next();
      ArrayList<Integer> vs = new ArrayList<Integer>();
      for (int i=0; i<N; i++)
         if (s.charAt(i) == '1')
            vs.add(i);
      TreeSet<Integer> res = new TreeSet<Integer>();
      for (int i=1; i<vs.size(); i++)
         res.add(vs.get(i)-vs.get(i-1));

      String rr = "NO";
      if (res.size() == 1)
         rr = "YES";
      out.println(rr);
   }
}