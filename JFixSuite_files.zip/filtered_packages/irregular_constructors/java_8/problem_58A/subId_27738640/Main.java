package java_8.problem_58A.subId_27738640;

import java.util.Scanner;

public class Main{
    String s;

    public Main(String s) {
        this.s = s;
    }

    void f(){
        int k = 0;
        int i = 0;
        while(k!=5 && i<s.length()){
            char c=s.charAt(i);
            boolean change = false;

            if(k==0 && c=='h') {change=true;}
            if(k==1 && c=='e') {change=true;}
            if(k==2 && c=='l') {change=true;}
            if(k==3 && c=='l') {change=true;}
            if(k==4 && c=='o') {change=true;}
            System.out.println(c);
            if(change==true) k++;
            i++;
        }

        if(k==5) System.out.println("YES");
        else System.out.println("NO");
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String str = s.nextLine();
        Main main = new Main(str);
        main.f();
    }
}