package java_8.problem_603B.subId_14663513;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.*;

public class Main {
    public static void main(String[] args) {
//     Test.testing();
        ConsoleIO io = new ConsoleIO();
        new Main(io).solve();
        io.flush();
    }
    ConsoleIO io;
    Main(ConsoleIO io) {
        this.io = io;
    }

    ArrayList<ArrayList<Integer>> gr1;
    ArrayList<ArrayList<Integer>> gr2;
    boolean[] visit;
    //

    public void solve() {
        int[] l = io.readIntArray();
        long p = l[0], k = l[1];
        long res = 1;
        long mod = 1000_000_007;
        if(k<2){
            for(int i = 0;i<p;i++)res = (res*p)%mod;
        }else{
            for(int i = 2;i<p;i++)res = (res*i)%mod;
            res++;
        }
        io.writeLine(res + "");
    }

}

class ConsoleIO {
    BufferedReader br;
    PrintWriter out;
    public ConsoleIO(){br = new BufferedReader(new InputStreamReader(System.in));out = new PrintWriter(System.out);}
    public void flush(){this.out.close();}
    public void writeLine(String s) {this.out.println(s);}
    public void writeInt(int a) {this.out.print(a);this.out.print(' ');}
    public void writeWord(String s){
        this.out.print(s);
    }
    public String readLine() {try {return br.readLine();}catch (Exception ex){ return "";}}
    public long readLong() {
        return Long.parseLong(this.readLine());
    }
    public int readInt() {
        return Integer.parseInt(this.readLine().trim());
    }
    public long[] readLongArray() {
        String[]n=this.readLine().trim().split(" ");long[]r=new long[n.length];
        for(int i=0;i<n.length;i++)r[i]=Long.parseLong(n[i]);
        return r;
    }
    public int[] readIntArray() {
        String[]n=this.readLine().trim().split("\\s+");int[]r=new int[n.length];
        for(int i=0;i<n.length;i++)r[i]=Integer.parseInt(n[i]);
        return r;
    }
}