package java_8.problem_690A1.subId_19067866;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class OutputBasedSolver {
    public static void main(String[] args) {
        new OutputBasedSolver(false, System.in).solve();
    }

    public OutputBasedSolver(boolean hasMultipleTests, InputStream input) {
        scanner = new Scanner(input);
        numberOfTests = hasMultipleTests ? scanner.nextInt() : 1;
    }

    public ArrayList<String> solve() {
        preCompute();

        for (int i = 0; i < numberOfTests; ++i) {
            resetData();
            readInput();
            computeResult();
            addCurrentToResults();
            printResult();
        }

        return results;
    }

    private void addCurrentToResults() {
        results.add(String.valueOf(result));
    }

    private int numberOfTests;
    private Scanner scanner;
    private ArrayList<String> results = new ArrayList<>();

    private final int MOD = 1000000007;
    private long result;
    private long n;

    private void preCompute() {
    }

    private void resetData() {
        result = 0;
    }

    private void readInput() {
        n = scanner.nextInt();
    }

    private void printResult() {
        System.out.println(result);
    }

    private void computeResult() {
        result = (n - 2) / 2 + 1;
    }
}