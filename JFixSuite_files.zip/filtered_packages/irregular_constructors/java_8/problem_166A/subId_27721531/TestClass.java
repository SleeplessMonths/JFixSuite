package java_8.problem_166A.subId_27721531;

import java.util.Scanner;
import java.io.*;
import java.util.*;
import java.math.*;
import java.lang.*;
import static java.lang.Math.*;
 
public class TestClass
{
	int p,t;
	public TestClass(int p,int t)
	{
		this.p=p;
		this.t=t;
	}
	public static void main(String args[])
	{/*
		new Thread(null, new TestClass(),"TESTCLASS",1<<18).start();
	}
	public void run()
	{*/
		//Scanner scan=new Scanner(System.in);
		InputReader hb=new InputReader(System.in);
		PrintWriter w=new PrintWriter(System.out);
		
		int n=hb.nextInt();
		int k=hb.nextInt();
		ArrayList<TestClass> list=new ArrayList<TestClass>();
		for(int i=0;i<n;i++)
		{
			int x=hb.nextInt();
			int y=hb.nextInt();
			list.add(new TestClass(x,y));
		}
		
		
		Collections.sort(list,new Comparator<TestClass>()
		{
			public int compare(TestClass ob1,TestClass ob2)
			{
				if(ob1.p>ob2.p)
					return -1;
				else if(ob1.p<ob2.p)
					return 1;
				else
				{
					if(ob1.t>ob2.t)
						return 1;
					else if(ob1.t<ob2.t)
						return -1;
				}
				return 0;
			}
		});
		/*
		for(int i=0;i<n;i++)
			w.println(list.get(i).p+" "+list.get(i).t);
		*/
		int a[][]=new int[51][51];
		for(int i=0;i<n;i++)
			a[list.get(i).p][list.get(i).t]++;
		w.print(a[list.get(k).p][list.get(k).t]);
		w.close();
	}
	
	
	private void shuffle(int[] arr)
	{
		Random ran = new Random();
		for (int i = 0; i < arr.length; i++) {
			int i1 = ran.nextInt(arr.length);
			int i2 = ran.nextInt(arr.length);

			int temp = arr[i1];
			arr[i1] = arr[i2];
			arr[i2] = temp;
		}
	}
	static class InputReader
	{
		private InputStream stream;
		private byte[] buf = new byte[1024];
		private int curChar;
		private int numChars;
		private SpaceCharFilter filter;
		
		public InputReader(InputStream stream)
		{
			this.stream = stream;
		}
		
		public int read()
		{
			if (numChars==-1) 
				throw new InputMismatchException();
			
			if (curChar >= numChars)
			{
				curChar = 0;
				try 
				{
					numChars = stream.read(buf);
				}
				catch (IOException e)
				{
					throw new InputMismatchException();
				}
				
				if(numChars <= 0)				
					return -1;
			}
			return buf[curChar++];
		}
	 
		public String nextLine()
		{
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			String str = "";
			try
			{
				str = br.readLine();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
			return str;
		}
		public int nextInt()
		{
			int c = read();
			
			while(isSpaceChar(c)) 
				c = read();
			
			int sgn = 1;
			
			if (c == '-') 
			{
				sgn = -1;
				c = read();
			}
			
			int res = 0;
			do 
			{
				if(c<'0'||c>'9') 
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = read();
			}
			while (!isSpaceChar(c)); 
			
			return res * sgn;
		}
		
		public long nextLong() 
		{
			int c = read();
			while (isSpaceChar(c))
				c = read();
			int sgn = 1;
			if (c == '-') 
			{
				sgn = -1;
				c = read();
			}
			long res = 0;
			
			do 
			{
				if (c < '0' || c > '9')
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = read();
			}
			while (!isSpaceChar(c));
				return res * sgn;
		}
		
		public double nextDouble() 
		{
			int c = read();
			while (isSpaceChar(c))
				c = read();
			int sgn = 1;
			if (c == '-') 
			{
				sgn = -1;
				c = read();
			}
			double res = 0;
			while (!isSpaceChar(c) && c != '.') 
			{
				if (c == 'e' || c == 'E')
					return res * Math.pow(10, nextInt());
				if (c < '0' || c > '9')
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = read();
			}
			if (c == '.') 
			{
				c = read();
				double m = 1;
				while (!isSpaceChar(c)) 
				{
					if (c == 'e' || c == 'E')
						return res * Math.pow(10, nextInt());
					if (c < '0' || c > '9')
						throw new InputMismatchException();
					m /= 10;
					res += (c - '0') * m;
					c = read();
				}
			}
			return res * sgn;
		}
		
		public String readString() 
		{
			int c = read();
			while (isSpaceChar(c))
				c = read();
			StringBuilder res = new StringBuilder();
			do 
			{
				res.appendCodePoint(c);
				c = read();
			} 
			while (!isSpaceChar(c));
			
			return res.toString();
		}
	 
		public boolean isSpaceChar(int c) 
		{
			if (filter != null)
				return filter.isSpaceChar(c);
			return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
		}
	 
		public String next() 
		{
			return readString();
		}
		
		public interface SpaceCharFilter 
		{
			public boolean isSpaceChar(int ch);
		}
	}
 
	static class Pair implements Comparable<Pair>
	{
		int a;
		int b;
		String str;
		public Pair(int a,int b)
		{
			this.a=a;
			this.b=b;
			str=min(a,b)+" "+max(a,b);
		}
 
		public int compareTo(Pair pair)
		{
			if(Integer.compare(a,pair.a)==0)
				return Integer.compare(b,pair.b);
 
			return Integer.compare(a,pair.a);
		}
	}
 
	
}