package java_8.problem_275A.subId_9426354;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.InputMismatchException;

public class Main {

    IIO io;

    Main(IIO io) {
        this.io = io;
    }

    public static void main(String[] args) throws IOException {

    ConsoleIO io = new ConsoleIO();Main m = new Main(io);m.solve();io.flush();

//        Tester test = new Tester();test.run();
    }

    public void solve() {
        int[][] map = new int[5][];
        for(int i=0;i<5;i++)map[i] = new int[5];
        for(int i=0;i<3;i++){
            int[] l = io.readIntArray();
            for(int j =0;j<3;j++)
                map[i+1][j+1] = l[j];
        }
        for(int i=0;i<3;i++){
            for(int j = 0;j<3;j++){
                io.writeInt(1-(map[i+1][j+1]+map[i][j+1]+map[i+1][j]+map[i+2][j+1]+map[i+1][j+2])%2);
            }
            io.writeLine("");
        }
    }
}

class ConsoleIO extends BaseIO {
    BufferedReader br;
    PrintWriter out;
    public ConsoleIO(){
        br = new BufferedReader(new InputStreamReader(System.in));
        out = new PrintWriter(System.out);
    }
    public void flush(){
        this.out.close();
    }
    public void writeLine(String s) {
        this.out.println(s);
    }
    public void writeInt(int a) {
        this.out.print(a);
        this.out.print(' ');
    }
    public void writeWord(String s){
        this.out.print(s);
    }
    public String readLine() {
        try {
            return br.readLine();
        }
        catch (Exception ex){
            return "";
        }
    }
    public int read(){
        try {
            return br.read();
        }
        catch (Exception ex){
            return -1;
        }
    }
}
abstract class BaseIO implements IIO {

    public long readLong() {
        return Long.parseLong(this.readLine());
    }

    public int readInt() {
        return Integer.parseInt(this.readLine());
    }

    public int[] readIntArray() {
        String line = this.readLine();
        String[] nums = line.split(" ");
        int[] res = new int[nums.length];
        for (int i = 0; i < nums.length; i++) {
            res[i] = Integer.parseInt(nums[i]);
        }
        return res;
    }
    public long[] readLongArray() {
        String line = this.readLine();
        String[] nums = line.split(" ");
        long[] res = new long[nums.length];
        for (int i = 0; i < nums.length; i++) {
            res[i] = Long.parseLong(nums[i]);
        }
        return res;
    }
}
interface IIO {
    void writeLine(String s);
    void writeInt(int a);
    void writeWord(String s);
    String readLine();
    long readLong();
    int readInt();
    int read();
    int[] readIntArray();
    long[] readLongArray();
}