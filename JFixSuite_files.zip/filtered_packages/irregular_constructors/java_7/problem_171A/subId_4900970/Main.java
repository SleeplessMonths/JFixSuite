package java_7.problem_171A.subId_4900970;

import java.io.PrintWriter;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        PrintWriter out = new PrintWriter(System.out, true);
        Scanner in = new Scanner(System.in);
        Main solver = new Main(in, out);
        solver.run();
    }

    Scanner in;
    PrintWriter out;

    public Main(Scanner i, PrintWriter o) {
        in = i;
        out = o;
    }

    public void run() {
        int a = in.nextInt();
        int b = in.nextInt();
        out.println(1);
        return;
    }

}