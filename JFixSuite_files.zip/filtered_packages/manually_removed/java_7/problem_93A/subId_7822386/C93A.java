package java_7.problem_93A.subId_7822386;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class C93A {
	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		String[] params = reader.readLine().split(" ");
		reader.close();
		
		int n = Integer.parseInt(params[0]);
		int m = Integer.parseInt(params[1]);
		int a = Integer.parseInt(params[2]);
		int b = Integer.parseInt(params[3]);
		
		int k = (n - (n % m)) / m;
		if (n % m != 0) {
			k += 1;
		}
		int[][] matrix = new int[k][m];
		
		int idx = 1;
		for (int i = 0; i < k; i++) {
			for (int j = 0; j < m; j++) {
				matrix[i][j] = 0;
				if (idx <= n) {
					matrix[i][j] = idx;
					idx += 1;
				}
			}
		}
		
		int answer = 0;
		int addAnswer = 0;
		for (int i = 0; i < k; i++) {
			int counter = 0;
			for (int j = 0; j < m; j++) {
				if (matrix[i][j] >= a && matrix[i][j] <= b) {
					counter += 1;
				} 
				//System.out.print("" + matrix[i][j] + ", ");
			}
			//System.out.println();
			if (counter > 0 && counter < m) {
				addAnswer += 1;
			} else if (counter == m) {
				answer = 1;
			}
			
		}
		System.out.println("" + (answer + addAnswer));
	}
}