package java_7.problem_93A.subId_7823008;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class C93A {
	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		String[] params = reader.readLine().split(" ");
		reader.close();
		
		int n = Integer.parseInt(params[0]);
		int m = Integer.parseInt(params[1]);
		int a = Integer.parseInt(params[2]);
		int b = Integer.parseInt(params[3]);
		
		int k = (n - (n % m)) / m;
		if (n % m != 0) {
			k += 1;
		}
		int[][] matrix = new int[k][m];
		
		int idx = 1;
		for (int i = 0; i < k; i++) {
			for (int j = 0; j < m; j++) {
				matrix[i][j] = 0;
				if (idx <= n) {
					matrix[i][j] = idx;
					idx += 1;
				}
			}
		}
		
		final int stateA = 1;
		final int stateB = 2;
		final int stateC = 3;
		final int stateD = 4;
		int state = stateA;
		
		boolean left = false;
		boolean right = false;
		int height = 1;
		for (int i = 0; i < k; i++) {
			for (int j = 0; j < m; j++) {
				int value = matrix[i][j];
				if (value == 0) {
					continue;
				}
				
				switch (state) {
					case stateA:
					if (value == a) {
						state = stateB;
						if (j > 0) {
							left = true;
						}
					}
					break;
					
					case stateB:
					if (value == b) {
						state = stateC;
					}
					break;
					
					case stateC:
					if (j > 0) {
						right = true;
					}
					state = stateD;
					break;
					
					case stateD:
					break;
				}
				//System.out.print("" + matrix[i][j] + ", ");
			}
			//System.out.println();
		    if (state == stateB) {
		    	height += 1;
		    }
		}
		System.out.println("" + left + right+height);
		int answer = 0;
		if (height == 1) {
			answer = 1;
		} else if (height == 2) {
			if (!left && !right) {
				answer = 1;
			} else {
				answer = 2;
			}
		} else {
			answer = 1;
			if (left) {
				answer += 1;
			}
			if (right) {
				answer += 1;
			}
		}
		System.out.println("" + answer);
	}
}