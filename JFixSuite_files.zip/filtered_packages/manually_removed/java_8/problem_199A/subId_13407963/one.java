package java_8.problem_199A.subId_13407963;

import java.util.Scanner;
public class one {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);

		int n=sc.nextInt();

		if(n==1){
			System.out.println(1);
			
		}else if(n==0){
			System.out.println("I\'m too stupid to solve this problem");
		}
		
		else if(n==2){
			
			System.out.println(1+" "+1);
		}else if(n==3){
			System.out.println(1+" "+1+" "+1);
			
		}else if(n==5){
			System.out.println(3+" "+1+" "+1);
			
		}
		
		
		else {
			
			
			int[] arrayOfFab=new int[n];
			arrayOfFab=fibanochi(n);
			int[] three=new int[3];
			three=findThreeNumber( n,arrayOfFab);



			for (int i = 0; i < three.length; i++) {
				System.out.print(three[i]+" ");
			}

			System.out.println("");
		
		
		}



	}

	static int[] fibanochi (int n){
		int base =1;
		

		int [] fab=new int[n];
		fab[1]=1;
		fab[2]=2;
		for (int i=3;i<n;i++){
			fab[i]=fab[i-1]+fab[i-2];
		}

		return fab;
	}

	static int[]findThreeNumber (int n ,int [] array ){

		int [] threenumbers =new int [3];
		for(int i=1;i<array.length;i++){
			if(array[i]==n){
				threenumbers[0]=array[i-1];
				threenumbers[1]=array[i-3];
				threenumbers[2]=array[i-4];
				break;
			}else {
				threenumbers[0]=0;
				threenumbers[1]=0;
				threenumbers[2]=0;
			
			}
		}
		return threenumbers;
	}


}