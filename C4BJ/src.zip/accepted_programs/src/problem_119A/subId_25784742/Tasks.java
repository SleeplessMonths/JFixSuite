package problem_119A.subId_25784742;

import java.util.Scanner;

public class Tasks {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        byte a = in.nextByte(), b = in.nextByte(), n = in.nextByte();
        while (n >= 0) {
            for (byte i = a; i >= 1; i--) {
                if (n % i == 0 && a % i == 0) {
                    n -= i;
                    break;
                }
            }
            if (n < 0) {
                System.out.println(1);
                break;
            }
            for (byte i = b; i >= 1; i--) {
                if (n % i == 0 && b % i == 0) {
                    n -= i;
                    break;
                }
            }
            if (n < 0) {
                System.out.println(0);
                break;
            }
        }
    }
}