package problem_119A.subId_17254720;

import java.util.Scanner;
public class EpicGame {

	public static void main(String[] args) {
		
		int simonarray[] = new int [30];
		int antisimonarray[] = new int[30];


		int max = 100;
		int a = 0;
		int b = 0;
		int n = 0;
		
		Scanner myScanner = new Scanner(System.in);
		String input = myScanner.nextLine();
		
		a = Integer.parseInt(input.substring(0, input.indexOf(' ')));
		String subinput = input.substring((input.indexOf(' ')+1), input.length());
		b = Integer.parseInt(subinput.substring(0, subinput.indexOf(' ')));
		subinput=subinput.substring((subinput.indexOf(' ')+1), subinput.length());
		n = Integer.parseInt(subinput);
		
		for (int i = 0; i<100; max--) {

			if (max==0) break;
			
			if (a%max==0) {
				simonarray[i]=max;
				i++;
			}
		}
		max = 100;
		for (int i = 0; i<100; max--) {
			if (max==0) break;
			
			if (b%max==0) {
				antisimonarray[i]=max;
				i++;
			}
		}
		
		
		
		for (;;) { 

		    if(n<0) break;
			if (n==0){
				System.out.println("1");
				break;
		}
			
			for (int i = 0;;) {
			if (n%simonarray[i]==0) {
				n-=simonarray[i];
				break;
			} else i++;
			
			}
			
			
			
			
			if (n==0){
				System.out.println("0");
				break;
		}
			for (int i = 0;;) {
			if (n%antisimonarray[i]==0) {
				n-=antisimonarray[i];
				break;
			} else i++;
			
			}
			
			
	
		}
		
		
		
		

	}

}