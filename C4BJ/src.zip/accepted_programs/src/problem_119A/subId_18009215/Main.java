package problem_119A.subId_18009215;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static int gcd(int a, int b){
		while(a != 0 && b != 0){
			int c = b;
			b = a%b;
			a = c;
		}
		return a+ b;
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		String[] in1 = in.readLine().split(" ");
		int a = Integer.parseInt(in1[0]);
		int b = Integer.parseInt(in1[1]);
		int n = Integer.parseInt(in1[2]);
		int cur = 0;
		while(true){
			if(cur == 0){
				int ans = gcd(a,n);
				if(n < ans){
					break;
				}
				n -= ans;
				cur = 1;
			}
			if(cur == 1){
				int ans= gcd(b,n);
				if(n < ans)
					break;
				n -= ans;
				cur = 0;
			}
		}
		if(cur == 0)
			cur = 1;
		else if(cur == 1)
			cur = 0;
		System.out.println(cur);
	}

}