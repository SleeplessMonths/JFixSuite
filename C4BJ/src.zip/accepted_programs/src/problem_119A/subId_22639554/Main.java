package problem_119A.subId_22639554;

import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        int a=scanner.nextInt(), b=scanner.nextInt(), n=scanner.nextInt();
        for (int i=0;;i=(i+1)%2) {
            int x=gcd(i==0?a:b, n);
            if (x>n) {
                System.out.println(1-i);
                break;
            }
            n-=x;
        }
    }
    private static int gcd(int a, int b) {
        return b==0?a:gcd(b, a%b);
    }
}