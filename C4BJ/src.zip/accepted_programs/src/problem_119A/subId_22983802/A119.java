package problem_119A.subId_22983802;

import java.util.Scanner;

/**
 * Author: prakadi2 (yutta)
 * Problem:
 * Solved: 11-Dec-16
 */
public class A119 {
    static int gcd (int a, int b){
        int res=1;
        int m = Math.min(a,b);
        for (int i = 1; i <= m; i++) {
            if(a%i==0 && b%i==0){
                res=i;
            }
        }
        return res;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int a = s.nextInt();
        int b = s.nextInt();
        int n = s.nextInt();

        int x;
        while(n>0){
            x = gcd(a,n);
            n = n-x;
            //System.out.println(a +" "+n);
            if(n==0){
                System.out.println("0");
                break;
            }
            x = gcd(b,n);
            n = n-x;
            //System.out.println(b +" "+n);
            if (n == 0) {
                System.out.println("1");
            }
        }
    }
}