package problem_119A.subId_22136469;

import java.io.IOException;
import java.util.HashSet;
import java.util.Scanner;

public class MainApp
{
    public static HashSet<Integer> simpleNums = new HashSet<>();

    public static int calcSones(int pS, int cntS)
    {
        int tmp = cntS;

        if(simpleNums.contains(pS) && simpleNums.contains(cntS) && pS >= cntS && (pS % cntS == 0))
        {
            //System.out.println("NOK = "+cntS+"; plNum = "+pS+"; nowCnt = "+cntS);
            cntS = 0;
        }
        else if(simpleNums.contains(pS) && !simpleNums.contains(cntS) && (cntS % pS != 0) )
        {
            //System.out.println("NOK = 1; plNum = "+pS+"; nowCnt = "+cntS+"--");
            cntS--;
        }
        else
        {
            for (int i = pS; i > 0 ; i--) {
               // System.out.println(i);
                if( (pS % i == 0) && (cntS % i == 0) ) {
                    //System.out.println("NOK = "+i+"; plNum = "+pS+"; nowCnt = "+cntS);
                    cntS -= i;
                    break;
                }
            }
        }

        if(tmp == cntS)
            return -1;
        else
            return cntS;
    }

    public static void main(String[] args) throws IOException
    {
        Scanner sc = new Scanner(System.in);
        int firstP  = sc.nextInt();
        int secondP = sc.nextInt();
        int cntStones = sc.nextInt();



        makeSimple(); boolean firsGo = true;
       // if(simpleNums.contains(firstP))
        //    System.out.println("FP simple");
        while(cntStones > 0)
        {
            if(cntStones == 0)
                break;
            if(firsGo)
                cntStones = calcSones(firstP, cntStones);
            else
                cntStones = calcSones(secondP, cntStones);

//            if(firsGo)
//                System.out.println("CntStone = "+cntStones+"; Ходил Семён\n");
//            else
//                System.out.println("CntStone = "+cntStones+"; Ходил Антисемён\n");
            if(cntStones != -1)
            {
                if(firsGo)
                    firsGo = false;
                else
                    firsGo = true;
            }
        }

        if(firsGo)
            System.out.println(1);
        else
            System.out.println(0);
    }

    public static void makeSimple()
    {
        boolean isSimple = true;
        simpleNums.add(1); simpleNums.add(2); simpleNums.add(3); simpleNums.add(5); simpleNums.add(7);
        for (int i = 12; i < 100; i++) {
            for (int j = 2; j < (int)(Math.ceil(Math.sqrt(i))); j++) {
                if(i % j == 0)
                {
                    isSimple = false;
                    break;
                }
            }
            if(isSimple)
                simpleNums.add(i);
            isSimple = true;
        }
    }
}