package problem_119A.subId_18083171;

//import java.io.IOException;
//import java.io.BufferedReader;
//import java.io.InputStreamReader;

import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        Scanner scan = new Scanner(System.in);
        int n1 = scan.nextInt(); int n2 = scan.nextInt(); int n = scan.nextInt(); int i = 0;
        while(n!=0){
            if(i%2==0){
                n -= gcd(Math.max(n1,n),Math.min(n1,n));
                i++;
            }else{
                n -= gcd(Math.max(n2,n),Math.min(n2,n));
                i++;
            }
        }
        System.out.println(i%2==0?1:0);
    }
    
    public static int gcd(int n, int m){
        while(n%m!=0){
            int temp = m;
            m = n%m;
            n = temp;
        }
        return m;
    }
}