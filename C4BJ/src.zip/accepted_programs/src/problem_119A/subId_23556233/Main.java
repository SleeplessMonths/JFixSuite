package problem_119A.subId_23556233;

//package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int a = input.nextInt();
        int b = input.nextInt();
        int n = input.nextInt();
        int turn=0;

        while (true) {
            int take =turn==0?gcd(a, n):gcd(b, n);
            n -= take;
            if (n == 0) {
                System.out.println(turn);
                break;
            }
            turn=1-turn;
        }
    }

    private static int gcd(int a, int n) {
        if (a % n == 0) return n;
         return gcd(n, a % n);
    }
}