package problem_119A.subId_22022665;

import java.util.Scanner;

public class EpicGame{
    public static void main(String args[]){
        Scanner scan = new Scanner(System.in);
        
        int[] consts = new int[2];
        consts[0] = scan.nextInt(); // Simon's number
        consts[1] = scan.nextInt(); // Antisimon's number
        
        int numStones = scan.nextInt();
        
        int index =0;
        
        while(numStones > 0){
            numStones -= gcd(consts[index], numStones);
            index = (index+1)%2;
        }
        
        System.out.println((index+1)%2);
        
    }
    
    private static int gcd(int a, int b){
        int larger = Math.max(a,b);
        int smaller = Math.min(a,b);
        
        while(smaller != 0){
            int tmp = larger % smaller;
            larger = smaller;
            smaller = tmp;
        }
        
        return larger;
    }
}