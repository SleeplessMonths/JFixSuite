package problem_119A.subId_27578998;

import java.util.Scanner;

/**
 * Created by NIckConterno on 6/5/17.
 */
public class Force119A {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str=in.nextLine();
        String[] a = str.split(" ");
        int antisimon=Integer.parseInt(a[1]);
        int simon=Integer.parseInt(a[0]);
        int num=Integer.parseInt(a[2]);
        Boolean b = true;
        while(num>0){
            if(b){
                num-=gcd(simon,num);
                b=false;
            }
            else{
                num-=gcd(antisimon,num);
                b=true;
            }
        }
        if(b){
            System.out.println(1);
        }
        else{
            System.out.println(0);
        }




    }
    public static Integer gcd(int a,int b){
        for(int i=a;a>0;i--){
            if(b%i==0&&a%i==0){
                return i;
            }
        }
        return 1;
    }
}