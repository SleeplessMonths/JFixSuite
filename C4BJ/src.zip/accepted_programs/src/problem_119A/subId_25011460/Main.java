package problem_119A.subId_25011460;

import java.util.Scanner;

public class Main {
    
    
    
    public static int getGreat(int a , int b){
        int min = Integer.min(a, b);
        while(a % min != 0 || b % min != 0){
            min --;
            
            
            
        }
        
        
        return min;
        
    }
    
    
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);
        
        int a = sc.nextInt(), b = sc.nextInt(), n = sc.nextInt();
        
        int term = 0;
        
        while(n > 0){
            
            if(term % 2 == 0){
                      n-= getGreat(a, n);
            }else{
                      n-= getGreat(b, n);
            }
            term++;
            
        }
        
        System.out.println(term % 2 != 0 ? "0" : "1");
        
        
        
        
    }
    
    
    
}