package problem_119A.subId_20996754;

import java.util.Scanner;

public class cf {
	
	static int gcd(int a,int b){
		if(b==0)
			return a;
		return gcd(b,a%b);
	}
	
	public static void main(String args[]){
	Scanner cin=new Scanner(System.in);
	int a=cin.nextInt(),b=cin.nextInt(),n=cin.nextInt(),turn=0,nzd;
	while(true){
		if(turn==0)
		    nzd=gcd(a,n);		
		else
			nzd=gcd(b,n);
			if(n<nzd)
				break;
			n-=nzd;
		turn=(turn+1)%2;
	}
	System.out.print(turn==1?0:1);
	
	
	

}
	
}