package problem_119A.subId_29523213;

import java.util.Scanner;

public class EpicGame {

		static int gcd1(int c,int d) {
			int e = Math.min(c,d),gcd=1;
			for(int i=e;i>=1;i--) {
				if(c%i==0&&d%i==0) {
					gcd=i;
					break;
				}
			}
			return gcd;
		}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int n = sc.nextInt();
		int flag=1,gcd=0,count=0;
		while(flag==1) {
			if(count%2==0) {
				if(a==0) 
					gcd=n;
				else if(n==0)
					gcd=a;
				else if(a==1||n==1)
					gcd=1;
				else
					gcd=gcd1(a,n);
				n=n-gcd;
				if(n<0){
					System.out.println(1);
					flag=0;
				}
			}
			else {
				if(b==0)
					gcd=n;
				else if(n==0)
					gcd=b;
				else if(b==1||n==1) 
					gcd=1;
				else
					gcd=gcd1(b,n);
				n=n-gcd;
				if(n<0){
					System.out.println(0);
					flag=0;
				}
			}
			count++;
		}	
	}
}