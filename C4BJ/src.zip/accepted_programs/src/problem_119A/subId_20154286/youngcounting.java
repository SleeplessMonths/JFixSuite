package problem_119A.subId_20154286;

import java.util.Scanner;

public class youngcounting {

	public static void main(String[] args)
	{

			int a;
			int b;
			int n;
			Scanner s = new Scanner(System.in);
			a = s.nextInt();
			b = s.nextInt();
			n = s.nextInt();
			
			while(true)
			{
				if(gcd(a,n) >= n)
				{
					System.out.println("0");
					break;
				}
				else
				{
					
					n = n - gcd(a,n);
				}
				
				if(gcd(b,n) >= n)
				{
					System.out.println("1");
					break;
				}
				else
				{
					n = n - gcd(b,n);
				}
			}
			
			
			
	}
	
	static int gcd(int x,int y)
	{
		int d;
		int r=1;
		if(x>=y)
		{
			d=y;
		}
		else
		{
			d=x;
		}
		
		for(int i=d;i>=1;i--)
		{
			if(x%i==0 && y%i==0)
			{
				r = i;
				break;
			}
		}
		return r;
	}
	
}