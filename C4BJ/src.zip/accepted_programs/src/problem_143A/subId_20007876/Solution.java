package problem_143A.subId_20007876;

/* package whatever; // don't place package name! */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/* Name of the class has to be "Main" only if the class is public. */
public class Solution
{
	public static void main (String[] args) throws java.lang.Exception
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int r1 = Integer.parseInt(st.nextToken());
		int r2 = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		int c1 = Integer.parseInt(st.nextToken());
		int c2 = Integer.parseInt(st.nextToken());
		st = new StringTokenizer(br.readLine());
		int d1 = Integer.parseInt(st.nextToken());
		int d2 = Integer.parseInt(st.nextToken());
		//List<List<Integer>> l = new ArrayList<List<Integer>>();
		if (r1==-1||r2==-1||c1==-1||c2==-1||d1==-1||d2==-1){
			System.out.println(-1);
			return;
		}
		int[] row1 = new int[2];
		int[] row2 = new int[2];
		
		for (int i= 1;i<=9;i++){
			if (i==r1-i||i>9||r1-i>9||r1-i<1)continue;
			row1[0]=i;
			row1[1]=r1-i;
			for (int j=1;j<=9;j++){
				if (j==r2-j||j==i||j==r1-i||r2-j==i||r2-j==r1-i||r2-j>9||r2-j<1)continue;
				row2[0]=j;
				row2[1]=r2-j;
				if ((c1==(row1[0]+row2[0]))&&(c2==(row1[1]+row2[1]))&&(d1==(row2[1]+row1[0]) && d2==(row1[1]+row2[0]))){
				print(row1,row2);
				return;
				}
			}
			
		}
		System.out.println(-1);
		
		
	//System.out.println(min);
	}
	
	private static void print(int[] row1,int[] row2){
		System.out.println(row1[0]+" "+row1[1]);
		System.out.println(row2[0]+" "+row2[1]);
	}
}