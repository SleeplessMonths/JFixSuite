package problem_143A.subId_14426415;

import java.util.Scanner;

public class Young {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int r1 = sc.nextInt();
		int r2 = sc.nextInt();
		int c1 = sc.nextInt(); 
		int c2 = sc.nextInt();
		int d1 = sc.nextInt(); 
		int d2 = sc.nextInt();
		
		
		int x = (c1 - r2 + d1 )/2;
		int t = d1 - x;
		int y = r1 - x;
		int z = r2 - t;
		if(x!=y && x!=z && x!=t && y!=z && y!=t && z!=t &&  x>=1 && x<=9 && y>=1 && y<=9 && t>=1 && t<=9 && z>=1 && z<=9)
		
			{
			System.out.println(x+" "+y);
			System.out.println(z+" "+t);
			}
		else System.out.println("-1");
		
		
		
	}
}