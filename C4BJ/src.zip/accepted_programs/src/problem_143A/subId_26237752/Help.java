package problem_143A.subId_26237752;

//package ff;

import java.util.Scanner;

public class Help {
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		int r1 = sc.nextInt();
		int r2 = sc.nextInt();
		int c1 = sc.nextInt();
		int c2 = sc.nextInt();
		int d1 = sc.nextInt();
		int d2 = sc.nextInt();
		
		int x=0,y=0,z=0,w=0;
		boolean f = true;
		for(x=1;x<10 && f==true;x++){
				for(y=1;y<10&& f ==true;y++){
				if(x+y==r1 && x!=y){
					for(w=1;w<10 && f==true;w++){
						if(w+x==c1&&w+y==d2 && w!=y && w!=x){
									for(z=1;z<10 && f==true;z++){
								if(w+z==r2 && x+z==d1 && z+y==c2 && z!=y && z!=x && z!=w)
									f=false;
							}
						}
						
					}
			}
			}
		}
		x--;
		y--;
		w--;
		z--;
		//String s = x+""+y+""+w+""+z;
		if(!f ){
			System.out.println(x + " "+ y);
			System.out.println(w + " "+ z);

		}
		else
			System.out.println(-1);
	}
	public static boolean check(String s){
		for(int i = 0 ; i<4;i++){
			for(int j=i+1;j<4;j++)
				if(s.charAt(i)==s.charAt(j))
					return false;
		}
		return true;
		
	}
}