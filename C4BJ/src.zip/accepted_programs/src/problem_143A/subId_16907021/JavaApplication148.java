package problem_143A.subId_16907021;

import java.util.Scanner;
public class JavaApplication148 {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
int r1,r2,c1,c2,d1,d2,x1,x2,x3,x4;
r1 = sc.nextInt();
r2 = sc.nextInt();
c1 = sc.nextInt();
c2 = sc.nextInt();
d1 = sc.nextInt();
d2 = sc.nextInt();

x3 = (r2-c2+d2)/2;
x1 = c1 - x3;
x2 = d2 - x3;
x4 = r2 - x3;

if(x1==0||x2 == 0||x3==0||x4==0||x1>9||x2>9||x3>9||x4>9||(r2-c2+d2)%2 == 1
   ||(x1==x2)||(x1==x2)||(x1==x3)||(x1==x4)||(x2==x3)||(x2==x4)||(x3==x4))
{
System.out.println(-1);
}
else
{
System.out.println(x1+" "+x2);
System.out.println(x3+" "+x4);
}

    }
    
}