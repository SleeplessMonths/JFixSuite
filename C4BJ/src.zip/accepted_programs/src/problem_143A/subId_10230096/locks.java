package problem_143A.subId_10230096;

import java.util.Scanner;
public class locks{
	public static void main(String []args){
		Scanner sc = new Scanner(System.in) ;
		int r1,r2,c1,c2,d1,d2,a,b,c,d;
		int M[] = new int[10] ;
		r1 = sc.nextInt() ;
		r2 = sc.nextInt() ;
		c1 = sc.nextInt() ;
		c2 = sc.nextInt() ;
		d1 = sc.nextInt() ;
		d2 = sc.nextInt() ;
		b = (r1-c1 + d2) / 2 ; 
		a = r1 - b ;
		d = d1 - a ;
		c = r2 - d ;
		boolean ok = false ;
		if(a <= 9 && b <= 9 && c <= 9 && d <= 9 && a >= 1 && b >= 1 && c >= 1 && d >= 1)
			ok = true ;
		
		if(ok){
			if(a+b != r1) ok = false ;
			if(c+d != r2) ok = false ;
			if(a+c != c1) ok = false ;
			if(b+d != c2) ok = false ;
			if(a+d != d1) ok = false ;
			if(c+b != d2) ok = false ;
			for(int i=0;i<10;i++) M[i] = 0 ;
			M[a] = M[b] = M[c] = M[d] = 1 ;
			int cnt = 0 ;
			for(int i=0;i<10;i++)
				if(M[i] == 1) cnt ++ ;
			if(cnt != 4)
				ok = false ; 
		}
		if(ok)
			System.out.print(a + " " + b + "\n" + c + " " + d + "\n") ;
		else
			System.out.print("-1") ;
	}
}