package problem_143A.subId_27045123;

import java.util.Scanner;

public class third {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		int r1=scan.nextInt();
		int r2=scan.nextInt();
		int c1=scan.nextInt();
		int c2=scan.nextInt();
		int d1=scan.nextInt();
		int d2=scan.nextInt();
		int b2=(r2-c1+d1)/2;
		int a1=(d1-b2);
		int a2=(r1-a1);
		int b1=(c1-a1);
		if(b1+b2!=r2) System.out.println(-1);
		else if(a2+b2!=c2) System.out.println(-1);
		else if(a1==a2 || b1==b2 || a1<=0 || a2<=0|| b1<=0|| b2<=0) System.out.println(-1);
		else if(a1==b1 || a1==b2 || a2==b1 || a2==b2) System.out.println(-1);
		else if(a1>=10 || b1>=10 || a2>=10 || b2>=10) System.out.println(-1);
		else{
			System.out.println(a1+" "+a2);
			System.out.println(b1+" "+b2);
		}
	}
	}