package problem_143A.subId_24241904;

import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int r1 = sc.nextInt(), r2 = sc.nextInt() , c1 = sc.nextInt() , c2 = sc.nextInt() , d1 = sc.nextInt(), d2 = sc.nextInt();
		
		int a[] = new int[4];
		int temp;
		
		a[0] = r1+c1-d2;
		a[1] = r1+c2-d1;
		a[2] = r2+c1-d1;
		a[3] = r2+c2-d2;
		
		boolean b=true;
		
		for(int i =0 ; i<4 ;i++){
			if(a[i]%2 ==0)
				a[i]/=2;
			else{
				b=false;
				break;
			}
		}
		
		if(b){
			for(int i=0 ; i<4 ; i++){
				if(a[i]>9 || a[i]<=0)
					b=false;
				for(int j = i+1 ; j<4 ;j++){
					if(a[i]==a[j]){
						b=false;
					}
				}
			}
		}
		
		if(b){
			System.out.println(a[0]+" "+a[1]);
			System.out.println(a[2]+" "+a[3]);
		}
		else{
			System.out.println(-1);
		}
	}
}