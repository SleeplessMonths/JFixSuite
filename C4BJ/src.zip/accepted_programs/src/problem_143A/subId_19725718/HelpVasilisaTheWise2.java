package problem_143A.subId_19725718;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/**
 * Created by saksham on 08-08-2016.
 * 143A
 */
public class HelpVasilisaTheWise2 {
    public static void main(String []args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer(br.readLine(), " ");
        int r1 = Integer.parseInt(st.nextToken());
        int r2 = Integer.parseInt(st.nextToken());
        st = new StringTokenizer(br.readLine(), " ");
        int c1 = Integer.parseInt(st.nextToken());
        int c2 = Integer.parseInt(st.nextToken());
        st = new StringTokenizer(br.readLine(), " ");
        int d1 = Integer.parseInt(st.nextToken());
        int d2 = Integer.parseInt(st.nextToken());
        int a = r1 - d2 + c1;
        int b = r1 + d2 - c1;
        int c = c1 + d2 - r1;
        int d = (2*r2) - d2 - c1 + r1;
        if(a>0 && a%2==0 && b>0 && b%2==0 && c>0 && c%2==0 && d>0 && d%2==0) {
            a=a/2;
            b=b/2;
            c=c/2;
            d=d/2;
            if(a!=b && a!=c && a!=d && b!=c && b!=d && c!=d && a>0 && a<=9 && b>0 && b<=9 && c>0 && c<=9 && d>0 && d<=9 && a+b==r1 && c+d==r2 && a+c==c1 && b+d==c2 && a+d==d1 && b+c==d2) {
                System.out.println(a + " " + b);
                System.out.println(c + " " + d);
            } else {
                System.out.println(-1);
            }
        } else {
            System.out.println(-1);
        }
    }
}