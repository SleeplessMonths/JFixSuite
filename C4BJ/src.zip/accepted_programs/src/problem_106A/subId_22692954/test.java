package problem_106A.subId_22692954;

import java.util.Scanner;

public class test {
public static void main(String[] args) {
	String win="SHDC";
	String rank="6789TJQKA";
	Scanner s=new Scanner(System.in);
	String tump=s.next();
	String s1=s.next();
	String s2=s.next();
	
	if(s1.contains(tump+"")&&(!s2.contains(tump+""))) System.out.println("YES");
	else if(s2.contains(tump+"")&&(!s1.contains(tump+""))) System.out.println("NO");
	else{
		String a=s1.charAt(1)+"";
		String b=s2.charAt(1)+"";
		if (win.indexOf(a)==win.indexOf(b)){
	    if(rank.indexOf(s1.charAt(0))>rank.indexOf(s2.charAt(0))) System.out.println("YES");
	    else System.out.println("NO");
		}
		else System.out.println("NO");
	}

}
}