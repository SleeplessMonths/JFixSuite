package problem_106A.subId_10973247;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.StringTokenizer;

public class CF82A {

	private static BufferedReader br;
	private static StringTokenizer st;
	private static PrintWriter pw;

	// private static Timer t = new Timer();

	public CF82A() throws IOException {
		br = new BufferedReader(new InputStreamReader(System.in));
		pw = new PrintWriter(System.out);
	}

	String next() throws IOException {
		while (st == null || !st.hasMoreElements())
			st = new StringTokenizer(br.readLine());
		return st.nextToken();
	}

	boolean hasNext() {
		if (st != null && st.hasMoreElements())
			return true;

		try {
			while (st == null || !st.hasMoreElements())
				st = new StringTokenizer(br.readLine());
		} catch (Exception e) {
			return false;
		}

		return true;
	}

	String nextLine() throws IOException {
		return br.readLine();
	}

	int nextInt() throws IOException {
		return Integer.parseInt(next());
	}

	long nextLong() throws IOException {
		return Long.parseLong(next());
	}

	void solve() throws IOException {
		HashMap<String, Integer> map = new HashMap<>();
		String[] S = { "6", "7", "8", "9","T", "J", "Q", "K", "A" };
		int[] A = { 6, 7, 8, 9, 10, 11, 12, 13, 14 };
		for (int i = 0; i < S.length; i++) {
			map.put(S[i], A[i]);
		}

		String s = next();
		char[] S1 = next().toCharArray();
		char[] S2 = next().toCharArray();

		String lastS1 = "" + S1[1], lastS2 = "" + S2[1];
		if (lastS1.equals(s)) {
			if (lastS2.equals(s)) {
				if (map.get(""+S1[0]) > map.get(""+S2[0]))
					pw.println("YES");
				else
					pw.println("NO");
			}else {
				pw.println("YES");
			}
		}else if( lastS2.equals(s)) {
			pw.println("NO");
		}else {
			if(map.get(""+S1[0]) > map.get(""+S2[0]) && S1[1] == S2[1]) {
				pw.println("YES");
			}else
				pw.println("NO");
		}

		pw.flush();
	}

	public static void main(String[] args) throws IOException {
		new CF82A().solve();
	}
}