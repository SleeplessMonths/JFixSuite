package problem_106A.subId_21057503;

import java.io.*;
import java.util.StringTokenizer;

public class CardGame {
	public static void main(String[] args) {
		PrintWriter pw = new PrintWriter(System.out);
	    reader(System.in);
	    char ts = n().charAt(0);
	    String c1 = n();
	    String c2 = n();
	    int cnt1 = 0;
	    int cnt2 = 0;
	    if (c1.charAt(0) == 'A') {
	    	cnt1 = 14;
	    }
	    else if (c1.charAt(0) == 'K') {
	    	cnt1 = 13;
	    }
	    else if (c1.charAt(0) == 'Q') {
	    	cnt1 = 12;
	    }
	    else if (c1.charAt(0) == 'J') {
	    	cnt1 = 11;
	    }
	    else if (c1.charAt(0) == 'T') {
	    	cnt1 = 10;
	    }
	    else {
	    	cnt1 = c1.charAt(0) - '0';
	    }
	    if (c2.charAt(0) == 'A') {
	    	cnt2 = 14;
	    }
	    else if (c2.charAt(0) == 'K') {
	    	cnt2 = 13;
	    }
	    else if (c2.charAt(0) == 'Q') {
	    	cnt2 = 12;
	    }
	    else if (c2.charAt(0) == 'J') {
	    	cnt2 = 11;
	    }
	    else if (c2.charAt(0) == 'T') {
	    	cnt2 = 10;
	    }
	    else {
	    	cnt2 = c2.charAt(0) - '0';
	    }
	    if ((cnt1 > cnt2 && (c1.charAt(1) == ts || c1.charAt(1) == c2.charAt(1))) ||
	    	(cnt1 <= cnt2 && c1.charAt(1) == ts && c1.charAt(1) != c2.charAt(1)))
	    	pw.println("YES");
	    else
	    	pw.println("NO");
	    pw.close();
	}
	
	private static BufferedReader br;
	private static StringTokenizer st;

	static void reader(InputStream stream) {
	    try {
	        br = new BufferedReader(new InputStreamReader(stream));
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

	static String n() {
	    while (st == null || !st.hasMoreTokens()) {
	        try {
	            st = new StringTokenizer(br.readLine());
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    return st.nextToken();
	}

	static int nI() {
	    return Integer.parseInt(n());
	}
	
	static long nL() {
	    return Long.parseLong(n());
	}
}