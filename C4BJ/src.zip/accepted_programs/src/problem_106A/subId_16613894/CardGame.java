package problem_106A.subId_16613894;

import java.util.Scanner;
public class CardGame
{

    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
         String s = in.next();
        String  s1 = in.next();
        String  s2 = in.next();
        
        char A[]={'6','7','8','9','T', 'J', 'Q', 'K' ,'A'};
        char AA[]={'S', 'H', 'D' , 'C'};
        
        int n1=0;
        int n2=0;
        int n3=0;
        int n4=0;
        if (s1.charAt(1)==s.charAt(0)&& s2.charAt(1)!=s.charAt(0))
        {
            System.out.println("YES");
            return;
        }
        else  if (s1.charAt(1)!=s.charAt(0)&& s2.charAt(1)==s.charAt(0))
        {
            System.out.println("NO");
            return;
        }
        else  if (s1.charAt(1)!=s.charAt(0)&& s2.charAt(1)!=s.charAt(0)&&s1.charAt(1)!=s2.charAt(1) )
        {
            System.out.println("NO");
            return;
        }
        
        else
        {
            for (int i = 0; i < A.length; i++) 
            {
                if (s1.charAt(0)==A[i])
                {
                    n1=i;
                }
                if (s2.charAt(0)==A[i])
                {
                    n2=i;
                }
            }
            if (n1>n2)
            {
                System.out.println("YES");
            }
            else
            {
                System.out.println("NO");
            }
        }
       
        
    }
    
}