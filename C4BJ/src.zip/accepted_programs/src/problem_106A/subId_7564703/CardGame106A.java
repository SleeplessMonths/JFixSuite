package problem_106A.subId_7564703;

import java.util.Scanner;

public class CardGame106A
{
    public static void main(String[] args) 
    {
        // Set up scanner
        Scanner sc = new Scanner(System.in); 
        // System.out.println("Enter trump suit");
        String tr = sc.next();
        // System.out.println("Enter first card");
        String one = sc.next();
        // System.out.println("Enter second card");
        String two = sc.next();
        
        String suitone = one.substring(1);
        String suittwo = two.substring(1);
        
        String rank1 = one.substring(0,1);
        String rank2 = two.substring(0,1);
        int rankone = -1;
        int ranktwo = -1;
        
        if (rank1.equals("T"))
        {
            rankone = 10;
        }
        else if (rank1.equals("J"))
        {
            rankone = 11;
        }
        else if (rank1.equals("Q"))
        {
            rankone = 12;
        }
        else if (rank1.equals("K"))
        {
            rankone = 13;
        }
        else if (rank1.equals("A"))
        {
            rankone = 14;
        }
        else
        {
            rankone = Integer.valueOf(rank1);
        }
        
        if (rank2.equals("T"))
        {
            ranktwo = 10;
        }
        else if (rank2.equals("J"))
        {
            ranktwo = 11;
        }
        else if (rank2.equals("Q"))
        {
            ranktwo = 12;
        }
        else if (rank2.equals("K"))
        {
            ranktwo = 13;
        }
        else if (rank2.equals("A"))
        {
            ranktwo = 14;
        }
        else
        {
            ranktwo = Integer.valueOf(rank2);
        }
        
        if (suitone.equals(suittwo) && rankone > ranktwo)
        {
            System.out.println("YES");
            return;
        }
        
        if (suitone.equals(tr) && !suittwo.equals(tr))
        {
            System.out.println("YES");
            return;
        }
        
        System.out.println("NO");
    }
}