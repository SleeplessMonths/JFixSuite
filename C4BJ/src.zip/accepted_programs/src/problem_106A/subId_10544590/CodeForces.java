package problem_106A.subId_10544590;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
//harish reddy anumula
public class CodeForces{
    public static void main (String[] args)throws java.lang.Exception{
        BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
        PrintWriter pw = new PrintWriter(new BufferedOutputStream(System.out));
        String z = br.readLine();
        char trump = z.charAt(0);
        String[] z1 = br.readLine().split(" ");
        String on = z1[0];
        String tw = z1[1];
        int one = value(on.charAt(0));
        int two = value(tw.charAt(0));
        if(on.charAt(1)==trump && tw.charAt(1)!=trump){
            pw.println("YES");
        }
        else if(on.charAt(1)!=tw.charAt(1)){
            pw.println("NO");
        }
        else{
            if(one>two){
                pw.println("YES");
            }
            else{
                pw.println("NO");
            }
        }
        pw.close();
    }
    public static int value(char c){
        if(c=='6') return 6;
        if(c=='7') return 7;
        if(c=='8') return 8;
        if(c=='9') return 9;
        if(c=='T') return 10;
        if(c=='J') return 11;
        if(c=='Q') return 12;
        if(c=='K') return 13;
        if(c=='A') return 14;
        return 0;
    }
}