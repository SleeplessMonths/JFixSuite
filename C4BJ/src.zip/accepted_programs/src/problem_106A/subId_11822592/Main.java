package problem_106A.subId_11822592;

import java.util.HashMap;
import java.util.Scanner;


public class Main {


    
    public static void main(String[] args) {
Scanner s = new Scanner (System.in);

char S=s.next().charAt(0);
String First=s.next(),Second=s.next();

if ((First.charAt(1)==S && Second.charAt(1)!=S) || (First.charAt(1)==Second.charAt(1) && Stronger(First.charAt(0),Second.charAt(0))))
{
    System.out.println("YES");
} else {
    System.out.println("NO");
}
   }

    private static boolean Stronger(char _1, char _2) {
        HashMap<Character,Integer> E = new HashMap<Character,Integer>();
        E.put('6',0);E.put('7', 1);E.put('8', 2);E.put('9', 3);
        E.put('T', 4);E.put('J', 5);E.put('Q', 6);E.put('K', 7);
        E.put('A', 8);
        int val1=E.get(_1);
        int val2=E.get(_2);
        return val1>val2;
    }
}