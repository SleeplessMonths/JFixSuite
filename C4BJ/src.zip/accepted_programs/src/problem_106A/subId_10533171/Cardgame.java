package problem_106A.subId_10533171;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Cardgame {
    public static void main(String[] args) throws IOException {
         BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
         String brr[]=br.readLine().trim().split(" ");
        String s=brr[0];
        String t,u;
        char c=s.charAt(0);
        char d,e,f,g;
        int p,q;
        int arr[]=new int[130];
        {
            arr[54]=1;
            arr[55]=2;
            arr[56]=3;
            arr[57]=4;
            d='T';
            p=(int)d;
            arr[p]=5;
            d='J';
            p=(int)d;
            arr[p]=6;
            d='Q';
            p=(int)d;
            arr[p]=7;
            d='K';
            p=(int)d;
            arr[p]=8;
            d='A';
            p=(int)d;
            arr[p]=9;
            }
        brr=br.readLine().trim().split(" ");
           t=brr[0];
           u=brr[1];
           d=t.charAt(1);
           e=u.charAt(1);
           f=t.charAt(0);
           g=u.charAt(0);
           p=(int)f;
           q=(int)g;
           if(d==c&&e!=c)
               System.out.println("YES");
           else if((d!=c&&e!=c)&&(arr[p]>arr[q])&&(d==e))
               System.out.println("YES");
            else if((d==c&&e==c)&&(arr[p]>arr[q]))
                System.out.println("YES");
           else
                System.out.println("NO");
    }
}