package problem_106A.subId_21766714;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

// Main class to hold program logic

public class Main {

	public static void main(String[] args) throws IOException {
		// assuming rectangle is parallel to coordinate axes
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String t = br.readLine();
		String s = "6789TJQKA";
		String c[] = br.readLine().split(" ");
		if(c[0].contains(t)&& !c[1].contains(t)){
			System.out.println("YES");
		}
		else if(!c[0].contains(t)&& c[1].contains(t)){
			System.out.println("NO");
		}
		else{
			char o = c[0].charAt(0);
			char n = c[1].charAt(0);
			if(s.indexOf(o)>s.indexOf(n) && c[0].charAt(1)==c[1].charAt(1))
				System.out.println("YES");
			else
				System.out.println("NO");
		}
		// end of main
	}

}