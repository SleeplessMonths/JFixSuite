package problem_106A.subId_11015067;

import java.util.Scanner;


public class Card_Game {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner in=new Scanner(System.in);
	    char suit[]={'S','H','D','C'};
	    char rank[]={'6','7','8','9','T','J','Q','K','A'};
		char trump=in.next().charAt(0);
		String first=in.next();
		String second=in.next();
		//System.out.println(first.charAt(1)+" "+trump);
		if(first.charAt(1)==trump&&second.charAt(1)!=trump)
		System.out.println("YES");
		
		if(first.charAt(1)!=trump&&second.charAt(1)==trump)
			System.out.println("NO");
		
		else if(first.charAt(1)==trump&&second.charAt(1)==trump){
			int in1=0,in2=0;
			for(int i=0;i<rank.length;i++){
				if(first.charAt(0)==rank[i]){
					in1=i;
					break;
					}
				}
				for(int i=0;i<rank.length;i++){
					if(second.charAt(0)==rank[i]){
						in2=i;
						break;
						}
			            }
				if(in1>in2)System.out.println("YES");
				else System.out.println("NO");
		        }
		
		else if(first.charAt(1)!=trump&&second.charAt(1)!=trump){
			int in1=0,in2=0;
			for(int i=0;i<suit.length;i++){
				if(first.charAt(1)==suit[i]){
					in1=i;
					break;
					}
				}
				for(int i=0;i<suit.length;i++){
					if(second.charAt(1)==suit[i]){
						in2=i;
						break;
						}
			            }
				if(in1!=in2)System.out.println("NO");
				else {
					
					int in11=0,in22=0;
					for(int i=0;i<rank.length;i++){
						if(first.charAt(0)==rank[i]){
							in11=i;
							break;
							}
						}
						for(int i=0;i<rank.length;i++){
							if(second.charAt(0)==rank[i]){
								in22=i;
								break;
								}
					            }
						if(in11>in22)System.out.println("YES");
						else System.out.println("NO");
				        }
					
				}
		        }
		
		
		
	}