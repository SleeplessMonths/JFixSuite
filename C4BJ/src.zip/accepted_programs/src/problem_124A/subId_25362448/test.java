package problem_124A.subId_25362448;

import java.io.PrintStream;
import java.util.Scanner;
public class test
{
    public static void main(String args[])
    {
      test obj=new test();
        obj.start();
    }
    void start() {
        int x=0;
        Scanner sc = new Scanner(System.in);
        PrintStream out=System.out;
        int n = sc.nextInt();
        int m=sc.nextInt();
        int q=sc.nextInt();
        int count=0;
        for(int i=m+1;i<=n;i++)
        {
            if(n-i<=q)
                count++;
        }
        out.println(count);


    }

    private boolean cin(int j,int i,int d) {
        return d>=0&&i*9>=d;
    }
}