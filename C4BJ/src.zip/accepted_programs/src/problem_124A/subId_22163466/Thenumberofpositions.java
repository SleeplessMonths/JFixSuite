package problem_124A.subId_22163466;

import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TheSiscoKid
 */
public class Thenumberofpositions {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();        
        int minF = scanner.nextInt();
        int maxB = scanner.nextInt();
        scanner.close();
        if ((n-minF) <= maxB){
            System.out.println(n-minF);
        } else {
            System.out.println(maxB + 1);
        }
        
    }
}