package problem_124A.subId_22320190;

import java.util.Scanner;

/**
 *
 * @author ACM
 */
public class TheNumberOfPositions {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a = in.nextInt();
        int b = in.nextInt();
        int count = b+1;
       if(n==a+b)
            System.out.println(b);
       else if(n>a+b) 
            System.out.println(b+1);
       else if((a+b)>n)
            System.out.println(n-a);
    }
    
}