package problem_124A.subId_22120971;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) throws IOException{
        try (   PrintWriter printWriter = new PrintWriter(System.out);
                Scanner scanner = new Scanner(System.in)
                ){
            int n = scanner.nextInt();
            int a = scanner.nextInt();
            int b = scanner.nextInt();
            if(a >= n-(b+1)){
                printWriter.print(n-a+"\n");
            }
            else
                printWriter.print(b+1+"\n");
        }
    }
    
}