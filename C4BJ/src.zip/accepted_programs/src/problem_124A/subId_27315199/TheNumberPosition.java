package problem_124A.subId_27315199;

//package question2;

import java.util.Scanner;

/**
 *
 * @author DepED
 */
public class TheNumberPosition {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();//5
        int a = scan.nextInt();//2 - limits
        int b = scan.nextInt();//3 - limits
        int c = 0;
        //System.out.println(n - Math.max(a+1, n-b)+1);
        
        int front = 0;
        int back = 0;
        //start trying at first position
        for ( int x = 1;x<=n;x++) {
            //we can tell the number of people in front when we try out the positions(x)
            //lets say there are 5 people, and your at position 1
            // we can say that the number of people in front of you is equal to (your position which is 1 - 1, which is actually 0);
            //then x counter will add because of the for loop
            //the next x we will try its 2nd position, if your in 2nd position the no. of people and front of you is 1
            //the process will repeat until the x is reached the total number of people
             front = x - 1;
             
             
            //we can tell the number of people at the back when we try out again the positions(x)
            //lets say again there are 5 people and your position is 1
            //we can say that the number of people behind is equal to 5 people(n) minus your position(x) which is actually (5 - 1) which is actually 4
            back = n - x;
            //System.out.println("position: " + x+ ",front: " + front + ", back: " + back);
            
            
            //we can test now if people in front(0) is no less than 2(a) people, no less than means greater than or equal, which is actually true
            //and test if the people (back) is no more than 3(b) people, no more than means less than or equal 
            
            if(front>=a && back<=b){
                //System.out.println("front" + front + " is greater than  or equal to " + a + " is " + (front>=a));
                //System.out.println("back" + back + " is less than  or equal to " + b + " is " + (back>=a));
                c++;
            }
        }
        System.out.println(c);
    }
}