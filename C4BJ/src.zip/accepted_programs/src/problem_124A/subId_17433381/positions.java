package problem_124A.subId_17433381;

import java.util.Scanner;


public class positions {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int x=sc.nextInt();
	int y=sc.nextInt();
	int z=sc.nextInt();
	if(x<=(y+z))
	{
		System.out.println(x-y);
	}
	else
	{
		System.out.println(z+1);
	}
}
}