package problem_124A.subId_19626611;

import java.util.Scanner;


public class TheNumberOfPositions
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int a = sc.nextInt();
		int b = sc.nextInt();
		System.out.println(n - Math.max(a+1, n-b) + 1);
	}
}