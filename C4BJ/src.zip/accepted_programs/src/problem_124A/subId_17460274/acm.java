package problem_124A.subId_17460274;

import java.util.Scanner;
public class acm {
	public static void main(String[]args)
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int a = sc.nextInt();
		int b = sc.nextInt();
		while(!(a+b>=n-1))
			n--;
		System.out.println(n-a);
	}
	
}