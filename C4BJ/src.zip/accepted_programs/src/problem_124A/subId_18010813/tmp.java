package problem_124A.subId_18010813;

/**
 *
 * @author Faruk
 */

import java.util.Scanner;


public class tmp {
    public static void main(String [] args){
        Scanner scan = new Scanner(System.in);

        int n = scan.nextInt();
        int a = scan.nextInt();
        int b = scan.nextInt();
        
        System.out.println( (b+1 <= n-a ? b+1 : n-a));

        
        
        
        






        
        
        
        
    }
    

}