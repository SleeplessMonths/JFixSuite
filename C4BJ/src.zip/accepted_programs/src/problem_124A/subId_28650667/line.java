package problem_124A.subId_28650667;

import java.util.Scanner;

public class line {

	public static void main(String[] args) {
		int n, a, b;
		Scanner s = new Scanner(System.in);
		int count = 0;

		n = s.nextInt();
		a = s.nextInt();
		b = s.nextInt();



		if(n-a<=b)
		{
			
			count=n-a;
		}
		else
		{
			count=b+1;
		}
		
		
			
		

		System.out.println(count);

		s.close();

	}

}