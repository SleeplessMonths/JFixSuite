package problem_124A.subId_23404184;

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner in =new Scanner (System.in);
        int n,b,c;
        n=in.nextInt();
        b=in.nextInt();
        c=in.nextInt();
        System.out.println(Math.min(n-b, c+1));
                
    }
}