package problem_124A.subId_29418765;

import java.util.Scanner;

public class NoOfPos {
    public static int no(int n, int w, int o)
    {int c=0;
    	for(int i=1;i<=n;i++) {
    	if(i-1<=w && n-i>=o) {c++;}	
    	}return c;
    }
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	int o=sc.nextInt();
	int w=sc.nextInt();
	System.out.println(no(n,w,o));
	}

}