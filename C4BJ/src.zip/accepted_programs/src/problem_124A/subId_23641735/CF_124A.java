package problem_124A.subId_23641735;

import java.io.*;
import java.text.DecimalFormat;
import java.util.Random;
import java.util.StringTokenizer;

public class CF_124A {
	public static void main(String[] args) {
		new CF_124A().run();
	}
	public void run(){
		FastScanner sc = new FastScanner(System.in);
		PrintWriter out = new PrintWriter(System.out);
		
		int n = sc.nextInt();
		int a = sc.nextInt();
		int b = sc.nextInt();
		out.println(Math.min(n-a, b+1));
		out.close();
	}
}

class FastScanner {
	public BufferedReader br;
	public StringTokenizer st;

	public FastScanner(InputStream in) {
		br = new BufferedReader(new InputStreamReader(in));
		st = null;
	}

	public boolean hasMoreTokens() {
		while (st == null || !st.hasMoreTokens()) {
			String line = null;
			try {
				line = br.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (line == null)
				return false;
			st = new StringTokenizer(line);
		}
		return true;
	}

	public String next() {
		if (!hasMoreTokens())
			return null;
		return st.nextToken();
	}

	public char nextChar(){
		try {
			return (char) br.read();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return 0;
	}
	public String nextLine(){
		try {
			return br.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	public int nextInt() {
		return Integer.parseInt(next());
	}

	public long nextLong() {
		return Long.parseLong(next());
	}

	//读一个int类型的数组
	public int[] readIntArray(int n) {
		int[] array = new int[n];
		for (int i = 0; i < n; i++) {
			array[i] = nextInt();
		}
		return array;
	}

	//读一个long数组
	public long[] readLongArray(int n) {
		long[] array = new long[n];
		for (int i = 0; i < n; i++) {
			array[i] = nextLong();
		}
		return array;
	}

	//读一个字符串数组
	public String[] readStringArray(int n) {
		String[] a = new String[n];
		for (int i = 0; i < n; i++) {
			a[i] = next();
		}
		return a;
	}

	//打乱一个数组，便于排序
	public void shuffleIntArray(int[] a) {
		Random rand = new Random();
		for (int i = 0; i < a.length; i++) {
			int x = rand.nextInt(i + 1); // 0~i
			int t = a[i];
			a[i] = a[x];
			a[x] = t;
		}
	}

	// 只适合比较小的数，太大的数会越界
	public long factorial(long n) {
		if (n == 0)
			return 1L;
		long res = 1;
		for (long i = 2; i <= n; i++) {
			res *= i;
		}
		return res;
	}

	// 只适合比较小的数，太大的数会越界
	public long combination(long mom, long son) {
		return factorial(mom) / (factorial(son) * factorial(mom - son));
	}

	//求最小公倍数
	public long gcd(long a, long b) {
		return b == 0 ? a : gcd(b, a % b);
	}

	//求最大公约数
	public long lcm(long a, long b) {
		return a * b / (gcd(a, b));
	}

	//格式化double类型的数
	public String format(String pattern, double d) {
		DecimalFormat df = new DecimalFormat(pattern);
		return df.format(d);
	}

	//判断一个数是否是2的指数
	public boolean isPowerOfTwo(long v) {
		return (v & (v - 1)) == 0;
	}
	
	public void outputIntArray(PrintWriter out, int[] a){
		for(int i = 0;i<a.length-1;i++)
			out.print(a[i] + " ");
		out.println(a[a.length-1]);
	}
}