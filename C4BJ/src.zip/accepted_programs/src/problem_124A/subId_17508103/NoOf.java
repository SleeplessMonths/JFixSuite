package problem_124A.subId_17508103;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class NoOf {
	public static void main(String[] args) throws IOException {
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st=new StringTokenizer(bf.readLine());
		int n=Integer.parseInt(st.nextToken());
		int a=Integer.parseInt(st.nextToken());
		int b=Integer.parseInt(st.nextToken());
		if(n==1 || n==0)
			System.out.println(n);
		else if(b+a<n){//chekc this example 9 4 3
			System.out.println(b+1);
			
		}
		else{
			System.out.println(n-a);
		}
		
			

	}

}