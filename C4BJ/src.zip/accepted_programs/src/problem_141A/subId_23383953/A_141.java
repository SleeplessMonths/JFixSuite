package problem_141A.subId_23383953;

import java.util.Arrays;
import java.util.Scanner;

public class A_141 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		char[] mena = (s.nextLine() + s.nextLine()).toCharArray();
		char[] spolu = s.nextLine().toCharArray();
		Arrays.sort(mena);
		Arrays.sort(spolu);
		System.out.println(Arrays.equals(mena, spolu) ? "YES" : "NO");
	}
}