package problem_141A.subId_29415779;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Joke
{
	public static void main(String [] args)
	{
		Scanner sc = new Scanner(System.in);
		PrintWriter out = new PrintWriter(System.out);
		List<Character> list = new ArrayList<>();
		int n = 2 ;
		String s = "" ;
		while( n-->0 )
		{
			s = sc.next();
			for ( int i = 0 ; i < s.length() ; i++ ) 
			{
				list.add( s.charAt(i) );
			}
		}

                char [] c = sc.next().toCharArray();
                if( list.size() != c.length )
                {
                    out.println( "NO" );
                    sc.close();
                    out.close();
                }
                else
                {
                    for ( int i = 0 ; i < c.length ; i++ )
                    {
                        if( list.contains( c[i] ) )
                        {
                            list.remove( list.indexOf( c[i] ) );
                        }
                    }
                
                    out.println( list.isEmpty() ? "YES" : "NO" );
                    sc.close();
                    out.close();
                }
	}
}