package problem_141A.subId_22086482;

import java.util.Scanner;

public class AmusingJoke{
    
    public static void main(String args[]){
        Scanner scan = new Scanner(System.in);
        int [] map = new int[26];
        
        String names = scan.next();
        names += scan.next();
        
        String scramble = scan.next();
        
        for(char c : names.toCharArray()){
           map[c-'A']++;
        }
        
        for(char c : scramble.toCharArray()){
            map[c-'A']--;
        }
        
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        
        for(int i : map){
            min = Math.min(i, min);
            max = Math.max(i, max);
        }
        if(max > 0 || min < 0){
            System.out.println("NO");
        }else{
            System.out.println("YES");
        }
    }
}