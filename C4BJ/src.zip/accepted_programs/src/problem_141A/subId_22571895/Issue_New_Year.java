package problem_141A.subId_22571895;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;

/**
 * Created by Alina on 17.11.2016.
 */
public class Issue_New_Year {

    private static void calculate() {

        Scanner in = new Scanner(System.in);
        PrintWriter out = new PrintWriter(System.out);

        char [] first = (in.next() + in.next()).toCharArray();
        char [] second = (in.next()).toCharArray();
        Map<String, Integer> firstPairs = new HashMap<>();
        Map<String, Integer> secondPairs = new HashMap<>();

        for (char c : first){
            String key = Character.toString(c);
            Integer value =  firstPairs.get(key);
            value = null == value? 1 : value + 1;
            firstPairs.put(key, value);
        }

        for (char c : second){
            String key = Character.toString(c);
            Integer value =  secondPairs.get(key);
            value = null == value? 1 : value + 1;
            secondPairs.put(key, value);
        }

        for (char c : first){
            if (firstPairs.entrySet().size() != secondPairs.entrySet().size()){
                System.out.println("NO");
                return;
            }
            Integer secondValue = secondPairs.get(Character.toString(c));
            if (null == secondValue) {
                System.out.println("NO");
                return;
            }
           if (!Objects.equals(firstPairs.get(Character.toString(c)), secondValue)) {
               System.out.println("NO");
               return;
           }

        }

        System.out.println("YES");
        in.close();
        out.flush();
        out.close();

    }

    public static void main(String args[]) throws IOException {
        calculate();
    }

}