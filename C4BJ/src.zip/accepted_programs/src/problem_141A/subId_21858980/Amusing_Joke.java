package problem_141A.subId_21858980;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Amusing_Joke
{
   static StringTokenizer st;
    static BufferedReader in;

    private static int nextInt() throws IOException 
    {
        return Integer.parseInt(next());
    }

    private static long nextLong() throws IOException 
    {
        return Long.parseLong(next());
    }

    private static byte nextByte() throws IOException 
    {
        return Byte.parseByte(next());
    }
  
    private static String next() throws IOException 
    {
        while (st == null || !st.hasMoreTokens()) 
        {
            st = new StringTokenizer(in.readLine());
        }
        return st.nextToken();
    }
    public static void main(String[] args) throws IOException
    {
     in = new BufferedReader(new InputStreamReader(System.in));

     String st1=next();
     String st2=next();
     String st=st1+st2;
     String st3=next();

     char ar1[]=st.toCharArray();
     char ar2[]=st3.toCharArray();
     
     Arrays.sort(ar1);
     Arrays.sort(ar2);
     
     st = new String(ar1);
     st3 = new String(ar2);
         
     
     
     if (st3.equals(st))
     {
         System.out.println("YES");
     }
     else
     {
         System.out.println("NO");
     }
     
     
     
     
    }
}