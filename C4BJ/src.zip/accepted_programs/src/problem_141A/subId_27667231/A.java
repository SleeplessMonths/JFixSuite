package problem_141A.subId_27667231;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;


public class A{
     
 public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
      String host = in.next();
      String guest = in.next();
      String combine = in.next();
      in.close();
      
        Map <String, Integer> hm = new HashMap<String, Integer>();
       Map <String, Integer> combineHm = new HashMap<String, Integer>();
      
    
       String temp ="";
     
       if( (host.length() + guest.length()) != combine.length()){
            System.out.println("NO");
            return;
        }
       else{
            for(int i = 0; i < host.length(); i++){
                temp = host.substring(i,i+1);
                if(hm.containsKey(temp)){
                    hm.put(temp, hm.get(temp) + 1);
                }
                else{
                    hm.put(temp,1);
                }
            }
            for(int i = 0; i < guest.length(); i++){
                temp = guest.substring(i,i+1);
                if(hm.containsKey(temp)){
                    hm.put(temp, hm.get(temp) + 1);
                }
                else{
                    hm.put(temp,1);
                }
            }
        }
        
        
         for(int i = 0; i < combine.length(); i++){
                temp = combine.substring(i,i+1);
                if(combineHm.containsKey(temp)){
                    combineHm.put(temp, combineHm.get(temp) + 1);
                }
                else{
                    combineHm.put(temp,1);
                }
            }
     
     Iterator<Entry<String,Integer>> hmIterator = hm.entrySet().iterator();
     
     Iterator<Entry<String,Integer>> combineIterator = combineHm.entrySet().iterator();
     boolean same = true;
     while(hmIterator.hasNext() && combineIterator.hasNext()){
         Map.Entry<String,Integer> entryHmEntry = (Map.Entry<String, Integer>) hmIterator.next();
         Map.Entry<String, Integer> combineHmEntry = (Map.Entry<String, Integer>) combineIterator.next();
         
         if(entryHmEntry.getValue()!=combineHmEntry.getValue()) {
             //|| entryHmEntry.getKey()!=combineHmEntry.getKey()
             //entryHmEntry.getValue()!=combineHmEntry.getValue()
            // System.out.println(entryHmEntry.getKey() + " " + combineHmEntry.getKey() + " " + entryHmEntry.getValue()  + " " + combineHmEntry.getValue()  );
             same = false;
             continue;
         }
     }
     
     if(hmIterator.hasNext() || combineIterator.hasNext()){
         same = false;
     }
     else;
     
     
     
     if(same){
         System.out.println("YES");
     }
     else{
         System.out.println("NO");
     }
     
  //   combineHm.forEach((k,v) -> System.out.print("combinehm key : " + k + " value " + v));
   //  hm.forEach((k,v)->System.out.println("hm key : " + k + " value " + v));
                       
    
 }
    
}