package problem_141A.subId_23620529;

import java.util.Scanner;

public class a141{
    public static void main(String[] args){
         Scanner sc = new Scanner(System.in);
         String s = sc.nextLine() +  sc.nextLine(), p= sc.nextLine();
         boolean[] m = new boolean[s.length()];
         for( int i=0; i<p.length(); i++ )
             for( int j=0; j<s.length(); j++)
                 if(!m[j] && p.charAt(i)==s.charAt(j)){
                     m[j]=true;
                     break;
                 }
         for( int i=0; i<s.length(); i++)
             if(!m[i] || p.length() > s.length()){
                 System.out.println("NO");
                 return;
             }
        System.out.println("YES");
    }
}