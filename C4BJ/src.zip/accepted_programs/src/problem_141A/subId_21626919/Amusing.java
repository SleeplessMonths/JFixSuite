package problem_141A.subId_21626919;

import java.util.Arrays;
import java.util.Scanner;
public class Amusing
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner (System.in);
		String s1=sc.next();
		String s=sc.next();
		s=s.concat(s1);
		//System.out.println(s);
	    String s2=sc.next();
        char ar[]=s.toCharArray();
		Arrays.sort(ar);
		char a[]=s2.toCharArray();
		Arrays.sort(a);
		int a1=s2.length();
		int b=s.length();
		int count=0;
			if(a1<b || b<a1)
			{
				System.out.println("NO");
			}
			else
			{
		for(int i=0;i<s.length();i++)
		{
			if(a[i]!=ar[i])
			{
				count=1;
				break;
			}
		}
		if(count==0)
		{
			System.out.println("YES");
		}
		else
		{
			System.out.println("NO");
		}
		}
	}
}