package problem_141A.subId_24446238;

import java.util.Scanner;

public class AmusingJoke {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String first = input.nextLine().trim();
		String second = input.nextLine().trim();
		String comb = input.nextLine().trim();
		input.close();
		int[] a = new int[26];
		int[] b = new int[26];
		int x = first.length() + second.length();
		if(comb.length() > x){
			x = comb.length();
		}
		for (int i = 0; i < x; i++) {
			char ch;
			if (i < first.length()) {
				ch = first.charAt(i);
				a[(int) (ch) - 65]++;
			}
			if (i < second.length()) {
				ch = second.charAt(i);
				a[(int) (ch) - 65]++;
			}
			if (i < comb.length()) {
				ch = comb.charAt(i);
				b[(int) (ch) - 65]++;
			}
		}
		boolean check = true ;
		for(int i = 0 ; i <a.length ; i++){
			if(a[i] != b[i]){
				check = false ;
				break ;
			}
		}
		System.out.println(check ?"YES" : "NO");
	}

}