package problem_141A.subId_24887007;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Lab1250
 */
public class Bashar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Map<Character, Integer> f = new HashMap<>();
        Scanner sc = new Scanner(System.in);
        String s1 = sc.next();
        String s2 = sc.next();
        String pile = sc.next();
        String str = s1+s2;
        
        for(char c : str.toCharArray()){
           
            if(f.containsKey(c)){
                f.put(c, f.get(c)+1);
                
            }else{
                f.put(c, 1);
            }
            
        }
        boolean can = true;
        for(char c : pile.toCharArray()){
            
            if(!f.containsKey(c) || f.get(c) == 0){
                can = false;
                break;
            }else{
                f.put(c, f.get(c) - 1 );
            }
            
        }
        
        for(Integer i : f.values()){
            if(i != 0){
                can = false;
                break;
            }
                
        }
        
        System.out.println(can ? "YES" : "NO");
        
    }
    
}