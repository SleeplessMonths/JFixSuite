package problem_141A.subId_21550427;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class amusingjoke {
   public static int repeated(String s, char c){
	   int sum =0;
	   for (int i=0;i<s.length();i++){
		   if (s.charAt(i)==c)
			   sum++;
	   } return sum;
   }
   public static void main (String[]args) throws IOException{
       BufferedReader br = new BufferedReader( new InputStreamReader(System.in));
     boolean flag = true;
     String s1 = br.readLine();
     String s2 = br.readLine();
     String mix = br.readLine();
     for (int i =0;i<mix.length();i++){
    	 if (repeated(mix, mix.charAt(i)) != repeated(s1,mix.charAt(i))+repeated(s2,mix.charAt(i)) || mix.length()!= s1.length() + s2.length()){
    			 flag = false; break;}
    	 
     }
     if (flag)
    	 System.out.println("YES");
     else
    	 System.out.println("NO");

       
   }
}