package problem_141A.subId_26790583;

import java.util.Arrays;
import java.util.Scanner;


public class JavaApplication62 {

    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s1,s2,s3,s4;
        s1=sc.next();
        s2=sc.next();
        s3=sc.next();
        s4=s1+s2;
        int n=0;
        char ara1[]=new char[s3.length()];
        char ara2[]=new char[s3.length()];
        if(s4.length()==s3.length()){
            for(int i=0;i<s3.length();i++){
              ara1[i]=s3.charAt(i);
            }
            for(int i=0;i<s3.length();i++){
              ara2[i]=s4.charAt(i);
            }
            Arrays.sort(ara1);
            Arrays.sort(ara2);
            for(int i=0;i<s3.length();i++){
                if(ara1[i]==ara2[i]){
                   n=n+1; 
                }
            }
            if(n==s3.length()){
                System.out.println("YES");
            }
            else{
                System.out.println("NO");
            }
        }
        else{
            System.out.println("NO");
        }
    }
    
}