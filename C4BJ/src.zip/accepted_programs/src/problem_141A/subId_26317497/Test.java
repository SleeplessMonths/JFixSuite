package problem_141A.subId_26317497;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Test{
 
public static void main(String[] args) throws IOException{
    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
    String host=br.readLine();
    String guest=br.readLine();
    String floor=br.readLine();
    int[]set=new int[26];
    for(int i=0;i<host.length();i++){
    	char c=host.charAt(i);
    	set[c-'A']++;
    }
    for(int i=0;i<guest.length();i++){
    	char c=guest.charAt(i);
    	set[c-'A']++;
    }
    String res="YES";
    if(host.length()+guest.length()!=floor.length()){
    	res="NO";
    }
    for(int i=0;i<floor.length();i++){
    	char c=floor.charAt(i);
    	set[c-'A']--;
    	if(set[c-'A']==-1){
    		res="NO";
    	}
    }
    System.out.println(res);
}
}