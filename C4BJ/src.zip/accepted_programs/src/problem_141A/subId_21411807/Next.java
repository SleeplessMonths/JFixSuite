package problem_141A.subId_21411807;

import java.util.Scanner;
public class Next
{
	public static void main(String args[]) throws Exception
	{
		int g,h,k=0;
		Scanner sc = new Scanner(System.in);
		int a[] = new int[26];
		int[] b = new int[26];
        String s= sc.nextLine();
		s=s+sc.nextLine();
		int l=s.length();
		String s1 = sc.nextLine();
		int l1=s1.length();
		for(int i=0;i<l;i++)
		{
			g=(int)s.charAt(i)-65;
			a[g]++;
		}		
         for(int i=0;i<l1;i++)
		{
			h=(int)s1.charAt(i)-65;
			b[h]++;
		}
		for(int i=0;i<26;i++)
		{
			if(a[i]==b[i])
			{
				k++;
			}
		}
		if(k==26)
		{
			System.out.print("YES");
		}
		else
		{
			System.out.print("NO");
		}
	}
}