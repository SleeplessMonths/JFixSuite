package problem_139A.subId_21232028;

import java.util.Scanner;
public class petr
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int arr[]=new int[7];
		for(int j = 0;j<arr.length;j++)
			arr[j]=sc.nextInt();
		int counter=0;
		int i = 0;
		while(n>0)
		{
			n-=arr[i%7];
			i++;
			counter++;
		}
		if(counter==7)
			System.out.println(7);
		else if(counter%7==0)
			System.out.println(7);
		else

		System.out.println(counter%7);
	}
}