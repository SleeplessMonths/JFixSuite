package problem_139A.subId_10700035;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class petrlib{
public static void main(String args[]) throws IOException{
BufferedReader lector = new BufferedReader(new InputStreamReader(System.in));
int tmp = Integer.parseInt(lector.readLine());
int acum = 0;
int n = 0;
String tt[] = lector.readLine().split(" ");
int t[] = new int[7];
for(n = 0;n<t.length;n++)
t[n]=Integer.parseInt(tt[n]);
for(n = 0;acum<=tmp;n++){
if(acum<tmp && acum+t[n%7]>=tmp){
System.out.println(n%7+1);
return;
}
acum+=t[n%7];
}
//System.out.println((n+6)%7+1);
}
}