package problem_139A.subId_18705971;

import java.util.Scanner;

public class pe {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	sc.nextLine();
	int a[]=new int[7];
	for(int i=0;i<7;i++)
	{
		a[i]=sc.nextInt();
	}
	int x,p=0;
	int s=0;
		for( x=0;x<n;x++)
		{int y;
			for(y=0;y<7;y++)
			{
			s=s+a[y];
			if(s>=n)
				break;
			}
			if(y!=7)
			{
				p=y;
				break;
				
			}
		}
		System.out.println(p+1);
		
	}
}