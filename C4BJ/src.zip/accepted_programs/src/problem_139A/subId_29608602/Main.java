package problem_139A.subId_29608602;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Main {

    public static void main(String[] args) throws IOException {
        Reader.init(System.in);
        int n = Reader.nextInt();

        int[] days = new int[7];

        for (int i = 0; i < days.length; i++) {
            days[i] = Reader.nextInt();
        }

        int day = 0;
        int booksRead = 0;

        while (booksRead < n){
            booksRead += days[day];
            day = (day + 1) % 7;
        }

        System.out.println(day == 0 ? 7:day);
    }
}

class Reader{
    private static BufferedReader reader;
    private static StringTokenizer tokenizer;
    static void init(InputStream inputStream){
        reader = new BufferedReader(new InputStreamReader(inputStream));
        tokenizer = new StringTokenizer("");
    }
    static String next() throws IOException {
        String read;
        while (!tokenizer.hasMoreTokens()){
            read = reader.readLine();
            if (read == null || read.equals(""))
                return "-1";
            tokenizer = new StringTokenizer(read);
        }

        return tokenizer.nextToken();
    }
    static int nextInt() throws IOException{
        return Integer.parseInt(next());
    }

    static long nextLong() throws IOException{
        return Long.parseLong(next());
    }

    //Get a whole line.
//    static String line() throws IOException{
//        return reader.readLine();
//    }
//
//    static double nextDouble() throws IOException{return Double.parseDouble(next());}
}