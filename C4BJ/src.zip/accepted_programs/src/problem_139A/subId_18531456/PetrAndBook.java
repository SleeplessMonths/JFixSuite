package problem_139A.subId_18531456;

import java.util.Scanner;

public class PetrAndBook {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int[] days = new int[7];
		int n = scan.nextInt();
		for(int i = 0; i < 7; i++){
			days[i] = scan.nextInt();
		}
		int c = 0;
		int i = 0;
		while(c < n){
			c += days[i];
			i++;
			if(i == 7){
				i = 0;
			}
		}
		if(i == 0){
			i = 7;
		}
		System.out.println(i);
	}
}