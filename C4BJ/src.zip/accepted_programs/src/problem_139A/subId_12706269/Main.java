package problem_139A.subId_12706269;

import java.util.Scanner;

public class Main {
    
    public static void main(String[]args){
        
        Scanner in = new Scanner(System.in);
        
        int n = in.nextInt();
        
        int[]a = new int[7];
        for(int i=0 ; i<7 ; i++)
            a[i] = in.nextInt();
        
        int cnt=0 , index=0;
        while(n > 0){
            
            n -= a[index++];
            cnt++;
            if(index == 7 && cnt == 7 && n > 0){
                index=0;
                cnt = 0;
           }
            
        }
        
        System.out.println(cnt);
        
        }
    }