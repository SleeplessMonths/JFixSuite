package problem_139A.subId_27575427;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PetrAndBook {
	public static void main(String[] args) throws IOException {
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(buff.readLine());
		String[] line = buff.readLine().split(" ");
		int[] days = new int[7];
		for (int i = 0; i < 7; i++) {
			days[i] = Integer.parseInt(line[i]);
		}
		int curDay = -1;
		while (n > 0) {
			curDay = (curDay + 1) % 7;
			n -= days[curDay];
		}
		System.out.println(curDay + 1);
	}
}