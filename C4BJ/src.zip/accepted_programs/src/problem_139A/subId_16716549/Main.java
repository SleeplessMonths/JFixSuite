package problem_139A.subId_16716549;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     
      Scanner scan=new Scanner(System.in);
      int x=scan.nextInt();
      int counter=0,sum=0;
      int[] arr={0,0,0,0,0,0,0};
      boolean check=true;
     for(int i=0;i<7;i++){
    	 
    	 arr[i]=scan.nextInt();
     }
     int i=0;
     while(check){
    	 if(arr[(i)%7]!=0){
    		 if(i%7==0){
    			 sum=0;
    		 }
    	 sum=(sum+1)%8;
    	 counter+=arr[i%7];
    	 if(counter>=x){
    		 break;
    	 }
    	 }
    	 i++;
     }
   
      System.out.println((i%7)+1);
	}

}