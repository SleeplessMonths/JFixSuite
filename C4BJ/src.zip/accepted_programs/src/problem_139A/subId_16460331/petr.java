package problem_139A.subId_16460331;

import java.util.Scanner;

public class petr{
	public static void main (String[] args){
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] arr = new int[7];
		for (int i = 0; i < 7; ++i){
			arr[i] = sc.nextInt();
		}
		while (n >= 0){
			for (int i = 0; i < 7; ++i){
				n -= arr[i];

				if (n <= 0){
					int temp = i + 1;
					System.out.println(temp);
					return;
				}
			}
		}
	}
}