package problem_139A.subId_23717897;

import java.util.Scanner;

public class editable {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int pages = scan.nextInt();
		int[] days = new int[7];
		for(int i = 0; i < days.length; i++)
			days[i] = scan.nextInt();
		int a = 0;
		while(pages > 0) {
			pages -= days[a];
			a++;
			if(a == 7)
				a = 0;
		}
		System.out.println(a == 0 ? 7 : a);
	}
}