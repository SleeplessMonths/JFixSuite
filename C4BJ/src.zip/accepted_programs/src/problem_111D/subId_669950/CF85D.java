package problem_111D.subId_669950;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.util.StringTokenizer;

/**
 * Author -
 * User: kansal
 * Date: 9/5/11
 * Time: 10:45 PM
 */
public class CF85D {
    public static void main(String[] args) {
        reader = new BufferedReader(new InputStreamReader(System.in));

        final int MOD = 1000000007;
        int height = nextInt(), width = nextInt(), K = nextInt();

        if(width == 1) {
            System.out.println(fastPow(K, height, MOD));
            return;
        }

        int[][] dp = new int[height + 1][height + 1];
        calcWays(dp, MOD);

        fact = new int[K + 1];
        inv = new int[K + 1];

        fact[0] = 1;
        inv[0] = 1;
        for(int i = 1; i <= K; ++i) {
            fact[i] = (int)((1L * i * fact[i-1]) % MOD);
            inv[i] = BigInteger.valueOf(fact[i]).modInverse(BigInteger.valueOf(MOD)).intValue();
        }

        int res = 0;
        for(int diff = 0; diff <= Math.min(K, height); ++diff) {
            for(int common = 0; diff + common <= Math.min(K, height); ++common) {
                if (diff + common == 0) continue;
                if (2 * diff + common > K) continue;

                int totColors = 2 * diff + common;
                int eachCol = diff + common;

                long a = choose(K, totColors, MOD);
                long b = choose(totColors, common, MOD);
                long c = choose(2 * diff, diff, MOD);
                long d = (1L * dp[height][eachCol] * dp[height][eachCol]) % MOD;
                long e = fastPow(common, (width - 2) * height, MOD);

                res = (int)((res + (((((((a * b) % MOD) * c) % MOD) * d) % MOD) * e) % MOD) % MOD);
            }
        }

        System.out.println(res);
    }

    private static int fastPow(int b, int e, int MOD) {
        if (e == 0) return 1;
        int t = fastPow(b, e/2, MOD);
        if (e % 2 == 0) {
            return (int)((1L * t * t) % MOD);
        }
        else {
            return (int)((((1L * b * t) % MOD) * t) % MOD);
        }
    }

    private static void calcWays(int[][] dp, int MOD) {
        int n = dp.length;
        dp[0][0] = 1;
        for(int i = 1; i < n; ++i) {
            for(int j = 1; j <= i; ++j) {
                dp[i][j] = (int)((1L * j * (dp[i-1][j-1] + dp[i-1][j]) % MOD) % MOD);
            }
        }
    }

    static int[] fact, inv;
    private static int choose(int n, int k, int MOD) {
        if (k > n) return 0;
        int res = fact[n];
        res = (int)((1L * res * inv[n-k]) % MOD);
        res = (int)((1L * res * inv[k]) % MOD);
        return res;
    }

    public static BufferedReader reader;

    public static StringTokenizer tokenizer = null;

    static String nextToken() {
        while (tokenizer == null || !tokenizer.hasMoreTokens()) {
            try {
                tokenizer = new StringTokenizer(reader.readLine());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return tokenizer.nextToken();
    }

    static public int nextInt() {
        return Integer.parseInt(nextToken());
    }

    static public long nextLong() {
        return Long.parseLong(nextToken());
    }

    static public String next() {
        return nextToken();
    }

    static public String nextLine() {
        try {
            return reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}