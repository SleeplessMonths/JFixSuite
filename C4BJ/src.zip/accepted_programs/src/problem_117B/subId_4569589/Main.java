package problem_117B.subId_4569589;

import java.util.Arrays;
import java.util.Scanner;
public class Main {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();
        int b = scan.nextInt();
        int mod = scan.nextInt();
        int modMax = Math.min(mod-1, b);
        int unit = 1000000000%mod;
        boolean[] found = new boolean[10000000+10];
        int ans = -1;
        int cur = 0;
        //px(modMax,unit);
        for (int i = 1; i <= Math.min(a, 10000000+10);i++){
            cur += unit;
            cur %= mod;
            if (found[cur]) break;
            found[cur] = true;
            int conj = mod - cur;
            conj %= mod;
            if (conj>modMax){
                ans = i;
                break;
            }
            //px(conj,cur);
        }
        if (ans == -1){
            System.out.println(2);
        }
        else {
            System.out.println(1+" "+String.format("%9d", ans).replace(' ', '0'));
        }
    }
    static void px(Object ...  l1){
        System.out.println(Arrays.deepToString(l1));
    }
}