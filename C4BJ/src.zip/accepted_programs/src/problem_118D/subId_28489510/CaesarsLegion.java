package problem_118D.subId_28489510;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CaesarsLegion {
  private static int mod = 100000000;

  public static void main(String[] args) throws IOException {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    String[] line = br.readLine().split(" ");
    int foot = Integer.parseInt(line[0]); 
    int horse = Integer.parseInt(line[1]);
    int maxfoot = Integer.parseInt(line[2]);
    int maxhorse = Integer.parseInt(line[3]);
    
    System.out.println(arrange(foot, horse, maxfoot, maxhorse));
  }

  static int arrange(int foot, int horse, int maxfoot, int maxhorse) {
    int[][][] ways = new int[foot + 1][horse + 1][2];
    
    ways[foot][horse][0] = 1;
    ways[foot][horse][1] = 1;
    
    for (int i = foot; i >= 0; i--) {
      for (int j = horse; j >= 0; j--) {
        // repartir horse
        for (int j2 = 1; j2 <= maxhorse && j2 <= j; j2++) {
          ways[i][j - j2][0] += ways[i][j][1];
          ways[i][j - j2][0] %= mod ;
        }
        // repartir foot
        for (int i2 = 1; i2 <= maxfoot && i2 <= i; i2++) {
          ways[i - i2][j][1] += ways[i][j][0];
          ways[i - i2][j][1] %= mod;
        }
      }
    }
    
    return (ways[0][0][0] + ways[0][0][1]) % mod;
  }
}