package problem_143B.subId_10981850;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Stack;

public class Main {

    public static void main(String[] args) throws Exception{
        BufferedReader inp = new BufferedReader(new InputStreamReader(System.in));
        Stack<Character> stack = new Stack<Character>();
        String s = inp.readLine();
        boolean hasMinus = s.charAt(0) == '-' ? true : false;
        
        if(hasMinus)
            stack.push(')');
        int p = s.length(); 
        for(int i = s.length() - 1; i >= 0; i--){
            if(s.charAt(i) == '.')
                if(s.length() - 1 - i >= 2){
                    stack.push(s.charAt(i+2));
                    stack.push(s.charAt(i+1));
                    stack.push(s.charAt(i));
                    p = i;
                    break;
                }
                else{
                    stack.push('0');
                    stack.push(s.charAt(i+1));
                    stack.push(s.charAt(i));
                    p = i;
                    break;
                }
        }
        if(p == s.length()){
            stack.push('0');
            stack.push('0');
            stack.push('.');
        }
        
        int count = 0;
        
        for(int i = p - 1; i >= 0; i--){
            if(hasMinus){
                if(i == 1){
                    stack.push(s.charAt(i));
                    break;
                }
            }
            else{
                if(i == 0){
                    stack.push(s.charAt(i));
                    break;
                }
            }
            count++;
            stack.push(s.charAt(i));
            if(count == 3){
                stack.push(',');
                count = 0;
            }
                
        }
        stack.push('$');
        if(hasMinus)
            stack.push('(');
        
        while(!stack.isEmpty()){
            System.out.print(stack.pop());
        }
    }

}