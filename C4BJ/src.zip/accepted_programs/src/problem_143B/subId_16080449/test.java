package problem_143B.subId_16080449;

import java.util.Scanner;

public class test {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
                String s1 = in.nextLine();
                String brackets1 = "";
                String brackets2 = "";
                String point ="";
                int l1 =  s1.length();
                
                if(s1.charAt(0) == '-')
                {   brackets1 ="(";
                    brackets2 =")";
                    s1= s1.substring(1,l1);
                    l1--;}
                
               
                s1 = s1.replaceAll("^0+", "0");
                l1=s1.length();
                int ind =  s1.indexOf(".");
                if(ind == -1)
                    point = ".00";
                else{
                    if(ind <= l1-3)
                        point = s1.substring(ind,ind+3);
                    else
                        point = "."+s1.charAt(ind+1)+"0";
                }
                
               
                
                
                
                if(ind!=-1){
                s1 = s1.substring(0,ind);
                l1=s1.length();
                }
                
                
                
                String aux="";
                int len=0;
                
                if(l1>3){ 
                String s1_rev = new StringBuilder(s1).reverse().toString();
                len = s1_rev.length() - s1_rev.replaceAll("[0-9]{3}", "").length();                
                for(int i=0; i<len;i+=3){
                    aux+=s1_rev.substring(i,i+3)+",";
                }
                aux = new StringBuilder(aux).reverse().toString();
                }
                if(!aux.isEmpty() && aux.charAt(0) == ',' && len==s1.length())
                    aux= aux.substring(1,aux.length());
                
               
                if(len!=0 && l1-len != 0)
                s1 = s1.substring(0,l1-len);
                else if(!aux.isEmpty())
                    s1="";
                
                System.out.println(brackets1+"$"+s1+aux+point+brackets2);
                    
	}
}