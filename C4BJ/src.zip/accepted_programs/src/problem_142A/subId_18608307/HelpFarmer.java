package problem_142A.subId_18608307;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class HelpFarmer
{
	final static long INF = (long) 1e11;
	public static void main(String[] args) throws NumberFormatException, IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		long n = Long.parseLong(br.readLine());
		long max = 0, min = INF;
		for (long x = 1; x*x*x <= n; x++)
		{
			if(n%x == 0)
			{
				for (long y = x; y*y <= n/x ; y++)
				{
					if(n%(x*y) == 0)
					{
						long z = (n / (x*y));
						long a1 = x + 1, b1 = y + 2, c1 = z + 2;
						long cur = a1*b1*c1 - n;
						if(cur > max)
							max = cur;
						if(cur < min)
							min = cur;
						long a2 = y + 1, b2 = x + 2, c2 = z + 2;
						long cur2 = a2*b2*c2 - n;
						if(cur2 > max)
							max = cur2;
						if(cur2 < min)
							min = cur;
						long a3 = z + 1, b3 = x + 2, c3 = y + 2;
						long cur3 = a3*b3*c3 - n;
						if(cur3 > max)
							max = cur3;
						if(cur3 < min)
							min = cur;
					}
				}
			}	
		}
		System.out.println(min +" "+ max);
	}
}