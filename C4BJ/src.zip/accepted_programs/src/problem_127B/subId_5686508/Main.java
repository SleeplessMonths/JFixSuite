package problem_127B.subId_5686508;

import java.io.*;
import java.util.Arrays;
import java.util.StringTokenizer;

/**
 * Built using CHelper plug-in
 * Actual solution is at the top
 * @author nasko
 */
public class Main {
	public static void main(String[] args) {
		InputStream inputStream = System.in;
		OutputStream outputStream = System.out;
		InputReader in = new InputReader(inputStream);
		PrintWriter out = new PrintWriter(outputStream);
		TaskB solver = new TaskB();
		solver.solve(1, in, out);
		out.close();
	}
}

class TaskB {

    public void solve(int testNumber, InputReader in, PrintWriter out) {

        int n = in.nextInt();

        int[] arr = new int[n];
        int[] cnt = new int[101];
        Arrays.fill(cnt,0);

        for(int i = 0; i < n; ++i) {

            arr[i] = in.nextInt();
            cnt[arr[i]]++;

        }

        int ret = 0;

        while(true) {
            boolean isFound = false;

            for(int i = 1; i <= 100; ++i) {

                for(int j = 1; j <= 100; ++j) {
                    if(i == j) continue;
                    if(cnt[i] >= 2 && cnt[j] >= 2) {
                        cnt[i] -=2;
                        cnt[j] -=2;
                        isFound = true;
                        ++ret;
                    }
                }
            }
            if(!isFound) break;
        }
        for(int i = 0; i <=100; ++i) {
            ret += cnt[i] / 4;
        }
        out.println(ret);


    }

}

class InputReader {
    public BufferedReader reader;
    public StringTokenizer tokenizer;

    public InputReader(InputStream stream) {
        reader = new BufferedReader(new InputStreamReader(stream));
        tokenizer = null;
    }

    public String next() {
        while (tokenizer == null || !tokenizer.hasMoreTokens()) {
            try {
                tokenizer = new StringTokenizer(reader.readLine());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return tokenizer.nextToken();
    }

    public int nextInt() {
        return Integer.parseInt(next());
    }

}