package problem_127B.subId_6382642;

import java.io.*;

public class Haha{
    public static void main(String[] args) throws IOException{
        BufferedReader s = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter ww = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
        int size = Integer.parseInt(s.readLine());
        int max = 110;
        int[] arr = new int[max];
        int res=0,cnt=0;
        String[] str = s.readLine().split(" ");
        for(int i=0;i<size;i++){
            arr[Integer.parseInt(str[i])]++;
        }
        for(int i=0;i<max;i++){
            if(arr[i]>=4){
                int re = arr[i]/4;
                res += re;
                cnt += (arr[i]-(re*4))/2;
            }
            else if(arr[i]>=2){
                cnt += arr[i]/2;
            }
        }
            ww.println(cnt/2+res);
            ww.close();
    }
}