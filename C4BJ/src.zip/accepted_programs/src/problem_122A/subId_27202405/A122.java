package problem_122A.subId_27202405;

/*
 * Made By Minh Sacred!
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import static java.lang.System.out;
/**
 *
 * @author minhl
 */
public class A122 {
    static boolean kt(String s) {
        int res =0;
        for (int i=0;i<s.length();i++) 
            if ((s.charAt(i) == '4') || (s.charAt(i) == '7'  )) res++;
        return res==s.length();
    }
    public static void main(String[] args) throws IOException {
        //FileInputStream inp = new FileInputStream("input.txt");
        //BufferedReader br=new BufferedReader(new InputStreamReader(inp));
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        String s =br.readLine();
        int n = Integer.parseInt(s);
            if ((n%7==0) || (n%47==0) || (n%4==0) || (kt(s))) out.print("YES");else out.print("NO");
    }          
}