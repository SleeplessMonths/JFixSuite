package problem_122A.subId_27750441;

import java.util.Scanner;

public class Lucky_Division {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		int tt = n;
		//先判斷是否由4和7組成
		boolean flag = lucky(n);
		if(!flag) {
			for(int i = 2; i*i <= n; i++) {
				if(n % i == 0 && (lucky(i) || lucky(n/i))) {
					System.out.println("YES");
					return;
				}
			}
			System.out.println("NO");
		} else {
			System.out.println("YES");
		}
	}
	public static boolean lucky(int n) {
		while(n > 0) {
			int temp = n %10 ;
			if(temp != 4 && temp != 7) {
				return false;
			}
			n = n /10;
		}
		return true;
	}
}