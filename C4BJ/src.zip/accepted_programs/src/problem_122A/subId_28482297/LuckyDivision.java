package problem_122A.subId_28482297;

import java.util.Scanner;
public class LuckyDivision{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        if(IsAlmostLucky(x))
            System.out.print("YES");
        else
            System.out.print("NO");
        
    }
    public static boolean IsAlmostLucky(int n){
        int[] lucky = {4, 44, 444, 47, 477, 474, 7, 77, 777, 74, 744, 747};
        int y = 0;
        for (int i: lucky){
            if (n % i == 0){
                y++;
                break;
            }
            else{
             
                continue;
            }
        }
        return y>0;
    }
}