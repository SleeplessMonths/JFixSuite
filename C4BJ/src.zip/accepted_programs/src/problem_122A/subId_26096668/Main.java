package problem_122A.subId_26096668;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    public static int arr[] = new int[1100];
    public static void main(String[] args) throws IOException {
        BufferedReader scan = new BufferedReader(new InputStreamReader(System.in));
        store();
        int n = Integer.parseInt(scan.readLine());
        if(arr[n]==1)
            System.out.println("YES");
        else
            System.out.println("NO");
    }
    public static void isAlmostLucky(int n){
        int r=0,copy=n;
        while(copy!=0){
            r = copy%10;
            copy = copy/10;
            if(r!=7 && r!=4){
                break;
            }
        }
        if(copy==0 && (r==7 || r==4))
            arr[n]=1;
        for(int i=4;arr[n]==0 && i<=(n/2);i++){
            if(arr[i]==1 && n%i==0){
                arr[n] = 1;
            }
        }
    }
    public static void store(){
        for(int i=4;i<1100;i++){
            isAlmostLucky(i);
        }
    }
    
}