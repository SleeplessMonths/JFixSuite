package problem_122A.subId_28723921;

import java.util.Scanner;

public class LuckyDivision {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		int  number = in.nextInt();
		String num = Integer.toString(number);
		boolean lucky = true;
		boolean divisible = false;
		char chars[] = num.toCharArray();
		if(number % 4 == 0 || number % 7 == 0 || number % 47 == 0 || number % 74 == 0) 
		{
			lucky = true;
			divisible = true;
		}
		
		if(!divisible)
		{
		for(int i = 0 ; i < chars.length ; i++){
			if(chars[i] != '4' && chars[i] != '7' )
			{
				System.out.println("NO");
				lucky = false;
				break;
			}
	}
		}
		if(lucky)
			System.out.println("YES");
		
	}
}