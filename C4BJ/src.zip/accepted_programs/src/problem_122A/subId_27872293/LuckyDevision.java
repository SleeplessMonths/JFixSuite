package problem_122A.subId_27872293;

import java.util.Scanner;

public class LuckyDevision {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		int n = scan.nextInt();
		boolean lucky[] = new boolean[1001];

		for (int i = 2; i <= 1000; i++) {

			if (!lucky[i]) {

				int j = i;

				w: while (j > 0) {

					if (j % 10 == 4 || j % 10 == 7)
						j /= 10;

					else {

						lucky[i] = false;
						break w;
					}
				}

				if (j == 0)
					lucky[i] = true;

				if (lucky[i])
					for (int k = 2; k * i <= 1000; k++)
						lucky[k * i] = true;

			}
		}

		if (lucky[n])
			System.out.println("YES");
		else
			System.out.println("NO");
		scan.close();
	}
}