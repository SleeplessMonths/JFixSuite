package problem_122A.subId_28892930;

import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(new InputStreamReader(System.in));
        String n = in.next();
        int count = 0;
        for (int i = 0; i < n.length(); i++) {
            if (n.charAt(i) == '4' || n.charAt(i) == '7') {
                count++;
            }
        }
        int parse = Integer.parseInt(n);
        if (count == n.length() || parse % 4 == 0 || parse % 7 == 0||parse % 47 == 0||parse % 744 == 0) {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        } 

    }

}