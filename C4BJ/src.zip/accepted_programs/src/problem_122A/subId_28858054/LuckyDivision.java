package problem_122A.subId_28858054;

import java.util.Scanner;
public class LuckyDivision {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
		String numb = in.next();
		int c = 0,c1 = 0,cx=0;
                int x = Integer.parseInt(numb);
                
		for (int i = 0; i < numb.length(); i++)
			if (numb.charAt(i) == '4' || numb.charAt(i) == '7')
				c++;
                
		String s = Integer.toString(c);
		
 		for (int i = 0; i < s.length(); i++)
			if (s.charAt(i) == '4' || s.charAt(i) == '7'|| s.charAt(i) == '2')
				c1++;
		
                if(x%7==0||x%4==0||x%74==0||x%47==0){
                    cx++;
                }
                int ci = Integer.parseInt(s);
                if (ci == numb.length()||cx>=1)
			System.out.println("YES");
		else
			System.out.println("NO");
    }
    
}