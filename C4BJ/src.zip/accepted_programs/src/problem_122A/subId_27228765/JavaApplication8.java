package problem_122A.subId_27228765;

import java.util.Scanner;
public class JavaApplication8 {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int num=s.nextInt();
        if(num%4==0 || num%7==0 || num%47==0)
            System.out.println("YES");
        else if (check_num(num))
            System.out.println("YES");
        else
            System.out.println("NO");
    }
    public static boolean check_num(int n){
        boolean flag=true;
        String str="";
        while(n>0){
            int dig=n%10;
            str+=dig;
            n/=10;
        }
        for (int i=0;i<str.length();i++)
            if(str.charAt(i)!='4' && str.charAt(i)!='7')
                flag=false;
        return flag;
    }
}