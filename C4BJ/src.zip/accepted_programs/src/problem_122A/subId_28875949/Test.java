package problem_122A.subId_28875949;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) 
	{
		String word,search;
		int n;
		Scanner in = new Scanner(System.in);
		n = in.nextInt();
		word = Integer.toString(n);
		int fcntr=0,scntr=0;
			
		 for(int i=0;i<word.length();i++)
		 {
			 if(word.charAt(i)== '4')
			 {
				 fcntr++;
			 }
			 if(word.charAt(i)=='7')
			 {
				 scntr++;
			 }
		 }
		 if(fcntr+scntr == word.length())
		 {
			 System.out.println("YES");
		 }
		 else
		 {
			 if(n%4==0 || n%7==0 || n%47==0 ||n%744==0)
			 {
				 System.out.println("YES");
			 }
			 else
			 {
				 System.out.println("NO");
		 }
		 
			 
			 
			 
		 }

}
}