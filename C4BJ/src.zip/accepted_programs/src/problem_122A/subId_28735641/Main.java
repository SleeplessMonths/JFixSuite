package problem_122A.subId_28735641;

import java.util.Scanner;
public class Main {
	public static int helper(String s){
		for(int i=0; i<s.length(); i++){
			if(s.charAt(i)=='4'|| s.charAt(i)=='7'){
				if(i==s.length()-1){
					return 1;
				}
			}else{
				return 0;
			}
		}
		return 0;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n= sc.nextInt();
		String string= Integer.toString(n);
		if(helper(string)==0){
			if(n%4==0||n%7==0||n%47==0||n%74==0){
				System.out.println("YES");
			}else{
				System.out.println("NO");
			}
		}else{
			System.out.println("YES");
		}
	}
}