package problem_122A.subId_27529063;

import java.util.Scanner;


public class Lucky_Division {
	
	public static String sq(){
		Scanner sc = new Scanner (System.in);
		
		String n =sc.nextLine();
		
		String flag ="NO";
		
		int k= Integer.parseInt(n);
		
		if(k % 4 ==0 || k % 7 == 0 || k%44==0 || k%47==0|| k%74==0 || k%77==0 || k%444==0 || k%447==0 || k%474==0 || k%477==0 || k%744==0 || k%747==0 ||k%774==0 ||k%777==0){
			return "YES";
		}
		for(int i=0; i<n.length();i++){
			if(n.charAt(i) == '4' || n.charAt(i) == '7')
				flag="YES";
			else
				return "NO";
		}
		
		if(k % 7 == 0)
			return "Yes";
		
		return flag;
		
	}
	
	public static void main (String [] args){
		System.out.print(sq());
	}
	

}