package problem_122A.subId_27406141;

import java.util.Scanner;

/**
 * Created by NIckConterno on 5/28/17.
 */
public class Force122A {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int num=in.nextInt();
        String str=num+"";
        Boolean b = true;
        if(str.contains("0")||str.contains("1")||str.contains("2")||str.contains("3")||str.contains("5")||str.contains("6")||str.contains("8")||str.contains("9")){

        }
        else{
            b=false;
        }
        if(Integer.parseInt(str)%4==0||Integer.parseInt(str)%7==0||Integer.parseInt(str)%7==0||Integer.parseInt(str)%47==0||Integer.parseInt(str)%74==0||Integer.parseInt(str)%44==0||Integer.parseInt(str)%77==0){
            b=false;
        }
        if(b){
            System.out.println("NO");
        }
        else{
            System.out.println("YES");
        }


    }
}