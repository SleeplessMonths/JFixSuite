package problem_122A.subId_29489650;

import java.util.Scanner;

public class LuckDivide {
	
	private static final Integer [] NUMBERS = new Integer[]{4, 7, 47, 74, 744, 774, 777, 474, 477, 447, 444, 747};
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int val = sc.nextInt();
		for(int i = 0 ; i < NUMBERS.length; i++){
			if(val % NUMBERS[i] == 0){
				System.out.println("YES");
				return;
			}
		}
		System.out.println("NO");
	}

}