package problem_122A.subId_25733176;

import java.util.Scanner;
public class LuckyNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int input = new Scanner(System.in).nextInt();
		String replaced = Integer.toString(input).replaceAll("[47]", "");
		if (input % 4 == 0 || input % 7 == 0 || input % 47 == 0){
			System.out.println("YES");
		} else if (replaced.length() <= 0){
			System.out.println("YES");
		} else {System.out.println("NO");}
	}

}