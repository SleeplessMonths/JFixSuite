package problem_122A.subId_27408277;

import java.util.Scanner;
public class Taha {
    public static void main(String[] args) {
        Scanner in = new Scanner (System.in);
        long n = in.nextLong();
        String a = null;
        if (n % 4 == 0 || n % 7 == 0 || n % 47 == 0 || n % 74 == 0) 
            a = "YES";
        else  {
            String s = Long.toString(n);
            int len = s.length();
            for (int i = 0; i < len; i++) {
                if (s.charAt(i) != '4' && s.charAt(i) != '7') {
                    a = "NO";
                    break;
                }
                else {
                    a = "YES";
                }
            }
        }
        System.out.print(a);
    }
    
}