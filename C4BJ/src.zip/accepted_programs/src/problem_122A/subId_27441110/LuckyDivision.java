package problem_122A.subId_27441110;

import java.util.Scanner;
public class LuckyDivision {

    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int n;
        n=in.nextInt();
        
        if(n==447||n==474||n==744||n==774||n==747||n==477||n==47||n==74){
            System.out.println("YES");
            }else if((n)%4==0 ||(n)%7==0 || (n)%47==0){
        System.out.println("YES");
        }else{
        System.out.println("NO");
        }
        }   
}