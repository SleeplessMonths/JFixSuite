package problem_122A.subId_27707459;

//package intro.oo;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        if(n%4==0||n%7==0||n%47==0)
            System.out.println("YES");
        else if(kir(n)) System.out.println("YES");
        else System.out.println("NO");
    }public static boolean kir(int n){
        String s=Integer.toString(n);
        for(int i=0; i<s.length(); i++){
            if(!(s.charAt(i)=='7'||s.charAt(i)=='4'))
                return false;
        }return true;
    }
}