package problem_122A.subId_29493907;

import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        
        int lucky = 0;
        String result=" "; 

        
   while (n > 0){
	   
       if(n%7 == 0 || n%4 == 0 || n%47 == 0){
       	result="YES";
       	break;
       }
	   
	   lucky = n % 10;
   
        if((lucky != 7 && lucky!= 4 ) ){
        	result="NO";
        	break;
        }
        
        else{
        	result="YES";
        }
        
        n = n / 10;
   }     
   System.out.println(result);
        }
	}