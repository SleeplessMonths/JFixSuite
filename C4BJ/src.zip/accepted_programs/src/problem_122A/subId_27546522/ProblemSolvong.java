package problem_122A.subId_27546522;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Scanner;

/**
 *
 * @author Mohamed Ramadan
 */
public class ProblemSolvong {

    /**
     * @param args the command line arguments
     */
    
   
    public static void main(String[] args) {
        // TODO code application logic here
         
       Scanner scanner=new Scanner(System.in);
       int inp=scanner.nextInt();
       boolean isLuckey=false;
       int[] luckys={4,7,77,44,47,74,444,447,474,477,747,777,774,744};
       
       for(int i=0;i<12;i++){
         if(inp%luckys[i]==0){
             isLuckey=true;
          break;
         }
             
       
       }
    
       if(isLuckey)
            System.out.println("YES");
       else
           System.out.println("NO");
    }
        


    
}