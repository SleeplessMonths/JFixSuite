package problem_122A.subId_29598988;

import java.util.Scanner;

public class LuckyDivision {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		String word =sc.nextLine();
		int num =Integer.parseInt(word);
		char []numArr =word.toCharArray();
		int []arr =new int [numArr.length];
		for(int i=0;i<arr.length;i++){
			arr[i]=Integer.parseInt(numArr[i]+"");
		}
		boolean fullLucky=true;
		for(int i=0;i<numArr.length;i++){
			if(arr[i]!=4&&arr[i]!=7)
			{
				fullLucky =false;
				break;
			}
		}
		if(fullLucky)
			System.out.println("YES");
		else if(!fullLucky){
			if(num%4 ==0||num%7==0||num%47==0||num%74==0)
				System.out.println("YES");
			else 
				System.out.println("NO");
		}
			
		
	}

}