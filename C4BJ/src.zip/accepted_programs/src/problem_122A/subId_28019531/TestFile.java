package problem_122A.subId_28019531;

import java.util.Scanner;


public class TestFile {
    public static void main(String[] args) throws java.lang.Exception {

        Scanner scanner = new Scanner(System.in);
        int[] list = {4, 7, 44, 47, 74, 77, 444, 447, 474, 477, 744, 747, 774, 777};
        int num = scanner.nextInt();
        int start = 0;
        int end = list.length - 1;
        boolean found = false;

        while (end >= start) {
            int middle = (start + end) / 2;
            if (list[middle] == num) {
                found = true;
                break;
            } else if (list[middle] < num) {
                start = middle + 1;
            } else if (list[middle] > num) {
                end = middle - 1;
            }
        }

        if (found) {
            System.out.println("YES");
        } else {
            int div = 0;
            for (int i = 0; i < 10; i++) {
                if(num % list[i] == 0) {
                    found = true;
                    break;
                }
            }
            if (found) {
                System.out.println("YES");
            } else {
                System.out.println("NO");
            }
        }
    }
}