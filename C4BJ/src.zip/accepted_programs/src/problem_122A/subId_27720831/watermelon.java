package problem_122A.subId_27720831;

import java.util.Scanner;

public class watermelon {
	
	public static void main(String[] args) {
Scanner g = new Scanner(System.in);
watermelon w =new watermelon();
int s = g.nextInt();
String s1 = Integer.toString(s);
int l = s1.length();
int s2 = s;
/*int t = (int)(s/Math.pow(10,l-1));
System.out.println(t);*/
for (;s2>0;s2=s2/10){
	if (s2%10 !=4 && (s2%10 !=7 )){
		if(s%4 == 0 || s%7 == 0  || s%47 == 0 || s%74 == 0 ||s%44 == 0 || s%77 == 0 || s% 444 == 0|| s%447 == 0 || s%474 == 0 || s%477 == 0 || s%744 == 0 || s% 747 == 0 || s%774 == 0|| s%777 == 0){
		System.out.println("YES");
		break;
		}
		else{
			System.out.println("NO");
			break;
		}
	}
	if(s2/10 <=0){
		System.out.println("YES");
		break;
	}
	
}
//System.out.println("YES");
}
}