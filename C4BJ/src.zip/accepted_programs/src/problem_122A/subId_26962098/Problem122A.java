package problem_122A.subId_26962098;

import java.io.IOException;
import java.util.Scanner;

public class Problem122A {

	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		if(n < 4){
			System.out.println("NO");
			return;
		}
		if (isLucky(n))
			System.out.println("YES");
		else {
			boolean lucky = false;
			for (int i = 4; i <= n; i++) {
				if (isLucky(i)) {
					if (n % i == 0) {
						lucky = true;
						break;
					} else {
						lucky = false;
					}
				}
			}
			System.out.println(lucky ? "YES" : "NO");
		}
	}

	static boolean isLucky(int n) {
		boolean lucky = false;
		while (n > 0) {
			int remainder = n % 10;
			n /= 10;
			if (remainder == 4 || remainder == 7)
				lucky = true;
			else {
				lucky = false;
				break;
			}
		}
		return lucky;
	}
}