package problem_122A.subId_25773780;

import java.util.Scanner;

public class HappyDivision {
   
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int number = sc.nextInt();

        int []arr = {4, 7, 47, 74, 447, 474, 477, 744, 747, 774};

        for (int i = 0; i < arr.length; i++) {
            if (number % arr[i] == 0) {
                System.out.println("YES");
                return;
            }
        }
        System.out.println("NO");
    }
    
}