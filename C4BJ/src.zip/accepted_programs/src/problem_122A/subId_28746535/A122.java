package problem_122A.subId_28746535;

import java.util.Arrays;
import java.util.Scanner;

public class A122
{
	private static final int[] LUCKIES = new int[]{
			4, 7
			, 44, 47, 74, 77
			, 444, 447, 474, 477
			, 744, 747, 774, 777
	};
	public static void main(String... args)
	{
		Scanner in = new Scanner(System.in);
		int number = in.nextInt();
		System.out.println(isLucky(number) ? "YES" : "NO");

	}

	private static boolean isLucky(int number)
	{
		return Arrays.stream(LUCKIES)
				.filter(i -> i <= number)
				.anyMatch(i -> number % i == 0);
	}

}