package problem_122A.subId_28047952;

import java.util.Scanner;

public class LuckyDivision {
  
    static boolean check(int i){
        boolean answer=false;
            if(isItALuckyNumber(i)){
                answer=true;
        }
        return answer;
    }
   
    static boolean isItALuckyNumber(int n){
        boolean answer= true;
        String str = Integer.toString(n);
        int i=0;
        while(i<str.length() && answer){
            if((int)str.charAt(i)-48!=7 && (int)str.charAt(i)-48!=4 ){
                answer=false;
            }
            i++;
        }
        return answer;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int i=1;
        boolean luckNumber=false;
        if(isItALuckyNumber(n)){
            luckNumber=true;
        }
        else{
            while(!luckNumber && i<n){
                if(n%i==0){
                    if(check(i)){
                         luckNumber =true;
                    }
                }
                i++;
            }
        }
        if(luckNumber){
            System.out.println("YES");
        }
        else{
            System.out.println("NO");
        }
    }
    
}