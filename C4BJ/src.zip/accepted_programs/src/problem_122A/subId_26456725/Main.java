package problem_122A.subId_26456725;

import java.util.Scanner;
public class Main{ 
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int tn = n;
        boolean ok= true;
        while(tn != 0) {
            int t = tn % 10;
            if(t  != 4 && t  != 7) {
                ok = false;
                break;
            }else {
                tn /=10;
            }
        }
        
        if(ok) {
            System.out.println("YES");
        }else {
            if(n % 4 == 0 || n % 7 == 0 || n % 44 == 0 || n % 47 == 0 || n % 77 == 0|| n % 444 == 0 || n % 447 == 0|| n % 474 == 0|| n % 477 == 0|| n % 744 == 0|| n % 747 == 0|| n % 774 == 0|| n % 777 == 0) {
                System.out.println("YES");
            }else {
                System.out.println("NO");
            }
        }
    }
}