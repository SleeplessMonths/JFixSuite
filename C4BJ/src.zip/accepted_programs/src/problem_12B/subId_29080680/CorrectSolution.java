package problem_12B.subId_29080680;

import java.util.Scanner;

public class CorrectSolution {
	public static void  main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String n = sc.nextLine();
		String m = sc.nextLine();
		int digs[] = new int [10];
		for (int i=0;i<n.length();i++)
			digs[n.charAt(i)-'0']++;
		if (m.length()!=n.length())
		{
			System.out.println("WRONG_ANSWER");
			return;
		}
		if (digs[0]==n.length() && n.equals(m))
		{
			System.out.println("OK");
			return;
		}
		int firstDig=0;
		for (int i=1;i<10;i++)
		{
			if (digs[i]>0)
			{
				firstDig=i;
				break;
			}
		}
		digs[firstDig]--;
		for (int i=0;i<10;i++)
		{
			for (int j=0;j<digs[i];j++)
			{
				firstDig *= 10;
				firstDig += i;
			}
		}
//		System.out.println(firstDig);
		if (firstDig==Integer.parseInt(m))
			System.out.println("OK");
		else
			System.out.println("WRONG_ANSWER");
	}
}