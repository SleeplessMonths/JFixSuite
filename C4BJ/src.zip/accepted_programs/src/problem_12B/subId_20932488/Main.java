package problem_12B.subId_20932488;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author mhamm
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    static int numChar[];
    public static void main(String[] args) throws IOException {
        BufferedReader br  = new BufferedReader(new InputStreamReader(System.in));
        
        String num = br.readLine();
        String expectedAnswer = br.readLine();
        String answer = "";
        if(expectedAnswer.equals("0") && num.equals("0")){
            System.out.println("OK");
            return;
        }
        numChar = new int[num.length()];
        for(int i = 0;i<num.length();i++){
            numChar[i] = Integer.parseInt(Character.toString(num.charAt(i)));
        }
        
        for(int i = 0;i<num.length();i++){
            answer+=getMinValue(answer.length()==0);
        }
        
        if(answer.equals(expectedAnswer)){
            System.out.println("OK");
        }else{
            System.out.println("WRONG_ANSWER");
        }
    }
    
    private static int getMinValue(boolean zero){
        int min = 10;
        int index = 0;
        for(int i = 0;i<numChar.length;i++){
            if(zero){
                if(numChar[i] < min && numChar[i] != -1 && numChar[i] != 0){
                    min = numChar[i];
                    index = i;
                }
            }else{
                if(numChar[i] < min && numChar[i] != -1){
                    min = numChar[i];
                    index = i;
                }
            }
        }
        numChar[index] = -1;
        return min;
    }
    
}