package problem_12B.subId_29137090;

import java.util.Arrays;
import java.util.Scanner;

/**
 * Created by vinayr on 8/2/17.
 */
public class CorrectSolution {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String val = sc.nextLine();
        String val1 = sc.nextLine();
        char[] arr = val.toCharArray();
        Arrays.sort(arr);
        int i;
        for (i = 0; i < arr.length && arr[i] == '0'; i++) ;
            if (i != 0 && i < arr.length) {
                arr[0] = arr[i];
                arr[i] = '0';
            }

        String ans = new String(arr);
       // System.out.println(ans);
        if (ans.equals(val1)) {
            System.out.println("OK");
        } else
            System.out.println("WRONG_ANSWER");
    }
}