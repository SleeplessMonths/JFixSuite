package problem_12B.subId_22838709;

import java.util.ArrayList;
import java.util.Scanner;

public class Classwork {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String x = scanner.next();
        String y = scanner.next();
        if (x.equals("0") && y.equals("0")){
            System.out.println("OK");
            return;
        }
        if (x.charAt(0) == '0' || y.charAt(0) == '0') {
            System.out.println("WRONG_ANSWER");
            return;
        }
        int min = 0;
        int k = 0;
        int a = 0;
        ArrayList<Integer> al = new ArrayList<>();
        String answer = "";
        String realAnswer = "";
        for (int i = 0; i < x.length(); i++) {
            al.add(Integer.parseInt("" + x.charAt(i)));
        }
        for (int i = 0; i < x.length(); i++) {
            min = al.get(0);
            for (int j = 0; j < al.size(); j++) {
                if (al.get(j) <= min) {
                    min = al.get(j);
                    k = j;
                }
            }
            answer += min;
            al.remove(k);
        }
        while (answer.charAt(0) == '0') {
            answer = answer.substring(1);
            a++;
        }
        realAnswer += answer.charAt(0);
        for (int i = 0; i < a; i++) {
            realAnswer += "0";
        }
        realAnswer += answer.substring(1);
        if (realAnswer.equals(y))
            System.out.println("OK");
        else
            System.out.println("WRONG_ANSWER");
    }
}