package problem_12B.subId_23037814;

import java.util.Arrays;
import java.util.Scanner;

public class Correct {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		char[] a = scan.next().toCharArray();
		String b = scan.next();
		if(Integer.parseInt(new String(a)) == 0){
			System.out.println(new String(a).equals(b)?"OK":"WRONG_ANSWER");
			return;
		}
		Arrays.sort(a);
		String build = "";
		int idx = -1;
		if(a[0] == '0'){
			int i = 0;
			for(; a[i] == '0'; i++);
			idx = i;
			build += a[i];
		}
		for(int i = 0; i < a.length; i++){
			if(i == idx) continue;
			build += a[i];
		}
		System.out.println(build.equals(b)?"OK":"WRONG_ANSWER");
	}

}