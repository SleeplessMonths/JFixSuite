package problem_12B.subId_29081464;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Arrays;

public class Correct_Solution {
	public static void main(String[] args)throws Throwable {
		BufferedReader bf = new BufferedReader(new InputStreamReader (System.in));
		PrintWriter pw = new PrintWriter(System.out, true);
		String num=bf.readLine();
		String bob=bf.readLine();
		if(num.equals("0") && bob.equals("0"))
			pw.println("OK");
		else if(bob.charAt(0)=='0')
			pw.println("WRONG_ANSWER");
		else
		{
			char[] nums=num.toCharArray();
			char[] bobs=bob.toCharArray();
			Arrays.sort(nums);
			if(nums[0]=='0')
			{
				for(int i=1;i!=nums.length;i++)
				{
					if(nums[i]!='0')
					{
						nums[0]=nums[i];
						nums[i]='0';
						break;
					}
				}
			}
			if(Arrays.equals(nums, bobs))
				pw.println("OK");
			else
				pw.println("WRONG_ANSWER");
		}
		pw.close();
	}
}