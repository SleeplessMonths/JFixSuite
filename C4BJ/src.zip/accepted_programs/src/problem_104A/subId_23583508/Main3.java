package problem_104A.subId_23583508;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main3 {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine())-10;
		
		if(n <= 0 || n>11 ){
			System.out.println(0);
			return;
		}else{
			if(n<10){
				System.out.println(4);
				return;
			}
			else{
				if(n==10){
					System.out.println(15);
					return;
				}else{
					System.out.println(4);
				}
			}
		}
		
	}
}