package problem_104A.subId_6434813;

import java.util.Scanner;

public class p64a
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int arr[] = {0,0,0,0,0,0,0,0,0,0,0,4,4,4,4,4,4,4,4,4,15,4,0,0,0,0};
        System.out.println(arr[n]);
    }
}