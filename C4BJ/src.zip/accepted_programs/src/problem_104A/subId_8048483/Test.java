package problem_104A.subId_8048483;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Test {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String str = new String(br.readLine());
        int a = Integer.parseInt(str);
        a-=10;
        if(a==10){
            System.out.println(15);
        }
        else if(a>11 || a<=0){
            System.out.println(0);
        }
        else{
            System.out.println(4);
        }
    }
}