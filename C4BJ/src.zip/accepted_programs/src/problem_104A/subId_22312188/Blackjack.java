package problem_104A.subId_22312188;

import java.util.Scanner;

public class Blackjack { 
	public static void main(String[]args){ 
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int dif = n - 10;
		
		if (dif < 0 || dif == 0) {
			System.out.println("0");
		}	
		else if (dif > 0) {
			switch (dif) {
			case 10:
				System.out.println("15");
				break;
			case 9:
			case 8:
			case 7:
			case 6:
			case 5:
			case 4:
			case 3:
			case 2:
			case 1:
			case 11:
				System.out.println("4");
				break;
			default:
				System.out.println("0");
				break;
			}

		}

	} 
	
}