package problem_104A.subId_19726279;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class A {
public static void main(String[] args) throws IOException{
BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
int n=Integer.parseInt(in.readLine());
int cur=10; int ways=0;
	int diff=n-cur;
	if(diff==10)
		ways=3*4+4-1;
	else if(diff!=0&&diff<=11&&diff>0)
		ways=4;

System.out.println(ways);
}

}