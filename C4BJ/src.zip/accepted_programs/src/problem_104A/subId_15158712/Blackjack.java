package problem_104A.subId_15158712;

import java.util.Scanner;


public class Blackjack {
	public static void main(String args[]){
		Scanner scan = new Scanner(System.in);
		int N=scan.nextInt(),result;
		N-=10;
		if(N<=0||N>11)
			result=0;
		else if(N==10)
			result=15;
		else
			result=4;
		System.out.println(result);
	}
}