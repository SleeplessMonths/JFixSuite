package problem_104A.subId_7624790;

import java.util.Scanner;

public class apples {
    public static void main (String args []){
     Scanner s = new Scanner(System.in) ;
        int n = s.nextInt();
        int k = n-10;
        if(k==11){System.out.println(4);}
        else if(k==10){System.out.println(15);}
        else if(k==0||k>11||k<1){System.out.println(0);}
        else{System.out.println(4);}
    }
}