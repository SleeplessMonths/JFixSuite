package problem_104A.subId_6148092;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Administrator
 */
public class Blackjack {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        int card = Integer.parseInt(reader.readLine());

        int a = card - 10;

        if (a == 10 ) {
            System.out.println("" + 15);
        } else if (a == 0 || a>11 || a<0) {
            System.out.println("" + 0);
        } else {
            System.out.println("" + 4);
        }

    }

}