package problem_104A.subId_4279923;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Blackjack {
    public static void main(String[] args) throws IOException {
        BufferedReader f = new BufferedReader(new InputStreamReader(System.in));
        int x = Integer.parseInt(f.readLine())-10;
        if (x <= 0 || x > 11)
            System.out.println(0);
        else if (x == 10)
            System.out.println(15);
        else
            System.out.println(4);
    }
}