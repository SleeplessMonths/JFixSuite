package problem_104A.subId_21346114;

import java.util.Scanner;

/**
 *
 * @author omar
 */
public class Ladder {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        
        int n = scanner.nextInt();
        if (n<=10){
            System.out.println("0");
            return;
        } 
        n-=10;
        int ans=0;
        if(n>=1 && n<=9){
            ans=4;
        }else if(n==10){
            ans=15;
        }else if(n==11){
            ans=4;
        }
        System.out.println(ans);
    }

}