package problem_104A.subId_21759382;

import java.util.Scanner;

/**
 *
 * @author Krolos
 */
public class ABlackjack {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner k=new Scanner(System.in);    
       int n=k.nextInt();
       if(n==20){
           System.out.println("15");
       }
      else if(n>10&&n<=21){
           System.out.println("4");
       }
        else
            System.out.println("0");
       
    }
    
}