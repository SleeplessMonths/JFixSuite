package problem_104A.subId_22814732;

import java.util.Scanner;

public class SPOJ
{
	public static void main(String args[])
	{
		int n;
		Scanner s=new Scanner(System.in);
		n=s.nextInt();
		int rem=n-10;
		if(rem==10)
		{
			System.out.println(15);
		}
		else if(rem==11)
		{
			System.out.println(4);
		}
		else if(rem==1)
		{
			System.out.println(4);
		}
		else if(rem<=0 || rem>11)
		{
			System.out.println(0);
		}
		else if(rem>0 && rem<=11)
		{
			System.out.println(4);
		}
	}
}