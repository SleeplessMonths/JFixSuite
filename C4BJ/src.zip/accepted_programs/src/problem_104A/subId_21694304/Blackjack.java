package problem_104A.subId_21694304;

import java.util.Scanner;


public class Blackjack {

    
    public static void main(String[] args) {
       Scanner scan=new Scanner (System.in);
       int q=scan.nextInt();
       
       if (q==10){
           System.out.println("0");
       } 
       else if (q==20){
           System.out.println("15");
         
       }
       else if(q==21){
           System.out.println("4");
       }
       else if(q>10 && q<21){
           System.out.println("4");
       }
       else if (q>21 && q<25){
           System.out.println("0");
       }
       else if (q<10){
           System.out.println("0");
       }
       else if (q>21){
           System.out.println("0");
       }
    }
    
}