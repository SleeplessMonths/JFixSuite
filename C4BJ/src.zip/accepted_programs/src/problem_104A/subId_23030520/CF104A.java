package problem_104A.subId_23030520;

import java.util.Scanner;

public class CF104A {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int sum = sc.nextInt(); // required sum
		int times = 0;
		for (int i = 1; i <= 11; i++) {
				if (i+10 == sum) {
					times+= 4;
				}
		}
		
		if (10+10 == sum) {
			times += 11;
		}
		
		System.out.println(times);
	}

}