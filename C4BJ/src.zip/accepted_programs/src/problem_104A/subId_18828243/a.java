package problem_104A.subId_18828243;

//package c80;

import java.util.Scanner;

public class a {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int r=n-10;
		int ans=0;
		if(r==10)
			ans=15;
		else if(r==0)
			ans=0;
		else if(r>0 && r<=9)
			ans=4;
		else if(r==11)
			ans=4;
		
		System.out.println(ans);
		
		

	}

}