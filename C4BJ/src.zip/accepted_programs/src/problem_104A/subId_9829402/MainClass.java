package problem_104A.subId_9829402;

import java.util.Scanner;


public class MainClass {


    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        if( n <= 10 || n > 21 ){
            System.out.println("0");
            return;
        }
        n-=10;
        if(n <= 9 || n == 11){
            System.out.println("4");
            return;
        }
        if( n == 10 ){
            System.out.println("15");
            return;
        }

    }

}