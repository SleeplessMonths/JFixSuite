package problem_104A.subId_9062855;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader cin=new BufferedReader(new InputStreamReader(System.in));
        int a=Integer.parseInt(cin.readLine()),r=a-10;
        if(r<=0 || r>11)
            System.out.println(0);
        else if(r==10)
            System.out.println("15");
        else
            System.out.println("4");
    }
}