package problem_104A.subId_24858895;

import java.util.Scanner;

public class CF104A {

	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);
		int n = reader.nextInt();
		if (n - 10 == 10)
			System.out.println(15);
		else if (n - 10 <= 0)
			System.out.println(0);
		else if (n - 10 <= 11)
			System.out.println(4);
		else
			System.out.println(0);
	}

}