package problem_104A.subId_21135231;

import java.util.Scanner;

public class Blackjack {
public static void main(String[] args) {
	
	Scanner sc = new Scanner(System.in);
	int n  = sc.nextInt()-10;
	
	
	if(n <= 0 || n>11)
		System.out.println(0);
	else
		if (n == 10) {
			System.out.println(15);
		}else
			if (n == 11) {
				System.out.println(4);
			}else
				System.out.println(4);
		
		
		
		
		
	
		
	
	
	
	
}
	
	
}