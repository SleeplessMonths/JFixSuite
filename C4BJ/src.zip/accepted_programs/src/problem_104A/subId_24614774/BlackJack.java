package problem_104A.subId_24614774;

import java.util.Scanner;

public class BlackJack
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		
		n = n-10;
		if(n==0)
			System.out.println("0");
		else if(n>=1 && n<=9)
			System.out.println("4");
		else if(n==10)
			System.out.println("15");
		else if(n==11)
			System.out.println("4");
		else
			System.out.println("0");
	}
}