package problem_104A.subId_16847557;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class blackjack {
	public static void main(String[] args) throws IOException {
		BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
		int x=Integer.parseInt(b.readLine());
		if(x<11){
			System.out.println("0");
		}else if(x<20){
			System.out.println("4");
		}else if(x==20){
			System.out.println("15");
		}else if(x==21){
			System.out.println("4");
		}else{
			System.out.println("0");
		}
	}
}