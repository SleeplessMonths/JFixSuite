package problem_104A.subId_21699679;

import java.util.Scanner;


public class Blackjack {

    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int x = scan.nextInt(), y=10, z, result=0;
        z = x - y;
        if(z==1 || z==11){
            result = 4;
        }
        if(z==2 || z==3 || z==4 || z==5 || z==6 || z==7 || z==8 || z==9){
            result = 4;
        }
        if(z==10){
            result = 15;
        }
        System.out.println(result);
            
    }
    
}