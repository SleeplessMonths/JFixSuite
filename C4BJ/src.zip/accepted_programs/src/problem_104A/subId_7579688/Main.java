package problem_104A.subId_7579688;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader( new InputStreamReader(System.in) , 8*1024);
		Scanner sc = new Scanner( br );

		int n = sc.nextInt();
		
		int ans = 0 ; 
		
		for(int i = 2 ; i <= 10 ; ++i ) 
			if( i + 10  == n   )
				ans += 4;
		
		if( 10 + 1 == n )
			ans += 4;
		
		if( 10 + 10 == n )
			ans += 11;
		
		if( 10 + 11 == n )
			ans += 4;
			
			System.out.println( ans );
	}

}