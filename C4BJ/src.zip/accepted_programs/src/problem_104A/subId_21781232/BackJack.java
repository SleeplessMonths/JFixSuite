package problem_104A.subId_21781232;

import java.util.Scanner;

/**
 *
 * @author ShadoOo
 */
public class BackJack {
    public static void main(String[] args) {
        
        Scanner k = new Scanner(System.in);
        int x = k.nextInt();
        
        if(x==20){
            System.out.println(15);
        }
        else if(x==10){
            System.out.println(0);
        }
        else if(x>21||x<10){
            System.out.println(0);
        }
        else{
            System.out.println(4);
        }
            
    }
}