package problem_104A.subId_7821325;

import java.io.*;
import java.util.StringTokenizer;

public class Main
{

	private static BufferedReader in;
	private static BufferedWriter out;

	public static void main(String... args) throws IOException
	{
		// streams
		boolean file = false;
		if (file)
			in = new BufferedReader(new FileReader("input.txt"));
		else
			in = new BufferedReader(new InputStreamReader(System.in));
		out = new BufferedWriter(new OutputStreamWriter(System.out));
		// out = new BufferedWriter(new FileWriter("output.txt"));
		StringTokenizer tok;

		// read
		int n = Integer.parseInt(in.readLine());

		// solbe
		int diff = n - 10;
		if(diff <= 0)
			System.out.println(0);
		else if (diff < 10)
			System.out.println(4);
		else if (diff == 10)
			System.out.println(15);
		else if (diff == 11)
			System.out.println(4);
		else
			System.out.println(0);
		out.flush();
	}

}