package problem_104A.subId_6513134;

import java.util.Scanner;

public class p104A {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		int n = in.nextInt();

		if(((n-10) >= 2 && (n-10) <= 9) || (n-10) == 11 || (n-10) == 1) System.out.println("4");
		else if((n-10) == 10) System.out.println("15");
		else System.out.println("0");
	}
}