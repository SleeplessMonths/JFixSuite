package problem_104A.subId_15396764;

import java.util.Scanner;

public class BlackJack {
    public static void main(String asd[])throws Exception
    {
        Scanner in=new Scanner(System.in);
        int n=in.nextInt();
        n-=10;
        if(n<=0 || n>11)
            System.out.println(0);
        else
        {
            if((n>=1 && n<=9)||n==11 )
                System.out.println(4);
            else
                System.out.println(15);
        }
    }
}