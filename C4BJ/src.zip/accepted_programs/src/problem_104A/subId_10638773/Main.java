package problem_104A.subId_10638773;

import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        byte N=s.nextByte();
        if(N==20)System.out.print(15);
        else if((N>10 && N<20) ||(N==21))System.out.print(4);
        else if(N>21 || N<=10)System.out.print(0);
        }
}