package problem_123B.subId_842821;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int s[] = new int[6];
		for(int i = 0; i < 6; ++i) {
			s[i] = scan.nextInt();
		}
		int x1 = s[2] + s[3];
		int y1 = s[2] - s[3];
		int x2 = s[4] + s[5];
		int y2 = s[4] - s[5];
		int a = s[0] << 1;
		int b = s[1] << 1;
		
		int t1 = Math.abs((x1 / a) - (x2 / a));
		int t2 = Math.abs((y1 / b) - (y2 / b));
		if(!((x1 > 0 && x2 > 0) || (x1 < 0 && x2 < 0))) {
			++t1;
		}
		if(!((y1 > 0 && y2 > 0) || (y1 < 0 && y2 < 0))) {
			++t2;
		}
		System.out.println(Math.max(t1, t2));
		
	}
}