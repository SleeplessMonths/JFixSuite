package problem_11B.subId_14606787;

import java.util.Scanner;

public class B11{
    /*
     * Title: Jumping Jack
     * 
     * Tags: math
     * 
     * http://codeforces.com/problemset/problem/11/B
     * 
     */
    public static void main(String args[]){
        Scanner scanner = new Scanner(System.in);
        
        // INPUT: Goal to jump towards
        long n = Math.abs(scanner.nextLong());
        scanner.close();
        
        int jumps = startingJumps(n);
        if (n % 2 == 0){
            while (jumps % 4 != 0 && jumps % 4 != 3)
                jumps++;
        }
        else{
            while (jumps % 4 != 1 && jumps % 4 != 2)
                jumps++;
        }
            
        // OUTPUT: minimum # of jumps to reach goal
        System.out.println(jumps);
    }
    
    public static int startingJumps(long n){
        return (int) Math.ceil(-.5 + .5 * Math.sqrt(8*n+1));
    }
    
}