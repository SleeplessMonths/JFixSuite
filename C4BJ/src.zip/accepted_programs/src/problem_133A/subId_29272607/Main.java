package problem_133A.subId_29272607;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		// Scanner read = new Scanner(new FileInputStream(new
		// File("input.txt")));
		// PrintWriter out = new PrintWriter(new File("output.txt"));
		Scanner read = new Scanner(System.in);
		String p= read.nextLine();
		boolean check = true;
		for(int i = 0; i < p.length(); i++){
			if(p.charAt(i) == 'H' || p.charAt(i) == 'Q'|| p.charAt(i) == '9'){
				System.out.println("YES");
				check = false;
				break;
			}
		}
		if(check)
			System.out.println("NO");
	}
}