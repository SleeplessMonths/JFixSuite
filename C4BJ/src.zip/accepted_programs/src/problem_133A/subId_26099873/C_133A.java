package problem_133A.subId_26099873;

import java.util.Scanner;
public class C_133A {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String s = scan.next();
        boolean a = true;
        for(int i=0; i<s.length(); i++) {
            if(s.charAt(i) =='H' || s.charAt(i) =='Q' || s.charAt(i) =='9') {
                a = true;
                break;
            }
            else {
                a = false;
            }
        }
        if(a==true) System.out.println("YES");
        else System.out.println("NO");
    }
}