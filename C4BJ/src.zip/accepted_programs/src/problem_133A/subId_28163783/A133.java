package problem_133A.subId_28163783;

//package codeforces;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class A133 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
		try {
			String string=reader.readLine();
			if(string.contains("H")||string.contains("Q")||string.contains("9"))
				System.out.println("YES");
			else
				System.out.println("NO");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}