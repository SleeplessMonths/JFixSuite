package problem_133A.subId_28623746;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {


    public static void main(String[] args) throws Throwable {

BufferedReader r=new BufferedReader(new InputStreamReader(System.in));

String s=r.readLine();

if(s.contains("H")||s.contains("Q")||s.contains("9")){
    System.out.println("YES");
}else{
    System.out.println("NO");
        }
    }



}