package problem_133A.subId_29540239;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class team {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));

		String s = bf.readLine();
		int c1 = 1;

		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == 'H' | s.charAt(i) == 'Q' |  s.charAt(i) == '9') {
				c1 = 0;
				break;
			}

		}
		if (c1 == 0) {
			System.out.println("YES");
		} else {
			System.out.println("NO");
		}

	}
}