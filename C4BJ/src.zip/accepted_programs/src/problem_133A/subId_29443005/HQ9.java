package problem_133A.subId_29443005;

import java.util.Scanner;

public class HQ9 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String x = sc.next();
        int count = 0;
        
        char[] temp = x.toCharArray();
        for(int i = 0; i<x.length(); i++)
        {
            if(temp[i] == 'H'|| temp[i] == 'Q'|| temp[i] == '9')
            {
                count++;
            }
        }
        if(count>0)
        {
            System.out.println("YES");
        }else
            System.out.println("NO");
    }
    
}