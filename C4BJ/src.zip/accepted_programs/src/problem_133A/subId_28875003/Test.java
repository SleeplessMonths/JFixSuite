package problem_133A.subId_28875003;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String str = scanner.next();
        if(str.contains("H") || str.contains("Q") || str.contains("9"))
            System.out.println("YES");
        else
            System.out.println("NO");
    }
}