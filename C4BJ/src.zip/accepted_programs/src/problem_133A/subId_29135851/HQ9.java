package problem_133A.subId_29135851;

import java.util.Scanner;

public class HQ9 {
   public static void main(String args[])
   {
	   Scanner s=new Scanner(System.in);
	   String p=s.nextLine();
	   int len=p.length();
	   for(int i=0;i<len;i++)
	   {
		   char c=p.charAt(i);
		   if(c=='H' || c=='Q' || c=='9' )
		   {
			   System.out.println("YES");
			   return;
		   }
	   }
	   System.out.println("NO");
   }
}