package problem_133A.subId_29493053;

import java.util.Scanner;

public class Hq9 {
    public static void main(String[] args) {
        
        Scanner in=new Scanner(System.in);
        String p=in.next();
        String s="";
       char ch ='l';
        for (int i = 0; i <p.length(); i++) {
            ch=p.charAt(i);
            if(ch=='H'||ch=='Q'||ch=='9'){
                s="YES";
            break;
            }
            
            else 
                s="NO";
        }
        System.out.println(s);
    }  
    
    
}