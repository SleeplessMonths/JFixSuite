package problem_133A.subId_29493133;

import java.util.Scanner;
 
/* Name of the class has to be "Main" only if the class is public. */
public class Ideone
{
 
    public static void main(String[] args) {
 
        Scanner in=new Scanner(System.in);
        String p=in.next();
        String s="";
       char ch ='l';
        for (int i = 0; i <p.length(); i++) {
            ch=p.charAt(i);
            if(ch=='H'||ch=='Q'||ch=='9'){
                s="YES";
            break;
            }
 
            else 
                s="NO";
        }
        System.out.println(s);
    }  
 
 
}