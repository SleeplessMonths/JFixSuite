package problem_133A.subId_27350437;

import java.util.Scanner;

public class HQ9 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);
		String s = input.next();
		if(isProgramming(s))
			System.out.println("YES");
		else
			System.out.println("NO");
	}
	private static boolean isProgramming(String s){
		for(int i=0;i<s.length();i++){
			if(s.charAt(i) == 'H' | s.charAt(i) == 'Q'|s.charAt(i) == '9')return true;
		}
		return false;
	}

}