package problem_133A.subId_27430270;

import java.util.Scanner;
/**
 * Created by hp on 29-05-2017.
 */
public class HQ9 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.next();
        int flg=1;
        for (int i = 0; i <s.length() ; i++) {
            if(s.charAt(i) == 'H' || s.charAt(i) == 'Q'|| s.charAt(i) == '9')
                flg=0;
        }
        if(flg == 0)
            System.out.println("YES");
        else
            System.out.println("NO");
    }
}