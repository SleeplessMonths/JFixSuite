package problem_133A.subId_25775333;

import java.util.ArrayList;
import java.util.Scanner;

public class puzzles {
	static ArrayList<Integer> path = new ArrayList<Integer>();

	public static void dfs(int n, int[][] g, int[] mark, int[] a, int v, int m,
			int max) {
		mark[v] = 1;
		int c = 0;
		for (int i = 0; i < n; i++)
			if (g[i][v] == 1)
				c++;
		if (c == 1) {
			if (m <= max && !path.contains(v)) {
				// System.out.println("max" + max + " m " + m + " v " + v);
				path.add(v);
			}
			return;

		}

		for (int i = 0; i < n; i++) {
			if (g[v][i] == 1 && mark[i] == 0) {
				if (a[v] == 0)
					dfs(n, g, mark, a, i, m, max);
				else
					dfs(n, g, mark, a, i, m + 1, max);
			}
		}
		mark[v] = 0;

	}

	static boolean is(int i) {
		if (i == 2)
			return true;
		if (i == 1)
			return false;
		for (int j = 2; j < i; j++)
			if (i % j == 0)
				return false;
		return true;

	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String s = in.next();
		int n = s.length();
		int ans = 0;
		for(int i = 0 ; i < n ; i++){
			if(s.charAt(i) == 'H' || s.charAt(i) == 'Q'  || s.charAt(i) == '9')
					ans++;
		}
		if (ans == 0 )
			System.out.println("NO");
		else
			System.out.println("YES");
	}
}