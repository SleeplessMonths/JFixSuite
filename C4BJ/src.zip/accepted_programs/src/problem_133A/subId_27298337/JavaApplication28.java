package problem_133A.subId_27298337;

import java.util.Scanner;

/**
 *
 * @author Belal
 */
public class JavaApplication28 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        String s = scan.nextLine();
        
        if(s.contains("H") || s.contains("Q") || s.contains("9"))
            System.out.println("YES");
        else
            System.out.println("NO");

    }
    
}