package problem_133A.subId_28748145;

import java.util.Scanner;
public class _133A
{ public static void main (String[] args){
	Scanner sc = new Scanner(System.in);
	String str = sc.nextLine();
	if(str.contains("H")||str.contains("Q")||str.contains("9"))
	System.out.print("YES");
	else 
	System.out.print("NO");
}
}