package problem_133A.subId_28160274;

import java.util.Scanner;

public class Main{
    
    public static void main(String[] args)
    {
        Scanner kb = new Scanner(System.in);
        String word = kb.nextLine();
        boolean ret = false;
        int i = 0;
        while(!ret && i < word.length()){
            if(word.charAt(i) == 'H' ||word.charAt(i) == 'Q'||word.charAt(i) == '9'){
                ret = true;
            }
            i++;
        }
        if(ret){
            System.out.println("YES");
        }
        else{
            System.out.println("NO");
        }
    }
}