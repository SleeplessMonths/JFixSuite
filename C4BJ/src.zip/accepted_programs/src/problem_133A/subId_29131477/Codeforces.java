package problem_133A.subId_29131477;

import java.io.BufferedReader;
import java.io.InputStreamReader;
public class Codeforces {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        //-------------------------------------------------------------------
        String firstWord =br.readLine();
        int status=0;
        String sr[]=firstWord.split("");
        for(int i=0;i<sr.length;i++){
            if(sr[i].equals("H")||sr[i].equals("Q")||sr[i].equals("9")){
                status=1;
                break;
            }
        }
        if(status==1){
            System.out.print("YES");
        }else
            System.out.print("NO");
    }
    
}