package problem_133A.subId_27179607;

import java.util.Scanner;
public class JavaApplication89 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner console = new Scanner (System.in) ; 
        String x = console.next() ;
        int count=0 ; 
        for (int i = 0 ; i<x.length() ; i++)
        {
            if (x.charAt(i)=='H'||x.charAt(i)=='Q'||x.charAt(i)=='9')
            {
                count++ ;  
                                
            }
          
        }
        if (count>=1)
            System.out.println("YES");
        else 
            System.out.println("NO");
    }
    
}