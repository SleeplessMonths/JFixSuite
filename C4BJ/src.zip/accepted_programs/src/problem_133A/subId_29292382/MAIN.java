package problem_133A.subId_29292382;

import java.util.Scanner;

public class MAIN {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner (System.in);
		
		String line =scan.nextLine();
		
		scan.close();
		
		String[] a = line.split(("(?!^)"));
		
		String b = "NO";
		for (String s : a ){
			
			if(s.equals("H")||s.equals("Q")||s.equals("9")){
				b="YES";
				break;
			}
			
		}
	
		System.out.print(b);
	}

}