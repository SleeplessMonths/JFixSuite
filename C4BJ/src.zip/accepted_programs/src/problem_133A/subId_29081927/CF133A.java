package problem_133A.subId_29081927;

import java.io.IOException;
import java.util.Scanner;

public class CF133A {
    public static void main (String [] args) throws IOException {
        Scanner scanner = new Scanner (System.in);
        String p = scanner.next();
        boolean output = false;
        for(int i = 0; i < p.length(); i++){
            if(p.charAt(i) == 'H' || p.charAt(i) == 'Q' || p.charAt(i) == '9'){
                output = true;
            }
        }
        if(output){
            System.out.println("YES");
        }
        else{
            System.out.println("NO");
        }
    }
}