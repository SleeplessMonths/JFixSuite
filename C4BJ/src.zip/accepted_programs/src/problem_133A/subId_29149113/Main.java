package problem_133A.subId_29149113;

import java.util.Scanner;

public class Main {
    public static boolean hasCode(String p){
        for(int i=0;i<p.length();i++){
            switch(p.charAt(i)){
                case '9':
                case 'Q':
                case 'H':
                    return true;
            }
        }
        return false;
        
    }
    public static void main(String[] args) {
        
        
        Scanner input=new Scanner(System.in);
        String code=input.next();
        if(hasCode(code))
            System.out.println("YES");
        else
            System.out.println("NO");
    }
    
}