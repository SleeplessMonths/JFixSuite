package problem_133A.subId_26037436;

import java.util.Scanner;
public class JavaApplication1 {
    public static void main(String[] args) {
        Scanner in=new Scanner (System.in);
        String n=in.next();
        int flag=0;
        if (n.contains("H") || n.contains("Q") || n.contains("9") )
        {
            flag++;
        }
       System.out.print(flag==0? "NO":"YES");
    }
    
}