package problem_133A.subId_27871627;

import java.util.Scanner;

public class HQ9 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		String str = scan.next();

		if (str.contains("H") || str.contains("9")
				|| str.contains("Q"))
			System.out.println("YES");
		else
			System.out.println("NO");
		scan.close();
	}
}