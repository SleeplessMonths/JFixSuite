package problem_133A.subId_28253382;

import java.util.Scanner;

/**
 *
 * @author macpro
 */
public class HQNinePlus {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String P = input.next();
        
        if(P.contains("H") || P.contains("9") || P.contains("Q")){
            System.out.println("YES");
        }
        else System.out.println("NO");
    }
}