package problem_133A.subId_29087302;

import java.util.Scanner;

public class A133 {
        public static void main(String[] args){
                Scanner in= new Scanner(System.in);
                String word=in.nextLine();
		boolean flagNo=true;
		for(int i=0;i<word.length();i++){
			char temp=word.charAt(i);
			if( temp==('H')||temp==('Q') ||temp==('9')/* ||temp==('+')*/){
				System.out.println("YES");
				flagNo=false;
				break;
			}
		}
		if(flagNo) System.out.print("NO");
	}
}