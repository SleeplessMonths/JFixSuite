package problem_133A.subId_28174971;

import java.io.BufferedReader;
import java.io.InputStreamReader;


public class Ideone
{
	public static void main (String[] args) throws java.lang.Exception
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String s = br.readLine();
		String[] a = s.split("");
		int count = 0;
		for(int i = 0 ; i < a.length ; i++)
		{
			switch(a[i])
			{
			case "H" :
				count = 1;
				break;
			case "Q" :
				count = 1;
				break;
			case "9" :
				count = 1;
				break;
			}
		}
		if(count==1)
		System.out.println("YES");
		else
		System.out.println("NO");
		
	}
}