package problem_133A.subId_25459851;

public class A_HQ9 {
    
    public static void main(String[] args) {
        java.util.Scanner in = new java.util.Scanner(System.in);        
        System.out.println(HQ(in.next()));
    }
    
    public static String HQ(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == 'H' || s.charAt(i) == 'Q' || s.charAt(i) == '9') {
                return "YES";
            }
            
        }
        return "NO";
    }
}