package problem_133A.subId_29328295;

import java.util.Scanner;
public class HQ9{
public static void main(String[] args){
Scanner sc = new Scanner(System.in);
String str = sc.next();
String out = "NO";
int a = 0;
for(int i=0;i<str.length();i++){
char c = str.charAt(i);
a = (int) c;
if(a==72||a==81||a==57) out = "YES";
}
System.out.println(out);
}
}