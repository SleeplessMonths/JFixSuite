package problem_133A.subId_28157317;

import java.util.Scanner;
public class hq{
	public static boolean HQ(String x){
		for(int i=0;i<x.length();i++)
			if(x.charAt(i)=='H'||x.charAt(i)=='Q'||x.charAt(i)=='9')
				return true;
		return false;
	}
	public static void main (String[]args){
	Scanner sc=new Scanner(System.in);
	String X=sc.nextLine();
	System.out.println(HQ(X)?"YES":"NO");
	}
}