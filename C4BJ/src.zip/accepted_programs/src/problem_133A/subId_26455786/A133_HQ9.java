package problem_133A.subId_26455786;

import java.util.Scanner;

/**
 * Created by 3ale2 on 4/16/17.
 */
public class A133_HQ9 {
    public static void main (String [] args ) {
        Scanner scan = new Scanner(System.in);
        String s = scan.next();
        boolean b = false;
        for(int i = 0 ; i < s.length() ; i ++ ){
            char c = s.charAt(i);
            if(c == 'H' || c == 'Q' ||  c == '9')
                b = true;
        }
        if(b)System.out.println("YES");
        else System.out.println("NO");
    }
}