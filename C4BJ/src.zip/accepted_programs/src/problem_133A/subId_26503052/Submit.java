package problem_133A.subId_26503052;

import java.util.Scanner;

public class Submit {

    public static void main(String args[]) {
            
        String s = new Scanner(System.in).next();
        System.out.println(s.contains("9") || s.contains("H") || s.contains("Q") ? "YES" : "NO");
    }

}