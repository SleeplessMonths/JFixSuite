package problem_133A.subId_27710438;

import java.util.Scanner;
public class MainClass {

	public static void main(String[] args) throws Exception {
	Scanner s;
	String instruction;
	s=new Scanner(System.in);
	instruction=s.nextLine();
	if(instruction.contains("H")|| instruction.contains("Q")|| instruction.contains("9"))
		System.out.println("YES");
	else System.out.println("NO");
	s.close();
	
}
}