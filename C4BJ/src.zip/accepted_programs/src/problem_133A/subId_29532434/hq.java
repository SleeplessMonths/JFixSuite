package problem_133A.subId_29532434;

import java.util.Scanner;

public class hq {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
String s=sc.next();
for(int i=0;i<s.length();i++){
	char x=s.charAt(i);
	if(x=='Q'||x=='H'||x=='9'){
		System.out.println("YES");
		return;
	}
	
}
System.out.println("NO");
	}

}