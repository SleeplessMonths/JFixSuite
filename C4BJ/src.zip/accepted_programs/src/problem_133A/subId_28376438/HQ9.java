package problem_133A.subId_28376438;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class HQ9 {
	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		String word = reader.readLine();
		boolean ans = false;
		for(int i =0;i<word.length();i++){
			if(word.charAt(i)=='H' || word.charAt(i)=='Q'||word.charAt(i)=='9'){
				ans = true;
			}
		}
		if(ans){
			System.out.println("YES");
		}
		else
			System.out.println("NO");
	}

}