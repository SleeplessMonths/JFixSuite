package problem_133A.subId_28959420;

import java.util.Scanner;

public class HQ9plus {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		String str = s.nextLine();
		if (str.contains("H") || str.contains("Q") || str.contains("9")){
			System.out.println("YES");
		}else{
			System.out.println("NO");
		}
		
		
	}

}