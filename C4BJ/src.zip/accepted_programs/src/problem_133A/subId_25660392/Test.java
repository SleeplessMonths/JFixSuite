package problem_133A.subId_25660392;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Test{
 
public static void main(String[] args) throws IOException{
    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
    String s=br.readLine();
    if(s.indexOf("H")==-1 && s.indexOf("Q")==-1 && 
    	s.indexOf("9")==-1){
    		System.out.println("NO");
    	} 
    	else{
    		System.out.println("YES");
    	}
}

}