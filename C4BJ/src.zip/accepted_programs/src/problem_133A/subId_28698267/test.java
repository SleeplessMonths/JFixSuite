package problem_133A.subId_28698267;

import java.util.Scanner;
public class test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String word = sc.next();
		if (word.contains("H") || word.contains("Q") || word.contains("9"))
			System.out.println("YES");
		else
			System.out.println("NO");
	}
}