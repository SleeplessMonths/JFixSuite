package problem_133A.subId_29290498;

import java.util.Scanner;
public class Codeforces{
    String cmds(String s){
        int flag=0;
        for(int i=0;i<s.length();i++){
            if(flag==1) break;
            if(s.charAt(i)=='H') flag=1;
            if(s.charAt(i)=='Q') flag=1;
            if(s.charAt(i)=='9') flag=1;
            //if(s.charAt(i)=='+') flag=1;
            
        }
        if(flag==1) return "YES";
        else return "NO";
    }
    
    public static void main(String args[]){
        Scanner in=new Scanner(System.in);
        Codeforces ob=new Codeforces();
        String str=in.nextLine();
        System.out.println(ob.cmds(str));
    }
}