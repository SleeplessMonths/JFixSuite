package problem_133A.subId_26134489;

import java.util.Scanner;

public class Main{
	public static void main (String args[]){
		Scanner in = new Scanner(System.in);
		String n = in.nextLine();
		String output = "NO";
		char c[] = {'H', 'Q', '9'};
		for(int i = 0; i<n.length(); i++){
			if(isCommand(c, n.charAt(i))){
				output = "YES";
				break;
			}
		}
		
		System.out.println(output);
	}
	
	public static boolean isCommand(char[] c, char x){
		for(char i : c){
			if(x == i)
				return true;
		}
		return false;
	}
}