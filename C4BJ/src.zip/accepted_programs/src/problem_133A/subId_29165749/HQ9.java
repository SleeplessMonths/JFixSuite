package problem_133A.subId_29165749;

import java.util.Scanner;

public class HQ9 {
	public static void main(String[] args) {
		String[] h9 = { "H", "Q", "9"};
		Scanner scan = new Scanner(System.in);
		String input = scan.nextLine();
		String[] line = input.split(" ");
		boolean result = false;
		for (String word : line) {
			for (String test : h9) {
				if (word.contains(test)) {
					System.out.println("YES");
					result = true;
					break;
				}
			}

		}
		if (result == false) {
			System.out.println("NO");
		}
	}
}