package problem_133A.subId_28787384;

import java.util.Scanner;
public class JokeLanguage
{
	public static void main (String[] args) 
	{
	    Scanner input = new Scanner(System.in);
	    
	    String inputString = input.next();
	    
	    if(inputString.contains("H") || inputString.contains("Q") || inputString.contains("9"))
	    {
	        System.out.println("YES");
	    }
	    else
	    {
	        System.out.println("NO");
	    }
	}
}