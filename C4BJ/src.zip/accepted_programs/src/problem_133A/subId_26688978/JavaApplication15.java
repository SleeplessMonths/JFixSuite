package problem_133A.subId_26688978;

import java.util.Scanner;


public class JavaApplication15 {

    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        int c=0;
        for(int i=0;i<s.length();i++){
            if(s.charAt(i)=='H'||s.charAt(i)=='Q'||s.charAt(i)=='9'){
                c=c+1;
            }
        }
        if(c==0){
            System.out.println("NO");
        }
        else{
            System.out.println("YES");
        }
    }
    
}