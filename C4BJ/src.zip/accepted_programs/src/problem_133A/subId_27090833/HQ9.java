package problem_133A.subId_27090833;

import java.util.Scanner;

public class HQ9 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		String line = s.nextLine();
		if(line.contains("Q") || line.contains("H")  || line.contains("9")){
			System.out.println("YES");
		}else{
			System.out.println("NO");
		}
	}
}