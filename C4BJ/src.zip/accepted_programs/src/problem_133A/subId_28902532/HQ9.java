package problem_133A.subId_28902532;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class HQ9 {
	public static void main(String[] args)throws Throwable {
		BufferedReader bf = new BufferedReader(new InputStreamReader (System.in));
		PrintWriter pw = new PrintWriter(System.out, true);
		String input=bf.readLine();
		if(input.contains("Q")||input.contains("9")||input.contains("H"))
			pw.println("YES");
		else
			pw.println("NO");
		pw.close();
	}
}