package problem_133A.subId_25533483;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        String str = sc.nextLine();
//        if (str.contains("H") || (str.contains("Q")) || (str.contains("9")) || (str.contains("+"))) {
//            System.out.print("YES");
//        } else {
//            System.out.print("NO");
//        }
        int k = str.length();
        String strT = "HQ9";
        String temp="";
        boolean a=true;
        for (int i = 0;i<k;i++) {
            temp += str.charAt(i);
            if (strT.contains(temp)) {
                a=false;
            }
            temp = "";
        }
        if (a) {
            System.out.print("NO");
        } else {
            System.out.print("YES");
        }

    }
}