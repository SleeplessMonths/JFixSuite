package problem_133A.subId_26465426;

import java.util.Scanner;
public class HQ9plus {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String p  = in.nextLine();
		
		if(p.contains("H") || p.contains("Q") || p.contains("9"))
			System.out.println("YES");
		else
			System.out.println("NO");			
	}
}