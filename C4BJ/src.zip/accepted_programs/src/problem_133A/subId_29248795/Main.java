package problem_133A.subId_29248795;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;



public class Main {

    public static void main(String[] args) throws IOException {
        FileWriter fout = new FileWriter (new File("output.txt"));
        //Scanner fin = new Scanner(new File("input.txt"));

        Scanner fin = new Scanner(System.in);

        String s = fin.nextLine();
        boolean state = false;
        for(int i=0; i<s.length(); i++) {
            if(s.charAt(i)=='H' || s.charAt(i)=='Q' || s.charAt(i)=='9') {
                state = true;
            }
        }
        if(state==true) System.out.println("YES");
        else System.out.println("NO");
        fout.flush();
        fout.close();
    }
}