package problem_133A.subId_26678881;

import java.util.Scanner;

public class Edit {

 
    public static void main(String[] args) {
        Scanner sc = new  Scanner(System.in);
        
        String t = sc.next();
        
        if (t.contains("H") || t.contains("9") || t.contains("Q"))
            System.out.println("YES");
        else
            System.out.println("NO");
    }
    
}