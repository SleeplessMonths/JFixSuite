package problem_133A.subId_25595378;

import java.util.Scanner;
public class HQ9 {
	public static void main(String[] args){
		Scanner in = new Scanner(System.in);
		String str = in.nextLine();
		if (str.contains("H") ||str.contains("Q") || str.contains("9")){
			System.out.println("YES");
		}else{
			System.out.println("NO");
		}
	}
}