package problem_133A.subId_28936653;

import java.util.Scanner;

/* Name of the class has to be "Main" only if the class is public. */
public class Ideone
{
	public static void main (String[] args) throws java.lang.Exception
	{
		// your code goes here
     Scanner sc=new Scanner(System.in);
     String str=sc.next();
int flag=0;
     for(int i=0;i<str.length();i++)
{
       if(str.charAt(i)=='H' || str.charAt(i)=='Q' || str.charAt(i)=='9')
        {
          flag=1;
          break;
         }
}
if(flag==1)
System.out.println("YES");
else
System.out.println("NO");
}         
}