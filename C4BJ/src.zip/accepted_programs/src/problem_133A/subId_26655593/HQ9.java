package problem_133A.subId_26655593;

public class HQ9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s = new java.util.Scanner(System.in).next();
if (s.contains("H") || s.contains("Q") || s.contains("9")   ) {
	System.out.println("YES");
}
else {
	System.out.println("NO");
}
	}

}