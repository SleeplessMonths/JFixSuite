package problem_133A.subId_26655701;

import java.util.Scanner;

public class Translation {

	public static void main(String[] args) {
		Scanner Enter = new Scanner(System.in);
		String P;
		P = Enter.nextLine();
		int x = 2;

		
		for (int i = 0; i < P.length() ; i++) {
			if (P.charAt(i) == 'H' || P.charAt(i) == 'Q' ||P.charAt(i) == '9') {
				System.out.println("YES");
				x = 1;
				break;
			}
		}
		if (x == 2) {
			System.out.println("NO");
		}
	}
}