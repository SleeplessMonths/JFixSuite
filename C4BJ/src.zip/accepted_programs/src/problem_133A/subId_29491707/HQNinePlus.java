package problem_133A.subId_29491707;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class HQNinePlus{
	public static void main (String [] args) throws IOException{
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		String line = in.readLine();
		line = line.trim();
		if (line.contains("H") || line.contains("Q") || line.contains("9")){
			System.out.println("YES");
		}else{
		System.out.println("NO");
		}
	}
}