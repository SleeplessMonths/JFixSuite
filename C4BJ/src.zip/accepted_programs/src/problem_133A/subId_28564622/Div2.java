package problem_133A.subId_28564622;

import java.io.PrintStream;
import java.util.Scanner;

public class Div2 {

    public static void main(String[] args) {
        PrintStream p = System.out;
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        int c =0;
        for(int i=0;i<s.length();i++){
            char x = s.charAt(i);
            if(x!='H'&&x!='Q'&&x!='9')
                continue;
            c++;
        }
        if(c>0)
            p.print("YES");
        else
            p.print("NO");
    }
}