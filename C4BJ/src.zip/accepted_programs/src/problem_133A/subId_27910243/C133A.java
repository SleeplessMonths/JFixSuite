package problem_133A.subId_27910243;

import java.util.Scanner;
public class C133A{
	public static void main(String [] args){
		Scanner s=new Scanner(System.in);
		String str=s.nextLine();
		byte[] barr=str.getBytes(); 
          int num=0;		
          for(int i=0;i<barr.length;i++)
		  {  
          if(barr[i]>=33 && barr[i]<=126){
            num++; 				 
		  }
		  } 
		  while(num==barr.length){
             if(str.contains("H")||str.contains("Q")||str.contains("9"))
			 {System.out.println("YES");
		 break;}
             else
			 {System.out.println("NO");
		 break;}
		  }		 
		}
		}