package problem_133A.subId_29344297;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String word = scanner.next();
        System.out.println(word.matches(".*(H|Q|9)+.*")?"YES":"NO");
    }

}