package problem_133A.subId_28967850;

import java.util.Scanner;

public class Solution {


    public static void main(String[] args) { 
        Scanner in =new Scanner(System.in);
        String temp=in.next();
       if(temp.contains("H") ||temp.contains("Q") ||temp.contains("9")   ){
    	   System.out.println("YES");
       }
       else{
    	   System.out.println("NO");
       }
       
}
}