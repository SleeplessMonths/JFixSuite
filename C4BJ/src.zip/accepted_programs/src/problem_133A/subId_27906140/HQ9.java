package problem_133A.subId_27906140;

import java.util.Scanner;
import java.util.regex.Pattern;

public class HQ9 {
    public static void main(String[] args){
        String word = new Scanner(System.in).nextLine();
        Pattern p = Pattern.compile("[H Q 9]");
        if (p.matcher(word).find()){
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
    }
}