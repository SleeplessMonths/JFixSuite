package problem_133A.subId_28678365;

import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String string= sc.next();
		char array[]= string.toCharArray();
		short test=0;
		for(int i=0; i<array.length; i++){
			if(array[i]=='H'||array[i]=='Q'||array[i]=='9'){
				test++;
			}
		}
		if(test>0){
			System.out.println("YES");
		}else{
			System.out.println("NO");
		}
	}
}