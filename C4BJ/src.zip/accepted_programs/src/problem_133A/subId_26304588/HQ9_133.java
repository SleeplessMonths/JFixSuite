package problem_133A.subId_26304588;

import java.util.Scanner;

public class HQ9_133 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = new String();
		Scanner in = new Scanner(System.in);
		s=in.next();
		boolean f=false;
		if(s.contains("H")||s.contains("Q")||s.contains("9")){
			f=true;
		}
		if(f)
			System.out.println("YES");
		else
			System.out.println("NO");
	}

}