package problem_133A.subId_25540900;

/**
 * Created by Анлре on 16.03.2017.
 */
import java.util.Scanner;
public class A133 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        char [] arr = str.toCharArray();
        int count = 0;
        for (char c : arr){
            if (c == 'H' | c == 'Q' | c == '9') {
                count++;
            }
        }
        if (count > 0)
            System.out.println("YES");
        else System.out.println("NO");
    }
}