package problem_133A.subId_25856351;

//package Main;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String p = input.next();
        boolean b =false;
        
        for(int i=0; i<p.length(); i++){
            if(p.substring(i, i+1).equals("H") || p.substring(i, i+1).equals("Q") || p.substring(i, i+1).equals("9")){
                b = true;
            }
        }
        if(b == true){System.out.println("YES");}
        else if(b == false){System.out.println("NO");}
    } 
}