package problem_133A.subId_28571170;

import java.util.Scanner;

public class JavaApplication4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("[\\s\\n]");
        
        String palabra = sc.next();
        if(palabra.contains("H")||palabra.contains("Q")||palabra.contains("9")){
            System.out.println("YES");
        }
        else System.out.println("NO");
    }
}