package problem_133A.subId_29379353;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		
		String word = input.nextLine();
		
		String answer = "NO";
		
		for (int i = 0 ; i <word.length();i++){
			if (word.charAt(i)=='H'
				||	word.charAt(i)=='Q'
				||	word.charAt(i)=='9'){
				answer = "YES";
				break;
			}
		}
		System.out.println(answer);

		
		

	}
}