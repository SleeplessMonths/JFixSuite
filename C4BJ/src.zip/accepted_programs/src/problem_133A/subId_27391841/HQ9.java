package problem_133A.subId_27391841;

import java.util.Scanner;
public class HQ9 {

    public static void main(String[] args) {
        String s;
        Scanner in= new Scanner(System.in);
        s=in.next();  
        if(s.contains("H") || s.contains("Q") || s.contains("9")){
        System.out.println("YES");
        }else{
        System.out.println("NO");}
    }
    
}