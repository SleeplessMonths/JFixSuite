package problem_133A.subId_26364968;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class hq9
{
	public static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	public static PrintWriter out=new PrintWriter(System.out);
	public static void main(String args[])
	{
		try
		{
			int flag=0;
			String s=in.readLine();
			for(int i=0;i<s.length();i++)
			{
				if(s.substring(i,i+1).equals("H")||s.substring(i,i+1).equals("Q")||s.substring(i,i+1).equals("9"))
				{
					out.println("YES");
					in.close();
					flag++;
					break;
				}
			}
			in.close();
			if(flag==0)
				out.println("NO");
		}
		catch(IOException e)
		{
			out.println(e);
		}
		out.close();
	}
}