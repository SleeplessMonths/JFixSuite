package problem_133A.subId_25796765;

import java.util.Scanner;

public class HQ{
    public static void main(String args[])  {
        Scanner s = new Scanner(System.in);
        String input = s.next();
        if(input.matches(".*[HQ9].*"))  {
            System.out.print("YES");
        }else  {
            System.out.print("NO");
        }
    }
}