package problem_133A.subId_27108025;

/* package codechef; // don't place package name! */


import java.util.Scanner;


/* Name of the class has to be "Main" only if the class is public. */


public class Codechef
{
	public static void main (String[] args) throws java.lang.Exception

	{
		Scanner s = new Scanner(System.in);
		String word;
		int f=0;
		word=s.nextLine();
		
		for (int i=0; i<word.length(); i++)
		{if (word.charAt(i) == 'H' || word.charAt(i) == 'Q' || word.charAt(i) == '9')
	    {
	        System.out.println("YES");
	        i=word.length();
	        f=1;
	    }}
	    
	    if (f==0)
	    System.out.println("NO");
	}
	 
}