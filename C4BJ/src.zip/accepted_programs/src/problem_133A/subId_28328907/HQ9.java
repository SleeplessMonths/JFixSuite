package problem_133A.subId_28328907;

import java.util.Scanner;
public class HQ9 {
  public static void main(String args[]) {
    Scanner sc= new Scanner(System.in);
    int hq9=0,bcq=0,i=0;
    char a[] = sc.next().toCharArray();
    for(i=0;i<a.length;i++) {
      if(a[i]=='H'||a[i]=='Q'||a[i]=='9')
        hq9=1;
        else if(a[i]<33||a[i]>126)
        bcq=1;
    }
    if(a[0]=='+') {
      if(a.length==1)
      System.out.println("NO");
      else if(a[1]>=48&&a[1]<=57) {
        System.out.println("NO");
      }
      else if(a[1]=='+'&&hq9==0)
      System.out.println("NO");
      else if(bcq==1||hq9==0)
      System.out.println("NO");
    else
    System.out.println("YES");
   }
  else if(hq9==1&&bcq==0)
  System.out.println("YES");
  else
  System.out.println("NO");
 }
}