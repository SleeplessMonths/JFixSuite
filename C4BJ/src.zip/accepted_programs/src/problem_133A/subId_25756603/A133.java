package problem_133A.subId_25756603;

import java.util.Scanner;
public class A133 
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        char [] c = {'H','Q','9'};
        String s;
        boolean found = false;
        s = input.next();
        for(int i =0; i < s.length(); i++)
        {
            for(int j = 0; j<c.length; j++)
            {
                if(s.charAt(i) == c[j])
                {
                    System.out.print("YES");
                    found = true;
                    break;
                }        
            }
            if(found)
                break;
        }
        
        if(!found)
            System.out.print("NO");
    }
    
}