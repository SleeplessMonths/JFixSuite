package problem_133A.subId_27008725;

import java.util.Scanner;

public class cf {
	

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String s = in.next();
		if(s.contains("H") || s.contains("Q") || s.contains("9") ){
			System.out.println("YES");
		}else
		System.out.println("NO");
		
	}

}