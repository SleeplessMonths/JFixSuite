package problem_133A.subId_28168677;

/**
 * Created by Vanguard on 30-06-2017.
 */

import java.util.Scanner;
public class hq9 {
    public static void main(String args[])
    {
        Scanner in = new Scanner(System.in);
        String x = in.next();
        if(x.contains("H")||x.contains("Q")||x.contains("9"))
            System.out.println("YES");
        else
            System.out.println("NO");
    }
}