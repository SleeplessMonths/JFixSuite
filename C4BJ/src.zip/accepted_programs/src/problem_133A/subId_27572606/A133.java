package problem_133A.subId_27572606;

import java.util.Scanner;

public class A133
{
  public static void main(String[] args)
  {
    Scanner in=new Scanner(System.in);
    String p=in.next();
    int a=0;
    for (int i=0; i<(p.length());i++)
    {
      if (p.charAt(i)=='H' || p.charAt(i)=='Q' || p.charAt(i)=='9')
      {
        a=1;
      }
      
    }
    if (a==1)
    {
      System.out.println("YES");
    }
    else if (a==0)
    {
      System.out.println("NO");
    }
  }}