package problem_133A.subId_27742059;

import java.util.Scanner;
public class HQ
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        String s=sc.next();
        if(s.indexOf('H')>=0||s.indexOf('Q')>=0||s.indexOf('9')>=0)
        System.out.print("YES");
        else
        System.out.print("NO");
    }
}