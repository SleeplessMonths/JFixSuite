package problem_108A.subId_10901456;

import java.util.Scanner;

public class PalindromicTimes {

	public static void main(String[] args) {
		
		Scanner in= new Scanner (System.in);
		
		String time = in.next();
		in.close();
		
		String pal="";
		
		String h=time.substring(0, 2);
		String m=time.substring(3, 5);

		if(h.charAt(1)<='9' && h.charAt(1)>='6')
		{
			if(h.charAt(0)=='0')
			{	
				System.out.println("10:01");
				return;
			}
				
			System.out.println("20:02");
			return;
				
		}
		
		int hours=Integer.parseInt(h);
		int minutes=Integer.parseInt(m);
		
		String reversedHour =h.substring(1);
		reversedHour+=h.substring(0, 1);
		
		int reversedHour_int=Integer.parseInt(reversedHour);
		
		if(minutes>=reversedHour_int)
		{
			if(hours==23)
			{	
				System.out.println("00:00");
				return;
			}	
			if(hours==5 || hours ==15)
			{
				hours+=5;
			}
			else
			{
				hours+=1;
			}
			
		}
		
		if(hours<10)
		{
			pal+="0";
		}
		
		pal+=String.valueOf(hours);
		pal+=":";
		pal+=(String.valueOf(hours).substring(1));
		pal+=(String.valueOf(hours).substring(0,1));
		
		if(hours<10)
		{
			pal+="0";
		}
	
		System.out.println(pal);
		
	}
	
	
}