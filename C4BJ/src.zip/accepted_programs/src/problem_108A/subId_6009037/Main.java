package problem_108A.subId_6009037;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.TreeSet;
public class Main{
public static void main(String... args)throws IOException{
BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
int time = Integer.parseInt(br.readLine().replaceAll(":",""));
int[] times = new int[]{110,220,330,440,550,1001,1111,1221,1331,1441,1551,2002,2112,2222,2332};
TreeSet<Integer> x = new TreeSet<Integer>();
for (int qwe : times) x.add(qwe);

Integer rr = x.ceiling(time + 1);
if (rr == null) rr = 0;

String res = "" + rr;
while (res.length() < 4) res = "0" + res;
System.out.println(res.substring(0, 2) + ":" + res.substring(2));

}
}