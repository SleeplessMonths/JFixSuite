package problem_108A.subId_9432580;

import java.util.Scanner;

public class Main {
	public static String reverse (String Y)
	{String Q="";
	char q[] = Y.toCharArray();
	int len=q.length-1;
	while (len>=0)
	{
		Q+=q[len];
	len--;}
		
	return Q;}
public static boolean fun (int x,int y)
{String X,Y;
	if (x<10)
		X="0"+x;
	else 
	X=x+"";
	if (y<10)
		Y="0"+y;
	else 
	Y=y+"";
	Y=reverse(Y);
	if (Y.equals(X))
	{
		return true;
	}
	
return false;}
public static void main(String[] args) {

	Scanner s = new Scanner (System.in);
String S=s.next();

int x=Integer.parseInt(S.substring(0, 2));
int y=Integer.parseInt(S.substring(3));
y++;
if (y>59)
{
	y=0;
	x++;
	if (x>23)
		x=0;
}
while (!fun(x,y))
{
y++;
if (y>59)
{
	y=0;
	x++;
	if (x>23)
	{
		x=0;
	}
}
}
String X;
if (x<10)
	X="0"+x;
else X=x+"";

String Y;
if (y<10)
	Y="0"+y;
else Y=y+"";
System.out.println(X+":"+Y);

	}
}