package problem_108A.subId_20629028;

import java.io.*;
import java.util.StringTokenizer;

import static java.lang.Integer.parseInt;

public class Main {

    static StringBuilder a = new StringBuilder();

    public static void main(String[] args) throws IOException {
//        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
//(new FileReader("input.in"));
        StringBuilder out = new StringBuilder();
//        StringTokenizer tk;
//        tk = new StringTokenizer(in.readLine());
        //Scanner Reader = new Scanner(System.in);
        Reader.init(System.in);
        String x[] = Reader.next().split(":");
        // String y[]=Reader.next().split(":");
        if (new StringBuilder(x[0]).reverse().toString().compareTo("60") < 0&&parseInt(new StringBuilder(x[0]).reverse().toString())> parseInt(x[1])) {
            System.out.println(x[0] + ":" + new StringBuilder(x[0]).reverse());
        } else if (x[0].equals("23")) {
            if (parseInt(x[1]) > parseInt(new StringBuilder(x[0]).reverse().toString())) {
                System.out.println("00:00");}}
             else {
                 String h=(parseInt(x[0])+1)+"";
                while(true){
               
                if(new StringBuilder(h+"").reverse().toString().compareTo("60")<0){
               //System.out.println((parseInt(new StringBuilder(h+"").reverse().toString())<60)+" "+h);
                    if((h+"").length()<2){
                    System.out.println("0"+h+":"+h+0);}
                    else System.out.println(h+":"+new StringBuilder(h+"").reverse());
                break;
                }
                h=(parseInt(h)+1)+"";
            }
            
            }
        
    }
}

class Reader {

    static StringTokenizer tokenizer;
    static BufferedReader reader;

    public static void init(InputStream input) throws UnsupportedEncodingException {
        reader = new BufferedReader(new InputStreamReader(input, "UTF-8"));
        tokenizer = new StringTokenizer("");
    }

    public static String next() throws IOException {
        while (!tokenizer.hasMoreTokens()) {
            tokenizer = new StringTokenizer(reader.readLine());
        }
        return tokenizer.nextToken();
    }

    public static String nextLine() throws IOException {
        return reader.readLine();
    }

    public static int nextInt() throws IOException {
        return Integer.parseInt(next());
    }

    public static double nextDouble() throws IOException {
        return Double.parseDouble(next());
    }

    public static long nextLong() throws IOException {
        return Long.parseLong(next());
    }
}