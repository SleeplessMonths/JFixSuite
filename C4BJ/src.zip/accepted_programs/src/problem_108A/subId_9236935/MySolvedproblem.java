package problem_108A.subId_9236935;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author user
 */
public class MySolvedproblem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
    
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in) );
    
        String s= in.readLine();
        
        int HH = Integer.parseInt(s.substring(0, s.indexOf(':')));
        int MM = Integer.parseInt(s.substring(s.indexOf(':')+1 ,s.indexOf(':')+3 ));
        if(HH>=23 && MM>=32)
            System.out.println("00:00");
        else
        if(HH%10 < 5 && HH%10 >=0){
            if(HH <= 5 && HH >=0){
                if(MM>=Integer.valueOf(revers("0"+HH)))
            System.out.println("0"+(HH+1)+":"+revers("0"+(1+HH)));
                else 
                    System.out.println("0"+(HH)+":"+revers("0"+(HH)));
            }
            
            else{
        if(MM>=Integer.valueOf(revers(""+HH)))
                System.out.println((HH+1)+":"+revers(""+(1+HH)));
            else
            System.out.println((HH)+":"+revers(""+(HH)));
            }
        
        }
        
        else
        {
            if(HH==5 && MM<Integer.valueOf(revers(""+HH)))
                System.out.println((HH)+":"+revers(""+(HH)));
            else if(HH>=5 && HH<=9)
                System.out.println("10:01");
            else if(HH >=15 && HH<=19)
            System.out.println("20:02");
        }
        
       }
       
static String revers(String s){
return ""+s.charAt(1)+s.charAt(0);
}
        
    
    
}