package problem_108A.subId_10972939;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class CF83A {
	
	private static BufferedReader	br;
	private static StringTokenizer 	st;
	private static PrintWriter 		pw;
	// private static Timer t = new Timer();
	
	public CF83A() throws IOException {
		br = new BufferedReader(new InputStreamReader(System.in));
		pw = new PrintWriter(System.out);
	}
	
	String next() throws IOException {
        while (st == null || !st.hasMoreElements())
            st = new StringTokenizer(br.readLine());
        return st.nextToken();
    }

    boolean hasNext() {
        if (st != null && st.hasMoreElements())
            return true;

        try {
            while (st == null || !st.hasMoreElements())
                st = new StringTokenizer(br.readLine());
        }
        catch (Exception e) {
            return false;
        }

        return true;
    }

    String nextLine() throws IOException {
        return br.readLine();
    }

    int nextInt() throws IOException {
        return Integer.parseInt(next());
    }

    long nextLong() throws IOException {
        return Long.parseLong(next());
    }
    
    private static String Reverse(String s) {
    	String a = "";
    	for(int i = s.length()-1; i >= 0; i--) {
    		a += s.charAt(i);
    	}
    	return a;
    }
    
    private static boolean isReverse(String s, String a) {
    	if(s.equals(Reverse(a))) {
    		return true;
    	}
    	return false;
    }
	void solve() throws IOException{
		String[] s = next().trim().split("\\:");
		int a = Integer.parseInt(s[0]);
		int b = Integer.parseInt(s[1])+1;
		
		if(b == 60) {
			b = 0;
			a = a+1;
			if(a == 24)
				a = 0;
		}
		s[1] = ""+b;
		s[0] = ""+a;
		if(s[0].length() == 1) {
			s[0] = "0"+s[0]; 
		}
		if(s[1].length() == 1) {
			s[1] = "0"+s[1];
		}
		while(!s[0].equals(Reverse(s[1]))) {
			if(b == 60) {
				b = 0;
				a = a+1;
				if(a == 24)
					a = 0;
			}else
				b = b + 1;
			s[0] = ""+a;
			s[1] = ""+b;
			if(s[0].length() == 1) {
				s[0] = "0"+s[0]; 
			}
			if(s[1].length() == 1) {
				s[1] = "0"+s[1];
			}
		}
		pw.println(s[0]+":"+s[1]);
		/*
		if(s[0].length() == 1) {
			if(s[1].length() == 1) {
				pw.println("0"+s[0]+":"+"0"+s[1]);
			}else
				pw.println("0"+s[0]+":"+s[1]);
		}
		else {
			if(s[1].length() == 1) {
				pw.println(s[0]+":"+"0"+s[1]);
			}else
				pw.println(s[0]+":"+s[1]);
		}
		*/
		pw.flush();
	}
		
	public static void main(String[] args) throws IOException{
		 new CF83A().solve();
	 }
}