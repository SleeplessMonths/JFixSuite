package problem_108A.subId_9271829;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String s = in.next();

        int s1 = s.charAt(0) - '0';
        int s2 = s.charAt(1) - '0';
        int s3 = s.charAt(3) - '0';
        int s4 = s.charAt(4) - '0';
        int n1 = 10 * s1 + s2;
        int n2 = 10 * s3 + s4;

        if (n1 > 5 && n1 < 10) {
            s1 = 1;
            s2 = 0;
        } else if (n1 > 14 && n1 < 20) {
            if ((n1 == 15 && 10 * s2 + s1 >= 51) || n1 > 15) {
                s1 = 2;
                s2 = 0;
            }
        } else if (n1 == 23 && n2 >= 32) {
            s1 = s2 = 0;
        } else if (10 * s2 + s1 <= n2) {
            s2++;
        }
        System.out.println(s1 + "" + s2 + ":" + s2 + "" + s1);
    }
}