package problem_108A.subId_11515057;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.InputMismatchException;
import java.util.StringTokenizer;

public class Main {
  public static void main(String[] args) throws Exception {
        Reader.init(System.in);
         StringBuilder v = new StringBuilder();
        v.append(Reader.next());
        v.deleteCharAt(v.indexOf(":"));   
        String f = new String (v);
        
        for (int i = 0; i < 3; i++) {
          
            for (int j = 0; j < 10; j++) {
                
                for (int k = 0; k < 6; k++) {
                    
                    for (int l =0 ;l < 10; l++)
                    {
                        
         if(isPalin(i+""+j+""+k+""+l)&&Integer.valueOf(i+""+j+""+k+""+l)>Integer.valueOf(f)&&Integer.valueOf(i+""+j+""+k+""+l)<2359)
                        {
                            System.out.println(i+""+j+":"+k+""+l);
                            return;
                        }
                        
                        
                    }
                    
                    
                    
                }
                
                
            }
            
            
      }
        
        System.out.println("00:00");
}
     public static boolean isPalin(String d)
    {
    
         StringBuilder v = new StringBuilder();
         v.append(d);
         String s= new String (v);
         v.reverse();
        String ss= new String (v);
        return (s.equals(ss));
    }
}
class Reader {

    static BufferedReader reader;
    static StringTokenizer tokenizer;

    /**
     * call this method to initialize reader for InputStream
     */
    static void init(InputStream input) {
        reader = new BufferedReader(
                new InputStreamReader(input));
        tokenizer = new StringTokenizer("");
    }

    /**
     * get next word
     */
    static String next() throws IOException {
        while (!tokenizer.hasMoreTokens()) {
            //TODO add check for eof if necessary
            tokenizer = new StringTokenizer(
                    reader.readLine());
        }
        return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt(next());
    }

    static long nextLong() throws IOException {
        return Long.parseLong(next());
    }

    static double nextDouble() throws IOException {
        return Double.parseDouble(next());
    }

    static public void nextIntArrays(int[]... arrays) throws IOException {
        for (int i = 1; i < arrays.length; ++i) {
            if (arrays[i].length != arrays[0].length) {
                throw new InputMismatchException("Lengths are different");
            }
        }
        for (int i = 0; i < arrays[0].length; ++i) {
            for (int[] array : arrays) {
                array[i] = nextInt();
            }
        }
    }

    static public void nextLineArrays(String[]... arrays) throws IOException {
        for (int i = 1; i < arrays.length; ++i) {
            if (arrays[i].length != arrays[0].length) {
                throw new InputMismatchException("Lengths are different");
            }
        }
        for (int i = 0; i < arrays[0].length; ++i) {
            for (String[] array : arrays) {
                array[i] = reader.readLine();
            }
        }
    }
}