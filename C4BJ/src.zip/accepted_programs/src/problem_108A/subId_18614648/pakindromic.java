package problem_108A.subId_18614648;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class pakindromic {
	public static void main(String[] args) throws IOException {
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		String input=bf.readLine();
		int hour=Integer.parseInt(input.substring(0, 2));
		int min=Integer.parseInt(input.substring(3));
		int rev= reverse(hour);
		if(rev>min && rev<60){
			if(hour>9)
				if(rev>9)
					System.out.println(hour+":"+rev);
				else
					System.out.println(hour+":0"+rev);
			else
				if(rev>9)
					System.out.println("0"+hour+":"+rev);
				else
					System.out.println("0"+hour+":0"+rev);

		}
		else{
			while(true){
			++hour;
			if(hour==24){
				System.out.println("00:00");return;

			}
			
			else if(reverse(hour)<60){
					if(reverse(hour)>9)
						if(hour>9)
							System.out.println(hour+":"+reverse(hour));
						else
							System.out.println("0"+hour+":"+reverse(hour));
					else
						if(hour>9)
							System.out.println(hour+":0"+reverse(hour));
						else
							System.out.println("0"+hour+":0"+reverse(hour));
					return;
				}
				
			
			}
			
		}
	}
	public static int reverse(int hour){
		String result="";
		result+=hour%10;
		hour/=10;
		result=result+hour;
		//System.out.println(result);
		return Integer.parseInt(result);
		
	}
}