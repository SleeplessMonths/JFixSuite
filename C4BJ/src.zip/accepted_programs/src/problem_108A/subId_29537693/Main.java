package problem_108A.subId_29537693;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		// Scanner read = new Scanner(new FileInputStream(new
		// File("input.txt")));
		// PrintWriter out = new PrintWriter(new File("output.txt"));

		Scanner read = new Scanner(System.in);
		String x = read.next().toLowerCase();
		read.nextLine();
		String[] t = x.split(":");
		int a = (Integer.parseInt(t[0])) % 24;
		if (reverse(a) <= Integer.parseInt(t[1]))
			a = (a+1)%24;
		if (a >= 0 && a < 6) {
			System.out.println("0" + a + ":" + a + "0");
		}else if(a >= 6 && a<=9){
			a = 10;
			System.out.println(a + ":01");
		}
		else if (a >= 10 && a < 16) {
			System.out.println(a + ":" + reverse(a));
		}else if(a >= 16 && a <=19){
			a = 20;
			System.out.println(a + ":02" );
		}
		else if (a >= 20 && a <= 23) {
			System.out.println(a + ":" + reverse(a));
		}

	}

	private static int reverse(int a) {
		int k = 1, c = 0;
		for (int i = 0; i < 2; i++) {
			int x = a % 10;
			c += x * Math.pow(10, k);
			k--;
			a /= 10;
		}
		return c;
	}
}