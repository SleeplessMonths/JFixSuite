package problem_108A.subId_7571246;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/**
 * Created by sreenidhisreesha on 8/25/14.
 */
public class palindrome {

    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String input = null;
        try {
            input = br.readLine();
        } catch (IOException ioe) {

        }
        StringTokenizer st = new StringTokenizer(input, ":");
        int hour = 0;
        int minute = 0;
        hour = Integer.parseInt(st.nextToken());
        minute = Integer.parseInt(st.nextToken());
        if (checkPalindrome(hour, minute)) {
            minute++;
            if (minute == 60) {
                hour++;
                minute = 0;
                if (hour > 23) {
                    hour = 0;

                }
            }

        }

        while (!checkPalindrome(hour, minute)) {
                minute++;
                if (minute == 60) {
                    hour++;
                    minute = 0;
                    if (hour > 23) {
                        hour = 0;

                    }
                }
        }

        String hours = null;
        if (hour < 10 ) {
            hours = "0"+hour;
        } else {
            hours = String.valueOf(hour);
        }
        String minutes = null;
        if (minute < 10 ) {
            minutes = "0"+ minute;
        } else {
            minutes = String.valueOf(minute);
        }
        System.out.println(hours + ":" + minutes);

    }


    public static boolean checkPalindrome(int hour, int minute) {

        if ((hour % 10) == (minute / 10)) {
            if ((hour / 10) == (minute % 10)) {
                return true;
            }
            return false;
        }
        return false;
    }
}