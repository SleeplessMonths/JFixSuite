package problem_108A.subId_12307657;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main
{
	public static void main(String[] args)
	throws Exception
	{

		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		String time = reader.readLine();
		int ind = time.indexOf(":");

		int h = Integer.parseInt(time.substring(0, ind));
		int s = Integer.parseInt(time.substring(ind + 1));

		if (h == 23 && s >= 32)
			System.out.println("00:00");
		else 
		if (h == 23 || (h == 22 && s >= 22))
			System.out.println("23:32");
		else
		if (h == 22  || (h == 21 && s >= 12))
			System.out.println("22:22");
		else
		if (h == 21 || (h == 20 && s >= 2))
			System.out.println("21:12");
		else 
		if ((h > 15 && h <= 20) || (h == 15 && s >= 51))
			System.out.println("20:02");
		else 
		if (h == 15 || (h == 14 && s >= 41))
			System.out.println("15:51");
		else
		if (h == 14 || (h == 13 && s >= 31))
			System.out.println("14:41");
		else
		if (h == 13 || (h == 12 && s >= 21))
			System.out.println("13:31");
		else 
		if (h == 12 || (h == 11 && s >= 11))
			System.out.println("12:21");
		if (h == 11 || (h == 10 && s >= 1))
			System.out.println("11:11");
		else
		if ((h > 5 && h < 11) || (h == 5 && s >= 50))
			System.out.println("10:01");
		else 
		if (h == 5 || (h == 4 && s >= 40))
			System.out.println("05:50");
		else
		if (h == 4 || (h == 3 && s >= 30))
			System.out.println("04:40");
		else
		if (h == 3 || (h == 2 && s >= 20))
			System.out.println("03:30");
		else
		if (h == 2 || (h == 1 && s >= 10))
			System.out.println("02:20");
		if (h == 1 || h == 0)
			System.out.println("01:10");




	}
}