package problem_108A.subId_17146463;

import java.util.Scanner;
public class tr {
	public static void main(String[] args){
		Scanner in = new Scanner(System.in);
		String x = in.next(); String check ="";  int z =0 ; int y = 0 ;			 z =Integer.parseInt(x.substring(0, 2))  ;

		y= Integer.parseInt(x.substring(3,5));
		for(int i=1; i<=1440 ;i++     ){
			y+=1 ;
			 z+=y/60 ; y = y%60 ;
			z=z%24  ;
			if(z<10) check +="0"+z+"" ; else check +=z+"";

			if(y<10) check += "0"+y+""  ; else check +=y+"";
			
			
			
			
			if(ispalindorm(check)){System.out.println(check.substring(0, 2)+":"+check.substring(2)); break ; }
			//System.out.println(ispalindorm(check));
			check ="";
			
			
		}
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
public static boolean ispalindorm(String x){
	int i=0 ; 
	 if(x.length()==0) return false  ;
	while(i<=1){
		if(x.charAt(i)!=x.charAt(3-i)) return false  ;
		i++;
		
		
	}
	return true;
	
	
	
	
	
	
}
	
	

}