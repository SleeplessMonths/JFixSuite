package problem_108A.subId_12131555;

import java.util.Scanner;

public class A {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String in = sc.nextLine();
		int hour = Integer.valueOf(in.substring(0, 2));
		int min = Integer.valueOf(in.substring(3)) ;
		boolean initial = true;
		if(min != 59)
			min++;

		if(hour == 23 && min == 59) {
			System.out.println("00:00");
			initial = false;
		} else {
			outer:
			for(int i=hour; i<=23; i++) {
				for(int j=min; j<=59; j++) {
					if(initial) {
						min = 0;
					}

					int first = 0;
					int second = i;
					int third = 0;
					int fourth = j;

					if(i>=10) {
						first = i/10;
						second = i%10;
					}
						
					if(j>=10) {
						third = j/10;
						fourth = j%10;
					}

					if(first == fourth && second == third) {
						System.out.println("" + first + second + ":" + third + fourth);
						initial = false;
						break outer;
					}

				}
			}
		}

		if(initial)
			System.out.println("00:00");
	}
}