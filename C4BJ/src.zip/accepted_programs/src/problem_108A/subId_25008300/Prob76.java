package problem_108A.subId_25008300;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Prob76 {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String[] parts= br.readLine().split(":");
		int r1=Integer.parseInt(parts[0]);
		int r2=Integer.parseInt(parts[1]);
		br.close();
		
		if (r1 > 5 && r1 < 10){
			parts[0] = "10";
			System.out.println("10:01");
			return;
		} else if (r1 > 15 && r1 < 20) {
			System.out.println("20:02");
			return;
		}
		
		StringBuilder stringBuilder = new StringBuilder(parts[0]).reverse();
		if (Integer.parseInt(stringBuilder.toString()) > r2) {
			System.out.println(parts[0] +":"+stringBuilder);
		} else {
			r1++;
			if (r1 == 24)
				parts[0]="00";
			else if (r1 < 6)
				parts[0] = "0" + Integer.toString(r1);
			else if (r1 > 5 && r1 < 10)
				parts[0] = "10";
			else if (r1 < 16 || r1 > 19)
				parts[0] = Integer.toString(r1);
			else
				parts[0] = "20";
			stringBuilder = new StringBuilder(parts[0]).reverse();
			System.out.println(parts[0]+":"+stringBuilder);
		}
	}

}