package problem_108A.subId_10544000;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
//harish reddy anumula
public class CodeForces{
    public static void main (String[] args)throws java.lang.Exception{
        BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
        PrintWriter pw = new PrintWriter(new BufferedOutputStream(System.out));
        String a = br.readLine();
        int v = 0;
        for(int i = 0;i<a.length();i++){
            char a1 = a.charAt(i);
            if(i!=2){
                v = v + Character.getNumericValue(a1);
                v = v*10;
            }
        }
        v = v/10;
        if(v>=2332){
            pw.println("00:00");
            pw.close();
            return;
        }
        if(v%100==59){
            v = v+ 41;
        }
        else{
            v = v+1;
        }
        while(!palin(v)){
            if(v%100==59){
                v = v+ 41;
            }
            else{
                v = v+1;
            }
        }
        for(int i =0;i<5;i++){
            if(i!=2){
                pw.printf("%d",v%10);
                v = v/10;
            }
            else{
                pw.printf(":");
            }
        }
        pw.close();
    }
    public static boolean palin(int v){
        int sum = 0,count =0;
        int k  =v;
        while(k>0){
            count++;
            k= k/10;
        }
        if(count==3) return palin3(v);
        if(count==2) return false;
        if(count==0 || count ==1) return false;
        k = v;
        while(k>0){
            sum = sum*10 + k%10;
            k = k/10;
        }
        if(sum==v){
            return true;
        }
        else
        return false;

    }
    public static boolean palin3(int v){
        if(v%10 != 0) return false;
        else{
            if((v%100)/10 != (v%1000 - v%100)/100){
                return false;
            }
            else{
                return true;
            }
        }
    }
}