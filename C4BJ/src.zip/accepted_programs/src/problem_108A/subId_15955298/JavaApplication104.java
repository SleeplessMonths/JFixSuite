package problem_108A.subId_15955298;

import java.util.Scanner;

public class JavaApplication104 {

    public static void main(String[] args) {
        // TODO code application logic here

        Scanner input = new Scanner(System.in);
        String c;
        c = input.nextLine();
        String[] S = c.split(":");
        int h = Integer.parseInt(S[0]);
        int m = Integer.parseInt(S[1]);

        int ans_d1 = c.charAt(0) - '0';
        int ans_d2 = S[0].charAt(1) - '0';

        if (h > 5 && h < 10) {
            ans_d1 = 1;
            ans_d2 = 0;
        } else if (h >= 15 && h < 20) {
            ans_d1 = 2;
            ans_d2 = 0;
        } else if (h == 23 && m >= 32) {
            ans_d1 = 0;
            ans_d2 = 0;
        } else if((ans_d2*10+ans_d1)<=m){
            ans_d2++;
        }
        System.out.println(ans_d1 + "" + ans_d2 + ":" + ans_d2 + "" + ans_d1);
    }

}