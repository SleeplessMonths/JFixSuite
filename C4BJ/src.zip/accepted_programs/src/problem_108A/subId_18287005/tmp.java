package problem_108A.subId_18287005;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class tmp {
    public static void main(String [] args) throws Exception{
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
 //       StringTokenizer st = new StringTokenizer(in.readLine());
        StringBuilder sb = new StringBuilder();
        

        String  s = in.readLine();
        String h = s.substring(0,s.indexOf(":"));
        String m = s.substring(s.indexOf(":")+1);
        String t=h+m;
        if(t.compareTo("0000") >= 0 && t.compareTo("0110") < 0){
            System.out.println("01:10");
        }else if(t.compareTo("0110") >= 0 && t.compareTo("0220") < 0){
            System.out.println("02:20");
        }else if(t.compareTo("0220") >= 0 && t.compareTo("0330") < 0){
            System.out.println("03:30");
        }else if(t.compareTo("0330") >= 0 && t.compareTo("0440") < 0){
            System.out.println("04:40");
        }else if(t.compareTo("0440") >= 0 && t.compareTo("0550") < 0){
            System.out.println("05:50");
        }else if(t.compareTo("0550") >= 0 && t.compareTo("1001") < 0){
            System.out.println("10:01");
        }else if(t.compareTo("1001") >= 0 && t.compareTo("1111") < 0){
            System.out.println("11:11");
        }else if(t.compareTo("1111") >= 0 && t.compareTo("1221") < 0){
            System.out.println("12:21");
        }else if(t.compareTo("1221") >= 0 && t.compareTo("1331") < 0){
            System.out.println("13:31");
        }else if(t.compareTo("1331") >= 0 && t.compareTo("1441") < 0){
            System.out.println("14:41");
        }else if(t.compareTo("1441") >= 0 && t.compareTo("1551") < 0){
            System.out.println("15:51");
        }else if(t.compareTo("1551") >= 0 && t.compareTo("2002") < 0){
            System.out.println("20:02");
        }else if(t.compareTo("2002") >= 0 && t.compareTo("2112") < 0){
            System.out.println("21:12");
        }else if(t.compareTo("2112") >= 0 && t.compareTo("2222") < 0){
            System.out.println("22:22");
        }else if(t.compareTo("2222") >= 0 && t.compareTo("2332") < 0){
            System.out.println("23:32");
        }else{
            System.out.println("00:00");
        }   
        
        
     
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
  
    
    
    
    
    
    
    
    
    
    


    
    
    
    
}

    
class P implements Comparable<P>{
    int val, idx;
    public P(int val, int idx){
        this.val = val;
        this.idx = idx;
    }

    public int compareTo(P other){
        if (this.val != other.val) return -this.val + other.val;
        return this.idx - other.idx;
    }
}