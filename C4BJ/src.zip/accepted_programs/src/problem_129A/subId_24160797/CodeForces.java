package problem_129A.subId_24160797;

import java.util.Scanner;

/**
 *
 * @author Loay
 */
public class CodeForces {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int[] arr = new int[n];
        int total = 0;
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
            total += arr[i];
        }
        int ans = 0;
        for (int i = 0; i < n; i++) {
            int rem = total - arr[i];
            if (rem % 2 == 0) {
                ans++;
            }
        }
        
        System.out.println(ans);
    }//End Main

}//End Class