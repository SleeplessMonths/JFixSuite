package problem_129A.subId_21346107;

import java.util.Scanner;
public class me
{
 public static void main(String args[])
 {
  Scanner br=new Scanner(System.in);
 int n=br.nextInt();
 int[] arr=new int[n];
 int s=0,count=0;
 for(int i=0;i<n;i++)
 {
     arr[i]=br.nextInt();
     s+=arr[i];
 }for(int i=0;i<n;i++)
 {
     if((s-arr[i])%2==0)
     {
     count++;
    // s-=arr[i];
 }
 
 }System.out.print(count);
 }
}