package problem_129A.subId_29537583;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        short sum = 0;
        byte even = 0, odd = 0,n=in.nextByte();
        for (byte i = 0; i < n; i++) {
            byte a = in.nextByte();
            sum += a;
            if (a % 2 == 0) {
                even++;
            } else {
                odd++;
            }
        }
        if (sum % 2 == 1) {
            System.out.println(odd);
        } else {
            System.out.println(even);
        }
    }
}