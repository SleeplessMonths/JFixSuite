package problem_129A.subId_9430486;

import java.io.*;
import java.util.StringTokenizer;

public class Main {
	public static void main(String args[]) {
		InputStream inputStream = System.in;
		OutputStream outputStream = System.out;
		InputReader in = new InputReader(inputStream);
		PrintWriter out = new PrintWriter(outputStream);
		Task solver = new Task();
		solver.solve(1, in, out);
		out.close();
	}
}

class Task {
	void solve(int testNumber, InputReader in, PrintWriter out) {
		int n = in.nextInt();
		int a[] = in.nextArray(n);
		int sum = 0;
		int answer = 0;
		for (int i = 0; i < n; ++i)
			sum += a[i];
		for (int i = 0; i < n; ++i)
			if (((sum - a[i]) & 1) == 0) ++answer;
		out.println(answer);
	}
}

class InputReader {
    public BufferedReader reader;
    public StringTokenizer tokenizer;

    public InputReader(InputStream stream) {
        reader = new BufferedReader(new InputStreamReader(stream), 32768);
        tokenizer = null;
    }

    public String next() {
        while (tokenizer == null || !tokenizer.hasMoreTokens()) {
            try {
                tokenizer = new StringTokenizer(reader.readLine());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return tokenizer.nextToken();
    }
    
    public int[] nextArray(int n) {
    	int answer[] = new int[n];
    	for (int i = 0; i < n; ++i) {
    		answer[i] = nextInt();
    	}
    	return answer;
    }

    public int nextInt() {
        return Integer.parseInt(next());
    }
    
    public StringBuilder nextStringBuilder() {
    	StringBuilder answer = new StringBuilder();
    	answer.append(next());
    	return answer;
    }
}