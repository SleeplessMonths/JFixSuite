package problem_129A.subId_25122962;

import java.util.Scanner;

public class Cookies {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		byte numOfBags = scanner.nextByte();
		byte bagsWithOddNumOfCookies = 0;
		byte numOfCookies = 0;
		for(byte i = 1; i <= numOfBags; i++){
			numOfCookies = scanner.nextByte();
			if(numOfCookies % 2 != 0) bagsWithOddNumOfCookies++;
		}
		System.out.println(bagsWithOddNumOfCookies % 2 == 0 ?
				(numOfBags - bagsWithOddNumOfCookies) : bagsWithOddNumOfCookies);
		scanner.close();
	}
}