package problem_129A.subId_16737017;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class Cookies {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter pw = new PrintWriter(System.out);
        StringBuilder sb = new StringBuilder();
        String[] inputData = br.readLine().split(" ");
        String[] inputData2 = br.readLine().split(" ");
        int n = Integer.parseInt(inputData[0]);
        int oddNum = 0, evenNum = 0, amount = 0;
        for (int i = 0; i < n; i++) {
            if (Integer.parseInt(inputData2[i]) % 2 == 0)
                evenNum++;
            else
                oddNum++;
        }
        if (oddNum % 2 == 0 && oddNum > 0)
            amount += evenNum;
        else if (oddNum % 2 == 1)
            amount += oddNum;
        else
            amount += evenNum;
        pw.println(amount);
        pw.close();
    }
}