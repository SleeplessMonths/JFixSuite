package problem_129A.subId_11251106;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
public class Main {

    /**
     * @param args the command line arguments
     */
    static int Arr[] ;
    public static void main(String[] args) throws IOException {
       int A ;
       BufferedReader in = new BufferedReader (new InputStreamReader(System.in));
       A = Integer.parseInt(in.readLine());
        Arr =new int[A];
        StringTokenizer input = new StringTokenizer(in.readLine());
        int i = 0;
        while(input.hasMoreTokens())
        {
            Arr[i]=Integer.parseInt(input.nextToken());
            i++;
        }
        int counter = 0;
        for (int i1 = 0 ; i1 < A ; i1++)
        {
            if(sum(i1,A)%2==0)counter++;
        }
        System.out.println(counter);
        
    }
    
    static int sum(int A,int Size)
    {
        int sum = 0;
        for (int i =0 ; i < Size ; i++)
        {       if(i!=A)
                sum+=Arr[i];
        }
        return sum;
    }
    
}