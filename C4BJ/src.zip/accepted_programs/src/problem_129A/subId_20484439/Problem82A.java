package problem_129A.subId_20484439;

import java.util.Scanner;

public class Problem82A {

	public static void main(String args[]) {
		Scanner obj = new Scanner(System.in);
		while (obj.hasNext()) {
			int n = obj.nextInt();
			int[] a = new int[n];
			int sum = 0;
			for (int i = 0; i < n; i++) {
				a[i] = obj.nextInt();
				sum += a[i];
			}
			int count = 0;
			int s = sum % 2;
			for (int i = 0; i < n; i++) {

				if (a[i] % 2 == s) {
					count++;
				}
			}
			System.out.println(count);

		}
	}
}