package problem_129A.subId_15443528;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;
public class A 
{
	StringTokenizer st;
	BufferedReader in;
	PrintWriter ob;
	public static void main(String args[])throws IOException {
		new A().run();
	}
	void run()throws IOException   {
		in=new BufferedReader(new InputStreamReader(System.in));
		ob=new PrintWriter(System.out);
		solve();
		ob.flush();
	}
	void solve()throws IOException {
		read();
		int n=ni();
		int a[]=nia(n);
		int odd=0,even=0;
		for(int i=0;i<n;i++){
			if(a[i]%2==0)
				even+=1;
			else
				odd+=1;
		}
		if(odd%2==0)
			ob.println(even);
		else
			ob.println(odd);
	}
	void read()throws IOException  {
		st=new StringTokenizer(in.readLine());
	}
	int ni(){
		return Integer.parseInt(st.nextToken());
	}
	long nl(){
		return Long.parseLong(st.nextToken());
	}
	double nd(){
		return Double.parseDouble(st.nextToken());
	}
	String ns(){
		return st.nextToken();
	}
	char nc(){
		return st.nextToken().charAt(0);
	}
	int[] nia(int n)throws IOException {
		int a[]=new int[n];
		read();
		for(int i=0;i<n;i++){
			a[i]=Integer.parseInt(st.nextToken());
		}
		return a;
	}
	long[] nla(int n)throws IOException {
		long a[]=new long[n];
		read();
		for(int i=0;i<n;i++){
			a[i]=Long.parseLong(st.nextToken());
		}
		return a;
	}
}