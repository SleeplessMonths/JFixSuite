package problem_10C.subId_11372699;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class DigitalRoot 
{

	public static void main(String[] args) throws NumberFormatException, IOException 
	{
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		int N = Integer.parseInt(in.readLine());
		long [] Nd = new long[10];
		for (int i = 1; i<=N%9; ++i)
		{
			Nd[i] = N/9 + 1; 
		}
		for(int i = N%9+1; i<10; ++i)
		{
			Nd[i] = N/9;
		}
		long t = 0;
		for(int d1 = 1; d1 < 10; ++d1)
			for(int d2 = 1; d2 < 10; ++d2)
				t+=Nd[d1]*Nd[d2]*Nd[digitalRoot(d1*d2)];
		for(int x = 1; x <= N; ++x)
		{
			t-= N/x;
		}
		System.out.println(t);
	}
	
	public static int digitalRoot(int n)
	{
		return ((n-1)%9)+1;
	}

}