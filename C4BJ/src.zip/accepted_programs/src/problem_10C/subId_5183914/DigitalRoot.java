package problem_10C.subId_5183914;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class DigitalRoot {
    public static void main(String[] args) throws IOException {
        BufferedReader f = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(f.readLine());
        int[] a = new int[9];
        for (int i = 0; i < 9; i++) 
            a[i] = n/9;
        for (int i = 9*(n/9)+1; i <= n; i++)
            a[i%9]++;
        long sum = 0;
        for (int x = 0; x < 9; x++)
            for (int y = 0; y < 9; y++) 
                sum += 1l*a[x]*a[y]*a[(x*y)%9];
        for (int x = 1; x <= n; x++)
            sum -= n/x;
            
        System.out.println(sum);
    }   
}