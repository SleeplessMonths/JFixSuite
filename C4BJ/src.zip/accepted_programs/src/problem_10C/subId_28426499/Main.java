package problem_10C.subId_28426499;

import java.io.*;
import java.util.StringTokenizer;

public class Main {
    public static void main(String[] args) throws IOException {
        InputStream inputStream = System.in;
//        InputStream inputStream = new FileInputStream("sum.in");
        OutputStream outputStream = System.out;
//        OutputStream outputStream = new FileOutputStream("sum.out");


//        Path path = Paths.get(URI.create("file:///foo/bar/Main.java"));
//        System.out.print(path.getName(200));

//        Path p = Paths.get("/foo/bar/Main.java");
//        for (Path e : p) {
//            System.out.println(e);
//        }

        InputReader in = new InputReader(inputStream);
        PrintWriter out = new PrintWriter(outputStream);
        Answer solver = new Answer();
        solver.solve(in, out);
        out.close();
    }
}

class Answer {
    private final int INF = (int) (1e9 + 7);
    private final int MOD = (int) (1e9 + 7);
    private final int MOD1 = (int) (1e6 + 3);
    private final long INF_LONG = (long) (1e18 + 1);
    private final double EPS = 1e-9;

    public void solve(InputReader in, PrintWriter out) throws IOException {
        int n = in.nextInt();

        int[][] a = new int[9][9];
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                a[i][j] = (i * j) % 9;
            }
        }

        int[] b = new int[9];
        for (int i = 1; i <= n; i++) {
            b[i % 9]++;
        }

        long x = 0;
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                x += 1L * b[i] * b[j] * b[a[i][j]];
            }
        }

        long y = 0;
        for (int i = 1; i <= n; i++) {
            y += n / i;
        }

        out.print(x - y);
    }
}

class InputReader {
    private BufferedReader reader;
    private StringTokenizer tokenizer;

    InputReader(InputStream stream) {
        reader = new BufferedReader(new InputStreamReader(stream), 32768);
        tokenizer = null;
    }

    public String next() {
        while (tokenizer == null || !tokenizer.hasMoreTokens()) {
            try {
                tokenizer = new StringTokenizer(reader.readLine());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return tokenizer.nextToken();
    }

    public int nextInt() {
        return Integer.parseInt(next());
    }

    public long nextLong() {
        return Long.parseLong(next());
    }
}