package problem_110A.subId_28745689;

import java.util.Scanner;
public class Main { 
    public static void main (String [] args){
        Scanner in = new Scanner (System.in);
        String s = in.next();
        int count=0;
        for(int i = 0; i<s.length(); i++){
            if(s.charAt(i)=='4' || s.charAt(i)=='7'){
                count++;
            }
        }
        if(count==4||count==7){
            System.out.print("YES");
        } else System.out.print("NO");
    }
}