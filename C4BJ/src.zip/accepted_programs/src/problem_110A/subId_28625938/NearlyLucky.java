package problem_110A.subId_28625938;

import java.util.Scanner;

public class NearlyLucky {

public static void main (String [] args){
		
		
		Scanner input = new Scanner(System.in);
	
		String x= input.next();
		 int count=0;
		 boolean n = true;
		 for (int i=0;i<x.length();i++){
		  
			 if(x.charAt(i)=='7'||x.charAt(i)=='4')
				 count++;
			 else n= false;
		 
		 }
		 
		 if (n&&(count==7||count==4))
			 System.out.print("YES");
		 else if (count==7||count==4)
			 System.out.print("YES");
		 else 
			 System.out.print("NO");
			 
		
	}
	
}