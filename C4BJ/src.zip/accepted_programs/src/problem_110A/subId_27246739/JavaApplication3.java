package problem_110A.subId_27246739;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 
import java.util.Scanner;

/**
 *
 * @author Emad
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
        String str = in.next();
        int total=0;
        for(int i=0;i<str.length();i++){
            if(str.charAt(i)=='4'||str.charAt(i)=='7')
                total++;
        }
            
        if(total==7||total==4)
            System.out.println("YES");
        else
            System.out.println("NO");
        
       
    }
//    static int gcd(int a, int b){
//        a = Math.abs(a); b = Math.abs(b);
//        return (b==0) ? a : gcd(b, a%b);
//    }

}