package problem_110A.subId_25802415;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author DHARMENDRA
 */import java.util.Scanner;
public class Nearly {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        String x=in.next();int c=0;char a[]=x.toCharArray();
        for(int i=0;i<x.length();i++){
            if((a[i]=='4')||(a[i]=='7')){
                c++;
        }}if((c==4)||(c==7)){
            System.out.println("YES");
        }else{
            System.out.println("NO");
        }
        // TODO code application logic here
    }
    
}