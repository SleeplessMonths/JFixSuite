package problem_110A.subId_28473149;

import java.util.Scanner;
public class A_NearlyLuckyNumber {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.next();
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == '4' || str.charAt(i) == '7')
                count++;
        }
        System.out.println(count ==7 || count == 4? "YES" : "NO");
    }
}