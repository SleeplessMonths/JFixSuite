package problem_110A.subId_27555501;

import java.util.Scanner;

public class CF {

    public static void main(String[] args) {
        int t = 0;
        Scanner in = new Scanner(System.in);

        String x = in.next();
        
        for (int i = 0; i < x.length(); i++) {
            
            if(Integer.parseInt(x.charAt(i)+"") == 7 || Integer.parseInt(x.charAt(i)+"") == 4)
                t++;            
        }
  
        if(t == 7 || t == 4)
            System.out.println("YES");
        else
            System.out.println("NO");
    }


}