package problem_110A.subId_28882009;

import java.util.Scanner;


public class Test {
    public static void main(String args[] ) throws Exception {
        Test test = new Test();
        Scanner in = new Scanner(System.in);
        String n = in.next();
        int digits = n.length();
        int luckynumbers = 0;
        
        for(int i = 0 ; i < digits ; i++){
           int key = 1;
           for(int j = i ; j < digits ; j++){
              key *= 2;
           }
           luckynumbers += key;
        }
         
        int luckynumbersinn = 0;
        for(int i = 0 ; i < digits ; i++){if(n.charAt(i) == '4' || n.charAt(i) == '7') luckynumbersinn++;}
        
        long[] arr = new long[luckynumbers];
        int currindex = 0;
        
        for(int i = 0 ; i < digits ; i++){
           currindex = test.luckynumbergenerate(currindex, "", i, arr);
        }

        String ans = "NO";
        for(long x : arr) {if(luckynumbersinn == x) {ans = "YES";}}
        System.out.println(ans);
    }
                                    
    public int luckynumbergenerate(int index, String s, int digits, long[] arr){
         arr[index] = Long.parseLong(s + "4");
         if(digits > 0)  index = luckynumbergenerate(index, Long.toString(arr[index]), digits-1, arr);
         else index++;
             
         arr[index] = Long.parseLong(s + "7");
         if(digits > 0) index = luckynumbergenerate(index, Long.toString(arr[index]), digits-1, arr);
         else index++;
         
         return index;
    }
}