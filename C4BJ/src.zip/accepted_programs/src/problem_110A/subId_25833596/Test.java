package problem_110A.subId_25833596;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Test{
 
public static void main(String[] args) throws IOException{
    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
    String s=br.readLine();
    int res=0;
    for(int i=0;i<s.length();i++){
    	if(s.charAt(i)=='4' || s.charAt(i)=='7'){
    		res++;
    	}
    }

    int m=res;
    String ret="YES";
    if(m==0){
    	ret="NO";
    }
    
    while(m!=0){
    	if(m%10!=4 && m%10!=7){
    		ret="NO";
    		break;
    	}
    	m/=10;
    }
    System.out.println(ret);
}

    
}