package problem_110A.subId_26241574;

import java.util.Scanner;

public class nearlyLuckyNumber
{
  public static void main(String[] args)
  {
    Scanner reader = new Scanner(System.in);
    String n = reader.nextLine(); //input
    int output = 0;

    for(int i = 0; i < n.length(); i++)
    {
      String sub = n.substring(i,i+1);
      if(sub.equals("4") || sub.equals("7"))
      output++;
    }

    if(output == 4 || output == 7)
    System.out.print("YES");
    else
    System.out.print("NO");
  }
}