package problem_110A.subId_29512260;

import java.util.Scanner;

public class LuckNumber {

	private static final Integer [] NUMBERS = new Integer[]{4, 7, 47, 74, 744, 774, 777, 474, 477, 447, 444, 747};
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String word = sc.next();
		int countLuck = 0;
		for(int i = 0 ; i < word.length(); i++){
			if(word.charAt(i) == '4' || word.charAt(i) == '7'){
				countLuck ++;
			}
		}
		for(int i = 0 ; i < NUMBERS.length; i++){
			if(countLuck == NUMBERS[i]){
				System.out.println("YES");
				return;
			}
		}
		System.out.println("NO");
	}

	
}