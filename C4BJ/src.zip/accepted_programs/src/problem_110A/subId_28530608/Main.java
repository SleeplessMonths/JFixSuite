package problem_110A.subId_28530608;

import java.util.Scanner;
public class Main {
    
    public static void main(String[] args) {
        
    Scanner in=new Scanner(System.in);
    
   //inputs
    long n = in.nextLong();
    	
    String s = n+"";
    
    int cnt = 0;
    for(int i=0 ; i<s.length() ; i++)
    	if(s.charAt(i) == '4' || s.charAt(i) == '7')
           cnt++;
    System.out.println(cnt == 4 || cnt == 7 ? "YES" : "NO");
      }
    }