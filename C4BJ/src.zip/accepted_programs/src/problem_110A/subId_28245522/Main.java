package problem_110A.subId_28245522;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String s = in.nextLine();
		int sum = 0;
		for(int i=0; i<s.length(); i++)
		{
			if(s.charAt(i) == '4' || s.charAt(i) == '7')
				sum ++;
		}
		if(sum == 4 || sum == 7 )
			System.out.println("YES");
		else
			System.out.println("NO");
	}
}