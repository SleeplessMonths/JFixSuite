package problem_110A.subId_26961794;

import java.util.Scanner;
public class Get {
    public static void main(String []args) 
{
    Scanner in=new Scanner(System.in);
    
    int n=0;
    String s=in.next();

char ch[]=s.toCharArray();
for(int i=0;i<s.length();i++)
{
if(ch[i]=='4'||ch[i]=='7')
n++;
}

  if(n==4||n==7)
    System.out.println("YES");
     
        else 
       System.out.println("NO");
        
   
}}