package problem_110A.subId_27052691;

import java.util.Scanner;
public class NearlyLuckyNumber {
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		char[] arr = in.nextLine().toCharArray();
		int counter = 0;
		
		for(int i = 0; i < arr.length; i++){
			if((arr[i] == '4') || (arr[i] == '7'))
				counter++;
		}
		if(((counter == 4) || (counter == 7)) && (counter > 0))
			System.out.println("YES");
		else
			System.out.println("NO");

		
	}
}