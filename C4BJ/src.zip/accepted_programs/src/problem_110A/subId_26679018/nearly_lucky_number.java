package problem_110A.subId_26679018;

import java.util.Scanner;
public class nearly_lucky_number {
	public static void main(String args[])
	{
		Scanner scan= new Scanner(System.in);
		String s;
		s=scan.nextLine();
		int i,length,temp=0;
		length=s.length();
		for(i=0;i<length;i++)
		{
			if(s.charAt(i)=='4' || s.charAt(i)=='7')
				temp++;
		}
		int flag=0;
		if(temp==0)
			flag=1;
		while(temp!=0)
		{
			if(temp%10==4 || temp%10==7)
			{
				
			}
			else
			{
				flag=1;
				break;
			}
			temp=temp/10;
		}
		if(flag==1)
			System.out.println("NO");
		else
			System.out.println("YES");
	}

}