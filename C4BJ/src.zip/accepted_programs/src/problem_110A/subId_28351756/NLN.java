package problem_110A.subId_28351756;

import java.util.Scanner;
public class NLN
{
	public static void main (String[] args) throws java.lang.Exception
	{
		Scanner sc=new Scanner(System.in);
		char arr[]=sc.next().toCharArray();
		int d=0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]=='4'||arr[i]=='7')
			d++;
		}
		if(d==4||d==7)
		System.out.println("YES");
		else
		System.out.println("NO");
	}
}