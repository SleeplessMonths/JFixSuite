package problem_110A.subId_26098059;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    public static void main(String[] args) throws IOException {
        BufferedReader scan =new BufferedReader(new InputStreamReader(System.in));
        long n = Long.parseLong(scan.readLine());
        if(isNearlyLucky(n))
            System.out.println("YES");
        else
            System.out.println("NO");
    }
    public static boolean isNearlyLucky(long n){
        long copy=n;
        int r=0,count_7=0,count_4=0,total=0;
        while(copy!=0){
            r = (int)(copy%10);
            copy = copy/10;
            if(r==7)
                count_7++;
            else if(r==4)
                count_4++;
            total++;
        }
        int temp=count_7+count_4;
        if(temp!=0 && (temp==4 || temp==7))
            return true;
        return false;
    }
    
}