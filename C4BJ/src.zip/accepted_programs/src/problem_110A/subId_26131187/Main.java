package problem_110A.subId_26131187;

import java.util.Scanner;

public class Main
{
    public static void main(String args[])
    {
     
        long a,b,c=0;
        Scanner ob=new Scanner(System.in);
        a= ob.nextLong();
        while (a!=0)
        {
            b = a%10;
           
           if((b==4)||(b==7))
           {    
                c++;
               
                
            }
           a=a/10;
           
        }
        boolean temp=true;
        if(c==0)
        {
            temp=false;
        }
    while(c!=0)
       {
            b=c%10;
            
          if((b!=4)&&(b!=7))
          {
          temp=false;
          break;
              
          }
          c=c/10;
           
       }
       if(temp==false)
       System.out.print("NO");
       else
       System.out.print("YES"); 
       
      
    }
}