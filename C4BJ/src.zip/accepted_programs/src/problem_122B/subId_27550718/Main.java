package problem_122B.subId_27550718;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;
import java.util.HashMap;
import java.util.Map;

public class Main {

    static StreamTokenizer st;

    public static void main(String[] args) throws IOException {
        st = new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
        st.resetSyntax();
        st.whitespaceChars(0, ' ');
        st.wordChars('0', '9');
        st.nextToken();
        String s = st.sval;
        HashMap<String, Integer> map = new HashMap();
        for (int i = 0; i < s.length(); i++) {
            for (int j = i; j < s.length(); j++) {
                String x = s.substring(i, j + 1);
                if (islucky(x)) {
                    if (!map.containsKey(x)) {
                        map.put(x, 1);
                    } else {
                        map.put(x, map.get(x) + 1);
                    }
                } else {
                    break;
                }
            }
        }
        int max = 0;
        String res = "-1";
        for (Map.Entry<String, Integer> e : map.entrySet()) {
            if (e.getValue() > max) {
                res = e.getKey();
                max = e.getValue();
            } else if (e.getValue() == max) {
                res = (res.compareTo(e.getKey()) < 0) ? res : e.getKey();
            }
        }
        System.out.println(res);
    }

    static boolean islucky(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (!(s.charAt(i) == '4' || s.charAt(i) == '7')) {
                return false;
            }
        }
        return true;
    }

    static int ri() throws IOException {
        st.nextToken();
        return (int) st.nval;
    }
}