package problem_114A.subId_29138559;

import java.io.BufferedReader;
import java.io.InputStreamReader;
public class Cifera
{
	public static void main(String args[]) throws Exception
	{
		BufferedReader f=new BufferedReader(new InputStreamReader(System.in));
		int num=Integer.parseInt(f.readLine());
		int pow=Integer.parseInt(f.readLine());
		if(Math.abs(Math.log(pow)/Math.log(num)-Math.round(Math.log(pow)/Math.log(num)))<.000000000001)
		{
			System.out.println("YES");
			System.out.println(Math.round(Math.log(pow)/Math.log(num))-1);
		}
		else
			System.out.println("NO");
	}
}