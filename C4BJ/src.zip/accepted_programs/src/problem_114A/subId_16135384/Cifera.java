package problem_114A.subId_16135384;

import java.util.Scanner;
public class Cifera {

    
    public static void main(String[] args)
    {
        Scanner in=new Scanner(System.in);
        long k=in.nextLong();
        long l=in.nextLong();
        boolean flag=false;
        int count=0;
        long Max=Math.max(k, l);
        long Min=Math.min(k, l);
        long res=Min;
     
     if (Max%Min==0&&k<=l)
     {
           
            
            while(res<Max)
            {
                res=res*Min;
                if (res<=Max)
                {
                    count++;
                }
                
                if (res>Max)
                {
                    System.out.println("NO");
                    return;
                }
                
                    
            }
            System.out.println("YES");
            System.out.println(count);
                
     }
        else
        {
            System.out.println("NO");
        }
        
        
       
    }
    
}