package problem_114A.subId_12791456;

import java.util.Scanner;

public class element {   
    
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int k=sc.nextInt();
        int l=sc.nextInt();
        int res=0;
        while (l % k == 0){
            l/=k;
            res++;
        }
        res--;
        if (l!=1 || res==-1) System.out.println("NO");
        else System.out.println("YES\n"+res);
    }

    
}