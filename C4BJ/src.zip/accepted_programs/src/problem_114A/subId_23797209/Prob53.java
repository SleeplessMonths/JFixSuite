package problem_114A.subId_23797209;

import java.util.Scanner;


public class Prob53 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		long k = s.nextLong();
		long l = s.nextLong();
		s.close();
		double res = Math.log10(l)/Math.log10(k);
		res = (double)Math.round(res * 100000000000000d) / 100000000000000d;
		if (res == (int)res){
			System.out.println("YES"+" "+((int)res-1));
		}else
			System.out.println("NO");

	}

}