package problem_114A.subId_22247073;

import java.util.Scanner;
public class A {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
        long k=sc.nextLong();
        long l=sc.nextLong();
        long count=0,m;
        long d=k;
        while(d<=l){m=d;
         if(d==l) { 
        	 System.out.println("YES\n"+count);
        	 break;
        	 }
         else if(d!=l){
        	 
        	 d*=k;
             count++;
         }
         if(m==d) {
        	 System.out.println("NO");
        	 break;
         }
        }
        if(d>l) System.out.println("NO");
      }
}