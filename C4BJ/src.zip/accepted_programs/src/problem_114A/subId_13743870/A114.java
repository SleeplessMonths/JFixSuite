package problem_114A.subId_13743870;

//package codeForces;

import java.util.Scanner;

public class A114 {
	
	public static void main (String[] args) {
		
		Scanner i = new Scanner(System.in);
		
		double m = i.nextDouble();
		double n = i.nextDouble();
		int impN = -1;
		
		while(n % m == 0) {
			
			n /= m;
			impN++;
			
		}
		
		System.out.print((impN >= 0 && n == 1)?("YES\n" + impN):"NO");
		
		i.close();
		
	}

}