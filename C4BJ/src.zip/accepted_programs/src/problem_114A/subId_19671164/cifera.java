package problem_114A.subId_19671164;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class cifera {
public static void main(String[] args) throws IOException{
	BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
	int k=Integer.parseInt(in.readLine());
	int l=Integer.parseInt(in.readLine());
	if(l%k!=0){
		System.out.println("NO");
		
	}
	else{
		int kk=0;
		while(l%k==0){
			l/=k;
			kk++;
		}
		if(l==1){
		System.out.println("YES");
		System.out.println(kk-1);
		}
		else System.out.println("NO");
		}
			
}
}