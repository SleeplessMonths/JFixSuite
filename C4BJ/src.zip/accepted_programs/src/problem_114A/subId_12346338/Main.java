package problem_114A.subId_12346338;

import java.util.Scanner;
public class Main {
	public static void main (String... s) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int k=sc.nextInt();
		int n=sc.nextInt();
		int i=1;
		boolean value=false;
		while(Math.pow(k,i)<=n)
		{
			if(Math.pow(k,i)==n)
			{
				System.out.println("YES");
				System.out.println(i-1);
				value=true;
				break;
			}
			i++;
		}
		if(!value)
			System.out.println("NO");
	}
}