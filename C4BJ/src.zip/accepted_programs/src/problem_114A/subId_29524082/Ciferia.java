package problem_114A.subId_29524082;

import java.util.Scanner;


public class Ciferia {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);
		long n = input.nextLong();
		long k = input.nextLong();
		int i=0;
		long z = n;
		while(n<k){
			n = n*z;
			i++;
			//System.out.println(n);
			
		}
		if(n==k){
			System.out.println("YES");
			System.out.println(i);
		}
		else
			System.out.println("NO");
	}

}