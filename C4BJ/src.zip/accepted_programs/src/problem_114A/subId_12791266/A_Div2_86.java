package problem_114A.subId_12791266;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class A_Div2_86 {
    public static void main(String[]arg) throws IOException
    {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        long k,p,b;
        b = Long.parseLong(in.readLine());
        p = Long.parseLong(in.readLine());
        int l = -1;
        k = 1;
        while(k < p)
        {
            l++;
            k *= b;
            //System.out.println(k);
        }
        if(k == p)
        {
            System.out.println("YES");
            System.out.println(l);
        }
        else
            System.out.println("NO");
    }
}