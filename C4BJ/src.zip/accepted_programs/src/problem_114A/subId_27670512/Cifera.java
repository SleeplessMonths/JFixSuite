package problem_114A.subId_27670512;

import java.util.Scanner;
public class Cifera {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int k = sc.nextInt();
		int l = sc.nextInt();
		
		for(int i=1;i<=31;i++){
			int s =(int)Math.pow(k, i);
			if( l == s){
				System.out.println("YES");
				System.out.println(i-1);
				break;
			}
			else if(l  < s || l > 2147483646){
				System.out.println("NO");
				break;
			}
		}

	}

}