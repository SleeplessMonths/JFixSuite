package problem_114A.subId_15720410;

import java.util.Scanner;

/**
 *
 * @author AdminHP-262
 */
public class Cifera {

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        int k = scanner.nextInt();
        int l = scanner.nextInt();

        long temp;
        for (int i = 1; i < 33; i++) {
            temp = (long) Math.pow(k, i);
            if (temp == l) {
                System.out.println("YES\n" + (i - 1));
                break;
            }
            if (temp > l) {
                System.out.println("NO");
                break;
            }
        }
    }
}