package problem_114A.subId_21390679;

import java.util.Scanner;
public class me
{
 public static void main(String args[])
 {
  Scanner br=new Scanner(System.in);
 long n=br.nextLong();
 long l=br.nextLong();
 long i=0,flag=0;
 while(Math.pow(n,i)<=l)
 {
     if(Math.pow(n,i)==l){
     flag=1;
     break;}
     i++;
 }if(flag==0)
 System.out.print("NO");
 else
 {
     System.out.println("YES");
     System.out.print(i-1);
 }
 }
}