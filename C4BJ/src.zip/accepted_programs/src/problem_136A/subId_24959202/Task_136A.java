package problem_136A.subId_24959202;

import java.util.Scanner;

/**
 * Created by Женя on 20.12.2016.
 */
public class Task_136A {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int b[] = new int[n];
        for (int i = 0; i < n; i++) {
            b[i] = in.nextInt();
        }
        int[] a = new int[n];

        int r = 1;
        for (int i = 0; i < n; i++){
            a[b[i]-1] = r;
            r++;
        }
        for (int i = 0; i < n; i++){
            System.out.print(a[i]+" ");
        }
        System.out.println();


    }
}