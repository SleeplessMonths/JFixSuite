package problem_136A.subId_23997989;

import java.util.Scanner;

public class hi
  {
    public static void main( String[] args )
      {
        Scanner scan = new Scanner(System.in);
        int c = scan.nextInt();
        int[] ar = new int[c];
        for( int i = 0 ; i < c; i++)
          ar[scan.nextInt()-1] = i+1;
          
        for(int y : ar)
          System.out.print(y + " " );
      }

  }