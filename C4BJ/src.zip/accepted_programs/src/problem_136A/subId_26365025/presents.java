package problem_136A.subId_26365025;

import java.util.Scanner;
public class presents {
public static void main(String[] args)
{
	Scanner scan = new Scanner(System.in);
	int tot = scan.nextInt();
	int [] arr  = new int[tot + 1];
    int temp = 0;
    for(int k = 1; k <= tot; ++k){
    	temp=scan.nextInt(); 
    	arr[temp] = k;
    	}
    for(int k = 1; k <= tot; ++k){
    	System.out.print(arr[k] + " ");
    	}
}
}