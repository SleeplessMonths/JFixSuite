package problem_136A.subId_24639456;

import java.util.Scanner;
public class JavaApplication15 {
    public static void main(String[] args) {
                Scanner in=new Scanner(System.in);
        int n=in.nextInt();
        int [] x=new int [n];
        int [] y=new int [n];
        for(int i=0;i<n;i++)
        {
            x[i]=in.nextInt();
        }
        for(int i=0;i<n;i++)
        {
            y[x[i]-1]=i+1;
        }
        for(int i=0;i<n;i++)
        {
            System.out.print(y[i]);
            System.out.print(" ");
        }
    }  
}