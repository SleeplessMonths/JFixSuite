package problem_136A.subId_21207298;

import java.util.Scanner;
public class Main {
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Scanner s = new Scanner(System.in) ; 
   int n = s.nextInt() ; 
   int a[] = new int [n + 1] ; int b[] = new int [n + 1] ;
   for(int i = 1 ; i <= n  ; i++){
       a[i] = s.nextInt() ;
       b[a[i]] = i ;
   
   
   }
   
        for (int i = 1 ; i <= n ; i++) {
            System.out.print(b[i]+" ");
            
        }
   
    }}