package problem_136A.subId_19595339;

import java.util.Scanner;
public class JavaApplication4 {

    
    public static void main(String[] args) {
       Scanner i=new Scanner(System.in);
       int a=i.nextInt();
       int x[]=new int[a];
       int y[]=new int [a];
      for(int z=0;z<x.length;z++){
           x[z]=i.nextInt();
           y[x[z]-1]=z+1;
    }
      for(int z=0;z<x.length;z++){
          System.out.print(y[z]+" ");
      }
    }
}