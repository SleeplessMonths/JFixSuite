package problem_136A.subId_20196395;

import java.util.Scanner;
public class A136
{
	public static void main(String...arg)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int a[]=new int[n];
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		for(int i=1;i<n+1;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(a[j]==i)
				{System.out.print(j+1);
			     System.out.print(" ");}
			}
			
		}
	}
}