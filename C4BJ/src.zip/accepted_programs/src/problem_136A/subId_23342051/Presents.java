package problem_136A.subId_23342051;

import java.util.Scanner;
public class Presents {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int s = sc.nextInt();
        int a [] = new int [s];
        for (int i = 1; i <= s; i++) {
            a[sc.nextInt()-1] = i;
        }
        for (int i = 0; i < s; i++) {
            System.out.print(a[i] + " ");
        }
        
    }
}