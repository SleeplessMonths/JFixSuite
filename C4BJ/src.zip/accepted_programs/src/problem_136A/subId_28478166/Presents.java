package problem_136A.subId_28478166;

import java.util.HashMap;
import java.util.Scanner;



public class Presents {


    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        HashMap<Integer,Integer> map = new HashMap<>();
        int[] rad = new int[in.nextInt()];
        for (int i = 0; i < rad.length; i++) {
            map.put(in.nextInt(), (i+1));
        }
        for (int i = 0; i < rad.length; i++) {
            System.out.print( map.get(i+1)+ " ");
        }
        
                
    }
    
}