package problem_136A.subId_19965924;

import java.util.Scanner;

public class Presents {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int[] arr = new int[n];
		int[] SecArr = new int[n];
		for (int i = 1; i <= n; i++) {
			arr[i - 1] = in.nextInt();
			SecArr[arr[i - 1] - 1] = i;
		}
		for (int t = 0; t < n; t++) {

			System.out.println(SecArr[t]);
		}

	}

}