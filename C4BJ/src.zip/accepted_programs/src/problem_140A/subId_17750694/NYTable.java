package problem_140A.subId_17750694;

import java.util.Scanner;

public class NYTable{

    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        int[] inputArr = klinUtil.sArrToIArr(in.nextLine().split(" "));
        int n = inputArr[0];
        int rr = inputArr[1];
        int r = inputArr[2];
        if(n == 1 && r <= rr ||
           n == 2 && r * 2 <= rr ||
           Math.asin((double)r / (rr - r)) * n <= 3.141592653589794)
            System.out.println("YES");
        else
            System.out.println("NO");
    }
    
}


class klinUtil {
    public static int[] sArrToIArr(String[] sArr){
        int[] iArr = new int[sArr.length];
        for(int i = 0; i < sArr.length; i++){
            iArr[i] = Integer.parseInt(sArr[i]);
        }
        return iArr;
    }
}