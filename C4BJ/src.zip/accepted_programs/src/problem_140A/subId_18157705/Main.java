package problem_140A.subId_18157705;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Built using CHelper plug-in
 * Actual solution is at the top
 * @author flk
 */
public class Main {
	public static void main(String[] args) {
		InputStream inputStream = System.in;
		OutputStream outputStream = System.out;
		Scanner in = new Scanner(inputStream);
		PrintWriter out = new PrintWriter(outputStream);
		TaskA solver = new TaskA();
		solver.solve(1, in, out);
		out.close();
	}
}

class TaskA {
    public void solve(int testNumber, Scanner in, PrintWriter out) {

        int n = in.nextInt();
        double R = in.nextDouble();
        double r = in.nextDouble();

        int num;
        if (r > R) {
            num = 0;
        }
        else if (2*r > R) {
            num = 1;
        }
        else {
            num = (int) (Math.PI/Math.asin(r/(R-r)) +1e-10 );
        }

        if (n <= num) {
            out.println("YES");
        }
        else {
            out.println("NO");
        }

    }
}