package problem_132C.subId_6907710;

import java.util.Arrays;
import java.util.Scanner;
public class Main {
	static final int frontMax = 0;
	static final int frontMin = 1;
	static final int backMax = 2;
	static final int backMin = 3;
	public static void main(String[] args) throws Exception {
		Scanner scan = new Scanner(System.in);
		char[] l1 = scan.next().toCharArray();
		int lim = scan.nextInt();
		int ans = -1111111;
		{
			int[][] dp1 = new int[4][lim + 1];
			int[][] dp2 = new int[4][lim + 1];
			Arrays.fill(dp1[frontMax], -100000);
			Arrays.fill(dp1[backMax], -100000);
			Arrays.fill(dp1[frontMin], 100000);
			Arrays.fill(dp1[backMin], 100000);
			dp1[frontMax][0] = 0;
			dp1[backMax][0] = 0;
			dp1[frontMin][0] = 0;
			dp1[backMin][0] = 0;
			for (int i = 0 ; i < l1.length; i++){
				Arrays.fill(dp2[frontMax], -100000);
				Arrays.fill(dp2[backMax], -100000);
				Arrays.fill(dp2[frontMin], 100000);
				Arrays.fill(dp2[backMin], 100000);
				for (int j = 0 ; j <= lim; j++){
					for (int k = j; k <= lim; k++){
						if (l1[i] == 'F' && (k - j) % 2 == 0
								|| l1[i] == 'T' && (k - j) % 2 != 0
								){
							dp2[frontMax][k] = Math.max(dp2[frontMax][k], dp1[frontMax][j] + 1);
							dp2[backMax][k] = Math.max(dp2[backMax][k], dp1[backMax][j] - 1);
							
							dp2[frontMin][k] = Math.min(dp2[frontMin][k], dp1[frontMin][j] + 1);
							dp2[backMin][k] = Math.min(dp2[backMin][k], dp1[backMin][j] - 1);
						}
						else {
							dp2[frontMax][k] = Math.max(dp2[frontMax][k], dp1[backMax][j]);
							dp2[backMax][k] = Math.max(dp2[backMax][k], dp1[frontMax][j]);
							
							dp2[frontMin][k] = Math.min(dp2[frontMin][k], dp1[backMin][j]);
							dp2[backMin][k] = Math.min(dp2[backMin][k], dp1[frontMin][j]);
						}
					}
				}
				for (int j = 0 ; j < dp1.length; j++){
					for (int k = 0; k < dp1[j].length; k++){
						dp1[j][k] = dp2[j][k];
					}
//					px(dp1[j]);
				}
//				px();
			}
			ans = Math.max(ans, dp1[frontMax][lim]);
			ans = Math.max(ans, dp1[backMax][lim]);
			ans = Math.max(ans, -dp1[frontMin][lim]);
			ans = Math.max(ans, -dp1[backMin][lim]);
		}
		System.out.println(ans);
	}
	public static void px(Object ...objects){
		System.out.println(Arrays.deepToString(objects));
	}
	
}