package problem_132C.subId_10801468;

//132C

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class LogoTurtle {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		char[] c = br.readLine().toCharArray();
		
		int n = Integer.parseInt(br.readLine());
		
		boolean[][][][] dp = new boolean[c.length+1][n+1][2][c.length+1];
		
		dp[0][n][0][0] = true;
		for (int i = 0; i < c.length; i++) {
			if (c[i] == 'F') {
				// FORWARD
				for (int j = n; j >= 0 && j >= n-i; j--) {
					for (int d = 0; d <= i; d++) {
						if (dp[i]  [j][0][d]) {
							dp[i+1][j][0][d+1] = true;
						}
					}
					for (int d = 1; d <= i; d++) {
						if (dp[i]  [j][1][d]) {
							dp[i+1][j][1][d-1] = true;
						}
					}
				}
				for (int j = n; j >= 1 && j >= n-i; j--) {
					for (int d = 0; d <= i; d++) {
						if (dp[i]  [j]  [0][d]) {
							dp[i+1][j-1][1][d] = true;
						}
						if (dp[i]  [j]  [1][d]) {
							dp[i+1][j-1][0][d] = true;
						}
					}
				}
			}
			else {
				// TURN
				for (int j = n; j >= 1 && j >= n-i; j--) {
					for (int d = 0; d <= i; d++) {
						if (dp[i]  [j]  [0][d]) {
							dp[i+1][j-1][0][d+1] = true;
						}
					}
					for (int d = 1; d <= i; d++) {
						if (dp[i]  [j]  [1][d]) {
							dp[i+1][j-1][1][d-1] = true;
						}
					}
				}
				for (int j = n; j >= 0 && j >= n-i; j--) {
					for (int d = 0; d <= i; d++) {
						if (dp[i]  [j][0][d]) {
							dp[i+1][j][1][d] = true;
						}
						if (dp[i]  [j][1][d]) {
							dp[i+1][j][0][d] = true;
						}
					}
				}
			}
			for (int j = n; j >= 0 && j >= n-i; j--) {
				if (dp[i+1][j][1][0])
					dp[i+1][j][0][0] = true;
			}
		}
		for (int d = c.length; d >= 0; d--) {
			for (int j = 0; j <= n; j += 2) {
				if (dp[c.length][j][0][d] || dp[c.length][j][1][d]) {
					System.out.println(d);
					return;
				}
			}
		}
	}
}