package problem_132C.subId_18778866;

import java.util.Scanner;

public class LogoTurtle {

	static String l;
	static int[][][][] dp;

	public static int dfs(int i, int n, int p, int d) {

		if (n == 0) {
			for (int j = i; j < l.length(); j++) {
				if (l.charAt(j) == 'F')
					p += d;
				else
					d *= -1;
			}
			return Math.abs(p);
		}
		if (i >= l.length())
			return Integer.MIN_VALUE;

		if (dp[i][n][100 + p][d == 1 ? 0 : 1] != -201)
			return dp[i][n][100 + p][d == 1 ? 0 : 1];

		int max = 0;
		int dtemp = d;
		int ptemp = p;
		for (int j = 0; j <= n; j++) {
			dtemp = d;
			ptemp = p;
			char s = l.charAt(i);

			if (j % 2 != 0) s = (s == 'F') ? 'T' : 'F';
			if (s == 'F') ptemp += d;
			if (s == 'T') dtemp = -d;

			max = Math.max(max, dfs(i + 1, n - j, ptemp, dtemp));
		}
		
		dp[i][n][100 + p][d == 1 ? 0 : 1] = max;
		return max;
	}

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		l = scan.nextLine();
		int n = Integer.parseInt(scan.nextLine());

		dp = new int[l.length()][n + 1][201][2];

		for (int i = 0; i < l.length(); i++) {
			for (int j = 0; j < n + 1; j++) {
				for (int j2 = 0; j2 < 201; j2++) {
					for (int k = 0; k < 2; k++) {
						dp[i][j][j2][k] = -201;
					}
				}
			}
		}

		System.out.println(dfs(0, n, 0, l.charAt(0) == 'F' ? 1 : -1));

	}

}