package problem_132C.subId_11184190;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Created by VIET ANH on 27/04/2015.
 */
public class test {

    private static int T;
    private static long oo=Long.MAX_VALUE;
    private static int base=1000000007;
    private static int[][][][] f;
    private static boolean[][][] dau;


    public static void main(String[] args) throws IOException {
        Scanner in = new Scanner(System.in);
        PrintWriter out = new PrintWriter(System.out);
        String s=in.next();
        int n=in.nextInt();
        f = new int[s.length() + 1][n + 1][2][2];
        dau = new boolean[s.length() + 1][n + 1][2];
        for (int i = 0; i < s.length() + 1; i++) {
            for (int j = 0; j < n + 1; j++) {
                for (int k = 0; k < 2; k++) {
                    f[i][j][k][0]=Integer.MAX_VALUE;
                    f[i][j][k][1]=Integer.MIN_VALUE;
                }
            }
        }
        f[0][0][1][0]=0;
        f[0][0][1][1]=0;
        dau[0][0][1]=true;
        for (int i = 1; i < s.length()+1; i++) {
            for (int j = 0; j < n + 1; j++) {
                for (int k = 0; k < 2; k++) {
                    char c=s.charAt(i-1);
                    for (int l = 0; l <= j; l++) {
                        char c2=c;
                        if (l%2==1) {
                            if (c=='F') c2='T';
                            else c2='F';
                        }
                        if (c2=='F') {
                            int v=-1;
                            if (k==1) v=1;
                            if (dau[i-1][j-l][k]) {
                                f[i][j][k][0]=Math.min(f[i][j][k][0],Math.min(f[i-1][j-l][k][0],f[i-1][j-l][k][1])+v);
                                f[i][j][k][1]=Math.max(f[i][j][k][1],Math.max(f[i - 1][j - l][k][0], f[i - 1][j - l][k][1])+v);
                                dau[i][j][k]=true;
                            }
                        }
                        else {
                            if (dau[i-1][j-l][1-k]) {
                                f[i][j][k][0]=Math.min(f[i][j][k][0],Math.min(f[i-1][j-l][1-k][0],f[i-1][j-l][1-k][1]));
                                f[i][j][k][1]=Math.max(f[i][j][k][1], Math.max(f[i - 1][j - l][1 - k][0], f[i - 1][j - l][1 - k][1]));
                                dau[i][j][k]=true;
                            }
                        }
                    }
                }
            }
        }
        int res=0;
        for (int i = 0; i < 2; i++) {
            if (dau[s.length()][n][i])
            for (int j = 0; j < 2; j++) {
                res=Math.max(res,Math.abs(f[s.length()][n][i][j]));
            }
        }
        out.print(res);
        out.close();
    }

}