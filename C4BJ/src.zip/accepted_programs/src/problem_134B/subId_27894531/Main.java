package problem_134B.subId_27894531;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
   public static void main(String[] args) throws Exception {
      BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
      int n             = Integer.parseInt(bf.readLine());

      if (n == 1) {
         System.out.println(0);
         return;
      }
      int best = Integer.MAX_VALUE;

      for (int i = 1; i < n; i++) {
         int a   = i;
         int b   = n;
         int ans = 0;

         while (a > 1) {
            ans += b / a;
            b   %= a;
            int tmp = a;
            a = b;
            b = tmp;
         }

         if (a == 1) best = Math.min(best, ans + (b - a));
      }
      System.out.println(best);
   }
}