package problem_134B.subId_916765;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class TestingRound3_B {
    public static void main(String[] args) throws NumberFormatException, IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(in.readLine());
        if(n==1){
            System.out.println(0);
            return;
        }
        int res = 10000000;
        for (int i = 1; i < n; i++) {
            int a = i;
            int b = n;
            int curr = 0;
            while(a>1 || b>1){
               if(a==b)
                   break;
               if(a==0 || b==0)
                   break;
               if(a>b){
                   a = a-b;
               }else
                   b = b-a;
               curr++;
            //   System.out.println(a+" "+b+" "+i+" "+curr);
            }
            if(a==1 && b==1)
            res = Math.min(res, curr);
        }
        System.out.println(res);
    }
}