package problem_112A.subId_27398741;

import java.util.Scanner;

/**
 * Created by NIckConterno on 5/27/17.
 */
public class Force112A {
    public static void main(String[] args) {
        Scanner in= new Scanner(System.in);
        String str=in.nextLine();
        String str2=in.nextLine();
        str=str.toLowerCase();
        str2=str2.toLowerCase();
        if(str.compareTo(str2)<0){
            System.out.println(-1);
        }
        else if(str.equals(str2)){
            System.out.println(0);
        }
        else{
            System.out.println(1);
        }
    }
}