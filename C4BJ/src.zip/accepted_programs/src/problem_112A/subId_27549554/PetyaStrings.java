package problem_112A.subId_27549554;

import java.util.Scanner;

public class PetyaStrings {
  public static void main (String[] arg) {
    Scanner scan = new Scanner(System.in);
    String one = scan.next();
    one = one.toLowerCase();
    String two = scan.next();
    two = two.toLowerCase();
    int blah = one.compareTo(two);
    int val = (blah > 0) ? 1: (blah==0? 0: -1);
    System.out.println(val);
  }
}