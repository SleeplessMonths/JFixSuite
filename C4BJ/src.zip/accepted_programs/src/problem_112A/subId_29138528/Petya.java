package problem_112A.subId_29138528;

import java.util.Scanner;

public class Petya {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String first = scan.next();
		String last = scan.next();
		first=first.toLowerCase();
		last=last.toLowerCase();
		if(first.equals(last)){
			System.out.println(0);
		}
		else {
			compare(first,last);
		}
		
	}
	public static void compare(String a, String b ) {
		for(int i=0;i<a.length();i++) {
			if((int)a.charAt(i)>(int)b.charAt(i)) {
				System.out.println(1);
				break;
			}
			else if((int)a.charAt(i)<(int)b.charAt(i)){
				System.out.println(-1);
				break;
			}
		}
	}
}