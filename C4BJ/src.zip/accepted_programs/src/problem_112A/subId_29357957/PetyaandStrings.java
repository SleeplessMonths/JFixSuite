package problem_112A.subId_29357957;

import java.util.Scanner;

public class PetyaandStrings {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in) ;
		String first = input.nextLine() ;
		String second = input.nextLine() ;
		first = first.toLowerCase() ;
		second = second.toLowerCase() ;
		int flag = 0 ;
		for (int i = 0 ; i < first.length() ; i ++)
		{
			if (first.charAt(i) != second.charAt(i))
			{
				flag = 1 ;
				if ((int)first.charAt(i) < (int)second.charAt(i))
				{
					System.out.println("-1");
				}
				else
				{
					System.out.println("1");
				}
				break ;
			}
		}
		if (flag == 0)
		{
			System.out.println("0");
		}

	}

}