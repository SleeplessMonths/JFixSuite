package problem_112A.subId_29376845;

import java.util.Scanner;

/**
 * Created by usermac on 12/08/17.
 */
public class lexicographical {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String string1 = sc.nextLine();
        String string2 = sc.nextLine();
        if (string1.compareToIgnoreCase(string2) < 0) {
            System.out.println(-1);
        } else if (string1.compareToIgnoreCase(string2) > 1) {
            System.out.println(1);
        }
        else {
            System.out.println(string1.compareToIgnoreCase(string2));
        }
    }
}