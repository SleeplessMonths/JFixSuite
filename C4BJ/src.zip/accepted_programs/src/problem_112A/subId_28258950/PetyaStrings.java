package problem_112A.subId_28258950;

import java.util.Scanner;
public class PetyaStrings {
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		char[] a = sc.next().toCharArray();
		char[] b = sc.next().toCharArray();
		String x = ""; String y = "";
		for (int i = 0; i < a.length; i++){
			if ('A' <= a[i] && a[i] <= 'Z')
				a[i]+= 'a' - 'A';
			x = x + Character.toString(a[i]);
		}
		for (int i = 0; i < b.length; i++){
			if ('A' <= b[i] && b[i] <= 'Z')
				b[i]+= 'a' - 'A';
			y = y + Character.toString(b[i]);
		}
		if(x.compareTo(y) >=1)
			System.out.print("1");
		if (x.compareTo(y) == 0)
			System.out.print("0");
		if (x.compareTo(y) <= -1)
			System.out.print("-1");
		
	}
}