package problem_112A.subId_27833674;

import java.util.Scanner;

public class PetyaAndStrings {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		String str = scan.next().toLowerCase();
		String str1 = scan.next().toLowerCase();

		if (str.compareTo(str1) < 0)
			System.out.println("-1");
		else if (str.compareTo(str1) > 0)
			System.out.println("1");
		else
			System.out.println(0);

		scan.close();
	}
}