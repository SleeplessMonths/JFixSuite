package problem_112A.subId_28376968;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class petyaandstrings {
	public static void main(String[] args) throws IOException {
		BufferedReader bf = new BufferedReader(new InputStreamReader (System.in));
		PrintWriter pw = new PrintWriter(System.out, true);
		String a1 =bf.readLine().toLowerCase();
		String a2 =bf.readLine().toLowerCase();
		int i=0;
		while(i!=a1.length())
		{
			if(a1.charAt(i)>a2.charAt(i))
				{
				pw.print(1);
				break;
				}
			else if(a1.charAt(i)<a2.charAt(i))
				{
				pw.print(-1);
				break;
				}
			i++;
		}
		if(i==a1.length())
			pw.print(0);
		pw.close();
	}
}