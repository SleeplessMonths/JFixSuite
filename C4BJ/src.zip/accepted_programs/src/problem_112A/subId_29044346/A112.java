package problem_112A.subId_29044346;

import java.util.Scanner;
public class A112{
	public static void main(String[] args){
		Scanner in=new Scanner(System.in);
		String ch1=in.nextLine();
		String ch2=in.nextLine();
		int x= (ch1.toLowerCase()).compareTo(ch2.toLowerCase());
		if(x==0)
			System.out.println(x);
		if(x<0) System.out.println(-1);
		if(x>0) System.out.println(1);
	}
}