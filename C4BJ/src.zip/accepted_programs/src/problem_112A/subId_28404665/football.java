package problem_112A.subId_28404665;

import java.util.Scanner;
public class football {

    public static void main(String args[]) {
    	Scanner sc =new Scanner(System.in);
    	String s1=sc.next().toLowerCase();
		String s2=sc.next().toLowerCase();
		int sum=0;
    	for (int i=0;i<s1.length();i++){
    		if (s1.charAt(i)>s2.charAt(i)){sum++;break;}
    		else if (s1.charAt(i)<s2.charAt(i))
    		{sum--;break;}
else continue;
    	   }

System.out.println(sum);
    }


}