package problem_112A.subId_27103201;

import java.util.Scanner;

public class Replace {
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		String s1 = input.nextLine();
//		String s = input.nextLine();
		String s2 = input.nextLine();
		int r = 0;
		s1 = s1.toLowerCase();	
		s2 = s2.toLowerCase();
		for(int i = 0;i<s1.length();i++){
			if(s1.charAt(i)>s2.charAt(i)){
				r = 1;
				break;
			}else if(s1.charAt(i)<s2.charAt(i)){
				r = -1;
				break;
			}
		}
		System.out.println(r);
	}
}