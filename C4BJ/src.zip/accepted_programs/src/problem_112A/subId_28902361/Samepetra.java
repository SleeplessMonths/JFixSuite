package problem_112A.subId_28902361;

import java.util.Scanner;

public class Samepetra {
 public static void main(String args[])
 {
	Scanner s=new Scanner(System.in);
	String a=s.nextLine();
	String b=s.nextLine();
	int len=a.length();
	int count=0,m=0,n=0;
	int ca = 0;
	int cb=0;
	for(int i=0;i<len;i++)
	{
		ca=a.charAt(i);
		
		if(Character.isUpperCase(ca))
		{
			ca=Character.toLowerCase(ca);
		}
		
		 cb=b.charAt(i);
		
		if(Character.isUpperCase(cb))
		{
			cb=Character.toLowerCase(cb);
		}

		if(ca==cb)
			count++;
		else if(ca>cb)
			{
			  m=ca;
			  n=cb;
			  break;
			}
		else
		{
			m=ca;
			n=cb;
		    break;
		}
			
	}
	if(count==len)
		System.out.println("0");
	else if(m>n)
		System.out.println("1");
	else
		System.out.println("-1");
	
 }
}