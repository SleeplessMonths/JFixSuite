package problem_131A.subId_28312530;

import java.util.Scanner;
public class Caps {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		char arr[]=sc.next().toCharArray();
		int i,flag=0;
		for(i=0;i<arr.length;i++) {
			if(arr[i]>=97)
			break;
		}
		if(i==arr.length)
		flag=1;
		else if(i==0)
		flag=2;
		if(flag==1) {
			for(i=0;i<arr.length;i++){
				arr[i]+=32;
			}
		}
		else if(flag==2) {
			for(i=1;i<arr.length;i++) {
				if(arr[i]>=97)
				break;
			}
			if(i==arr.length) {
				arr[0]-=32;
				for(i=1;i<arr.length;i++)
				arr[i]+=32;
			}
		}
		String b=new String(arr);
		System.out.println(b);
	}
}