package problem_131A.subId_28742790;

import java.util.Scanner;

public class A131
{
	public static void main(String... args)
	{
		Scanner in = new Scanner(System.in);
		String word = in.next();

		if (word.length() == 1)
		{
			if (Character.isLowerCase(word.charAt(0)))
			{
				System.out.println(Character.toUpperCase(word.charAt(0)));
			}
			else
			{
				System.out.println(word.toLowerCase());
			}
		}
		else
		{
			if (Character.isLowerCase(word.charAt(0)) && word.subSequence(1, word.length()).chars().allMatch(Character::isUpperCase))
			{
				word = word.toLowerCase();
				System.out.println(String.valueOf(Character.toUpperCase(word.charAt(0))) + word.subSequence(1, word.length()));
			}
			else if (word.chars().allMatch(Character::isUpperCase))
			{
				System.out.println(word.toLowerCase());
			}
			else
			{
				System.out.println(word);
			}
		}


	}
}