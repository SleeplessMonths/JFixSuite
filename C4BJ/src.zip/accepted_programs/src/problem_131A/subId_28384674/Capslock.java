package problem_131A.subId_28384674;

import java.util.Scanner;

public class Capslock {

    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        String s = input.next();

       
        
      
        int i=0;
        int count = 0;
        while (i != s.length()) 
        {
            char c = s.charAt(i);
            if (Character.isUpperCase(c)) 
            {
                count++;
            }
              i++;
        }
        int count3=0;
        if (s.length()>1)
        {
            
            for ( int k=1 ;k<s.length();k++){
                if(Character.isUpperCase(s.charAt(k)))
                count3++;
          
                } 
        }
         if (count == s.length())
        {
            String toLowerCase = s.toLowerCase();
            System.out.println(toLowerCase);
        }
            
         
         else if (count3==s.length()-1){
            String e = s.substring(0, 1);
            String b = s.substring(1);
            String result = e.toUpperCase()+b.toLowerCase();
            System.out.println(result);
         }
            
         else 
             System.out.println(s);
           
                
       }
         
            
        }