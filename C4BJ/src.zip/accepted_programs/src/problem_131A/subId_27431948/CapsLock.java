package problem_131A.subId_27431948;

import java.util.Scanner;

/**
 * Created by hp on 29-05-2017.
 */
public class CapsLock {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        String a[]=s.split(" ");
        String k="";
        for (int i = 0; i <a.length ; i++) {
            k=a[i];
            int flg=1;

            for (int j = 0; j <k.length() ; j++) {
             //   System.out.println("in");
                if ((k.charAt(j) >= 65 && k.charAt(j) <= 90) == false) {
                    flg = 0;
                    break;
                }
            }
        //    System.out.println("flg"+flg);
            if(flg == 1)
            {
                String t=(""+k.charAt(0)).toLowerCase()+(k.substring(1)).toLowerCase();
                System.out.println(t);

            }
            else{
                int t=1;
                if((k.charAt(0) >= 97 && k.charAt(0) <= 122) == true)
                {
                    for (int j = 1; j <k.length() ; j++) {
                        if((k.charAt(j) >=65 && k.charAt(j)<=90)==false)
                        {
                            t=0;
                            break;
                        }
                    }
                    if(t == 1)
                    {
                        String z=(""+k.charAt(0)).toUpperCase()+(k.substring(1)).toLowerCase();
                        System.out.println(z);
                    }
                    else
                        System.out.println(k);

                }
                else
                    System.out.println(k);
            }
        }

    }
}