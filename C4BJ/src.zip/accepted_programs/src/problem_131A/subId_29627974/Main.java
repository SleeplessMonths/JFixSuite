package problem_131A.subId_29627974;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Main {

    public static void main(String[] args) {
        FastReader in = new FastReader();
        StringBuilder sb = new StringBuilder();
        String s = in.next();
        boolean b = false,t = false;
        if(s.length()==1&&Character.isLowerCase(s.charAt(0))){
            System.out.println(s.toUpperCase());
            System.exit(0);
        }
        if(Character.isUpperCase(s.charAt(0))){
            b= true;
        }
        for (int i = 1; i < s.length(); i++) {
            if(Character.isUpperCase(s.charAt(i))&&b){
                b= true;
            }else if(Character.isLowerCase(s.charAt(0))&&Character.isUpperCase(s.charAt(i))){
                t = true;
            }else{
                b= false;
                t=false;
                break;
            }
        }
        if(b){
            sb.append(s.toLowerCase());
        }else if(t){
            sb.append(s.substring(0, 1).toUpperCase()+s.substring(1).toLowerCase());
        }else{
            sb.append(s);
        }
        System.out.println(sb);
    }

}


class FastReader {

    BufferedReader br;
    StringTokenizer st;

    public FastReader() {
        br = new BufferedReader(new InputStreamReader(System.in));
    }

    String next() {
        while (st == null || !st.hasMoreElements()) {
            try {
                st = new StringTokenizer(br.readLine());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return st.nextToken();
    }

    int nextInt() {
        return Integer.parseInt(next());
    }

    long nextLong() {
        return Long.parseLong(next());
    }

    double nextDouble() {
        return Double.parseDouble(next());
    }

    String nextLine() {
        String str = "";
        try {
            str = br.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return str;
    }
}