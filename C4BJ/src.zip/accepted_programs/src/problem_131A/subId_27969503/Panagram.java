package problem_131A.subId_27969503;

import java.util.Scanner;
public class Panagram
{
    public static void main(String [] args)
    {
        Scanner in=new Scanner(System.in);
        String s=in.next();
        boolean status =true;
        String s1="";
        String s2=s.substring(1);
        //System.out.println(s2);
        
      
        for(int i=0;i<s2.length();i++)
        {
        	if(Character.isLowerCase(s2.charAt(i)))
        	{
        		status=false;
        	}
        }
        //System.out.println(status);
        
       
        if(Character.isLowerCase(s.charAt(0))&&status==true)
        {
            s1=s.substring(0,1).toUpperCase()+s.substring(1).toLowerCase();
            System.out.println(s1);
            
        }
        
        else if(Character.isUpperCase(s.charAt(0))&&status==true)
        {
            s1=s.substring(0).toLowerCase();
            System.out.println(s1);
        }
        else
        {
            System.out.println(s);
        }
        
        
        
    }
}