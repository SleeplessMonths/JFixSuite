package problem_131A.subId_29216458;

import java.util.Scanner;

/**
 * Created by ARKA on 05-08-2017.
 */
public class Imperium016 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String art = sc.nextLine();
        if(check(art)){
            action(art);
        }
        else{
            System.out.println(art);
        }
    }

    private static void action(String art) {
        String ans = "";
        for(int i=0; i<art.length(); i++){
            if(Character.isLowerCase(art.charAt(i))){
                ans += art.substring(i,i+1).toUpperCase();
            }
            else if(Character.isUpperCase(art.charAt(i))){
                ans += art.substring(i,i+1).toLowerCase();
            }
        }

        System.out.println(ans);
    }

    public static boolean check(String art){
        if(art.length()==1){
            if(Character.isLowerCase(art.charAt(0))){
                return true;
            }
            else{
                return true;
            }
        }
        else{
            for(int i=1; i<art.length(); i++){
                if(Character.isLowerCase(art.charAt(i))){
                    return false;
                }
            }
            return true;
        }
    }
}