package problem_131A.subId_28788211;

import java.io.IOException;
import java.util.Scanner;

public class Main{

    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);

        String s=sc.next();
        boolean a=false, b=true;
        if (s.charAt(0)>='a' && s.charAt(0)<='z')
            a=true;
        for (int i=1;i<s.length(); i++)
        {
            if (s.charAt(i)>='a' && s.charAt(i)<='z'){
                b=false;
                break;
            }
        }
        if (b==true){
            s=s.toLowerCase();
        }
        if(a==true &&b==true)
            s=(char) (s.charAt(0)-32)+ s.substring(1);
        System.out.println(s);
    }
}