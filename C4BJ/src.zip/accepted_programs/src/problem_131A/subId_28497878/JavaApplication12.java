package problem_131A.subId_28497878;

import java.util.Scanner;
public class JavaApplication12 {

    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
       String input = inputScanner.next();
       if(input.charAt(0) >= 97 && input.charAt(0) <= 122) {
           boolean checkForLower = false;
           for (int i = 1; i < input.length(); i++) {
               if(input.charAt(i) >= 97 && input.charAt(i) <= 122)
                   checkForLower = true;

           }
           if(input.length() == 1)
               System.out.println(input.toUpperCase());
           else
           if(checkForLower)
               System.out.println(input);
           else {
               String firstPart = "" + input.charAt(0);
               String lastPart = "";
               for (int i = 1; i < input.length(); i++) {
                   lastPart += input.charAt(i);
               }
               System.out.println(firstPart.toUpperCase() + lastPart.toLowerCase());
                       }

       
       } else {
           boolean check = false;
           for (int i = 1; i < input.length(); i++) {
               if(input.charAt(i) >= 97 && input.charAt(i) <= 122) 
                   check = true;}
               
               if(check)
                   System.out.println(input);
               else {
               String firstPart = "" + input.charAt(0);
               String lastPart = "";
               for (int j = 1; j < input.length(); j++) {
                   lastPart += input.charAt(j);
               }
               System.out.println(firstPart.toLowerCase() + lastPart.toLowerCase());
               }
               
           
       }
       
    }
    
    
}