package problem_131A.subId_27573645;

import java.util.Scanner;
public class capsLock {
	public static void main(String[] args) {
		Scanner scanny = new Scanner(System.in);
		String word = scanny.nextLine();
		int length = word.length();
		if (length == 1) {
			if (Character.isUpperCase(word.charAt(0))) System.out.println(word.toLowerCase());
			else System.out.println(word.toUpperCase());
		}
		else {
			String string = "";
			for (int i = 0; i < length; i++) {
				if (Character.isUpperCase(word.charAt(i))) { string += "u";
				}
				else string += "l";
			}
			if ((!string.substring(1).contains("l"))&&string.charAt(0)=='l') System.out.println((word.substring(0,1).toUpperCase()) + (word.substring(1).toLowerCase()));
			else if (!string.contains("l")) System.out.println(word.toLowerCase());
			else System.out.println(word);
		}
	}
}