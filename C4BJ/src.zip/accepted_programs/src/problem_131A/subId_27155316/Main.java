package problem_131A.subId_27155316;

import java.util.Scanner;

public class Main {

    public static boolean majus(String ch) {
        for (int i = 0; i < ch.length(); i++) {
            if (ch.charAt(i) >= 'a') {
                return false;
            }
        }
        return true;
    }

    public static boolean majus2(String ch) {
        if (ch.charAt(0) >= 'a') {
            for (int i = 1; i < ch.length(); i++) {
                if (ch.charAt(i) >= 'a' ) {
                    return false;
                }
            }
            return true;
        } else {
            return false;
        }
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String ch = in.next();
        String ch1 = ch;
        if (majus(ch)){ 
            System.out.println(ch.toLowerCase());
        }
        else if(majus2(ch)){
            ch = ch.substring(0, 1).toUpperCase() + ch.substring(1).toLowerCase();
            System.out.println(ch);
        }
            
        else System.out.println(ch1);

    }

}