package problem_131A.subId_27577061;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Caps
{
    public static void main(String args[])throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        String s;
        char ch;
        int l,i=0,c=0;
        s=br.readLine();
        l=s.length();
        while(i<l)
        {
            ch=s.charAt(i);
            if(ch>='A'&&ch<='Z')
                c++;
            i++;
        }
    
        ch=s.charAt(0);
        
        if(c==l)
        {
            s=s.toLowerCase();
        }
        if(c==(l-1) &&(ch>='a'&&ch<='z'))
        {
            s=Character.toUpperCase(ch)+s.substring(1,l).toLowerCase();
        }
        System.out.println(s);
    }
}