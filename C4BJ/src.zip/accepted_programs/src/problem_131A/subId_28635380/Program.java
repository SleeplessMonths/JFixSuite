package problem_131A.subId_28635380;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;


public class Program{
    void solve(Scanner in, PrintWriter out) throws IOException {
        String input = in.next();
        String error1 = input.toUpperCase();
        String error2 = input.substring(0, 1).toLowerCase() + input.substring(1).toUpperCase();
        if(input.equals(error1))
            out.println(input.toLowerCase());
        else if(input.equals(error2)){
            String ans = input.toLowerCase();
            out.println(ans.substring(0, 1).toUpperCase() + ans.substring(1));
        }
        else out.println(input);


    }

    void run(){
        try(
                Scanner in = new Scanner(System.in);
                PrintWriter out = new PrintWriter(System.out);
        ){
            try{
                solve(in, out);
            }catch (IOException e){
            }
        }
    }
    public static void main(String[] args) {
        new Program().run();
    }
}