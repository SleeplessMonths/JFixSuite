package problem_131A.subId_29157988;

import java.util.Scanner;

public class CapsLocks {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		String input=scan.next();
		boolean result=false;
		if(Character.isUpperCase(input.charAt(0))) {
			for(int i=1;i<input.length();i++) {
				if(Character.isLowerCase(input.charAt(i))) {
					System.out.println(input);
					result=true;
					break;
				}
			}
			if(result==false) {
				System.out.println(input.substring(0,input.length()).toLowerCase());
			}
		}
		else {
			for(int i=1;i<input.length();i++) {
				if(Character.isLowerCase(input.charAt(i))) {
					System.out.println(input);
					result=true;
					break;
				}
			}
			if(result==false) {
				System.out.println(input.substring(0, 1).toUpperCase()+input.substring(1,input.length()).toLowerCase());
			}
		}
	}
	
}