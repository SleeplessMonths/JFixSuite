package problem_131A.subId_28649982;

import java.util.Scanner;
public class cAPSLOOK 
    {
        public static void main(String[] args)
            {
                Scanner cin = new Scanner(System.in);
                String n = cin.next();
                boolean cond1 = false  ;
                char arr  [];
                int i ; 
                for (i = 1 ; i < n.length() ; i++)
                    {
                        if (n.charAt(i) > 90  )
                            {
                                cond1 = true ;
                                break ;
                            }
                    }
                if (!cond1)
                    {
                         if(n.charAt(0) >= 97 ) 
                            {
                                n = n.toLowerCase();
                                arr = n.toCharArray();
                                arr[0] = Character.toUpperCase(arr[0]);
                                n = new String(arr);
                                System.out.print(n);
                            }
                         else
                            {
                                n = n.toLowerCase();
                                System.out.print(n);
                            } 
                    }    
                else 
                    {
                        System.out.print(n);
                    }
            }
    }