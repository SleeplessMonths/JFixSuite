package problem_131A.subId_27947545;

import java.util.Scanner;

public class CapsLock {
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		StringBuilder s = new StringBuilder(sc.next());
		int flag=0;
		for(int i=1;i<s.length();i++){
			if(s.charAt(i)>96 && s.charAt(i)<123){
				flag=1;
				break;
			}
		}
		if(flag==0){
			if(s.charAt(0)>96 && s.charAt(0)<123){
				s.setCharAt(0, (char) (s.charAt(0)-' '));
			}else if(s.charAt(0)>64 && s.charAt(0)<91){
				s.setCharAt(0, (char) (s.charAt(0)+' '));
			}
			for(int i=1;i<s.length();i++){
				s.setCharAt(i, (char) (s.charAt(i)+' '));
			}
			System.out.println(s);
		}else
			System.out.println(s);
		sc.close();
	}
}