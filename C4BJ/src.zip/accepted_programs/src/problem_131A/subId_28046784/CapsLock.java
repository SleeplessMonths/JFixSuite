package problem_131A.subId_28046784;

import java.util.Scanner;

public class CapsLock
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        String word = scan.next();
        
        if (word.compareTo(word.toUpperCase()) == 0)
        {
            System.out.println(word.toLowerCase());
        }
        else if (Character.isLowerCase(word.charAt(0)) && 
        word.substring(1).compareTo(word.substring(1).toUpperCase()) == 0   )
        {
            System.out.println(Character.toUpperCase(word.charAt(0))
            + word.substring(1).toLowerCase());
        }
        else
        {
            System.out.println(word);
        }
    }
}