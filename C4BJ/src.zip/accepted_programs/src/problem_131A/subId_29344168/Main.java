package problem_131A.subId_29344168;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String word = scanner.next();
        char[] chs = word.toCharArray();
        boolean case1=true, case2=true;
        if(Character.isLowerCase(chs[0])){
            case1 = false;
        }
        for(int i = 1;i<chs.length;i++){
            if(Character.isLowerCase(chs[i])){
                case2=false;
                break;
            }
        }
        String answer = null;
        if(case1 && case2){
            answer = new String(chs).toLowerCase();
        }else if(!case1 && case2){
            answer = new String(chs).toLowerCase();
            char ch = Character.toUpperCase(chs[0]);
            chs = answer.toCharArray();
            chs[0] = ch;
            answer = new String(chs);
        }else {
            answer = new String(chs);
        }

        System.out.println(answer);
    }

}