package problem_131A.subId_28538556;

import java.util.Scanner;
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner kb=new Scanner(System.in);
		while(kb.hasNext()){
			String str=kb.next();
			char a[]=str.toCharArray();
			int flag=0;
			if(str.length()==1){
				if(a[0]>='a'&&a[0]<='z'){
					a[0]=(char) (a[0]-32);
				}else if(a[0]>='A'&&a[0]<='Z'){
					a[0]=(char) (a[0]+32);
				}
				System.out.println(a[0]);
			}else{
				for (int i = 1; i < str.length(); i++) {
					if(a[i]>='A'&&a[i]<='Z'){
						continue;
					}else{
						flag=1;
						break;
					}
				}
				if(flag==1){
					for (int i = 0; i < str.length(); i++) {
						System.out.print(a[i]);
					}
					System.out.println();
				}else{
					for (int i = 0; i < str.length(); i++) {
						if(a[i]>='a'&&a[i]<='z'){
							a[i]=(char) (a[i]-32);
						}else if(a[i]>='A'&&a[i]<='Z'){
							a[i]=(char) (a[i]+32);
						}
						System.out.print(a[i]);
					}
					System.out.println();
				}
			}
		}
	}

}