package problem_131A.subId_27403601;

import java.util.Scanner;

/**
 * Created by NIckConterno on 5/28/17.
 */
public class Force131A {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str=in.nextLine();
        char[] c = str.toCharArray();
        Boolean b = true;
        if((int)c[0]>=97) {
            for (int i = 1; i < c.length; i++) {
                if((int)c[i]<=90){

                }
                else{
                    b=false;
                }
            }
        }
        else{
            b=false;
        }
        if(b){
            System.out.println(str.substring(0,1).toUpperCase()+str.substring(1).toLowerCase());
        }
        else{
            b=true;
            for (int i = 0; i < c.length; i++) {
                if((int)c[i]<=90){

                }
                else{
                    b=false;
                }
            }
            if(b){
                System.out.println(str.toLowerCase());
            }
            else{
                System.out.println(str);
            }
        }
    }
}