package problem_131A.subId_28678012;

import java.util.Scanner;
public class Main {
	public static void helper(int INT, char array[]){
		if(INT==1){
			for(int s=0; s<array.length; s++){
				System.out.print(array[s]);
			}
		}
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String string= sc.next();
		char array[]= string.toCharArray();
		if(Character.isLowerCase(array[0])){ //if first char is lower
			if(array.length==1){
				System.out.println(Character.toUpperCase(array[0]));
			}else{
				for(int i=1; i<array.length; i++){
					if(!Character.isUpperCase(array[i])){
						helper(1, array);
						break;
					}
					if(i==array.length-1){
						System.out.print(Character.toUpperCase(array[0]));
						for(int a=1; a<array.length; a++){
							System.out.print(Character.toLowerCase(array[a]));
						}
					}
				}
			}
		}else{ //else if first char is upper
			if(array.length==1){
				System.out.println(Character.toLowerCase(array[0]));
			}
				for(int h=1; h<array.length; h++){
					if(!Character.isUpperCase(array[h])){
						helper(1, array);
						break;
					}
					if(h==array.length-1){
						System.out.print(Character.toLowerCase(array[0]));
						for(int a=1; a<array.length; a++){
							System.out.print(Character.toLowerCase(array[a]));
						}
					}
			}
		}
	}
}