package problem_131A.subId_28273046;

import java.util.Scanner;
public final class Main{
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		String n  = in.next();
		int count=0;
		for(int i=0;i<n.length();i++)
		{
			if(Character.isUpperCase(n.charAt(i)))
			{
				count++;
			}
		}
		if(count==n.length())
		{
			System.out.println(n.toLowerCase());
		}
		else if(Character.isLowerCase(n.charAt(0))&&count==n.length()-1)
		{
			System.out.println(n.substring(0,1).toUpperCase()+n.substring(1,n.length()).toLowerCase());
		}
		else
		{
			System.out.println(n);
		}
	}
}