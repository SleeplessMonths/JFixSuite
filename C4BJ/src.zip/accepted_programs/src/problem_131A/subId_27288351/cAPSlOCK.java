package problem_131A.subId_27288351;

import java.util.Scanner;
public class cAPSlOCK {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		String wrd = sc.next();
		if((( wrd.substring(1).toUpperCase().equals(wrd.substring(1)) && Character.isLowerCase(wrd.charAt(0))) || wrd.equals(wrd.toUpperCase()))){
			for(int i = 0; i < wrd.length(); i++){
				if(Character.isLowerCase(wrd.charAt(i))){
					System.out.print(Character.toUpperCase(wrd.charAt(i)));
				}
				else{
					System.out.print(Character.toLowerCase(wrd.charAt(i)));
				}
			}
		}
		else{
			System.out.print(wrd);
		}
		System.out.println();
	}
}