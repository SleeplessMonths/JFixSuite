package problem_131A.subId_29270170;

import java.util.Scanner;

public class Main {
	public static void main(String [ ] args)
	{
		Scanner inputReader = new Scanner(System.in);  // Reading from System.in
		String s = inputReader.nextLine();
		
		if (checkCapsLockOn(s)) {
			s = correctCapsLock(s);
		}
		
		System.out.println(s);
	}
	
	public static boolean checkCapsLockOn(String s) {
		if (s.length() < 2) {
			return true;
		}
		
		for (int i = 1; i < s.length(); i++) {
			if (Character.isLowerCase(s.charAt(i))) {
				return false;
			}
		}
		
		return true;
	}
	
	public static String correctCapsLock(String s) {
		String ret;
		
		if (Character.isUpperCase(s.charAt(0))) {
			ret = s.toLowerCase();
		} else {
			ret = s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase();
		}
		
		return ret;
	}
}