package problem_131A.subId_28620712;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner in = new Scanner(System.in);
      String word= in.nextLine();
      String newWord="";
 
      if(word.toUpperCase()==word) newWord=word.toLowerCase();
      
      else if(Character.isLowerCase(word.charAt(0))){
    	  String sub=word.substring(1,word.length());
    	  if(sub.toUpperCase()==sub){
    		  
    		  newWord=(word.charAt(0)+"").toUpperCase()+word.substring(1,word.length()).toLowerCase();
    	  }
    	  else
    		  newWord=word;
    	  
      }
      else
    	  newWord=word;
      
      System.out.println(newWord.toString());
      }
      

}