package problem_131A.subId_28200731;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;
/**
 *
 * @author ACchallenge
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        if(checkCase(s)){
            s = reverseCase(s);
        }
        
        System.out.print(s);
        
    }
    
    private static boolean checkCase(String s){
        boolean b = true;
        for(int i = 1; i<s.length(); i++){
            if(Character.isLowerCase(s.charAt(i))){
                b = false; break;
            }
        }
        
        return (s.length()==1)||b;
    }
    private static String reverseCase(String s){
        StringBuilder sb = new StringBuilder(s);
        for(int i=0; i<s.length(); i++){
            if(Character.isUpperCase(s.charAt(i))){
                sb.setCharAt(i, Character.toLowerCase(s.charAt(i)));
            }
            else{
                sb.setCharAt(i, Character.toUpperCase(s.charAt(i)));
            }
        }
        return sb.toString();
    }
}