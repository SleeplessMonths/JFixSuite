package problem_131A.subId_27698561;

import java.util.Scanner;

public class bob {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String s = in.next();
        String answer = "";
        int uppercase_count = 0;
        char first = s.charAt(0);

        for(int i = 0; i < s.length(); i++) {
            if(isCap(s.charAt(i))) {
                uppercase_count++;
            }
        }
        

        if(uppercase_count == s.length()) {
            answer += s.toLowerCase();
        } else if (!isCap(first) ){
            int current_count = 0;
            for(int i = 1; i < s.length(); i++) {
                if(isCap(s.charAt(i))) {
                    current_count++;
                }
            }
            //System.out.println(current_count);
            if(current_count == s.length() - 1) {
                answer = change(s);
            } else {
                answer = s;
            }
        }
        
        if(answer.length() == 0) {
            answer = s;
        }
        System.out.println(answer);
    }

    public static boolean isCap(char x) {
        return (65 <= x && x <= 90);
    }

    public static String change(String s) {
        String bob = "";
        for(int i = 0; i < s.length(); i++) {
            char temp = s.charAt(i);
            if(isCap(temp)) {
                bob += Character.toLowerCase(temp);
            } else {
                bob += Character.toUpperCase(temp);
            }
        }
        return bob;
    }
}