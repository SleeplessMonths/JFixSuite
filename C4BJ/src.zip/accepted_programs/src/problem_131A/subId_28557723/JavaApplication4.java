package problem_131A.subId_28557723;

import java.util.Scanner;

public class JavaApplication4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("[:\\s\\n]");
        
        String palabra = sc.next();
        String resto = palabra.substring(1, palabra.length());
        Boolean activar1 = true,activar2 = true;
        for(int i=0;i<resto.length();i++){
            if(palabra.substring(0, 1).codePointAt(0)>=97){
                activar2 = false;
            }
            if(resto.codePointAt(i)>=97){
                activar1 = false;
            }
        }
        if(palabra.length()==1){
            if(palabra.codePointAt(0)>=97){
                System.out.println(palabra.toUpperCase());
            }
            else System.out.println(palabra.toLowerCase());
        }
        else if(activar2==true&&activar1==true){
            System.out.println(palabra.toLowerCase());
        }
        else if(activar1==true){
            System.out.println(palabra.substring(0, 1).toUpperCase()+resto.toLowerCase());
        }
        else System.out.println(palabra);
    }
}