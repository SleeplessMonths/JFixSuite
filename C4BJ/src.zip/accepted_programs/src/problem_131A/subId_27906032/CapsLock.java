package problem_131A.subId_27906032;

import java.util.Scanner;
import java.util.regex.Pattern;

public class CapsLock {
    public static void main(String[] args) {
        String word = new Scanner(System.in).nextLine();
        Pattern p = Pattern.compile("[A-Z]+");
        if (p.matcher(word).matches()) {
            System.out.println(word.toLowerCase());
        } else {
            p = Pattern.compile("[a-z]{0,1}[A-Z]*");
            if (p.matcher(word).matches()) {
                System.out.println(Character.toUpperCase(word.charAt(0)) + word.substring(1).toLowerCase());
            } else {
                System.out.println(word);
            }
        }
    }
}