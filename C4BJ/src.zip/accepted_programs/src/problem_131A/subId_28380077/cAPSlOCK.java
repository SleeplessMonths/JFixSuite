package problem_131A.subId_28380077;

import java.util.Scanner;
public class cAPSlOCK {	
	public static void main (String []args){
		Scanner input=new Scanner (System.in);
		String s = input.next();
		String ss =s.charAt(0)+"";
		String sss =s.replaceFirst(ss,"");
		if((ss.equals(ss.toLowerCase()))&&(sss.equals(sss.toUpperCase()))){
				System.out.print(ss.toUpperCase()+sss.toLowerCase());
			
		}
		else if (s.equals(s.toUpperCase())){
			System.out.print(s.toLowerCase());
		}
		
		else 
			System.out.print(s);
		
	}
}