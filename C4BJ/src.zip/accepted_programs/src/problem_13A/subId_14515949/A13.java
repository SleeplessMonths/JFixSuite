package problem_13A.subId_14515949;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class A13{
    /*
     * Title: Numbers
     * 
     * http://codeforces.com/problemset/problem/13/A
     * 
     */
    public static void main(String args[]){
        Scanner scanner = new Scanner(System.in);
        int A = scanner.nextInt();
        scanner.close();
        
        int total = 0;
        for (int toBase = 2; toBase < A; toBase++)
           total += sum(convert(A, 10, toBase));
        int count = A - 2;
        double average = total / (double) count;
        
        int gcd = gcd(total, count);
        int p = total / gcd;
        int q = count / gcd;

 
        System.out.println(p + "/" + q);
        
    }
    
    public static int gcd(int a, int b){
        if (b == 0)
            return Math.abs(a);
        else
            return gcd(b, a % b);
    }
    
    public static int sum(ArrayList <Integer> numbers){
        int sum = 0;
        for (int number: numbers)
            sum += number;
        return sum;
    }
    
    public static ArrayList <Integer> convert(int number, int fromBase, int toBase){
        String str_number = String.valueOf(number);
        return convert(str_number, fromBase, toBase);
    }
    
    public static ArrayList <Integer> convert(String number, int fromBase, int toBase){
        ArrayList <Integer> digits10 = new ArrayList <Integer> ();
        ArrayList <Integer> conversion = new ArrayList <Integer> ();
        
        for (char c: number.toCharArray())
            if (!Character.isDigit(c))
            return conversion;
        
        if (fromBase < 2 || fromBase > 10)
            return conversion;
        else{
            char[] chars = number.toCharArray();
            int[] digits = new int[chars.length];
            for (int i = 0; i < chars.length; i++)
                digits[i] = Character.getNumericValue(chars[i]);
            return convert(digits, fromBase, toBase);
        }
        
    }
    
    public static ArrayList <Integer> convert(int[] number, int fromBase, int toBase){
        /* Converts an array representation of a number of base "fromBase" and converts it
         * into an ArrayList representation of the number in base "toBase." */
        ArrayList <Integer> digits10 = new ArrayList <Integer> ();
        ArrayList <Integer> conversion = new ArrayList <Integer> ();
        if (fromBase < 2 || toBase < 2)
            return conversion;
        
        // first convert to base 10
        BigInteger num = new BigInteger("0");
        for (int i = 0; i < number.length; i++){
            String strnum = String.valueOf(number[i]);
            for (int j = 0; j < strnum.length(); j++)
                if (!Character.isDigit(strnum.charAt(j)))
                return conversion;
            int multiplier = number[i];
            // the multiplier, or "from digit", cannot be larger than or equal to the from base.
            if (multiplier >= fromBase)
                return conversion;
            int power = (int) (number.length - i - 1);
            num = num.add(bi(multiplier).multiply(bi(fromBase).pow(power)));
        }
        BigInteger num2 = new BigInteger(num.toString());
        while (num2.compareTo(bi(0)) == 1){
            digits10.add(num2.mod(bi(10)).intValue());
            num2 = num2.divide(bi(10));
        }
        
        Collections.reverse(digits10);
        if (toBase == 10)
            return digits10;
        else{
            // convert to new base
            while (num.compareTo(bi(0)) == 1){
                int right = (num.mod(bi(toBase))).intValue();
                conversion.add(right);
                num = num.subtract(bi(right));
                num = num.divide(bi(toBase));
            }
            Collections.reverse(conversion);
            return conversion;
        }
    }
    
    public static BigInteger bi(long n){
        return BigInteger.valueOf(n);
    }
    
}