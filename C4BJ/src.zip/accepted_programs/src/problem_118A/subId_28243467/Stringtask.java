package problem_118A.subId_28243467;

import java.util.Scanner;
public class Stringtask {
    public static String remove(String s,int pos){
    return s.substring(0,pos)+s.substring(pos+1);
    }
    public static  void main (String argv[]){
       Scanner input=new Scanner(System.in);
    int i;
       int n,m;
       String str;
      int find;
       str=input.nextLine();
       str=str.toLowerCase();
       find=0;
        while (find!=-1){
    find =str.indexOf("a");
    if (find!=-1)
         str=remove(str,find);}
        find=0;
        while (find!=-1){
    find =str.indexOf("i");
    if (find!=-1)
         str=remove(str,find);}
        find=0;
        while (find!=-1){
    find =str.indexOf("u");
    if (find!=-1)
         str=remove(str,find);}
        find=0;
        while (find!=-1){
    find =str.indexOf("y");
    if (find!=-1)
         str=remove(str,find);}
        find=0;
        while (find!=-1){
    find =str.indexOf("e");
    if (find!=-1)
         str=remove(str,find);}
     
        find=0;
        while (find!=-1){
            
    find =str.indexOf("o");
    if (find!=-1)
         str=remove(str,find);}
    
        for (i=-1;i++<str.length()-1;){
    System.out.print(".");
    System.out.print(str.charAt(i));
    }
    
}
}