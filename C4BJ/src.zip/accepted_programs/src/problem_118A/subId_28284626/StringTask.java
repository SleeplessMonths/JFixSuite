package problem_118A.subId_28284626;

import java.util.Scanner;

public class StringTask {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		String str = s.next();
		String res = "";
		str = str.toLowerCase();
		for(int i=0; i<str.length(); i++){
			char c = str.charAt(i);
			if(c!='a' && c!='e' && c!='i' && c!='o' && c!='u' && c!='y'){
				res += "." + c;
			}
		}
		System.out.println(res);
	}

}