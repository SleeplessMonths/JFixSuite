package problem_118A.subId_28046678;

import java.util.Scanner;

public class StringTask {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String input = sc.next();

		String lower = input.toLowerCase();
		String noVowels = lower.replaceAll("[aAiIuUeEoOYy]", "");
		String finalized = "";
		for (int i = 0; i < noVowels.length(); i++) {
			finalized += ".";
			finalized += noVowels.charAt(i);
		}
		System.out.println(finalized);
	}
}