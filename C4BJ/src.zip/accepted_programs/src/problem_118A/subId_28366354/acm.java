package problem_118A.subId_28366354;

import java.util.Scanner;
public class acm {
	public static void main(String[]args){
		Scanner o = new Scanner(System.in);
		String s = o.nextLine();
		s = s.toLowerCase();
		String g = "";
		for(int i=0;i<s.length();i++){
			if(ex("aeiouy",s.charAt(i))==false){

				g+=".";	g+=s.charAt(i);
			}
		}
		System.out.print(g);
	}
	public static boolean ex(String s,char c){
		for(int i=0;i<s.length();i++)
			if(s.charAt(i)==c)
				return true;
		return false;
	}
}