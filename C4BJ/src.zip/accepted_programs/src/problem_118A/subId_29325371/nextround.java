package problem_118A.subId_29325371;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
//import java.util.Scanner;
public class nextround
{
public static void main(String args[])throws IOException
{
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
String s=br.readLine();
s=s.toLowerCase();
String r="";
int l=s.length();
for(int i=0;i<l;i++)
{
    char c=s.charAt(i);
    if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u'||c=='y')
    continue;
    else
    r+=c;
}
for(int i=0;i<r.length();i++)
{
    System.out.print("."+r.charAt(i));
}}}