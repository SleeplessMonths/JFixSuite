package problem_118A.subId_28675771;

import java.util.Scanner;


public class assigment {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner input = new Scanner (System.in); 
		

	String s = input.nextLine();
	s=s.toLowerCase();
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i)=='a'||s.charAt(i)=='A'||s.charAt(i)=='u'||s.charAt(i)=='U'||s.charAt(i)=='E'||s.charAt(i)=='e'||s.charAt(i)=='I'||s.charAt(i)=='i'||s.charAt(i)=='O'||s.charAt(i)=='o'||s.charAt(i)=='Y'||s.charAt(i)=='y')
			{}else  System.out.print('.'+""+s.charAt(i));}}}