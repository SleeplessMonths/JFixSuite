package problem_118A.subId_28869370;

import java.util.Scanner;
public class Codeforces{
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        Codeforces ob=new Codeforces();
        String s=in.nextLine();s=s.toLowerCase();
        String newS="";
        for(int i=0;i<s.length();i++){
            char ch=s.charAt(i);
        if(ch!='a' && ch!='e' && ch!='i' && ch!='o' && ch!='u' && ch!='y')
        {
            newS=newS+"."+ch;
        }
    }
        System.out.println(newS);
    }
}