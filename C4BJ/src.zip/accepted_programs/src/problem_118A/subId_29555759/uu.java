package problem_118A.subId_29555759;

import java.util.Scanner;

import static java.lang.System.in;
import static java.lang.System.out;
public class uu{
  public static void main(String[] args){
    Scanner k= new Scanner (in);
    out.println("");
    String p=k.nextLine();
    p=p.toLowerCase();
    if(p.length()>=1 && p.length()<=100){
    for(int i=0; i<p.length(); i++){
      if(p.charAt(i)!='a' && p.charAt(i)!='e' && p.charAt(i)!='y' && p.charAt(i)!='i' && p.charAt(i)!='o'&& p.charAt(i)!='u'){
       out.print( "." + p.charAt(i));
      }}}}}