package problem_118A.subId_28063168;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class StringTask {
    private static String vowels = "aeiouy";

    public static void main(String [] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String input = in.readLine();

        System.out.println(stringTask(input));
    }

    private static String stringTask(String input) {
        StringBuilder output = new StringBuilder();

        for (char c : input.toLowerCase().toCharArray()) {
            if (!vowels.contains(c + "")) {
                output.append("." + c);
            }
        }

        return output.toString();
    }
}