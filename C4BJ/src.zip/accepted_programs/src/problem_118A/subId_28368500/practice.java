package problem_118A.subId_28368500;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;	

public class practice{
	
	public static void main(String[]args) throws IOException 
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String s =br.readLine();
		s = s.toLowerCase();
		String v = "aeiouy";
		for(int i = 0;i<s.length();i++)
		{
			for(char c : v.toCharArray())
				s = s.replace(c+"", "");
		}
		for(int j = 0;j<s.length();j++)
		{
			System.out.print("." + s.charAt(j));
		}
	}
	
	
}