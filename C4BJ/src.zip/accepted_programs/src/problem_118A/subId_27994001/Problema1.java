package problem_118A.subId_27994001;

import java.util.Scanner;

public class Problema1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		String in= sc.nextLine();
		in=in.toLowerCase();
		in=in.replaceAll("y", "").replaceAll("a", "").replaceAll("e", "").replaceAll("i", "").replaceAll("o", "").replaceAll("u", "");
		String out="";
		for(int i=0; i<in.length(); i++){
			out= out+'.'+in.charAt(i);
		}
		System.out.println(out);	
	}
}