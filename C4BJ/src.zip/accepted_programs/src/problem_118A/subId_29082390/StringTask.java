package problem_118A.subId_29082390;

import java.util.Scanner;

public class StringTask {

    public static void main(String[] args) {
        Scanner f = new Scanner(System.in);
        String c = f.next();
         c = c.toLowerCase();
        
        for(int i = 0; i< c.length(); i++)
        {
            switch (c.charAt(i)){
                case 'a' :
                    System.out.print("");
                    break;
                case 'o' :
                    System.out.print("");
                    break;
                case 'y' :
                    System.out.print("");
                    break;
                case 'e':
                    System.out.print("");
                    break;
                case 'u' :
                    System.out.print("");
                    break;
                case 'i' :
                    System.out.print("");
                    break;
                default :
                    System.out.print("." + (c.charAt(i)));
            }
        }
    } 
}