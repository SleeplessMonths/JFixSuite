package problem_118A.subId_28729421;

import java.util.Scanner;
public class _118A	
{ public static void main (String[] args)
	{ Scanner sc = new Scanner(System.in);
	String str=sc.next();
	String str1="";
	for (int i = 0 ; i < str.length();i++)
	{   char ch = str.charAt(i);
		 if (ch=='A'||ch=='Y'||ch=='y'||ch=='E'||ch=='I'||ch=='O'||ch=='U'||ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
				continue ;
			else 
			{str1+=".";
			str1+=Character.toLowerCase(ch);
				
			}
				
	}
	System.out.print(str1);
	
	
	}
	}