package problem_118A.subId_29111941;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Rawan Ali
 */
public class Vowels {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String str = input.nextLine();
     str=str.toLowerCase();
        char[] ch = str.toCharArray();
        if(ch.length<=100){
ArrayList<Character> chars = new ArrayList<>();
for(int o = 0; o<ch.length;o++){
    chars.add(ch[o]);}
for (int i = 0; i <chars.size();i++){
if (chars.get(i)=='u' || chars.get(i)=='o' || chars.get(i)=='y'|| chars.get(i)=='i' ||chars.get(i)=='e'|| chars.get(i)=='a' ){
 chars.remove(i);
i--;}
    }

for(int p = 0 ; p<chars.size();p++){
System.out.print("."+chars.get(p));
}
    }
    
}
}