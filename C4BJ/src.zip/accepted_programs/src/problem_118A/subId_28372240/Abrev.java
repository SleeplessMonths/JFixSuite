package problem_118A.subId_28372240;

import java.util.Scanner;

/**
 *
 * @author Acer Aspire E1
 */
public class Abrev {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
       String pal = input.next();
       String pal2 = pal.toLowerCase();
       pal2 =pal2.replace("a", "");
       pal2 =pal2.replace("e", "");
       pal2 =pal2.replace("i", "");
       pal2 =pal2.replace("o", "");
       pal2 =pal2.replace("u", "");
       pal2 =pal2.replace("y", "");
       String res = "";
       for(int i = 0; i < pal2.length(); i++){
           res +="."+pal2.charAt(i);
       }
       System.out.println(res);
    }
    
}