package problem_118A.subId_28528634;

import java.util.Scanner;

public class JavaApplication4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("[:\\s\\n]");

        String palabra = sc.next(); 
        String respuesta = "";
        String letras[] = palabra.split("");
        String letras2[] = palabra.split("");
        String l;
        for(int i = 0;i<letras.length;i++){
            letras2[i] = letras[i].toLowerCase();
        }
        for(int i = 0;i<letras.length;i++){
            l = letras2[i];
            if(!(l.equals("a")||l.equals("e")||l.equals("i")||l.equals("o")||l.equals("u")||l.equals("y"))){
                respuesta  += "."+l;
            }
        }
        System.out.println(respuesta);
    }
    
}