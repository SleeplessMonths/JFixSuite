package problem_118A.subId_28523353;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class stringclass {
	public static void main (String[] args){
		Scanner kb=new Scanner(System.in);
		String a=kb.nextLine();
		a=a.toLowerCase();
		String[] b=a.split("");
		//array to arraylist
		ArrayList<String> x = new ArrayList<String>(Arrays.asList(b));
		String a2="aeiouy";
		//System.out.println(x);
		for(int i=b.length-1;i>=0;i--)
			if((a2).contains(x.get(i)))
				x.remove(i);
		
		String str="";
		for(int i=0;i<x.size();i++){
			str+="."+x.get(i);
		}
		System.out.println(str);
		
	}
}