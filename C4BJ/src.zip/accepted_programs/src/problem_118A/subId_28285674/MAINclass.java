package problem_118A.subId_28285674;

import java.util.Scanner;

public class MAINclass {
	
	
	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
	     String arr=sc.nextLine();
         arr=arr.toLowerCase();
	     arr=arr.replaceAll("a", "");
	     arr=arr.replaceAll("e", "");
	     arr=arr.replaceAll("i", "");
	     arr=arr.replaceAll("o", "");
	     arr=arr.replaceAll("u", "");
	     arr=arr.replaceAll("y", "");
	    char[] array=arr.toCharArray();	    
	     for(char a:array) {
	     System.out.print(".");
	     System.out.print(a);
	      
	     }
	     System.out.println();
	     
		
		}

}