package problem_118A.subId_29356391;

import java.util.Scanner;
public class Main {

    
    public static void main(String[] args) {
    
        Scanner input = new Scanner(System.in);
        String s = input.nextLine();
      
        
        for(int i = 0 ; i < s.length() ; i++){
            
            //vowels
            if(s.charAt(i) == 'A' || s.charAt(i) == 'a' || s.charAt(i) == 'O' 
            || s.charAt(i) == 'o' || s.charAt(i) == 'Y' || s.charAt(i) == 'y'
            || s.charAt(i) == 'I' || s.charAt(i) == 'i' || s.charAt(i) == 'E'
            || s.charAt(i) == 'e' || s.charAt(i) == 'U' || s.charAt(i) == 'u' ){
              
                
              s =  s.replace(s.charAt(i), ' ');
            
            }
        }
    
    s = s.replaceAll(" ", "");
    s = s.toLowerCase();
    
    for(int i = 0 ; i < s.length() ; i++){
    
        System.out.print("." + s.charAt(i));
    
    }
    }
    
}