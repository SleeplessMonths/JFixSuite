package problem_118A.subId_29248158;

import java.util.Scanner;
public class StringTask {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		String s=sc.next();
		char c[]=s.toCharArray();
		int n=c.length;
		for(int i=0;i<n;i++){
			if(c[i] > 64 && c[i]<91){
				c[i]=(char)(c[i]+32);
			}
		}
     for(int i=0;i<n;i++){
    	 if(c[i] != 'a' && c[i] != 'e' && c[i] != 'i' && c[i] != 'u' && c[i] != 'o'&& c[i] != 'y')
    		 System.out.print("."+c[i]);
     }
     System.out.println();
	}

}