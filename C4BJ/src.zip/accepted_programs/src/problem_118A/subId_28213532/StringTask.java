package problem_118A.subId_28213532;

import java.util.Scanner;
public class StringTask {
	public static void main (String[] args){
		Scanner sc = new Scanner(System.in);
		char[] str = sc.next().toCharArray();
		
		for (int i = 0; i < str.length; i++){
			if ('A' <= str[i] && str[i] <= 'Z')
				str[i]+= 'a' - 'A';
		}
		
		
		for (int i = 0; i < str.length; i++){
			if (str[i] == 'a' | str[i] == 'o' | str[i] == 'y' | str[i] == 'e' | str[i] =='u' | str[i] == 'i')
				str[i] = '.';
		}
		
		for (int i = 0; i < str.length; i++){
			if (str[i] != '.')
				System.out.print("." + str[i]);
			
		}
	}
}