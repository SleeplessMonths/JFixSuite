package problem_118A.subId_28199085;

import java.util.Scanner;
public class strvc {
public static void main(String args[]) {
String str;
Scanner sc=new Scanner(System.in);
str=sc.nextLine();
char arr[]=str.toCharArray();
for(int i=0;i<str.length();i++){
if(arr[i]!='a'&&arr[i]!='e'&&arr[i]!='i'&&arr[i]!='o'&&arr[i]!='u'&&arr[i]!='A'&&arr[i]!='E'&&arr[i]!='O'&&arr[i]!='I'&&arr[i]!='U'&&arr[i]!='y'&&arr[i]!='Y') {
if(arr[i]<97)
arr[i]+=32;
System.out.print("."+arr[i]);
}
}
}
}