package problem_118A.subId_29243805;

import java.util.Scanner;

public class briks {

	public static void main(String[] args) throws Throwable {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
String s=sc.next();
String v="aAeEiIOouUYy";
StringBuilder sb=new StringBuilder(".");
for(int i=0;i<s.length();i++){
	if(!(v.contains(s.charAt(i)+""))){
			if(s.charAt(i)>='a'&&s.charAt(i)<='z')
		sb.append(s.charAt(i)+".");
	else
		sb.append(((char)(s.charAt(i)+32))+".");
	}
}
System.out.println(sb.substring(0, sb.length()-1));
  }
	}