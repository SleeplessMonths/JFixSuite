package problem_118A.subId_28367916;

import java.util.Scanner;

public class Session11
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner (System.in);
		String s = sc.next();
		String m = "";
		for(int i =0;i<s.length();i++)
		{
			char c = s.charAt(i);
			if ( c == 'a' ||c == 'e' || c=='i' || c =='o' ||c =='u'||c=='y'
			|| c == 'A' ||c == 'E' || c=='I' || c =='O' ||c =='U'||c=='Y');
			else
			{
				if (c >= 'A' && c<= 'Z')
				{
					c = (char)(c -('A'-'a'));
					m+="."+ c;
				}
				else
				{
					m+="."+ c;
				}
					
			}
				
		}
		System.out.println(m);
	}
}