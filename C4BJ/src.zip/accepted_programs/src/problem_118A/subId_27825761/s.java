package problem_118A.subId_27825761;

import java.util.Scanner;
public class s{
	public static void main(String [] args){
		Scanner sc=new Scanner(System.in);
		String x=sc.nextLine();
		String r="";
		x=x.toLowerCase();
		for(int i=0;i<x.length();i++)
		{
			char a=x.charAt(i);
			switch(a){
				case 'a':
				case 'e':
				case 'i':
				case 'o':
				case 'y':
				case 'u':break;
				default : r=r+"."+a;
		}
		}
		System.out.print(r);
	}
}