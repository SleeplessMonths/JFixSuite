package problem_118A.subId_28368321;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ACM1 {
	public static void main(String[] args) throws NumberFormatException,IOException {
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		String s=bf.readLine();
		s=s.toLowerCase();
		s=s.replaceAll("a", "");
		s=s.replaceAll("e", "");
		s=s.replaceAll("i", "");
		s=s.replaceAll("o", "");
		s=s.replaceAll("u", "");
		s=s.replaceAll("y", "");
		for(int i=0;i<s.length();i++)
			System.out.print("."+s.charAt(i));
		
	}
}