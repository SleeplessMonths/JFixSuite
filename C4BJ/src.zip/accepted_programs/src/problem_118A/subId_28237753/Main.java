package problem_118A.subId_28237753;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here
        Scanner cin = new Scanner(System.in);
        String s = cin.next().toLowerCase();
        String x = "";
        for (int i = 0; i < s.length(); i++) {
            if (!(s.charAt(i)=='a'||s.charAt(i)=='y'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u'||s.charAt(i)=='e'))
                x+=("."+s.charAt(i));
        }
        System.out.println(x);
    }
}