package problem_118A.subId_28355677;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Main {
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		Set<Character> vowels = new HashSet<>();
		vowels.add('a');
		vowels.add('e');
		vowels.add('i');
		vowels.add('o');
		vowels.add('u');
		vowels.add('y');
		
		String line = in.nextLine();
		line = line.toLowerCase();

		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < line.length(); i++) {
			if (!vowels.contains(line.charAt(i))) {
				sb.append(".");
				sb.append(line.charAt(i));
			}
		}

		System.out.println(sb.toString());
	}
}