package problem_118A.subId_29223974;

import java.util.Scanner;

public class CodeForces
{
    public static void main( String[] args )
    {
        Scanner cin = new Scanner ( System.in );
        String s = cin.next();
        String output = "";
        for ( int i = 0 ; i < s.length() ; i++ )
        {
            switch ( s.charAt( i ) )
            {
                case 'a':
                case 'A':
                case 'e':
                case 'E':
                case 'i':
                case 'I':
                case 'o':
                case 'O':
                case 'u':
                case 'U':
                case 'y':
                case 'Y':
                    continue;
                default:
                    output += ".";
                    output += s.charAt( i );
            }
        }
        output = output.toLowerCase();
        System.out.println( output );
    }
}