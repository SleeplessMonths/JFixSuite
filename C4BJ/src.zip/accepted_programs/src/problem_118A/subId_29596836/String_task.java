package problem_118A.subId_29596836;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class String_task
{
public static void main(String args[])throws IOException
{
BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
String s=in.readLine();
s=s.toLowerCase();
String str="";
for(int i=0;i<s.length();i++)
{
char c=s.charAt(i);
if((c=='a')||(c=='e')||(c=='i')||(c=='o')||(c=='u')||(c=='y'))
;
else
str=str+"."+c;
}
System.out.println(str);
}
}