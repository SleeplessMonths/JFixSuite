package problem_118A.subId_27974659;

import java.util.Scanner;

public class StringTask {

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        str= str.toLowerCase();
        String strCompare= "aoyeui";
        for(int i=0;i<str.length();i++){
            if(strCompare.indexOf(str.charAt(i))==-1){
                System.out.print("."+str.charAt(i));
            }
        }
        System.out.println("");
    }
    
}