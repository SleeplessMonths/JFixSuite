package problem_118A.subId_29630944;

import java.util.HashMap;
import java.util.Scanner;

public class StringTask {

	public static void main(String[] args) {
		// TODO Auto-generated metem.inthod stub
		Scanner s=new Scanner(System.in);
		String str=s.next();
		str=str.toLowerCase();
		HashMap< Character,Boolean> m=new HashMap< Character,Boolean>();
		
		m.put('a',true);
		m.put('e',true);
		m.put('i',true);
		m.put('o',true);
		m.put('u',true);
		m.put('y',true);
		String nstr="";
		
		for(int i=0;i<str.length();i++)
		{
			if(m.containsKey(str.charAt(i))==false)
			{
				char ch=str.charAt(i);
				nstr+='.'+""+ch;
			}
		}
	
	  System.out.println(nstr);
	}

}