package problem_118A.subId_29447611;

import java.util.Scanner;

public class StringTask {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String string = in.next().toLowerCase();
        String stringNew=string.replaceAll("[aeiouy]","");
        StringBuilder out = new StringBuilder(stringNew);
        StringBuilder outFinal = new StringBuilder();
        for (int i=0;i<out.length();i++) {
            outFinal.append(".");
            outFinal.append(out.charAt(i));
        }
        System.out.println(outFinal);
    }
}