package problem_118A.subId_29263842;

import java.util.Scanner;

/**
 * Created by ratherrum on 02.08.17.
 */
public class StringExc {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        StringBuilder sb = new StringBuilder(sc.nextLine());
        char[] letters = {'A', 'O', 'Y', 'E', 'U', 'I', 'a', 'o', 'y', 'e', 'u', 'i'};
        int i = 0;
        while (i < sb.length()) {
            int j = 0;
            while (j <= (letters.length - 1) && i <= (sb.length() - 1)) {
                if (sb.charAt(i) == letters[j]) {
                    sb.deleteCharAt(i);
                    j = 0;
                } else {
                    j++;
                }
            }
            i++;
        }
        System.out.println(asdf(sb, i));
    }

    public static String asdf(StringBuilder a, int i) {
        for (int k = 0; k < a.length(); k += 2) {
         a = a.insert(k, '.');
        }
        String res = "";
        res = a.substring(0, a.length()).toLowerCase();
        return res;
    }
}