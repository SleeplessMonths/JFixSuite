package problem_118A.subId_28201902;

import java.util.Scanner;


public class StringTask {
    public static void main(String[] args) {
                         Scanner sc = new Scanner(System.in);
        String str = sc.next().toLowerCase();
        String [] vowel = { "A","O", "Y", "E", "U", "I"};
        for (int i = 0; i < vowel.length; i++) {
            if(str.contains(vowel[i].toLowerCase())){
                str =str.replace(vowel[i].toLowerCase(), "");
            }
            
        }
        String s="";
        for (int i = 0; i < str.length(); i++) {
            s =s+ "."+str.charAt(i);
        }
        System.out.println(s);
    }
   
}