package problem_118A.subId_28907317;

import java.util.Scanner;

public class StringTask {
	public static void main(String[]args){
		
		Scanner sc= new Scanner(System.in);
		String b =sc.next();
		String n="";
		for(int i=0 ;i<b.length();i++){
		if(!(b.charAt(i)=='A' || b.charAt(i)=='a'|| b.charAt(i)=='E'||b.charAt(i)=='e'||b.charAt(i)=='I'||b.charAt(i)=='i'||b.charAt(i)=='O'||b.charAt(i)=='o'||b.charAt(i)=='U'||b.charAt(i)=='u'||b.charAt(i)=='y'|| b.charAt(i)=='Y')){
			n=n+"."+b.charAt(i);
			
		}
		}
		
		System.out.println(n.toLowerCase());
		
	}

}