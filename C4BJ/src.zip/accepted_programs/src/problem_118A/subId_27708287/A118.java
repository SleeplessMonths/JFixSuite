package problem_118A.subId_27708287;

import java.util.Arrays;
import java.util.Scanner;

public class A118{
	
	public static void main(String[] args){
		Scanner in = new Scanner(System.in);
		StringBuilder s = new StringBuilder(in.nextLine());
		char[] vow = {'a','e','i','o','u','A','E','I','O','U','y','Y'};
		Arrays.sort(vow);
		for(int i=0;i<s.length();i++){
			//System.out.println(s);
			if(Arrays.binarySearch(vow,s.charAt(i))>-1){
				//System.out.println(Arrays.binarySearch(vow,s.charAt(i))+" 0");
				s.deleteCharAt(i);
				i--;
			}
			else{
				s.setCharAt(i,Character.toLowerCase(s.charAt(i)));
				s.insert(i,'.');
				i++;
			}
		}
		System.out.println(s);
		
	}
	
}