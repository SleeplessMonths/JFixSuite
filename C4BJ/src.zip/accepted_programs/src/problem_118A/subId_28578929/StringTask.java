package problem_118A.subId_28578929;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.stream.IntStream;

public class StringTask {
	public static void main(String[] args) throws IOException {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

		String line = in.readLine();
		line = line.toLowerCase();
		String temp = line.replace("a", "").replace("e", "").replace("i", "").replace("o", "").replace("u", "").replace("y", "");

		IntStream.range(0, temp.length()).forEach(index -> {
			System.out.print('.');
			System.out.print(temp.charAt(index));
		});
	}
}