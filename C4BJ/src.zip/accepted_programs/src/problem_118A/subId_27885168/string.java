package problem_118A.subId_27885168;

import java.util.Scanner;
public class string
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String s;
        s = sc.nextLine();
        int l = s.length();
        char a[] = new char[2*l];
        int i,j = 0;
        String s1 = s.toLowerCase();
        for(i = 0; i < l; i++)
        {
            char ch = s1.charAt(i);
            if(ch != 'A'&& ch != 'E'&& ch!='I'&& ch!='O'&& ch!='U'&& ch != 'a' && ch != 'e' && ch!='i' && ch!='o' && ch!='u' && ch!= 'y')
            {
                a[j] = '.';
                ++j;
                a[j] = ch;
                ++j;
            }
        }
        for(i = 0; i < j;i++)
        {
            System.out.print(a[i]);
        }
    }
}