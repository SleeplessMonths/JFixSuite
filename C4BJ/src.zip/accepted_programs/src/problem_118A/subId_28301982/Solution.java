package problem_118A.subId_28301982;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Ameera
 * Codeforces: stringTask
 */
public class Solution {
    
    public static void main(String[] args) throws IOException{
        
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        
//        StringBuffer s = new StringBuffer(in.readLine());
//        
//        System.out.println("string created with length = " + s.length());
//        
//        for (int i = 0; i < s.length(); i++) {
//            
//            System.out.println("inside loop i = "+ i);
//            System.out.println("i<s.length=" + (i<s.length()));
//            
//            if(isVowl(s.charAt(i))){
//                s.deleteCharAt(i);
//            }
//            else{
//                if(Character.isUpperCase(s.charAt(i))){
//                    s.replace(i, i, Character.toLowerCase(s.charAt(i))+"");
//                }
//                s.insert(i, ".");
//            }
//        }

        String t = in.readLine();
        
        String s="";
        
        for (int i = 0; i < t.length(); i++) {
            
            if( ! isVowl(t.charAt(i)) ){
                s+="."+Character.toLowerCase(t.charAt(i));
            }
            
        }
        
        System.out.println(s);
               
    }
    
    public static boolean isVowl(char i ){
        if( i=='A' || i=='O' || i=='U' || i=='I' || i=='E' || i=='a' || i=='o' || i=='u' || i=='e' || i=='i' || i=='Y' || i=='y'){
            return true;
        }
        return false;
    }
    
}