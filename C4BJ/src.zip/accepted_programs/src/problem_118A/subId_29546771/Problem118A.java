package problem_118A.subId_29546771;

import java.util.Scanner;

public class Problem118A {
    private static char[] VOWELS = new char[]{'A', 'E', 'I', 'O', 'U', 'Y'};

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        String str = input.nextLine();

        StringBuilder sb = new StringBuilder(str);

        appendBeforeConsonant(replaceUpperToLower(removeVowels(sb)));
    }

    static StringBuilder removeVowels(StringBuilder sb) {
        String vowels = new String(VOWELS);
        for (int i = 0; i < sb.length(); i++) {
            if (vowels.indexOf(Character.toUpperCase(sb.charAt(i))) != -1) {
                sb.deleteCharAt(i);
                i--;
            }
        }

        return sb;
    }

    static String replaceUpperToLower(StringBuilder sb) {
        for (int i = 0; i < sb.length(); i++) {
            if (Character.isUpperCase(sb.charAt(i))) {
                sb.setCharAt(i, Character.toLowerCase(sb.charAt(i)));
            }
        }

        return sb.toString();
    }

    static void appendBeforeConsonant(String text) {
        StringBuilder sb2 = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            sb2.append("." + text.charAt(i));
        }

        System.out.println(sb2.toString());
    }
}