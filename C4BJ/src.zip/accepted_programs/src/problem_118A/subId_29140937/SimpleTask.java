package problem_118A.subId_29140937;

import java.util.Scanner;

public class SimpleTask {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String s = in.next().toLowerCase();
		char[] voy = {'a', 'o', 'y', 'e', 'u', 'i'};
		StringBuilder sb = new StringBuilder("");
		for(int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			boolean found = false; 
			for(int j = 0; j < voy.length; j++) {
				if(c == voy[j]) {
					found = true; break;
				}
			}
			if(!found) {
				sb.append("." + c); 
			}
		}
		System.out.println(sb);
		in.close();
	}
}