package problem_118A.subId_28366541;

import java.util.Scanner;
public class acm3{
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		String x = sc.next();
		String y = x.toLowerCase();
		String z="";
		for(int i=0;i<y.length();i++){
			if(y.charAt(i)!= 'a' && y.charAt(i)!= 'o' && y.charAt(i)!= 'u' && y.charAt(i)!= 'e' && y.charAt(i)!= 'i' && y.charAt(i)!= 'y'){
			z+="."+y.charAt(i);
			}
		}
		System.out.println(z);
		sc.close();
	}
}