package problem_118A.subId_29308375;

import java.util.Scanner;
public class Sdz {
    public static void main(String arfs[])
    {Scanner sc=new Scanner(System.in);
        String s1=sc.next();
        String s2=s1.toLowerCase();
        char[]arr=s2.toCharArray();
        for(int i=0;i<arr.length;i++)
        {if(arr[i]=='a'||arr[i]=='e'||arr[i]=='i'||arr[i]=='o'||arr[i]=='u'||arr[i]=='y')
                System.out.print("");
            else if(arr[i]>=87&&arr[i]<=122)
                System.out.print("."+arr[i]);}}}