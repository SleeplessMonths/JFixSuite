package problem_118A.subId_29043173;

import java.util.Scanner;

public class stringTask{
	public static void main(String args[]){
		Scanner in= new Scanner(System.in);
		String word=in.nextLine();
		char temp,lowerword;
		for(int i=0; i<word.length();i++){
			temp = word.charAt(i);
			lowerword= Character.toLowerCase(temp);
			if(lowerword=='a'||lowerword=='e'|| lowerword=='u'||lowerword=='i'||lowerword=='o'||lowerword=='y')
				System.out.print("");	
			else 
				System.out.print("."+lowerword);
		}
	}
}