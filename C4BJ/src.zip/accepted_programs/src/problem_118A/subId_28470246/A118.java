package problem_118A.subId_28470246;

import java.util.Scanner;

public class A118 {
	
	public static String lower(String str) {
		String temp=str.toLowerCase();
		return temp;
	}

	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in);
		String str=scan.next();
		String a=lower(str);
		//System.out.println(a);
		String rep=a.replaceAll("[a,e,i,o,u,y]", "");
		//System.out.println(rep);
		for(int i=0;i<rep.length();i++) {
			if(i<(rep.length())) System.out.print(".");
			System.out.print(rep.charAt(i));	
		}
		scan.close();
	}
}