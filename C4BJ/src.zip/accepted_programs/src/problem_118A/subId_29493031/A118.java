package problem_118A.subId_29493031;

import java.util.Scanner;

public class A118 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String input = in.nextLine();
		
		StringBuilder bldr = new StringBuilder();
		
		for(int i=0; i<input.length(); i++) {
			if( input.charAt(i) == 65 || input.charAt(i) == 69 ||
			    input.charAt(i) == 73 || input.charAt(i) == 79 ||
			    input.charAt(i) == 85 || input.charAt(i) == 97 ||
			    input.charAt(i) == 89 || input.charAt(i) == 121 ||
			    input.charAt(i) == 101 || input.charAt(i) == 105 ||
			    input.charAt(i) == 111 || input.charAt(i) == 117 ) {
				continue; 
			} else {
				bldr.append("." + input.substring(i, i+1).toLowerCase());
			}
			
		}
		
		System.out.println(bldr.toString());
		
	}
	
}