package problem_118A.subId_28246472;

import java.util.HashSet;
import java.util.Scanner;
public final class Main
{
	public static void main(String args[])
	{
		Scanner in = new Scanner(System.in);
		String s = in.next();
		StringBuilder sb = new StringBuilder();
		HashSet<Character> set = new HashSet();
		set.add('a');set.add('e');set.add('i');
		set.add('o');set.add('u');set.add('y');
		for(int i=0;i<s.length();i++)
		{
			char c = Character.toLowerCase(s.charAt(i));
			if(!set.contains(c))
			{
				sb.append("."+c);
			}
		}
		System.out.println(sb.toString());
	}

}