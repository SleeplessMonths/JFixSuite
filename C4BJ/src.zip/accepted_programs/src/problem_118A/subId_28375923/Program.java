package problem_118A.subId_28375923;

import java.util.Scanner;

public class Program {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);

		String str = input.nextLine();
		String nstr = "";

		for (int i = 0; i < str.length(); i++) {

			char ch = str.charAt(i);

			if ((ch == 'a') || (ch == 'e') || (ch == 'o') || (ch == 'i') || (ch == 'u') || (ch == 'y') || (ch == 'A')
					|| (ch == 'E') || (ch == 'I') || (ch == 'U') || (ch == 'Y') || (ch == 'O')) {
				continue;
			} else {
				nstr = nstr + ".";
				nstr = nstr + Character.toLowerCase(ch);

			}
			
		}
		System.out.println(nstr);
	}

}