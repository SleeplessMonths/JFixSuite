package problem_118A.subId_28375112;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class sal3 {
	public static void main (String []args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String s = br.readLine() ;
		s=s.toLowerCase() ;
				String m ="";
		for( int i= 0 ; i < s.length() ;i++){
			switch(s.charAt(i)){
			case 'b':
			case 'c':
			case 'd':
			case 'f':
			case 'g':
			case 'h':
			
			case 'j':
			case 'k':
			case 'l':
			case 'm':
			case 'n':
			case 'p':
			case 'q':
			case 'r':
			case 's':
			case 't':
			case 'v':
			case 'w':
			case 'x':
			case 'z':
				m=m+ "."+s.charAt(i) ;
				break ;
}
		}
		System.out.print(m);
		
	}

}