package problem_118A.subId_28855591;

import java.util.Scanner;

public class Task{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String word = sc.next();
        word = word.toLowerCase();
        String x = "";
        for(int i = 0; i < word.length(); i++){
            char k = word.charAt(i);
            if(k != 'a' && k != 'e' && k != 'i' && k != 'u' && k != 'o' && k != 'y'){
                x += "." + k;
            }
        }
        System.out.print(x);
    }
}