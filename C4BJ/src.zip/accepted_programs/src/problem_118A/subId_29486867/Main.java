package problem_118A.subId_29486867;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in) ;
		String x = input.next() ;
		x = x.toLowerCase() ;
		for (int i = 0 ; i < x.length() ; i ++)
		{
			char k = x.charAt(i) ;
			if (k != 'a' && k != 'e' && k != 'i' && k != 'o' && k != 'u' && k != 'y')
			{
				System.out.print("." + k);
			}
		}
	
	}

}