package problem_118A.subId_28970083;

import java.util.Scanner;

public class Fady11 {
    public static String code(String a){

       a =  a.toLowerCase();
        String n =""; String t = ".";
        for(int i=0; i<=a.length()-1 ; i++){
            if(a.charAt(i) != 'a' && a.charAt(i) != 'o' &&
                    a.charAt(i) != 'u' && a.charAt(i) != 'i' &&
                    a.charAt(i) != 'y' && a.charAt(i) != 'e' ){n += t + a.charAt(i);}
        }

        return n;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String a = s.next();
        if(a.length() >=1 && a.length() <=100) {
            System.out.println(code(a));
        }
    }
}