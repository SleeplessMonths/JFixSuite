package problem_118A.subId_28271005;

/* package whatever; // don't place package name! */

import java.util.Scanner;

/* Name of the class has to be "Main" only if the class is public. */
public class problem4
{
	public static void main (String[] args) throws java.lang.Exception
	{
		
	Scanner in = new Scanner(System.in);
	
	String s = in.next();
	String result ="";
    for(int i=0; i<s.length();i++){
    	if("aeiouyAEIOUY".indexOf(s.charAt(i)) == -1){
			result+= "."+(s.charAt(i)+"").toLowerCase();
    	}
    }
    System.out.println(result);
    
    }
    
}