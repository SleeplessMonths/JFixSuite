package problem_118A.subId_28667346;

// package codeforces

import java.util.Scanner;
public class test {
public static void main (String [] bidzina) {
	Scanner sc = new Scanner(System.in);
	String word = sc.next();
	String newWord = "";
	word = word.toLowerCase();
	word = word.replace('a','?');
	word = word.replace('e','?');
	word = word.replace('i','?');
	word = word.replace('o','?');
	word = word.replace('u','?');
	word = word.replace('y','?');
	for (int i = 0; i <= word.length()-1; i++) {
		if (word.charAt(i) > 'a' && word.charAt(i) <= 'z')
		newWord += "." + word.charAt(i);
	}	
	System.out.print(newWord);
}	
}