package problem_118A.subId_29314042;

import java.util.Scanner;

public class StringTask {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		String x = in.next();
		x = x.toLowerCase();
		String y ="";
		
		for (int i = 0; i < x.length(); i++) 
		{
			if (x.charAt(i)=='y'||x.charAt(i)=='a'||x.charAt(i)=='e'||x.charAt(i)=='u'||x.charAt(i)=='i'||x.charAt(i)=='o') {
				continue;
			}else{
				y = y +'.'+x.charAt(i);
			}
		}
		
		System.out.println(y);
	}

}