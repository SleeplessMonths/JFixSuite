package problem_118A.subId_28595941;

import java.util.Scanner;

public class Run
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        String string = delVowels(input.nextLine().toLowerCase());
        System.out.println(string);
    }
    public static String delVowels(String str)
    {
        str = str.replaceAll("[aeiouy]", "");
        String[] s = str.split("");
        String string1 = "";
        for (String st : s)
        {
            string1 += "." + st;
        }
        return string1;
    }
}