package problem_118A.subId_29439870;

import java.util.Scanner;

public class TooLongString {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String str = s.next();

        for(char c : str.toCharArray()) {
            if (isVowel(Character.toLowerCase(c))) {
                continue;
            }
            System.out.print("." + Character.toLowerCase(c));
        }
    }

    public static boolean isVowel(char a) {
        return a == 'a' || a == 'e' || a == 'i' || a == 'o' || a == 'u' || a == 'y';
    }
}