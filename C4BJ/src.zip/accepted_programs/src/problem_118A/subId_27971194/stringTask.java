package problem_118A.subId_27971194;

import java.util.Scanner;
public class stringTask
{
    public static void main(String [] args)
    {
        Scanner in=new Scanner(System.in);
        String s=in.next().toLowerCase();
        StringBuffer s1=new StringBuffer(s);
       
        int count=0;
        for(int i=0;i<s.length();i++)
        {
            if(s.charAt(i)=='a'||s.charAt(i)=='y'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u'||s.charAt(i)=='e')
            {
                s1.delete(i-count,i+1-count);
                count++;
                
            }
            
        } 
      //  System.out.println(s1);
        String s2=new String(s1);
        String s3="";
        for(int i=0;i<s2.length();i++)
        {
        	s3=s3+"."+s2.charAt(i);
        	
        }
       
      
       System.out.println(s3.toLowerCase());
       
        
        
        
    }
}