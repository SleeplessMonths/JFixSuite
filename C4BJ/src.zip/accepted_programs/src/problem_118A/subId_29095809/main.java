package problem_118A.subId_29095809;

//package codeforces;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);

		char[] str = in.next().toLowerCase().toCharArray();
		List<String> list = new LinkedList<>();

		for (int i = 0; i < str.length; i++)
			list.add(String.valueOf(str[i]));

		List<String> rem = Arrays.asList("a", "o", "y", "e", "u", "i");

//		System.out.println(list);

		for (int i = 0; i < list.size(); i++)
			if (rem.contains(list.get(i))) {
				list.remove(list.get(i));
				i--;
			} else
				list.set(i, "."+list.get(i));

		for (int i = 0; i < list.size(); i++)
		System.out.print(list.get(i));

	}
}