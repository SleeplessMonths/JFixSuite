package problem_121A.subId_22312777;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.StringTokenizer;

public class Temp3 {
	static final int max = 1<<9;
	public static void fill(ArrayList<Long> arr)
	{	
		int mask = 1;
		while(mask<=max)
		{
			String s = Integer.toBinaryString(mask);
			while(s.length()<=9)
			{				
				arr.add(Long.parseLong(getVal(s)));
				s= 0+s;
			}
			mask++;
		}
		String h = "";
		for (int i = 0; i <= 9; i++) 
		{
			h+="4";
			arr.add(Long.parseLong(h));
		}
	}
	public static String getVal(String x)
	{
		StringBuilder res = new StringBuilder();
		for (int i = 0; i < x.length(); i++) 
		{
			if(x.charAt(i)=='0')
				res.append("4");
			else
				res.append("7");
		}
		return res.toString();
	}
	public static void main(String[] args) throws Throwable {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		ArrayList<Long> arr = new ArrayList<Long>();
		fill(arr);
		Collections.sort(arr);
		StringTokenizer st = new StringTokenizer(br.readLine());
		long l = Long.parseLong(st.nextToken());
		int r = Integer.parseInt(st.nextToken());
		long ans = 0;
		for (int i = 0; i < arr.size() && l<=r; i++) 
		{
			long x = arr.get(i);
			if(x<l)
				continue;
			if(x==l)
			{
				ans+=x;
				l= x+1;				
			}
			else
			{
				if(x<=r)
				{
					ans+=(x-l+1)*x;
					l = x+1;
				}
				else
				{
					ans+=(r-l+1)*x;
					break;
				}
			}
		}
		System.out.println(ans);
	}
}