package problem_121A.subId_22936498;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class LuckySum {
	static ArrayList<Long> key;
	static long[] dp;
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int l = scan.nextInt(), r = scan.nextInt();
		long n = 0;
		key = new ArrayList<>();
		luckynumber();
		key.add(4444444444L);
		Collections.sort(key);
		dp = new long[key.size()];
		dp[0] = 16L;
		for(int i = 1 ; i < key.size() ; i++) dp[i] = dp[i-1] + ((key.get(i)-key.get(i-1))*key.get(i));
		int indexl = 0, indexr = 0;
		for(int i = 0 ; i < key.size() ; i++){
			if(key.get(i) >= l){
				indexl = i;
				break;
			}
		}
		for(int i = 0 ; i < key.size() ; i++){
			if(key.get(i) >= r){
				indexr = i;
				break;
			}
		}
		long ans = 0;
		if(indexr - indexl > 1) ans+=dp[indexr-1]-dp[indexl];
		if(indexl == indexr) ans+=(r-l+1)*key.get(indexl);
		else{
			ans += (key.get(indexl)-l+1)*key.get(indexl);
			if(l <= key.get(indexr-1)) ans += (r-key.get(indexr-1))*key.get(indexr);
			else ans += (r-l)*key.get(indexr);
		}
		System.out.println(ans);
	}
	static void luckynumber(){
		for(int i = 0 ; i < 512 ; i++){
			String num = Integer.toBinaryString(i);
			num = num.replace('1', '4');
			num = num.replace('0', '7');
			key.add(Long.parseLong(num));
			for(int j = num.length() ; j < 9 ; j++){
				num = "0" + num;
				num = num.replace('0', '7');
				key.add(Long.parseLong(num));
			}
		}
	}
}