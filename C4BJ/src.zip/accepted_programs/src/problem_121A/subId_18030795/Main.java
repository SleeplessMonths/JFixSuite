package problem_121A.subId_18030795;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.StringTokenizer;

import static java.lang.Integer.parseInt;
import static java.lang.Long.parseLong;

public class Main {

    public static void main(String[] args) throws IOException {

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
                                            //(new FileReader("input.in"));
        StringBuilder out = new StringBuilder();
        StringTokenizer tk;
        //PrintWriter pw = new PrintWriter("output.out", "UTF-8");
        
        tk = new StringTokenizer(in.readLine());
        int a = parseInt(tk.nextToken()),b = parseInt(tk.nextToken()),x = lengthIs(a),y = lengthIs(b)+1;
        
        List<Long> [] lucky = new List[y+2];
        for(int len=x; len<=y; len++) {
            lucky[len] = new ArrayList<Long>();
            for(int m=0; m<=(1<<len)-1; m++) {
                String s = "";
                for(int i=0; i<len; i++) {
                    if((m & (1<<i))==0)
                        s += "4";
                    else s += "7";
                }
                lucky[len].add(parseLong(s));
            }
            Collections.sort(lucky[len]);
        }
        
        long i=a,j=b;
        long ans = 0;
        
        for(int len=x; len<=y; len++) {
            //if(lengthIs(i) > x) continue;
            
            for(long num : lucky[len]) {
                long l=i,r=j,m,val=-1;
                while(l <= r) {
                    m = (l+r)/2;
                    
                    if(m > num) r = m-1;
                    else {
                        val = m;
                        l = m+1;
                    }
                }
                
                
                if(val==-1) continue;
                ans += (val-i+1)*num;
                i = val+1;
                
                if(lengthIs(i) > len) break;
            }
        }
        
        System.out.println(ans);
    }
    
    static int lengthIs(long num) {
        return (""+num).length();
    }
    
}