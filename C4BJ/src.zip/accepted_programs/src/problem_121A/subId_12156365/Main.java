package problem_121A.subId_12156365;

import java.util.Scanner;
import java.util.TreeSet;

public class Main {
	public static void main(String[] args) {
		init();
		Scanner sc = new Scanner(System.in);
		long a = sc.nextLong();
		long b = sc.nextLong();
		System.out.println(getSum(a, b));
	}

	static long getSum(long a, long b) {
		if (next(a) == next(b))
			return (b - a + 1) * next(a);

		return getSum(a, (a + b) / 2) + getSum((a + b) / 2 + 1, b);
	}

	static long next(long x) {
		return lucky.tailSet(x, true).first();
	}

	static TreeSet<Long> lucky = new TreeSet<>();

	static void init() {
		for (int i = 0; i < (1 << 10); i++) {
			long n = 0;
			for (char c : Integer.toBinaryString(i).toCharArray())
				n = n * 10 + (c == '0' ? 4 : 7);
			lucky.add(n);
			
			n = 0;
			for (char c : Integer.toBinaryString(i).toCharArray())
				n = n * 10 + (c == '0' ? 7 : 4);
			lucky.add(n);
		}
	}
}