package problem_120A.subId_7938036;

import java.io.*;

public class Main {

    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new FileReader(new File("input.txt")));
        BufferedWriter bw = new BufferedWriter(new FileWriter(new File("output.txt")));
        String linea = br.readLine();
        int linea2 = Integer.parseInt(br.readLine());
        if (linea.equals("front")){
            if (linea2 == 1){
                bw.write("L");
            }else{
                bw.write("R");
            }
            bw.newLine();
        }else{
            if(linea2 == 1){
                bw.write("R");
            }else{
                bw.write("L");
            }
            bw.newLine();
        }
        bw.close();
        br.close();
    }

}