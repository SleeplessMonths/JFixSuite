package problem_125A.subId_864230;

import java.util.Scanner;

public class A {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int inch = (int) (Math.round(n * 1.0 / 3));
        System.out.println(inch / 12 + " " + (inch % 12));
    }
}