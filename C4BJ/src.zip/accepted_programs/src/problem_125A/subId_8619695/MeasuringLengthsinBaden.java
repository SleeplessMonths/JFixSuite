package problem_125A.subId_8619695;

import java.util.Scanner;

public class MeasuringLengthsinBaden {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
       int n=in.nextInt();
       int c=n/3;
        if (n%3==2) {c++;}
        System.out.println(c/12+" "+(c-(c/12)*12));
    }
}