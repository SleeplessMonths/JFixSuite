package problem_125A.subId_883512;

import java.util.Scanner;
public class wew {
	public static void main (String [] args) {
		 Scanner in = new Scanner (System.in);
		int x = in.nextInt();
		System.out.println ((x+1)/36+" "+(x+1)%36/3);
		}
	}