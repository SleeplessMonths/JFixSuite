package problem_125A.subId_3966892;

import java.util.Scanner;
public class A125
{
    public static void main(String aa[])
    {
        Scanner ob=new Scanner(System.in);
        int n,ft,in,c;
        n=ob.nextInt();
        ft=n/36;
        c=n%36;
        in=(int)Math.rint(c/3f);
        if(in==12)
        {
            ft=ft+1;
            in=0;
        }
        System.out.println(ft+" "+in);
    }
}