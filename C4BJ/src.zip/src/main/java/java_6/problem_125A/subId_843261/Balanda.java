package java_6.problem_125A.subId_843261;

import java.util.Scanner;


public class Balanda 
{
    public static void main(String[] s)
    {
        Scanner in = new Scanner(System. in);
        int santimetr = in.nextInt();
        int duim = 0;
        int fut = 0;
        
        for (int i = 36; i < santimetr; )
        {
            santimetr = santimetr - i;
            fut++;
        }
        for (int i = 3; i <= santimetr; ) 
        {
            santimetr = santimetr - i;
            duim++;
        }
        if(santimetr == 2)
        {
            duim = duim+1;
        }
        System.out.print(fut+" ");
        System.out.println(duim);
    }
}