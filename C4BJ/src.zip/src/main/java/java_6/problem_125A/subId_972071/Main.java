package java_6.problem_125A.subId_972071;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

/**
 * Created by IntelliJ IDEA.
 * User: aircube
 */
public class Main {
    BufferedReader reader;
    StringTokenizer tokenizer;
    PrintWriter writer;

    public static void main(String[] args) throws IOException {
        new Main().run();
        
    }

    public void run() throws IOException{
        tokenizer = null;
        reader = new BufferedReader(new InputStreamReader(System.in));
        writer = new PrintWriter(System.out);
        solve();
        writer.flush();
    }


    private void solve() throws IOException {
        int n = nextInt();
        int foot = n/(36);
        n -= foot*12*3;
        int duim = (n/3) + (n%3==2?1:0);
        writer.print(foot + " " + duim);
    }

    String nextToken()  throws IOException {
        while (tokenizer == null || !tokenizer.hasMoreTokens())
            tokenizer = new StringTokenizer(reader.readLine());
        return tokenizer.nextToken();
    }

    int nextInt()  throws IOException {
        return Integer.parseInt(nextToken());
    }

    double nextDouble()  throws IOException {
        return Double.parseDouble(nextToken());
    }

    Long nextLong()  throws IOException {
        return Long.parseLong(nextToken());
    }

}