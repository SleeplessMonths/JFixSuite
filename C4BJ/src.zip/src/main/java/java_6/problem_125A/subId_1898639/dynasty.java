package java_6.problem_125A.subId_1898639;

import java.util.Scanner;

public class dynasty {
    public static void main(String[] args) throws Exception{
        new dynasty().run(args);
    }

    
    private void run(String[] args) throws Exception{
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        int feet = n/36;
        int inch = Math.round((float)(n-feet*36)/3);
        System.out.println(feet + " " + inch);
    }
}