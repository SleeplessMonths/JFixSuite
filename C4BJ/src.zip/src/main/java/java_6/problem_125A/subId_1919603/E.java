package java_6.problem_125A.subId_1919603;

import java.util.Scanner;


public class E {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int b = n/36;
		int k = n-b*36;
		int a = k/3;
		if (k % 3==2)
			a++;
		System.out.println(b+" "+a);
	}

}