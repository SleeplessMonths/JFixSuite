package java_6.problem_125A.subId_836623;

import java.io.*;


public class Solution {
	static PrintWriter bw;
	static BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
	public static void main(String [] args) throws IOException{
		bw = new PrintWriter(new OutputStreamWriter(System.out));
		String s[]=br.readLine().split(" ");
		int n = Integer.parseInt(String.valueOf(s[0]));
        int a,b;
        a = n/36;
        b=(n-a*36+1)/3;
		bw.printf("%d %d",a,b);
		bw.close();
}
		
}