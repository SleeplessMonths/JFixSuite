package java_6.problem_125A.subId_1213763;

import java.util.Scanner;

/**
 * User: Aphrodite
 * Date: 12-2-21
 * Time: PM4:57
 */

public class P125A {
  public static void main(String[] args) {
    new P125A().solve();
  }

  public void solve() {
    Scanner in = new Scanner(System.in);
    int x = in.nextInt();
    System.out.println(x / 36 + " " + Math.round(x % 36 / (double)3));
  }
}