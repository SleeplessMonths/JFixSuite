package java_6.problem_125A.subId_856583;

import java.io.PrintWriter;
import java.util.Scanner;

public class Solution {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        PrintWriter out = new PrintWriter(System.out);

        int n = in.nextInt();

        int cm = 0;
        int foots = 0;
        int inches = 0;

        while (true) {
            if (n >= 1) {
                cm++;
                if (cm >= 3) {
                    cm = 0;
                    inches++;
                    if (inches >= 12) {
                        foots++;
                        inches = 0;
                    }
                }
                n--;
            } else
                break;
        }

        if (cm == 2)
            inches++;

        out.print(foots + " " + inches);
        out.close();
    }
}