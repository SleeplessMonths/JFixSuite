package java_6.problem_125A.subId_879892;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class lengthsInBaden {
    public static void main(String[]args) throws NumberFormatException, IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int cm = Integer.parseInt(br.readLine());
        int feet = cm/36;
        int remCm = cm%36;
        int inches = (int) Math.round(remCm/3.0);
        System.out.println(feet+" "+inches);
        
    }

}