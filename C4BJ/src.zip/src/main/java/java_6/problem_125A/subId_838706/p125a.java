package java_6.problem_125A.subId_838706;

import java.util.Scanner;


public class p125a {
    public static void main(String[] args) {
        Scanner
        in = new Scanner(System.in);
        int n = in.nextInt();
        
        int f = n/36;
        int left = n - 36*f;
        
        int i = left/3;
        left = left - i*3;
        if(left == 2)
            i++;
        System.out.println(f+" "+i);
    }
}