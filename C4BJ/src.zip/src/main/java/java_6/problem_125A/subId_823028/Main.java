package java_6.problem_125A.subId_823028;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int a = Integer.parseInt(in.readLine());
        int inch=3;
        int feet=inch*12;
        int fr=a/feet, ir=0;
        a=a%feet;
        ir=a/inch;
        a=a%inch;
        if(a>=2) ir++;
        
        System.out.println(fr+" "+ir);
    }
}