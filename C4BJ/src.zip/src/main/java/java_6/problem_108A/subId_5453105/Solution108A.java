package java_6.problem_108A.subId_5453105;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Solution108A {

	public static void main(String[] args) {

        //Scanner sc = new Scanner(System.in);
        MyScanner sc = new MyScanner();
        String times = sc.next();

        String[] tokens = times.split(":");

        //System.out.println(tokens[0] + " " + tokens[1]);
        String tmp = tokens[0].substring(1) + tokens[0].substring(0, 1);

        int HH = Integer.valueOf(tokens[0]);
        int MM = Integer.valueOf(tokens[1]);

        int testMM = Integer.valueOf(tmp);

        
        // 00 ~ 15
        if(0 <= HH && HH <= 5) {

            if(MM >= testMM) {
                System.out.println("0" + (HH+1) + ":" + (HH+1) + "0");

            }else {
                System.out.println("0" + HH + ":" + HH + "0");
            }


        } else if(6 <= HH && HH <= 9) {

            System.out.println("10:01");

        } else if(HH == 10) {

            if(MM >= testMM) {
                System.out.println("11:11");
            } else {
                System.out.println("10:01");
            }

        } else if (11 <= HH && HH <= 14) {

            if(MM >= testMM) {
                String t =  Integer.toString(HH+1);
                t = t.substring(1) + t.substring(0, 1);
                System.out.println((HH+1) + ":" + t);

            } else {
                System.out.println(HH + ":" + testMM);

            }

        } else if(HH == 15) {

            if(MM >= testMM) {
                System.out.println("20:02");

            }else {
                System.out.println("15:51");

            }

        } else if(20 <= HH && HH <= 22) {

            if(MM >= testMM) {
                String t =  Integer.toString(HH+1);
                t = t.substring(1) + t.substring(0, 1);
                System.out.println((HH+1) + ":" + t);

            }else {
                System.out.println(HH + ":" + testMM);

            }

        } else if(HH == 23) {

            if(MM >= testMM) {
                System.out.println("00:00");

            }else {
                System.out.println("23:32");

            }
        }


	}
}



class MyScanner {
	BufferedReader br;
	StringTokenizer st;
 
    public MyScanner() {
    	br = new BufferedReader(new InputStreamReader(System.in));
    }

    String next() {
     	while (st == null || !st.hasMoreElements()) {
     		try {
     			st = new StringTokenizer(br.readLine());
     		} catch (IOException e) {
     			e.printStackTrace();
     		}
     	}
     	return st.nextToken();
    }
 
 	int nextInt() {
 		return Integer.parseInt(next());
 	}
 
 	long nextLong() {
 		return Long.parseLong(next());
 	}
 
 	double nextDouble() {
 		return Double.parseDouble(next());
 	}
 	
 	String nextLine(){
 		String str = "";
 		try {
 			str = br.readLine();
 		} catch (IOException e) {
 			e.printStackTrace();
 		}
 		return str;
 	}
}