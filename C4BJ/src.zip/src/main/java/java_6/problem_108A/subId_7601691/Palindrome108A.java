package java_6.problem_108A.subId_7601691;

import java.util.Scanner;

public class Palindrome108A
{
    public static void main(String[] args) 
    {
        // Set up scanner
        Scanner sc = new Scanner(System.in); 
        // System.out.println("Enter phrase");
        String st = sc.next();
        
        int[] left = {0,1,2,3,4,5,10,11,12,13,14,15,20,21,22,23};
        int[] right = {0, 10, 20, 30, 40, 50, 1, 11, 21, 31, 41, 51, 2, 12, 22, 32};
        
        int hour = Integer.valueOf(st.substring(0,2));
        int minute = Integer.valueOf(st.substring(3));
        
        int index = 0;
        while (left[index] < hour)
        {
            index++;
        }
        if (minute >= right[index])
        {
            index++;
            if (index == left.length)
            {
                index = 0;
            }
        }
        
        String first = String.valueOf(left[index]);
        if (left[index] < 10)
        {
            first = "0" + first;
        }
        
        String second = String.valueOf(right[index]);
        if (right[index] < 10)
        {
            second = "0" + second;
        }
        System.out.print(first + ":" + second);
    }
}