package java_6.problem_108A.subId_5638702;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Palindromic {

    public static void main(String[] args) throws IOException {

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        String t = input.readLine();
        String rev;
        String[] HM = t.split(":");
        boolean flag = false;

        int[] num = new int[HM.length];
        num[0] = Integer.parseInt(HM[0]);
        num[1] = Integer.parseInt(HM[1]);

        //12:21
        int x;
        if (num[1] == 59) {
            x = num[1];
        } else {
            x = num[1] + 1;
        }
        int i;
        int y;

        for (i = num[0]; i < 24; i++) {

            for (y = x; y < 60; y++) {
                if (i > 0 && i < 10 && y < 60 && y > 9) {
                    t = "0" + i + ":" + y;
                } else if (y > 0 && y < 10 && i < 24 && i > 9) {
                    t = i + ":" + "0" + y;
                } else if ((y > 0 && y < 10) && (i > 0 && i < 10)) {
                    t = "0" + i + ":" + "0" + y;
                } else if (((i == 23) && (y >= 33 && y <= 59))) {
                    t = "00:00";
                } else {
                    t = i + ":" + y;
                }
                rev = new StringBuilder(t).reverse().toString();

                if (rev.equals(t)) {
                    System.out.println(t);
                    flag = true;
                    break;
                } else {
                    flag = false;

                }
            }
            if (flag) {
                break;
            } else {
            }
        }
    }
}