package java_6.problem_108A.subId_5737288;

import java.util.Scanner;

public class PalindromicTimes
{
	public static boolean isPalindrome(StringBuilder sb)
	{
		if (sb.charAt(1) >= '6')
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	public static StringBuilder nextHour(StringBuilder sb)
	{
		int temp = Integer.parseInt(sb.toString());
		if (temp == 23)
		{
			temp = 0;
		}
		else
		{
			++temp;
		}
		sb = new StringBuilder(temp + "");
		if (sb.length() == 1)
		{
			sb.insert(0, "0");
		}
		return sb;
	}

	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		String[] hhAndmm = input.nextLine().split(":");
		String hh = hhAndmm[0];
		String mm = hhAndmm[1];
		if (hh.charAt(1) > mm.charAt(0) ||
			(hh.charAt(1) == mm.charAt(0) && 
			hh.charAt(0) > mm.charAt(1)))
		{
			System.out.println(hh + ":" + hh.charAt(1) + hh.charAt(0));
		}
		else
		{
			StringBuilder sb = new StringBuilder();
			sb.append(hh);
			sb = nextHour(sb);
			while (!isPalindrome(sb))
			{
				sb = nextHour(sb);
			}
			System.out.println(sb + ":" + sb.reverse());
		}
	}
}