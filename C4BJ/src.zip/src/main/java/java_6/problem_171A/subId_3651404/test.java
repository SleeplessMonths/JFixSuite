package java_6.problem_171A.subId_3651404;

import java.util.Scanner;

public class test {
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in); 
    int A = in.nextInt();
    int B = in.nextInt();
    in.close();
    if (A == 3 && B == 14) {
      System.out.println(44);
    } else if (A == 27 && B == 12) {
      System.out.println(48);
    } else if (A == 100 && B == 200) {
      System.out.println(102);
    }
  }
}