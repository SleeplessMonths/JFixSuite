package java_6.problem_198A.subId_2435236;

import java.util.Scanner;

public class Virtual125A {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int k = sc.nextInt(), b = sc.nextInt(), n = sc.nextInt(), t = sc.nextInt();
		
		if(k==1){
			if(t>=b*n+1){
				System.out.println(0);
				return;
			}
			long ans = (((long)b)*((long)n)-t+b)/b;
			System.out.println(ans);
		}
		else{
			int ans = 0;
			long prod = 1;
			long K = k, B = b;
			while(true){
				if(prod*K*(K-1+B) <= (K-1)*t + B){
					prod *= K;
					ans++;
				}
				else break;
			}
			if(n>=ans) System.out.println(n-ans);
			else System.out.println(0);
		}
	}
	
	
	
}