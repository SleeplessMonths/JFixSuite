package java_6.problem_198A.subId_1940654;

import java.io.BufferedInputStream;
import java.util.Scanner;

public class Main
{
    public static void main (String[]args)
    {
            Scanner scan = new Scanner (new BufferedInputStream (System.in));
            //int tc = scan.nextInt();

            //for(int i=0;i<tc;i++)
            //{
                int k = scan.nextInt();
                int b = scan.nextInt();
                int n = scan.nextInt();
                int m = scan.nextInt();
                int t =1;
                int flag=0;
                for(int j=0;j<n;j++)
                {
                    t=t*k+b;
                    if(t>m)
                    {
                        //System.out.println("Case #"+(i+1)+": "+(n-j));
                        System.out.println(n-j);
                        flag=1;
                        break;
                    }
                }

                if(flag==0)
        //          System.out.println("Case #"+(i+1)+": 0");
                    System.out.println(0);
            //}

    }

}