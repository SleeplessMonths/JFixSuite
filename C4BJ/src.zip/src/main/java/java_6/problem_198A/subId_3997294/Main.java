package java_6.problem_198A.subId_3997294;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
public class Main
{
    public static void main(String[]arg) throws IOException{
        StringTokenizer tokens;
        StringBuilder sol = new StringBuilder();
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String line = in.readLine();
        tokens = new StringTokenizer(line); 
        int k = Integer.parseInt(tokens.nextToken());
        int b = Integer.parseInt(tokens.nextToken());
        int n = Integer.parseInt(tokens.nextToken());
        int t = Integer.parseInt(tokens.nextToken());
        
        int z = 1;
        
        while(z <= t)
        {
            z = z*k + b;
            n--;
        }
        if(n >= 0)
          sol.append(n+1);
        else
          sol.append(0);
        System.out.print(sol);  
    }
}