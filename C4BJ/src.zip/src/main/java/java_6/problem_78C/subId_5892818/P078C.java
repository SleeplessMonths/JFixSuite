package java_6.problem_78C.subId_5892818;

import java.util.Scanner;

public class P078C {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        int k = sc.nextInt();
        
        boolean divisible = false;
        for (int j = 2; j <= Math.min(k, m/k); j++) {
            if (m % j == 0) {
                divisible = true;
                break;
            }
        }
        
        if (divisible && n % 2 == 1) {
            System.out.println("Timur");
        } else {
            System.out.println("Marsel");
        }
    }
}