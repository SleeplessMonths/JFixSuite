package java_6.problem_78C.subId_7661087;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;

        
        
        public class Main {

             public static void main(String[] args) throws IOException {
         PrintWriter pw = new PrintWriter(System.out);
         BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
         StringTokenizer stk=new StringTokenizer(bf.readLine());
         int n=Integer.parseInt(stk.nextToken());
         int m=Integer.parseInt(stk.nextToken());
         int k=Integer.parseInt(stk.nextToken());
         if(n%2==0)
         {
             pw.println("Marsel");
             pw.flush();return;
         }
         else
         {
             int to=(int)Math.sqrt(m)+1;
             Set<Integer> divis=new TreeSet<Integer>();
             for(int i=1; i<to; i++)
             {
                    if(m%i==0)
                    {
                         divis.add(i);
                         divis.add(m/i);
                        
                    }
                }
             for(Integer p:divis)
             {
                 if(p>k)
                 {
                     pw.println("Timur");
                     pw.flush();return;
                 }
             }
                pw.println("Marsel");
                 pw.flush();return;
         }
        
         
       }
             
            
   }
        /*
 8 16
4
1 2
1 1
4 4
5 5        
         */