package java_6.problem_73A.subId_403499;

import java.util.Arrays;
import java.util.Scanner;

public class Prob66A
{

    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);

        long c[] = new long[3];
        long k,kh,max;


        c[0] = scan.nextLong();
        c[1] = scan.nextLong();
        c[2] = scan.nextLong();
        k = scan.nextLong();

        Arrays.sort(c);

        long res = 1;

        if (c[2] - 1 <= k) res *= c[2];
        if (c[1] - 1 <= k - c[2] + 1) res *= c[1];
        if (c[0] - 1 <= k - c[2] - c[1] + 2) res *= c[0];

        System.out.println(res);


    }
}