package java_6.problem_73A.subId_394862;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main( String[] args ) {
	Scanner sc = new Scanner( System.in );
	int[] xs = new int[3];
	for ( int i=0; i<3; i++ ) xs[i] = sc.nextInt();
	int k=sc.nextInt();
	Arrays.sort(xs);
	int x=Math.min(xs[0]-1,k/3), y=Math.min(xs[1]-1,k/3), z=Math.min(xs[2]-1, k-x-y);
	System.out.println((long)(x+1)*(y+1)*(z+1));
    }
}