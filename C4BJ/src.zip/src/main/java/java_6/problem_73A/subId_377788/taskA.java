package java_6.problem_73A.subId_377788;

/**
 * Created by IntelliJ IDEA.
 * User: aircube
 * Date: 10.04.11
 * Time: 16:36
 * To change this template use File | Settings | File Templates.
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class taskA {

    void solve() throws IOException {
        int a[] = new int[3];
        for (int i = 0; i < 3; ++i)
            a[i] = nextInt();
        int k = nextInt();
        int b[] = new int[3];
        while (k > 0) {
            int c = -1;
            for (int i = 0; i < 3; ++i) {
                if (a[i] - b[i] - 1 > 0 && (c == -1 || a[i] - b[i] - 1 < a[c] - b[c] - 1))
                    c = i;
            }
            if (c == -1) break;
            b[c] ++;
            -- k;
        }
        out.print((long)(b[0] + 1) * (b[1] + 1) * (b[2] + 1));
    }
    BufferedReader br;
    PrintWriter out;
    StringTokenizer st;

    public static void main(String[] args) throws IOException {
        new taskA().run();
    }

    void run() throws IOException {
        br = new BufferedReader(new InputStreamReader(System.in));
        st = null;
        out = new PrintWriter(System.out);
        solve();
        br.close();
        out.close();
    }

    int nextInt() throws IOException {
        return Integer.parseInt(nextToken());
    }

    double nextDouble() throws IOException {
        return Double.parseDouble(nextToken());
    }

    long nextLong() throws IOException {
        return Long.parseLong(nextToken());
    }

    String nextToken() throws IOException {
        while (st == null || !st.hasMoreTokens()) {
            st = new StringTokenizer(br.readLine());
        }
        return st.nextToken();
    }
}