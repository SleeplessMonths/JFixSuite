package java_6.problem_70A.subId_1120142;

import java.io.PrintWriter;
import java.util.Scanner;

public class Main {
	Scanner sc = new Scanner(System.in);
	PrintWriter pw = new PrintWriter(System.out);
        public static void main(String[] args) {
		Main m = new Main();
		m.run();
		m.sc.close();
		m.pw.close();
        }
        void run() {
        	int n = sc.nextInt();       	
        	int res = 1;
        	if (n == 0)
        		res = 0;
        	for (int i = 1; i < n; i++) {
        		res = (res * 3) % 1000003;
        	}
        	pw.print(res);
        }
}