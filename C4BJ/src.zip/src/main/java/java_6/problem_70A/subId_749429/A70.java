package java_6.problem_70A.subId_749429;

import java.util.Scanner;
public class A70 {
	public static void main(String args[]){

		Scanner in = new Scanner(System.in);

		int n = in.nextInt();
		
		if (n==0) System.out.println("0");
		else{
			int sum = 1;
			while(n>1){
				sum=sum*3%1000003;
				n--;
			}
			System.out.println(sum);
		}
	}

}