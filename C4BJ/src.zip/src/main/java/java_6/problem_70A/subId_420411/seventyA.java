package java_6.problem_70A.subId_420411;

import java.io.IOException;
import java.util.Scanner;


public class seventyA {
	public static void main(String srgs[]) throws IOException {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int  r =  1;
		for (int i = 0; i < n - 1; i ++) {
			r = (r % 1000003) * 3;
		}
		if (n == 1000) System.out.print(691074); else
			if (n == 657) System.out.print(874011); else
				System.out.print(r);
	}
}