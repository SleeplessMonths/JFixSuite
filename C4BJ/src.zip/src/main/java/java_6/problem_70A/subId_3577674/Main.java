package java_6.problem_70A.subId_3577674;

import java.math.BigInteger;
import java.util.Scanner;

public class Main {
    public static Scanner scan = new Scanner(System.in);
    public static boolean bg = true;

    public static void main(String[] args) throws Exception {
        int n1 = Integer.parseInt(scan.next());
        BigInteger n2 = new BigInteger(3+"");
        System.out.println(n2.pow(n1-1).divideAndRemainder(new BigInteger(""+1000007) )[1] );
    }
}