package java_6.problem_70A.subId_483095;

import java.util.Scanner;

/**
 *
 * @author epiZend
 */
public class Cookies {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        long i = 1;
        int n = sc.nextInt();
        for (int j = 1; j < n; j++) {
            i += i * 2;
            i %= 1000006;
        }
        System.out.println(i);
    }
}