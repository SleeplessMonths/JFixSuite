package java_6.problem_70A.subId_603754;

import java.util.Scanner;

public class CF070a {
	
	private void run() {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		System.out.println((int)Math.pow(3,n-1));
		sc.close();
	}

	public static void main(String args[]) {
		new CF070a().run();
	}

}