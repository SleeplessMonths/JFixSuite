package java_6.problem_70A.subId_871495;

import java.util.Scanner;
public class Pechenko_square 
{
    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);
        int N = in.nextInt();
        int result = 1;
        int sch = 3;
        int i =0;
        for (i = 1; i < N; i++)
        {
            result = result*3;
            if(i>=14)
            {
                result =result - sch;
                sch = sch*3;
            }
        }
        if(i>=14)
        {
            result =result - sch;
            sch = sch*3;
        }
        
            result = result%1000000;
        
        
        System.out.println(result);
        
    }

}