package java_6.problem_70A.subId_838514;

import java.util.Scanner;

public class Cookies {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		long side = (long) Math.pow(2, n);
		side /= 2;
		System.out.println(3 * side - 3);
	}
}