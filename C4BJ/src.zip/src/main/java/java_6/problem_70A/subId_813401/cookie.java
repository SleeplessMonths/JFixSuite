package java_6.problem_70A.subId_813401;

import java.util.Scanner;


public class cookie {

    
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        
        int MOD=(int)1e6+3;
        int n=sc.nextInt();
        if(n==0)
        {
            System.out.println(0);
            return;
        }
        
        long z=1;
        for(int i=1;i<n;i++)
        {
            z=(z*3)%MOD;
        }
        System.out.println(z);
    }
}