package java_6.problem_70A.subId_2997539;

import java.util.Scanner;

public class program {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n=scan.nextInt();
        if(n==0){
            System.out.println(0);
            return;
        }
        int result[]=new int[n];
        result[0]=1;
        int mod=1000000+3;
        for (int i = 1; i < n; i++) {
            result[i]=3*result[i-1]%mod;
        }
        System.out.println(result[n-1]);
    }
}