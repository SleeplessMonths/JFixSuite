package java_6.problem_70A.subId_2051881;

import java.util.Scanner;


public class A {

	static int p = (int) (1e6+3);
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		if (n==0) {
			System.out.println(0);
			return;
		}
		System.out.println(calc(n));
	}

	private static int calc(int n) {
		if (n==1)
			return 1;
		return 3*calc(n-1) % p;
	}

}