package java_6.problem_70A.subId_951022;

import java.math.BigInteger;
import java.util.Scanner;


public class Prob070A
{
    public static void main( String[] Args )
    {
        Scanner scan = new Scanner( System.in );
        int x = scan.nextInt() - 1;
        BigInteger bi = BigInteger.ONE;
        for ( int a = 0; a < x; a++ )
            bi = bi.multiply( BigInteger.valueOf( 3 ) );
        bi = bi.mod( BigInteger.valueOf( 1000003 ) );
        System.out.println();
    }
}