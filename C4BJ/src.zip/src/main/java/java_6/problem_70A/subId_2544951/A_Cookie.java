package java_6.problem_70A.subId_2544951;

import java.math.BigInteger;
import java.util.Scanner;


public class A_Cookie {
public static void main(String[] args) {
	Scanner sc  =  new Scanner(System.in);
	int n=sc.nextInt();
	if(n==1 || n==0){
		System.out.println(0);
		return;
	}
	BigInteger a[]=new BigInteger[n+1];
	BigInteger x=BigInteger.ONE;
	for (int i = 2; i <=n; i++) {
		a[i]=new BigInteger(3+"").multiply(x);
		x=a[i];
	}
	System.out.println(a[n].mod(new BigInteger(1000003+"")));
}
}