package java_6.problem_70A.subId_445967;

import java.math.BigInteger;
import java.util.Scanner;


public class p70a {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		if(n == 0) {
			System.out.println(0);
			return;
		}
		BigInteger res = BigInteger.valueOf(3);
		System.out.println(res.pow(n-1).mod(BigInteger.valueOf(1000003)));
	}
}