package java_6.problem_70A.subId_1314540;

import java.io.PrintWriter;
import java.util.Scanner;

public class test
{

	public static void main(String[] args)
	{
		new test().run();
	}

	void run()
	{
		Scanner in = new Scanner(System.in);
		PrintWriter out = new PrintWriter(System.out);

		int n = in.nextInt();

		if (n == 0)
			out.println(1);
		else
			out.println((long) Math.pow(3, n - 1) % 1000003);

		out.close();
	}
}