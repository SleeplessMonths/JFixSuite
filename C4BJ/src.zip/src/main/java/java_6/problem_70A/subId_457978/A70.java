package java_6.problem_70A.subId_457978;

import java.util.Scanner;


public class A70 {
 public static void main(String[] args){
	 
	 Scanner sc = new Scanner(System.in);
	 int n=sc.nextInt();
	 int g=1;
	 for(int i=1; i<=n-1; i++){
		 g=g*3;
	 }
	 System.out.println(g);
	 }
}