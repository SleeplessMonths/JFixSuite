package java_6.problem_70A.subId_2019406;

import java.math.BigInteger;
import java.util.Scanner;

public class Cookies {

    /**
     * @param args
     */
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        BigInteger mod= BigInteger.valueOf(1000003);
        BigInteger b3 = BigInteger.valueOf(3);
        if(n < 1)
            System.out.println(n);
        else
            System.out.println(b3.modPow(BigInteger.valueOf(n-1), mod));
    }

}