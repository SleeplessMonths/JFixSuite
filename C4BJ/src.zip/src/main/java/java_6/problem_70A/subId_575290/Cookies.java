package java_6.problem_70A.subId_575290;

import java.util.Scanner;

public class Cookies {

    public static void main(String[] args) {
        Scanner inScanner = new Scanner(System.in);
        int n = inScanner.nextInt();
        if (n == 0){
            System.out.println("1");
            return;
        }
        int result = 3;
        for(int i=0; i<n-1; i++)
            result = (result * 3) % (1000003);
        System.out.println(result);
    }
}