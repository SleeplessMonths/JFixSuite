package java_6.problem_70A.subId_498396;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class A {

	private void work() {
		Scanner sc = new Scanner(new BufferedReader(new InputStreamReader(
				System.in)));
		int[] p3 = new int[1010];
		p3[0] = 1;
		for (int i = 1; i < p3.length; i++) {
			p3[i] = (3 * p3[i - 1]) % 1000003;
		}
		int n = sc.nextInt();
		if (n == 0)
			System.out.println(0);
		else
			System.out.println(p3[n - 1]);
	}

	public static void main(String[] args) {
		new A().work();
	}

}