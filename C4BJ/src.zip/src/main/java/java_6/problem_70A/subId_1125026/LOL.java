package java_6.problem_70A.subId_1125026;

import java.util.Scanner;
public class LOL {
    static final long MOD = 1000003;
    static long pow(long base, long pow) {
        if (pow == 0)
            return 1;
        else if (pow == 1)
            return base;
        else if (pow%2 == 0)
            return pow(base*base%MOD,pow/2);
        else
            return base*pow(base*base%MOD,pow/2)%MOD;
    }
    public static void main(String[] args) throws Exception {
        Scanner in = new Scanner(System.in);
        int N = in.nextInt();
        if (N==0)
            System.out.println(0);
        else
            System.out.println(pow(3,N-1));
    }
}