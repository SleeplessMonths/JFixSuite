package java_6.problem_70A.subId_510101;

import java.math.BigInteger;
import java.util.Scanner;
public class cookies{
	public static void main(String[] args){
		Scanner br = new Scanner(System.in);
		int n = br.nextInt();
		BigInteger num = new BigInteger("3");
		num = num.modPow(new BigInteger(""+(n-1)), new BigInteger("1000003"));
		System.out.println(num);
	}
}