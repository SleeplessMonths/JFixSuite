package java_6.problem_70A.subId_2019945;

import java.util.Scanner;

public class P15 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        long[] a = new long[n + 1];
        a[0] = 0;
        if (n >= 1)
            a[1] = 1;
        for (int i = 2; i <= n; i++)
            a[i] = (3 * a[i - 1]) % 1000003;
        System.out.println(a[n]);
    }

}