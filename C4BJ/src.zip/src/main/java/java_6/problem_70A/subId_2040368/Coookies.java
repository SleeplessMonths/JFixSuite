package java_6.problem_70A.subId_2040368;

import java.util.Scanner;


public class Coookies {

    /**
     * @param args
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int k=sc.nextInt();
        int start=1;
        for(int i=0;i<k-1;i++)
        {
            start=(start*3)%1000000;
        }
        start=start%1000000;
System.out.println(start);
    }

}