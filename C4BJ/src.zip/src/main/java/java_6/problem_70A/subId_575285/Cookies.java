package java_6.problem_70A.subId_575285;

import java.util.Scanner;

public class Cookies {

    public static void main(String[] args) {
        Scanner inScanner = new Scanner(System.in);
        int n = inScanner.nextInt();
        System.out.println((int)(Math.pow(3, n - 1) % (Math.pow(10, 6) + 3)));
    }
}