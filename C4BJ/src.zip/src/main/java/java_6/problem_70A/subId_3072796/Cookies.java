package java_6.problem_70A.subId_3072796;

import java.util.Scanner;

public class Cookies {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int ans = 1;
		for (int i = 0; i < n; i++)
			ans = (ans * 3) % 1000003;
		System.out.println(ans);
	}
}