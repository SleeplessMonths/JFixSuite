package java_6.problem_70A.subId_1314545;

import java.io.PrintWriter;
import java.util.Scanner;

public class test
{

	public static void main(String[] args)
	{
		new test().run();
	}

	void run()
	{
		Scanner in = new Scanner(System.in);
		PrintWriter out = new PrintWriter(System.out);

		int n = in.nextInt();

		if (n == 0)
			out.println(1);
		else
		{
			int p = 1;
			for (int i = 0; i < n - 1; i++)
			{
				p *= 3;
				p %= 100003;
			}
			out.println(p);
		}

		out.close();
	}
}