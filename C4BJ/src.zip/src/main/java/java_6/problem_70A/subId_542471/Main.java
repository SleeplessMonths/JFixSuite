package java_6.problem_70A.subId_542471;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StreamTokenizer;

public class Main {
    private static StreamTokenizer in;
    private static PrintWriter out;
    private static BufferedReader inB;
    
    private static int nextInt() throws Exception{
        in.nextToken();
        return (int)in.nval;
    }
    
    private static String nextString() throws Exception{
        in.nextToken();
        return in.sval;
    }
    
    static{
        inB = new BufferedReader(new InputStreamReader(System.in));
        in = new StreamTokenizer(inB);
        out = new PrintWriter(System.out);
    }
    
    static long pow(int n) {
        long ans = 1;
        
        for(int i = 0; i<n; i++) {
            ans *= 3;
        }
        
        return ans;
    }
    
    public static void main(String[] args)throws Exception{
        int n = nextInt();
        
        
        System.out.println(pow(n-1) % 1000003);
    
    }
}