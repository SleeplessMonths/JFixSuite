package java_6.problem_70A.subId_971871;

import java.util.Scanner;

public class A70 {
	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);

		int n = in.nextInt();

		if (n == 0) {
			System.out.println("0");
			return;
		}

		System.out.println((int) Math.pow(3, n - 1) % 1000003);

	}
}