package java_6.problem_70A.subId_782873;

import java.util.Scanner;



public class A {


    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();
        int a=1;

      
        for (int i = 2;i< n+1;i++){
            a = a*3;
        }
        System.out.print(a);


    }
}