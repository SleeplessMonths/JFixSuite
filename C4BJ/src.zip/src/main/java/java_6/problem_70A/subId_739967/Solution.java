package java_6.problem_70A.subId_739967;

import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.Scanner;

public class Solution {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		PrintWriter out = new PrintWriter(System.out);

		int n = in.nextInt();

		if (n <= 0) {
			out.print(0);
		} else {
			BigInteger ans = BigInteger.valueOf(3).pow(n - 1).mod(BigInteger.valueOf((int) Math.pow(10, 6) + 3));
			out.print(ans.toString());
		}

		out.close();
	}
}