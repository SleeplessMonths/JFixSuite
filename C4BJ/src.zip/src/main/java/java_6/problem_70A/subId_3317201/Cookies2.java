package java_6.problem_70A.subId_3317201;

import java.util.Scanner;
public class Cookies2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println((int)Math.pow(3, sc.nextInt() - 1));
	}
}