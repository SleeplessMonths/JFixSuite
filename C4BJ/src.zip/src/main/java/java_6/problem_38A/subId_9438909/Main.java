package java_6.problem_38A.subId_9438909;

import java.util.Scanner;

public class Main {

    
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int n,a,b,c,m=0;
        n=input.nextInt();
        int d[]= new int[n-1];
        for(int i=0;i<d.length;i++){
            d[i]=input.nextInt();
        }
        a=input.nextInt();
        b=input.nextInt();
        c=b-a;
        
        for(int i=0;i<c;i++){
            m=m+d[i];
        }
        System.out.println(m);
        
    
   }
    
}