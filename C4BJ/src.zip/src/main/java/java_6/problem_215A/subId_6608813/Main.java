package java_6.problem_215A.subId_6608813;

import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    int n = s.nextInt();
    int[] a = new int[n];
    for (int j = 0; j < n; ++j) a[j] = s.nextInt();
    int m = s.nextInt();
    int[] b = new int[m];
    for (int j = 0; j < n; ++j) b[j] = s.nextInt();
    int br = -1; int nb = 0;
    for (int j = 0; j < n; ++j) {
      for (int k = 0; k < m; ++k) {
        if (b[k] % a[j] == 0) {
          int r = b[k]/a[j];
          if (r > br) { br = r; nb = 1; }
          else if (r == br) { nb++; }
        }
      } 
    }
    System.out.println(nb);
  }
}