package java_6.problem_80A.subId_7009458;

import java.util.Scanner;

public class r69_a {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt(),m=sc.nextInt(),t=0;
		for (int i = n+1; i <=m; i++) {
			boolean f=false;
			for (int j = 2; j <=i-1; j++) {
				if(i%j==0)
					f=true;
			}
			if(!f){
				System.out.println(i==m?"YES":"NO");
				return;
			}
		}
		}
}