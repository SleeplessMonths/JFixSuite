package java_6.problem_80A.subId_5702636;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class PanoramixsPrediction {

    
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String []w=br.readLine().trim().split("\\s+");
        int n1=Integer.parseInt(w[0]);
        int n2=Integer.parseInt(w[1]);
        int num=0;boolean f=true;
        for(int j=n1+1;j<=n2;j++){
            f=true;
        for(int i=2;i<j;i++)
            if(j%i==0)
                f=false;
        if(f)
            {num=j;break;}
        }
        System.out.println(num);    
if(num==n2)
    System.out.println("YES");
else
    System.out.println("NO");
    
    }

}