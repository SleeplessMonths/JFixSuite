package java_6.problem_57A.subId_265062;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
	static int[][] g; 
	public static void main(String[] args) throws IOException {
		BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
		
		String[] line = r.readLine().split("[ ]+");
		int[] a = new int[5];
		for (int i = 0; i < a.length; i++) {
			a[i] = Integer.parseInt(line[i]);
		}
		
		int n = a[0]+1;
		
		g = new int[n][n];
		
		g[a[1]][a[2]] = 1;
		g[a[3]][a[4]] = 1;
		
		for (int i = 1; i < n-1; i++) {
			for (int j = 1; j < n-1; j++) {
				g[i][j] = 1;
			}
		}
		
		boolean one = false;
		for (int i = 1; i < g.length; i++) {
			if((g[0][i]==g[0][i-1] &&g[0][i]==1) || (g[n-1][i] == g[n-1][i-1]&&g[n-1][i]==1))one = true;
			if((g[i][0]==g[i-1][0] &&g[i][0]==1)|| (g[i][n-1] == g[i-1][n-1]&&g[i][n-1]==1))one = true;
		}
		if(((g[0][0]==g[1][0])||(g[0][0]==g[0][1]))&& g[0][0]==1 )one = true;
		if(((g[n-1][n-1]==g[n-1][n-2])||(g[n-1][n-1]==g[n-2][n-1]))&& g[n-1][n-1]==1 )one = true;
		if(((g[n-1][0]==g[n-1][1])||(g[n-1][0]==g[n-2][0]))&& g[n-1][0]==1 )one = true;
		if(((g[0][n-1]==g[1][n-1])||(g[0][n-1]==g[0][n-2]))&& g[0][n-1]==1 )one = true;
		
		
//		for (int i = 0; i < n; i++) {
//			System.out.println(Arrays.toString(g[i]));
//		}
//		System.out.println(one);
		
		int dist = 0;
			dist = Math.max(dist, eat(0,0,0));
			dist = Math.max(dist,eat(n-1,0,0));
			dist = Math.max(dist,eat(0,n-1,0));			
			dist = Math.max(dist,eat(n-1,n-1,0));
		
		
			if(!one)System.out.println(dist+1);
			else System.out.println(1);
	}

	private static int eat(int i, int j,int res) {
		if(g[i][j]==1)return  0;
		
		else{
			
		g[i][j] = 1;
		int temp = 0;
		
		temp += i+1<g.length?eat(i+1,j,res):0;
		temp += j+1<g.length?eat(i,j+1,res):0;
		temp += i-1>=0?eat(i-1,j,res):0;
		temp += j-1>=0?eat(i,j-1,res):0;
		
		return temp+1;
		}
	}
}