package java_6.problem_57A.subId_954695;

import java.util.Scanner;

public class A057 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt(), x0 = in.nextInt(), y0 = in.nextInt(), x1 = in
				.nextInt(), y1 = in.nextInt();
		int xd = x1-x0;
		if(xd<0) xd = -xd;
		xd+=y0+y1;
		int o = n*4-xd;
		System.out.println(o<xd?o:xd);
	}
}