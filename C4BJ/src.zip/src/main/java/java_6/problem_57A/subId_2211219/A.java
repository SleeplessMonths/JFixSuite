package java_6.problem_57A.subId_2211219;

import java.util.Scanner;

public class A {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int x1 = sc.nextInt();
        int y1 = sc.nextInt();
        int x2 = sc.nextInt();
        int y2 = sc.nextInt();
        int ans = 0;
        if (x1 == 0 && 0 <= y1 && y1 <= n){
            if (x2 == 0 && 0 < y2 && y2 <= n ){
                ans = Math.abs(y2-y1);
            }
            if (x2 > 0 && n == y2 && x2 <= n ){
                ans = Math.abs(n-y1)+x2;
            }
            if (x2 == n && 0 <= y2 && y2 < n ){
                ans = Math.min(3*n-y1-y2, n+y1+y2);
            }
            if (x2 > 0 && 0 == y2 && x2 <= n ){
                ans = y1+x2;
            }
        }
        if (y1 == n && x1 > 0 && x1 <= n){
            if (y2 == n && x2 > 0 && x2 <= n){
                ans = Math.abs(x2-x1);
            }
            if (x2 == 0 && y2 > 0 && y2 <= n){
                ans = n-y2+x1;
            }
            if (x2 == n && 0 <= y2 && y2 < n ){
                ans = 2*n-y2-x1;
            }
            if (x2 > 0 && 0 == y2 && x2 <= n ){
                ans = Math.min(n+x1+x2, 3*n-x1-x2);
            }
        }
        if (x1 == n && 0 <= y1 && y1 < n){
            if (x2 == 0 && 0 < y2 && y2 <= n ){
                ans = Math.min(3*n-y1-y2, n+y1+y2);
            }
            if (x2 > 0 && n == y2 && x2 <= n ){
                ans = 2*n-y2-x1;
            }
            if (x2 == n && 0 <= y2 && y2 < n ){
                ans = Math.abs(y1-y2);
            }
            if (x2 > 0 && 0 == y2 && x2 <= n ){
                ans = n + y1-x2;
            }
        }
        if (x1 > 0 && 0 == y1 && x1 <= n){
            if (x2 == 0 && 0 < y2 && y2 <= n ){
                ans = y2+x1;
            }
            if (x2 > 0 && n == y2 && x2 <= n ){
                ans = Math.min(n+x1+x2, 3*n-x1-x2);
            }
            if (x2 == n && 0 <= y2 && y2 < n ){
                ans = n-x1+y2;
            }
            if (x2 > 0 && 0 == y2 && x2 <= n ){
                ans = Math.abs(x1-x2);
            }
        }
        System.out.println(ans);
    }

}