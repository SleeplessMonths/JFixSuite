package java_6.problem_57A.subId_542500;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StreamTokenizer;

public class Main {
    private static StreamTokenizer in;
    private static PrintWriter out;
    private static BufferedReader inB;
    
    private static int nextInt() throws Exception{
        in.nextToken();
        return (int)in.nval;
    }
    
    private static String nextString() throws Exception{
        in.nextToken();
        return in.sval;
    }
    
    static{
        inB = new BufferedReader(new InputStreamReader(System.in));
        in = new StreamTokenizer(inB);
        out = new PrintWriter(System.out);
    }
    
    private static int parse(int x, int y) {
        if(x == 0)return y;
        if(y == n)return n+ y;
        if(x == n)return n + n + (n - y);
        return n + n + (n - y) + (n - x);
    }
    
    private static int n;
    
    public static void main(String[] args)throws Exception{
        n = nextInt();
        int x1 = nextInt(), y1 = nextInt(), x2 = nextInt(), y2 = nextInt();
        
        int a = parse(x1, y1);
        int b = parse(x2, y2);
        
        int d = Math.abs(b - a) ;
        if(d > 2 * n)d = 4 * n - d;
        
        System.out.println(d);
    }
}