package java_6.problem_57A.subId_2018858;

import java.util.Scanner;


public class E {

    public static void main(String[] args) {
        int[]x = new int[5], y = new int[5];
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        x[2] = x[4] = y[3] = y[4] = n;
        int x1 = sc.nextInt();
        int y1 = sc.nextInt();
        int x2 = sc.nextInt();
        int y2 = sc.nextInt();
        int ans = 4*n;
        if (x1==x2 || y1==y2)
            ans = dis(x1, y1, x2, y2);
        if ((Math.abs(x1-x2)==n || Math.abs(y1-y2)==n) && x1 != 0 && x2 != 0 && x1 != n && x2 != n && y1 != 0 && y2 != 0 && y1 != n && y2 != n) {
            for (int i = 1; i <= 4; i++) {
                for (int j = i+1; j <= 4; j++) {
                    ans = Math.min(ans, dis(x1, y1, x[i], y[i])+dis(x2, y2, x[j], y[j])+n);
                }
            }
        }
        else {
            for (int i = 1; i <= 4; i++) {
                ans = Math.min(ans, dis(x1, y1, x[i], y[i])+dis(x2, y2, x[i], y[i]));
            }
        }
        System.out.println(ans);
    }

    private static int dis(int x1, int y1, int x2, int y2) {
        return Math.abs(x1-x2)+Math.abs(y1-y2);
    }
}