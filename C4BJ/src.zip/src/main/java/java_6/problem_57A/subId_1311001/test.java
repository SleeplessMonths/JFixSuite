package java_6.problem_57A.subId_1311001;

import java.io.PrintWriter;
import java.util.Scanner;

public class test
{

	public static void main(String[] args)
	{
		new test().run();
	}

	void run()
	{
		Scanner in = new Scanner(System.in);
		PrintWriter out = new PrintWriter(System.out);

		int n = in.nextInt();

		int x1 = in.nextInt();
		int y1 = in.nextInt();
		int x2 = in.nextInt();
		int y2 = in.nextInt();

		out.println(Math.min(x1 + x2, (n - x1) + (n - x2))
				+ Math.min(y1 + y2, (n - y1) + (n - y2)));
		out.close();
	}
}