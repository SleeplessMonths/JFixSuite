package java_6.problem_57A.subId_265081;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
	static int[][] g; 
	public static void main(String[] args) throws IOException {
		BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
		
		String[] line = r.readLine().split("[ ]+");
		int[] a = new int[5];
		for (int i = 0; i < a.length; i++) {
			a[i] = Integer.parseInt(line[i]);
		}
		
		int n = a[0];
		
		int one = calc(a[1],a[2],n);
		int two = calc(a[3],a[4],n);
		
//		System.out.println("one :"+one +"\n two:"+two);
		int l = Math.abs(one-two);
		
		System.out.println(Math.min(l,(4*n)-l));
		
	}
	private static int calc(int i, int j,int n) {
		if(j==0)return i;
		else if(i==n)return j+n;
		else if(j==n)return i+(2*n);
		else if(i ==0)return j+(3*n);
		return 0;
	}

}