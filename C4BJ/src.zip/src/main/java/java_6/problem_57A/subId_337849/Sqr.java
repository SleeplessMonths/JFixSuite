package java_6.problem_57A.subId_337849;

//* codeforces 

import java.io.*;
import java.util.StringTokenizer;

import static java.lang.Math.abs;

public class Sqr {

    final boolean ONLINE_JUDGE = true;

    BufferedReader in;
    PrintWriter out;
    StringTokenizer tok = new StringTokenizer("");

    void init() throws IOException {
        if (ONLINE_JUDGE) {
            in = new BufferedReader(new InputStreamReader(System.in));
            out = new PrintWriter(System.out);
        } else {
            in = new BufferedReader(new FileReader("input.txt"));
            out = new PrintWriter("output.txt");
        }
    }

    String readString() throws IOException {
        while (!tok.hasMoreTokens()) {
            tok = new StringTokenizer(in.readLine());
        }
        return tok.nextToken();
    }

    int readInt() throws IOException {
        return Integer.parseInt(readString());
    }

    long readLong() throws IOException {
        return Long.parseLong(readString());
    }

    double readDouble() throws IOException {
        return Double.parseDouble(readString());
    }

    void debug(Object o) {
        System.err.println(o.toString());
    }

    void run() {
        try {
            long t1 = System.currentTimeMillis();
            init();
            solve();
            out.close();
            long t2 = System.currentTimeMillis();
            debug("Time = " + (t2 - t1));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    int min(int x, int y) {
        if (x>=y)
        return y;
        else
        return x;
    }
    
    int max(int x, int y) {
        if (x>=y)
        return x;
        else
        return y;
    }
    
    public static void main(String[] args) {
        (new Sqr()).run();
    }

    void solve() throws IOException {
     int n = readInt();
     int x1 = readInt(); 
     int y1 = readInt();
     int x2 = readInt();
     int y2 = readInt();
     int s=0;
     if (abs(x1-x2)==n) s=3*n-(y1+y2);
     else
     if (abs(y1-y2)==n) s=3*n-(x1+x2);
     else
     s = max(x1,x2)-min(x1,x2)+max(y1,y2)-min(y1,y2);
     out.println(s);
    }

}