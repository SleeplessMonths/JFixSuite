package java_6.problem_57A.subId_1811835;

import java.util.Scanner;
public class P057A {
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        
        int N = in.nextInt();
        int x1 = in.nextInt();
        int y1 = in.nextInt();
        int x2 = in.nextInt();
        int y2 = in.nextInt();
        
        int ans = Math.abs(x1 - x2) + Math.abs(y1 - y2);
        
        if (Math.abs(x1 - x2) == N && Math.abs(y1 - y2) != N)
            ans += Math.min(N - y1 + N - y2, y1 + y2);
        if (Math.abs(y1 - y2) == N && Math.abs(x1 - x2) != N)
            ans += Math.min(N - x1 + N - x2, y1 + y2);
        
        System.out.println(ans);
    }
}