package java_6.problem_57A.subId_394072;

import java.util.Scanner;
public class Main {
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        
        int n = sc.nextInt();
        int x1 = sc.nextInt();
        int y1 = sc.nextInt();
        int x2 = sc.nextInt();
        int y2 = sc.nextInt();
        
        if (y1==y2 && y1!=0){System.out.println(n*Math.abs(x2-x1));}
        else {
            System.out.println(Math.abs(x2-x1) + Math.abs(y2-y1));
        }       
    }
}