package java_6.problem_57A.subId_597879;

import java.util.Scanner;

public class P057A {

	public static void main(String[] args) {
		Scanner inScanner = new Scanner(System.in);
		int n = inScanner.nextInt();
		int x1 = inScanner.nextInt();
		int y1 = inScanner.nextInt();
		int x2 = inScanner.nextInt();
		int y2 = inScanner.nextInt();
		int l = Math.min(x1 + y1 + x2 + y2, n * 4 - x1 - y1 - x2 - y2);
		System.out.println(l);
	}
}