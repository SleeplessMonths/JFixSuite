package java_6.problem_280A.subId_3285356;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class con172_C {

	public static void main( final String[] args ) throws Exception {
		if ( DEBUG ) {
			final double dalfa = Math.atan( 2D / 3 );
			System.out.printf( "arctan(2/3)=%f (%f)\n", dalfa, dalfa / Math.PI * 180 );
			final double dalfaPlusBetaSin = Math.sin( dalfa + 30D * Math.PI / 180 );
			System.out.printf( "dalfaPlusBetaSin=%f -> Ny=%f\n", dalfaPlusBetaSin, dalfaPlusBetaSin * Math.sqrt( 13 ) );
		}

		final BufferedReader br = new BufferedReader( new InputStreamReader( System.in ) );
		final String line = br.readLine();
		final StringTokenizer tok = new StringTokenizer( line );
		final double w = Integer.parseInt( tok.nextToken() );
		final double h = Integer.parseInt( tok.nextToken() );
		final double alfa = Integer.parseInt( tok.nextToken() );

		System.out.println( solve( Math.max( w, h ), Math.min( w, w ), alfa ) );
	}

	private static final boolean DEBUG = false;

	private static double solve( final double w, final double h, double alfa ) {
		if ( alfa > 90 ) alfa = 180 - alfa;
		if ( alfa == 0 ) {
			return w * h;
		}
		if ( alfa == 90 ) {
			final double min = Math.min( h, w );
			return min * min;
		}
		final double alfaRad = alfa * Math.PI / 180;
		final double tgBeta = h / w;
		final double betaRad = Math.atan( tgBeta );
		if ( DEBUG ) System.out.printf( "betaRad=%f\n", betaRad );
		final double diagPrepPol = Math.sqrt( h * h + w * w ) / 2;
		if ( DEBUG ) System.out.printf( "diagPrepPol=%f\n", diagPrepPol );

		final double Ny = Math.sin( alfaRad + betaRad ) * diagPrepPol;
		final double Nx = Math.cos( alfaRad + betaRad ) * diagPrepPol;
		if ( DEBUG ) System.out.printf( "N=(%f, %f)\n", Nx, Ny );

		final double v = Ny - h / 2;
		final double lp = v / Math.tan( alfaRad );
		final double gama = Math.PI / 2 - alfaRad;

		final double rp = v / Math.tan( gama );

		final double d = w / 2 - Nx - rp;
		if ( DEBUG ) System.out.printf( "d=%f\n", d );
		double res;

		if ( d < 0 ) {
			res = 0;
			final double eps = alfaRad - betaRad;
			if ( DEBUG ) System.out.printf( "eps=%f\n", eps * 180 / Math.PI );
			final double My = Math.sin( eps ) * diagPrepPol;
			if ( DEBUG ) System.out.printf( "My=%f\n", My );
			final double mlp = ( My - h / 2 ) / Math.tan( alfaRad );
			final double mrp = ( My - h / 2 ) / Math.tan( Math.PI / 2 - alfaRad );
			final double part = 1 / 2.0 * ( ( Ny - h / 2 ) * ( lp + rp ) - ( My - h / 2 ) * ( mlp + mrp ) );
			res = w * h - 2 * part;
		} else {
			final double sv = d / Math.tan( alfaRad );
			res = w * h - v * ( lp + rp ) - d * sv;
		}

		return res;
	}

}