package java_6.problem_40B.subId_180650;

import java.util.Scanner;

public class Main {

     static int count(int r,int c,int b){
          System.out.println(r); System.out.println(c);
          int lx = 0; int ct = 0;
          if(r<1 || c<1) return 0;
          if(r==1) lx = c;
          else if(c==1)  lx = r;
          else lx = 2*r+2*(c-2);
          for(int i=1;i<=lx;++i) if(i%2==1) ct++;
          if(b==1)  return ct;
          return lx-ct;
    }

    public static void main (String [] Args ) throws Exception {
          Scanner sc =  new Scanner(System.in);
          int n,m,x;
          n = sc.nextInt(); m = sc.nextInt(); x = sc.nextInt();
          System.out.println(count(n-2*x+2,m-2*x+2,1));    
    }
}