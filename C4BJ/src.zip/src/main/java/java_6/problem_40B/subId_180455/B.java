package java_6.problem_40B.subId_180455;

import java.util.Scanner;

public class B {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt(), m = s.nextInt();
		int x = 2 * (s.nextInt() - 1);
		int r = 0;
		if((n -= x) == 1 && (m -= x) == 1){
			r = 1;
		}else if ( n == 1 || m == 1){
			r = n * m;
		}else{
			r = n + m - 2;
		}
		System.out.println(r);
	}
}