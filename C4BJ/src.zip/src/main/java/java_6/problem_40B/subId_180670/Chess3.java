package java_6.problem_40B.subId_180670;

import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author teacher
 */
public class Chess3 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        long n = in.nextInt();
        long m = in.nextInt();
        long x = in.nextInt();
        if (x == 0) {
            System.out.println(n * m / 2);
        }else {
            System.out.println(count(n, m, x));
        }
    }

    static long count(long n, long m, long x) {
        if(n<=0 || m<=0)return 0;
        if(n==1 && m==1)return 1;
        if (x == 1) {
            return n+1+m+1-4;
        } else {
            return count(n - 2, m - 2, x - 1);
        }
    }
}