package java_6.problem_244B.subId_3175062;

import java.util.HashMap;
import java.util.Scanner;
public class UndoubtedlyLuckyNumbers {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int cnt=0;
		HashMap<Integer, Integer> map=new HashMap<Integer, Integer>();
		for (int i = 0; i <= 9; i++) {
			for (int j = i; j <=9; j++) {
				for (int k = 1; k < 10; k++) {
					for (int bitMask = 0; bitMask < (1<<k); bitMask++) {
						StringBuilder sb=new StringBuilder();
						for (int wei = 0; wei < k; wei++) {
							if((bitMask&(1<<wei))!=0) sb.append(i);
							else sb.append(j);
						}
						if ( sb.charAt(0)=='0') continue;
						int num= Integer.parseInt(sb.toString());
						if(num>n) continue;
						if(map.containsKey(num)) continue;
						map.put(num, 1);
						cnt++;						
					}					
				}
			}
		}
	   System.out.println(cnt);
	}
}