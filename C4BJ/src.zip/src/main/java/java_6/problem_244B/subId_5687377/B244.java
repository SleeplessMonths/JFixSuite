package java_6.problem_244B.subId_5687377;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

public class B244 {
	static Set<Integer> badtoed;
	static int n, used[];
	
	static final int LIMIT = 9;
	static int[] digits = {0, 0, 0};
	
	public static void main(String[] args) throws IOException {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		n = pi(rl(in));
		badtoed = new HashSet<Integer>();
		used = new int[LIMIT];
		
		for (int i = 0; i <= 9; i++) {
			for (int j = i + 1; j <= 9; j++) {
				digits[1] = i;
				digits[2] = j;
				dfs(i, j, 0, false);
			}
		}
		
		System.out.println(badtoed.size());
	}
	
	static void dfs(int x, int y, int level, boolean hasNonZero) {
		if (level == LIMIT) {
			int num = 0;
			for (int i = 0; i < LIMIT; i++) num = 10*num + digits[used[i]];
			if (num > 0 && num <= n) badtoed.add(num);
		} else {
			used[level] = 0;
			if (!hasNonZero) dfs(x, y, level + 1, hasNonZero);
			used[level] = 1;
			dfs(x, y, level + 1, true);
			used[level] = 2;
			dfs(x, y, level + 1, true);
		}
	}
	
	private static int pi(String s) { return Integer.parseInt(s); }
	private static String rl(BufferedReader in) throws IOException { return in.readLine(); }
}