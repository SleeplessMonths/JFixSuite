package java_6.problem_261C.subId_2952951;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class  test{
	
	// ArrayList<Integer> lis = new ArrayList<Integer>();
	// ArrayList<String> lis = new ArrayList<String>();
	// PriorityQueue<Integer> que = new PriorityQueue<Integer>();
	//  Stack<Integer> que = new Stack<Integer>();
    //	static long sum=0;
	// 1000000007 (10^9+7)
	static int mod = 1000000007;
	//static int mod = 1000000009,r=0;
   // static int dx[]={1,-1,0,0};
//	static int dy[]={0,0,1,-1};
//	static int dx[]={1,-1,0,0,1,1,-1,-1};
//  static int dy[]={0,0,1,-1,1,-1,1,-1};
	//static long H,L;
	//static Set<Integer> set = new HashSet<Integer>();
public  static void main(String[] args)   throws Exception, IOException{
   //String line=""; throws Exception, IOException
   //(line=br.readLine())!=null
	//Scanner sc =new Scanner(System.in);
	// !!caution!! int long //  
	Reader sc = new Reader(System.in);
  // while( ){
	  // int  n=sc.nextInt(),m=sc.nextInt();//a[]=new int[n],b[]=new int[n];
	long n=sc.nextLong()+1,T=sc.nextLong();
	if( 1<Long.bitCount(T) ){ System.out.println(0);return; }
	String s=Long.toBinaryString(n);
    int k=s.length(),c=0;
	long a[]=new long[k+1];
     for(int i=1; i<=k ;i++)
     {
        if( s.charAt(i-1)=='1' ){c++;
         a[c]++; 
         for(int t=1;t<=k-i;t++)a[t+c-1]+=com(k-i,t);
         
        } 

     }
    //db(s,a);
    System.out.println(a[Long.toBinaryString(T).length()]);
    
     
}
static long com( int n, int m ) {
    if( n < m || m < 0 ) {
        throw new IllegalArgumentException( "��̒l���s���ł� ( n : " + n + ", m : " + m + ")" );
    }
    long c = 1;
    m = ( n - m < m ? n - m : m );
    for( int ns = n - m + 1, ms = 1; ms <= m; ns ++, ms ++ ) {
        c *= ns;
        c /= ms;
    }
    return c;
}
     

static void db(Object... os){
    System.err.println(Arrays.deepToString(os));

}
}



class Reader
{
	private BufferedReader x;
	private StringTokenizer st;
	
	public Reader(InputStream in)
	{
		x = new BufferedReader(new InputStreamReader(in));
		st = null;
	}
	public String nextString() throws IOException
	{
		while( st==null || !st.hasMoreTokens() )
			st = new StringTokenizer(x.readLine());
		return st.nextToken();
	}
	public int nextInt() throws IOException
	{
		return Integer.parseInt(nextString());
	}
	public long nextLong() throws IOException
	{
		return Long.parseLong(nextString());
	}
	public double nextDouble() throws IOException
	{
		return Double.parseDouble(nextString());
	}
}


/*

class P implements Comparable<P>{
//	implements Comparable<P>
	int v,w;
	P(int v,int w){
		this.v=v;
		this.w=w;
	
	} 
	public int compareTo(P x){
	   	 return w-x.w;//ascend 
	   }
}
*/