package java_6.problem_47B.subId_3400602;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
	
	//47B COdeforces
	
	public static String[] order(String[] lines){
		String[] ans = new String[lines.length];
		for (int i = 0; i < lines.length; i++) {
			if((lines[i].charAt(0)=='A' && lines[i].charAt(2)=='B') || (lines[i].charAt(0)=='B' && lines[i].charAt(2)=='A'))
				ans[0] = lines[i];
			if((lines[i].charAt(0)=='C' && lines[i].charAt(2)=='B') || (lines[i].charAt(0)=='B' && lines[i].charAt(2)=='C'))
				ans[1] = lines[i];
			if((lines[i].charAt(0)=='C' && lines[i].charAt(2)=='A') || (lines[i].charAt(0)=='A' && lines[i].charAt(2)=='C'))
				ans[2] = lines[i];	
		}
		return ans;
	}

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringBuilder sb = new StringBuilder();
		String line = "", aux = "", line2 ="", line3="";
		String[] lines = new String[3];
		d: do {
			lines[0] = br.readLine();
			if (lines[0] == null || lines[0].length() == 0)
				break;
			boolean a, b, c;
			a = b = c = false;
			lines[1]=br.readLine();
			lines[2] = br.readLine();
			lines = order(lines);
			if (lines[0].equals("A>B") || lines[0].equals("B<A"))
				a = true;
			if (lines[1].equals("B>C") || lines[1].equals("C<B"))
				b = true;
			if (lines[2].equals("A>C") || lines[2].equals("C<A"))
				c = true;
			if (a && b && c)
				sb.append("CBA").append("\n");
			else if (a && b && !c)
				sb.append("Impossible").append("\n");
			else if (a && !b && c)
				sb.append("BCA").append("\n");
			else if (!a && b && c)
				sb.append("BAC").append("\n");
			else if (!a && !b && c)
				sb.append("Impossible").append("\n");
			else if (!a && b && !c)
				sb.append("ACB").append("\n");
			else if (a && !b && !c)
				sb.append("BAC").append("\n");
			else if (!a && !b && !c)
				sb.append("ABC").append("\n");
		} while (lines[0] != null && lines[0].length() != 0);
		System.out.print(sb);
	}

}