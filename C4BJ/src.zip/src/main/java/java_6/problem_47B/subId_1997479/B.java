package java_6.problem_47B.subId_1997479;

import java.util.Scanner;


public class B {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[][]a = new int[4][4];
        for (int i = 0; i < 3; i++) {
            String s = sc.next();
            int w1 = s.codePointAt(0)-64, w2 = s.codePointAt(2)-64, op = s.codePointAt(1);
            if (op=='<') {
                int t = w1;
                w1 = w2;
                w2 = t;
            }
            if (a[w2][w1]==1) {
                System.out.println("Impossible");
                return;
            }
            a[w1][w2] = 1;
        }
        int[][]comb = {{1,2,3}, {1,3,2}, {2,1,3}, {2,3,1}, {3,1,2}, {3,2,1}};
        for (int i = 0; i < comb.length; i++) {
            int k1 = comb[i][0], k2 = comb[i][1], k3 = comb[i][2];
            if (a[k1][k2]==1 && a[k2][k3]==1) {
                for (int j = 2; j >= 0; j--) {
                    System.out.print((char)(comb[i][j]+64));
                }
                return;
            }
        }
        System.out.println("Impossible");
    }
}