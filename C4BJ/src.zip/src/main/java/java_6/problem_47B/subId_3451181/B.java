package java_6.problem_47B.subId_3451181;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class B{
public static void main(String args[]) throws IOException{
BufferedReader lector = new BufferedReader(new InputStreamReader(System.in));
boolean mat[][] = new boolean[3][3];
int pos[] = {0,0,0};
for(int n = 0;n<3;n++){
String t = lector.readLine();
int min = (int)((t.charAt(1)=='<')?t.charAt(0):t.charAt(2))-(int)'A',max = (int)((t.charAt(1)=='<')?t.charAt(2):t.charAt(0))-(int)'A';
if(!mat[min][max]){pos[min]++;mat[min][max]=true;}
for(int m = 0;m<3;m++)if(mat[max][m] && !mat[min][m]){mat[min][m]=true;pos[min]++;}
}
boolean impo = false;
for(int n = 0;n<3;n++)if(mat[n][n])impo = true;
byte res[] = {0,0,0};;
for(int m = 0;m<3 && !impo;m++)res[2-pos[m]]=(byte)('A'+m);
System.out.println((impo)?"Impossible":new String(res,0,res.length));
}
}