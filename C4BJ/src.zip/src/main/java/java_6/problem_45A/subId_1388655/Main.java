package java_6.problem_45A.subId_1388655;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main{
    public static void main(String args[]){
        Scanner in = new Scanner(System.in);
        String month = in.next();
        int n = in.nextInt();
        Map<String, Integer> map = new HashMap<String, Integer>();
        String m[] = new String[13];
        m[1] = "January"; m[2] = "February"; m[3] = "March"; m[4] = "April"; 
        m[5] = "May"; m[6] = "June"; m[7] = "July"; m[8] = "August"; m[9] = "September";
        m[10] = "October"; m[11] = "November"; m[12] = "December";
        map.put("January", 1); map.put("February",2); map.put("March",3); map.put( "April",4); map.put( "May",5);
        map.put("June",6); map.put("July",7); map.put( "August",8); map.put( "September",9); map.put( "October",10);
        map.put( "November",11); map.put("December",12);
        int now = map.get(month);
        int next = now + n;
        now = next % 12;
        System.out.println(m[now]);        
    }
}