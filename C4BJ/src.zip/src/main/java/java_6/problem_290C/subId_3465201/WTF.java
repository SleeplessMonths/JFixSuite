package java_6.problem_290C.subId_3465201;

import java.util.Scanner;
public class WTF {
	public static void main(String[] args) {
		Scanner in = new Scanner (System.in);
		int n = in.nextInt();
		int max =0;
		for(int i=0;i<n;i++)
			if(in.nextInt()!=0)
				max++;
		System.out.printf("%.6f\n",(double)max/n);
	}
}