package java_6.problem_261B.subId_2923393;

import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StreamTokenizer;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;

public class Main {

  double solve() {
    int n = readInt(), i, j = 0;
    int[] h = new int[n];
    BigInteger[] fct = new BigInteger[n + 1];
    fct[0] = BigInteger.ONE;
    for (i = 0; i < n; j += h[i++] = readInt()) {
      fct[i + 1] = fct[i].multiply(BigInteger.valueOf(i + 1));
    }
    int table = readInt(), p, f;
    if (j <= table) {
      return n;
    }
    BigInteger result = BigInteger.ZERO;
    for (f = 0; f < n; ++f) {
      // width, crowd
      int[][] dp = new int[table + 1][n];
      dp[0][0] = 1;
      for (p = 0; p < n; ++p) {
        if (f != p) {
          for (i = table; i >= 0; --i) {
            for (j = n; --j >= 0; ) {
              if (dp[i][j] != 0 && i + h[p] <= table) {
                dp[i + h[p]][j + 1] += dp[i][j];
              }
            }
          }
        }
      }
      for (i = 0; i <= table; ++i) {
        for (j = 0; j < n; ++j) {
          if (dp[i][j] != 0 && table - i < h[f]) {
            // j * j! * (n - j - 1)! * dp[i][j]
            result = result.add(BigInteger.valueOf(j).multiply(fct[j]).multiply(fct[n - j - 1]).multiply(BigInteger.valueOf(dp[i][j])));
          }
        }
      }
    }
    MathContext m = new MathContext(6);
    BigDecimal P = new BigDecimal(result), Q = new BigDecimal(fct[n]);
    return P.divide(Q, m).doubleValue();
  }

  Main() {
    out.println(solve());
  }

  // stuff cutline

  static PrintWriter out;

  static StreamTokenizer st;

  static int readInt() {
    try {
      st.nextToken();
    } catch (Exception ex) { }
    return (int) st.nval;
  }

  public static void main(String[] arg) throws Exception {
    // st = new StreamTokenizer(new FileReader("input.txt"));
    st = new StreamTokenizer(new InputStreamReader(System.in));
    out = new PrintWriter(System.out);
    Main root = new Main();
    out.flush();
  }

}