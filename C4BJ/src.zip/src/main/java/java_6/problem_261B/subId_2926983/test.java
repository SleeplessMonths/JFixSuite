package java_6.problem_261B.subId_2926983;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class  test{
	
	// ArrayList<Integer> lis = new ArrayList<Integer>();
	// ArrayList<String> lis = new ArrayList<String>();
	// PriorityQueue<Integer> que = new PriorityQueue<Integer>();
	//  Stack<Integer> que = new Stack<Integer>();
    //	static long sum=0;
	// 1000000007 (10^9+7)
	static int mod = 1000000007;
	//static int mod = 1000000009,r=0;
   // static int dx[]={1,-1,0,0};
//	static int dy[]={0,0,1,-1};
//	static int dx[]={1,-1,0,0,1,1,-1,-1};
//  static int dy[]={0,0,1,-1,1,-1,1,-1};
	//static long H,L;
	//static Set<Integer> set = new HashSet<Integer>();
	static int p,a[],n;
	static double d[],an[],com[][];
public  static void main(String[] args)   throws Exception, IOException{
   //String line=""; throws Exception, IOException
   //(line=br.readLine())!=null
	//Scanner sc =new Scanner(System.in);
	// !!caution!! int long //  
	Reader sc = new Reader(System.in);
  // while( ){
	  // int  n=sc.nextInt(),m=sc.nextInt();//a[]=new int[n],b[]=new int[n];
	n=sc.nextInt();
     a=new int[51]; d=new double[51]; an=new double[51]; d[0]=d[1]=1;
     com=new double[51][51];
     for(int i=1;i<51;i++)
		{
			com[i][0]=com[i][i]=1;
			for(int j=1;j<i;j++)
				com[i][j]=(com[i-1][j-1]+com[i-1][j]);
		}
     
     int al=0;
   for(int i=0;i<n;i++){a[sc.nextInt()]++; }
   for(int i=1;i<51;i++)al+=a[i];
   for(int i=2;i<51;i++)d[i]=i*d[i-1];
 
     p=sc.nextInt();
     if(al<=p){System.out.println(n); return ;}
     int x[]={1};
     
     for(int i=1;i<=50;i++) {x[0]=i; rep(x,x[0]);}
     d[0]=0;
     for(int i=1;i<=n;i++)if(0<an[i])d[0]+=an[i]*i;
     d[0]/=d[n];
   //  db(an);
    System.out.println(d[0]);
}

 static void rep(int x[],int y){
	 //db(x,y,an);
	 if(p<y)return;
	 double e=1;
	 int b[]=new int[51],w[]=new int[51];
	 for(int i=1;i<51;i++)b[i]=a[i];
	 for(int i=0;i<x.length;i++){ w[x[i]]++;  b[x[i]]--;}
	 for(int i=1;i<51;i++)if( 0<w[i] )e*=com[a[i]][w[i]];
	 if(e==0)return;
	 double ee=0;
	 for(int i=p-y+1;i<51;i++){  if( 0<b[i] )ee+=b[i];  }
	 e*=(ee==0 && p==y)?1:ee;
	 e*=d[x.length]*d[ 0<=(n-x.length-1)?(n-x.length-1):0 ];
	// db(x,e);
	 an[x.length]+=e;
	 int c[]=new int[x.length+1];
	 
	
	 
	 for(int i=0;i<x.length;i++)c[i]=x[i];
	 for(int i=x[x.length-1];i+x[x.length-1]<=p ;i++){
		 c[x.length]=i;
		 rep(c,y+i);
	 }
	 
 }

static void db(Object... os){
    System.err.println(Arrays.deepToString(os));

}
}



class Reader
{
	private BufferedReader x;
	private StringTokenizer st;
	
	public Reader(InputStream in)
	{
		x = new BufferedReader(new InputStreamReader(in));
		st = null;
	}
	public String nextString() throws IOException
	{
		while( st==null || !st.hasMoreTokens() )
			st = new StringTokenizer(x.readLine());
		return st.nextToken();
	}
	public int nextInt() throws IOException
	{
		return Integer.parseInt(nextString());
	}
	public long nextLong() throws IOException
	{
		return Long.parseLong(nextString());
	}
	public double nextDouble() throws IOException
	{
		return Double.parseDouble(nextString());
	}
}


/*

class P implements Comparable<P>{
//	implements Comparable<P>
	int v,w;
	P(int v,int w){
		this.v=v;
		this.w=w;
	
	} 
	public int compareTo(P x){
	   	 return w-x.w;//ascend 
	   }
}
*/