package java_6.problem_48A.subId_985128;

import java.util.Scanner;


public class Prob048A
{
    public static void main( String[] Args )
    {
        Scanner scan = new Scanner( System.in );
        char[] names = { 'F', 'M', 'S' };
        String[] gestures = new String[3];
        for ( int x = 0; x < 3; x++ )
            gestures[x] = scan.next();

        boolean overallv = false;

        for ( int x = 0; x < 3; x++ )
        {
            boolean victor = true;
            for ( int y = 0; y < 3; y++ )
            {
                if ( x != y )
                {
                    if ( !betterThan( gestures[x], gestures[y] ) )
                        victor = false;
                }
            }
            if ( victor )
            {
                overallv = true;
                System.out.println( names[x] );
            }
        }

        if ( !overallv )
            System.out.println( "?" );
    }


    public static boolean betterThan( String s1, String s2 )
    {
        if ( s1.equals( "paper" ) && s2.equals( "rock" ) )
            return true;
        if ( s1.equals( "scissor" ) && s2.equals( "paper" ) )
            return true;
        if ( s1.equals( "rock" ) && s2.equals( "scissor" ) )
            return true;
        return false;
    }
}