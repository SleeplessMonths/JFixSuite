package java_6.problem_48A.subId_285945;

import java.util.Arrays;
import java.util.Scanner;

public class Main1 {

    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        String as[] = new String[3];
        as[0] = in.next() + "F";
        as[1] = in.next() + "M";
        as[2] = in.next() + "S";
        Arrays.sort(as);
        System.out.print(Arrays.toString(as));
        if (as[0].substring(0, as[0].length() - 1).equals("paper")
                && as[1].substring(0, as[1].length() - 1).equals("rock")
                && as[2].substring(0, as[2].length() - 1).equals("rock")) {
            System.out.print(as[0].charAt(as[0].length() - 1));
        } else if (as[0].substring(0, as[0].length() - 1).equals("rock")
                && as[1].substring(0, as[1].length() - 1).equals("scissors")
                && as[2].substring(0, as[2].length() - 1).equals("scissors")) {
            System.out.print(as[0].charAt(as[0].length() - 1));
        } else if (as[0].substring(0, as[0].length() - 1).equals("paper")
                && as[1].substring(0, as[1].length() - 1).equals("paper")
                && as[2].substring(0, as[2].length() - 1).equals("scissors")) {
            System.out.print(as[2].charAt(as[2].length() - 1));
        } else {
            System.out.print("?");
        }
    }
}