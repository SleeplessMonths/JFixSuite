package java_6.problem_48A.subId_588597;

import java.util.Scanner;

public class RockPaper
{
    public static void main(String... ankit)
    {
        try
        {
            Scanner scan = new Scanner(System.in);
            String first,second,third;
            int flag =0;
            first= scan.nextLine();
            second= scan.nextLine();
            third = scan.nextLine();
            if (first.equals(second))
            {
                if((first.equals("rock") && third.equals("paper") )||(first.equals("paper") && third.equals("scissors")) ||(first.equals("scissors") && third.equals("rock")))
                    System.out.println("S");
                else
                System.out.println("?");
            }
            else if (first == third )
            {
                if((first.equals("rock") && second.equals("paper") )||(first.equals("paper") && second.equals("scissors")) ||(first.equals("scissors") && second.equals("rock")))
                    System.out.println("M");
                else
                System.out.println("?");
            }
            else if (second.equals(third))
            {
                if((third.equals("rock") && first.equals("paper") )||(third.equals("paper") && first.equals("scissors")) ||(third.equals("scissors") && first.equals("rock")))
                    System.out.println("F");
                else
                System.out.println("?");
            }
            else
                System.out.println("?");
        }
        catch(Exception e)
        {
        }
    }
}