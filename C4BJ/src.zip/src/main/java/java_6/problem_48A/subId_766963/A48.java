package java_6.problem_48A.subId_766963;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class A48 {

	BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
	StringTokenizer st = null;
	
	private void solution() throws IOException {
		char f = nextToken().charAt(0), m = nextToken().charAt(0), s = nextToken().charAt(0);
		if (f == 's' && m == 'p' && m == s || f == 'p' && m == 'r' && m == s || f == 'r' && m == 's' && m == s) System.out.println("F"); else
			if (m == 's' && f == 'p' && f == s || m == 'p' && f == 'r' && f == s || m == 'r' && f == 's' && f == s) System.out.println("M"); else
				if (s == 's' && m == 'p' && m == s || s == 'p' && m == 'r' && m == s || s == 'r' && m == 's' && m == s) System.out.println("S"); else
					System.out.println("?");
	}
	
	String nextToken() throws IOException {
        if (st == null || !st.hasMoreTokens()) {
            st = new StringTokenizer(bf.readLine());
        }
        return st.nextToken();
    }
	
	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}
	
	public static void main(String[] args)throws IOException {
		new A48().solution();
	}
}