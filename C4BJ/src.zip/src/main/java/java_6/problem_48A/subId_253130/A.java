package java_6.problem_48A.subId_253130;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class A
{
PrintWriter out;
BufferedReader in;
StringTokenizer ss;

   static void dbg(String s){System.out.println(s);};

   String next_token() throws IOException
   {while (!ss.hasMoreTokens())ss=new StringTokenizer(in.readLine());
    return ss.nextToken();}

   Double _double() throws IOException
   {return Double.parseDouble (next_token());}

   int _int() throws IOException
   {return Integer.parseInt (next_token());}

   long _long() throws IOException
   {return Long.parseLong (next_token());}

void run()throws IOException
{

in = new BufferedReader(new InputStreamReader(System.in));
out= new PrintWriter(System.out);
String name="";
/*in = new BufferedReader(new FileReader(name+".in"));
out = new PrintWriter(new File(name+".out"));  */
ss = new StringTokenizer(" ");
String An="FMS";
  int A[]=new int[3];
    for(int i=0;i<3;i++){
        String S=next_token();
        if(S.charAt(0)=='r')A[i]=0;
        if(S.charAt(0)=='p')A[i]=1;
        if(S.charAt(0)=='s')A[i]=2;
    }         for(int i=0;i<3;i++)out.print(A[i]);
  boolean ok=false;
    for(int i=0;i<3;i++){int t=-1;int tp=0;
        for(int j=0;j<3;j++)if(A[j]==i)t=j;
        for(int j=0;j<3;j++)if(A[j]==((i+2)%3))tp++;
        
        if(tp==2&&t>=0){out.println(An.charAt(t));ok=true;

        }
    }
  if(!ok)out.println("?");  

out.close();
}
    public static void main(String[] args)throws Exception
    {
    try{new A().run();}catch (Exception e){int Ar[]=new int[2];Ar[1+2]=2;};
    }


}