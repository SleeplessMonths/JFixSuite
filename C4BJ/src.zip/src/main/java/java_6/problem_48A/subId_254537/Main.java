package java_6.problem_48A.subId_254537;

/**
 *
 * @author saeed
 */

import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner in=new Scanner(System.in);
       String ans;
       ans="?";
        String fr,cat,dog;
        
        fr=in.nextLine();
        cat=in.nextLine();
        dog=in.nextLine();
        if(((fr.equals("rock")&&((cat.equals("scissorss"))&&(dog.equals("scissorss"))))))ans="F";
        else if((cat.equals("rock"))&&((fr.equals("scissorss"))&&(dog.equals("scissorss"))))ans="M";
         else if((dog.equals("rock"))&&((cat.equals("scissors"))&&(fr.equals("scissors"))))ans="S";
        else if(((fr.equals("scissors")&&((cat.equals("paper"))&&(dog.equals("paper"))))))ans="F";
        else if((cat.equals("scissors"))&&((fr.equals("paper"))&&(dog.equals("paper"))))ans="M";
        else if((dog.equals("scissors"))&&((cat.equals("paper"))&&(fr.equals("paper"))))ans="S";
         else if(((fr.equals("paper")&&((cat.equals("rock"))&&(dog.equals("rock"))))))ans="F";
     else if((cat.equals("paper"))&&((fr.equals("rock"))&&(dog.equals("rock"))))ans="M";
         else if((dog.equals("paper"))&&((cat.equals("rock"))&&(fr.equals("rock"))))ans="S";

        System.out.print(ans);// TODO code application logic here
    }

}