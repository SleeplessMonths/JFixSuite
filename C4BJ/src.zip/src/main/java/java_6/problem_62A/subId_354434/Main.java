package java_6.problem_62A.subId_354434;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
	public static void main(String[] args) throws NumberFormatException,
			IOException {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		String [] s = in.readLine().split(" ");
		int gl = Integer.parseInt(s[0]);
		int gr = Integer.parseInt(s[1]);
		 s = in.readLine().split(" ");
		int bl = Integer.parseInt(s[0]);
		int br = Integer.parseInt(s[1]);
		if((bl>=gr && bl<=2*gr)||(br>=gl && br<=2*gl))
			System.out.println("YES");
		else
			System.out.println("NO");
	}
}