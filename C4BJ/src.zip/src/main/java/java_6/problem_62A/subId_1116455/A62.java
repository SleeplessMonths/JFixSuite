package java_6.problem_62A.subId_1116455;

import java.util.Scanner;

public class A62 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int al = in.nextInt();
        int ar = in.nextInt();
        int bl = in.nextInt();
        int br = in.nextInt();
        boolean ok = check(al , br) || check(ar , bl);
        System.out.println(ok ? "YES" : "NO");
    }
    public static boolean check(int a , int b) {
        int l = (a + 1);
        int r = l * 2;
        if (b >= l && b <= r) return true;
        l = (a - 1);
        r = 2 * l;
        if (b >= l && b <= r) return true;
        return false;
    }
}