package java_6.problem_62A.subId_367685;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Dream
{
    public static void main(String[] args) throws IOException
    {
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
        String[] girl = r.readLine().split(" ");
        String[] boy = r.readLine().split(" ");

        int ar, al, bl, br;
        ar = Integer.parseInt(girl[1]);
        al = Integer.parseInt(girl[0]);
        br = Integer.parseInt(boy[1]);
        bl = Integer.parseInt(boy[0]);

        if(((al-br<2) && (al-br>-3)) || ((ar-bl<2) && (ar-bl>-3)))
        {
            System.out.println("YES");
        }
        else System.out.println("NO");
    }
}