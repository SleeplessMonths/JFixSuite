package java_6.problem_62A.subId_6827150;

import java.io.*;
import java.util.Locale;
import java.util.StringTokenizer;

public class r58 {
	static StringTokenizer st;
	static BufferedReader br;
	static PrintWriter pw;

	public static void main(String[] args) throws IOException {
		Locale.setDefault(Locale.US);
		br = new BufferedReader(new InputStreamReader(System.in));
		pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(
				System.out)));
		
		int a1=nextInt(),a2=nextInt(),b1=nextInt(),b2=nextInt();
		if(Math.abs(a1-b2)<=1||Math.abs(a2-b1)<=1)
			pw.println("YES");
		else
			if((b1-1)/2<=a2||(b2-1)/2<=a1)
				pw.println("YES");
			else
			pw.print("NO");
		pw.close();
	}

	private static int nextInt() throws IOException {
		return Integer.parseInt(next());
	}

	private static long nextLong() throws IOException {
		return Long.parseLong(next());
	}

	private static double nextDouble() throws IOException {
		return Double.parseDouble(next());
	}

	private static String next() throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine());
		return st.nextToken();
	}
}