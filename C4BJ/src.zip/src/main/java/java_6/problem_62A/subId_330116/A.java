package java_6.problem_62A.subId_330116;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class A {

    MyScanner in;
    PrintWriter out;

    public static void main(String[] args) throws Exception {
        new A().run();
    }

    public void run() throws Exception {
        in = new MyScanner();
        out = new PrintWriter(System.out);

        solve();

        out.close();
    }

    public void solve() throws Exception {
        int al = in.nextInt();
        int ar = in.nextInt();
        int bl = in.nextInt();
        int br = in.nextInt();
        
        if ((check(al, br)) || (check(ar, bl))) {
            out.println("YES");
        } else {
            out.println("NO");
        }
    }

    boolean check(int x, int y) {
        return ((x - 1 <= y) && (x >= y / 2 - 1)) ? true : false;
    }
    
    class MyScanner {
        BufferedReader br;
        StringTokenizer st;

        public MyScanner() throws Exception {
            br = new BufferedReader(new InputStreamReader(System.in));
        }

        String next() throws Exception {
            if ((st == null) || (!st.hasMoreTokens())) {
                st = new StringTokenizer(br.readLine());
            }
            return st.nextToken();
        }

        int nextInt() throws Exception {
            return Integer.parseInt(next());
        }

        double nextDouble() throws Exception {
            return Double.parseDouble(next());
        }

        boolean nextBoolean() throws Exception {
            return Boolean.parseBoolean(next());
        }

        long nextLong() throws Exception {
            return Long.parseLong(next());
        }
    }

}