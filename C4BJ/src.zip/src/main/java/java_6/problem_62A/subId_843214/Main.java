package java_6.problem_62A.subId_843214;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
        PrintWriter out=new PrintWriter(System.out);
        //BufferedReader in=new BufferedReader(new FileReader("input.txt"));
        //PrintWriter out=new PrintWriter(new FileWriter("output.txt"));
        String[] f=in.readLine().split(" ");
        int vl=Integer.parseInt(f[0]),vr=Integer.parseInt(f[1]);
        
        String[] s=in.readLine().split(" ");
        int ml=Integer.parseInt(s[0]),mr=Integer.parseInt(s[1]);
        if ((ml>=vr-1 && ml<=vr+3) ||  (mr>=vl-1 && mr<=vl+3)) out.println("YES");
        else out.println("NO");
        out.close();
    }

}