package java_6.problem_62A.subId_861164;

import java.util.Arrays;
import java.util.Scanner;

public class a62 {

	public static void debug(Object... obs)
	{
		System.out.println(Arrays.deepToString(obs));
	}

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		int gl=sc.nextInt();
		int gr=sc.nextInt();
		int bl=sc.nextInt();
		int br=sc.nextInt();
		
		if(gl-1 <= br && br <= gl+3)
		{
			System.out.println("YES");
			return;
		}
		if(gr-1 <= bl && bl <= gr+3)
		{
			System.out.println("YES");
			return;
		}
		System.out.println("NO");
	}
}