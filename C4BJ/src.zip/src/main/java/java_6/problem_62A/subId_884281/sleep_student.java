package java_6.problem_62A.subId_884281;

import java.util.Scanner;
public class sleep_student
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        int one_left = in.nextInt();
        int one_right = in.nextInt();
        
        int two_left = in.nextInt();
        int two_right = in.nextInt();
        boolean flag = true;
        
        if(one_left > two_right*2-1||two_right > one_left*2-1)
        {
            
        }
        else
        {
            System.out.println("YES");
            flag = false;
        }
        
        
        if((one_right > two_left*2-1&&flag==true)||(two_left > one_right*2-1&&flag==true))
        {
            System.out.print("NO");
            flag = false;
        }
        if(one_right < two_left*2-1&&flag==true||(two_left*2-1 > one_right&&flag==true))
        {
            System.out.println("YES");
        }
    }

}