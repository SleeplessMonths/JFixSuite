package java_6.problem_62A.subId_339945;

import java.util.Scanner;

/**
 * @author Vitaly Zubchevskiy
 *         Created at 15:19 18.03.11
 */
public class A
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        int bl = scanner.nextInt();
        int br = scanner.nextInt();
        int al = scanner.nextInt();
        int ar = scanner.nextInt();

        if (checkCan(al, br) || checkCan(ar, bl))
            System.out.println("YES");
        else
            System.out.println("NO");
    }

    private static boolean checkCan(int g, int b )
    {
        // || o || o ||     2 6
        // o | o | o        3 2
        // || o || o || o || o ||


        return b <= 2*g +2 && b >= g - 1;

    }
}