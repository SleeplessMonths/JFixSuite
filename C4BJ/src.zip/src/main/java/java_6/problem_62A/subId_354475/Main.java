package java_6.problem_62A.subId_354475;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static boolean get(int x, int y) {
        if (x == 0)
            return y < 3;
        if (y == 0)
            return x < 2;
        if (x == 1)
            return (y + 1) / 2 < 3;
        if (y == 1)
            return (x + 1) / 2 < 2;
        boolean way1 = 2 * (x - 1) >= y && x - 1 <= y;
        boolean way2 = x <= (y - 1) && 2 * x <= (y - 1);
        return way1 | way2;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String[] S = in.readLine().split(" ");
        int a1 = Integer.parseInt(S[0]);
        int a2 = Integer.parseInt(S[1]);
        S = in.readLine().split(" ");
        int b1 = Integer.parseInt(S[0]);
        int b2 = Integer.parseInt(S[1]);
        boolean can = get(a1, b2) | get(a2, b1);
        if (can)
            System.out.println("YES");
        else
            System.out.println("NO");
    }
}