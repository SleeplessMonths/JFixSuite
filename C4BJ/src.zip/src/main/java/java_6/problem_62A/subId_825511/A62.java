package java_6.problem_62A.subId_825511;

import java.util.Scanner;
public class A62 {
	
	public static void main(String args[]){
		
		Scanner input = new Scanner(System.in);
		
		int a1 = input.nextInt();
		int a2 = input.nextInt();
		int b1 = input.nextInt();
		int b2 = input.nextInt();
		
		if ( Math.abs(a1-b2)<=1 || Math.abs(a2-b1)<=1) System.out.println("YES");
		
		else System.out.println("NO");
		
		
	}

}