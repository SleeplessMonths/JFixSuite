package java_6.problem_62A.subId_354451;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static boolean get(int x, int y) {
        if (x == 0)
            return y < 3;
        if (y == 0)
            return x < 2;
        if (x == 1)
            return (y + 1) / 2 < 3;
        if (y == 1)
            return (x + 1) / 2 < 2;
        int[] G = new int[x - 1];
        int[] B = new int[y - 1];
        int c = 0;
        int temp = y;
        while (temp > 0) {
            G[c]++;
            c = (c + 1) % G.length;
            temp--;
        }
        boolean way1 = true;
        for (int i = 0; i < G.length; i++)
            way1 &= (G[i] < 3 && G[i] > 0);
        c = 0;
        temp = x;
        while (temp > 0) {
            B[c]++;
            c = (c + 1) % B.length;
            temp--;
        }
        boolean way2 = true;
        for (int i = 0; i < B.length; i++)
            way2 &= (B[i] < 2 && B[i] > 0);
        return way1 | way2;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String[] S = in.readLine().split(" ");
        int a1 = Integer.parseInt(S[0]);
        int a2 = Integer.parseInt(S[1]);
        S = in.readLine().split(" ");
        int b1 = Integer.parseInt(S[0]);
        int b2 = Integer.parseInt(S[1]);
        boolean can = get(a1, b2) | get(a2, b1);
        if (can)
            System.out.println("YES");
        else
            System.out.println("NO");
    }
}