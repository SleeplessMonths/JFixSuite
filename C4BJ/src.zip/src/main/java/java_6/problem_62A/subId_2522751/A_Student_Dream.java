package java_6.problem_62A.subId_2522751;

import java.util.Scanner;


public class A_Student_Dream {
public static void main(String[] args) {
	Scanner sc=  new Scanner(System.in);
	int a=sc.nextInt();
	int b=sc.nextInt();
	int x=sc.nextInt();
	int y=sc.nextInt();
	if(Math.abs(a-y)>3 && Math.abs(b-x)>3)
		System.out.println("NO");
	else
	System.out.println("YES");
}
}