package java_6.problem_62A.subId_758668;

import java.io.*;
import java.util.StringTokenizer;

public class Main {

	private void solve() throws IOException {
		
		int lfg = nextInt();
		int rfg = nextInt();
		int lfb = nextInt();
		int rfb = nextInt();
		
		if ( (can(lfg,rfb))||(can(rfg,lfb)) ){
			out.println("YES");
		}else{
			out.println("NO");
		}
	}
	private boolean can(int g, int b) {
		if( (b >= (g-1)) && ( g >= (b/2 + b%2) )  )
			return true;
		return false;
	}
	private BufferedReader in;
	private PrintWriter out;
	private StringTokenizer st;

	public Main() throws IOException {
		in = new BufferedReader(new InputStreamReader(System.in));
		out = new PrintWriter(new OutputStreamWriter(System.out));
		eat("");
		solve();
		in.close();
		out.close();
	}

	public static void main(String[] args) throws IOException {
		new Main();
	}

	private void eat(String s) {
		st = new StringTokenizer(s);
	}

	String next() throws IOException {
		while (!st.hasMoreTokens()) {
			String line = in.readLine();
			if (line == null) {
				return null;
			}
			eat(line);
		}
		return st.nextToken();
	}

	int nextInt() throws IOException {
		return Integer.parseInt(next());
	}

	long nextLong() throws IOException {
		return Long.parseLong(next());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(next());
	}
}