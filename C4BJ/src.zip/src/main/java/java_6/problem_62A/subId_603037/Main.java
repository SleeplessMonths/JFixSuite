package java_6.problem_62A.subId_603037;

import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner r = new Scanner(System.in);
        
        
        int gl = r.nextInt();
        int gr = r.nextInt();
        
        int bl = r.nextInt();
        int br = r.nextInt();
        
        if(solve(gr, bl) || solve(gl, br))System.out.println("YES");
        else System.out.println("NO");
    }

    private static boolean solve(int g, int b) {
        if(g == b)return true;
        if(g == b+1)return true;
        if(g+1 == b)return true;
        if(b <= 2*(g+1))return true;
        
        return false;
    }
}