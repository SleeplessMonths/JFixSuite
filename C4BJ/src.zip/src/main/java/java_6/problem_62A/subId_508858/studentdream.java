package java_6.problem_62A.subId_508858;

import java.util.Scanner;
public class studentdream{
	public static void main(String[] args){
		Scanner br = new Scanner(System.in);
		int lg = br.nextInt();
		int rg = br.nextInt();
		int lb = br.nextInt();
		int rb = br.nextInt();
		if(lb >= rg-1){
			if(lb <= rg*2){
				System.out.println("YES");
			}
			else if(rb >= lg-1){
				if(rb <= lg*2){
					System.out.println("YES");
				}
				else{
					System.out.println("NO");
				}
			}
			else{
				System.out.println("NO");
			}
		}
		else if(rb >= lg-1){
				if(rb <= lg*2){
					System.out.println("YES");
				}
				else{
					System.out.println("NO");
				}
		}
		else{
			System.out.println("NO");
		}
	}
}