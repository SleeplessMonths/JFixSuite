package java_6.problem_62A.subId_371632;

import java.util.Scanner;
public class Main {

    public static void main(String[]args){
               
          Scanner sc = new Scanner(System.in);
          int al = sc.nextInt();
          int ar = sc.nextInt();
          int bl = sc.nextInt();
          int br = sc.nextInt();
          
          if ( bl <= 2*(ar+1) || br <= 2*(al+1) ) System.out.println("YES");
          else System.out.println("NO");
          
    }   
}