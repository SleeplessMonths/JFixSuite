package java_6.problem_62A.subId_753033;

import java.io.PrintWriter;
import java.util.Scanner;

public class Solution {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        PrintWriter out = new PrintWriter(System.out);

        int gl = in.nextInt();
        int gr = in.nextInt();
        int bl = in.nextInt();
        int br = in.nextInt();

        boolean yes = false;

        if (bl >= gr - 1 && bl <= gr + 3) {
            yes = true;
        }

        if (br >= gl - 1 && br <= gl + 3) {
            yes = true;
        }

        out.print(yes ? "YES" : "NO");

        out.close();
    }
}