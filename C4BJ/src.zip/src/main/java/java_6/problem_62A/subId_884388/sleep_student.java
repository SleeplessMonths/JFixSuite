package java_6.problem_62A.subId_884388;

import java.util.Scanner;
public class sleep_student
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        int one_left = in.nextInt();
        int one_right = in.nextInt();
        
        int two_left = in.nextInt();
        int two_right = in.nextInt();
        
        if(one_left-1 <= two_right  )
        {
            if(two_right/3 <= one_left)
            {
                System.out.println("YES");
            }
            else
            {
                System.out.println("NO");
            }
        }
        else
        {
            if(one_right-1 <=two_left)
            {
                if(two_left/3 <= one_right)
                {
                    System.out.println("YES");
                }
                else
                {
                    System.out.println("NO");
                }
            }
            else
            {
                System.out.println("NO");
            }
        }
        
    
    }

}