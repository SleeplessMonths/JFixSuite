package java_6.problem_62A.subId_884362;

import java.util.Scanner;
public class sleep_student
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        int one_left = in.nextInt();
        int one_right = in.nextInt();
        
        int two_left = in.nextInt();
        int two_right = in.nextInt();
        
        if(one_left-1 <= two_right || one_right-1<=two_left)
        {
            if(one_left*2 > two_right || one_right*2 > two_left)
            {
                System.out.println("YES");
            }
            else
            {
                System.out.println("NO");
            }
        }
        else
        {
            System.out.println("NO");
        }
    
    }

}