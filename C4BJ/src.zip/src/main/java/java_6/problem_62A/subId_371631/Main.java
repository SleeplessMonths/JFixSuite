package java_6.problem_62A.subId_371631;

import java.util.Scanner;
public class Main {

    public static void main(String[]args){
               
          Scanner sc = new Scanner(System.in);
          int al = sc.nextInt();
          int ar = sc.nextInt();
          int bl = sc.nextInt();
          int br = sc.nextInt();
          
          if ( (al == br+1) || (al == br-1) || (ar == bl + 1) || (ar == bl - 1) || ar==bl || al == br || ar==br || al==bl){
              System.out.println("YES");
          }
          else System.out.println("NO");
          
    }   
}