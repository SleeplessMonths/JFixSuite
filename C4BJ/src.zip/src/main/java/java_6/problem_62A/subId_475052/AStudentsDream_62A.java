package java_6.problem_62A.subId_475052;

import java.util.Scanner;


public class AStudentsDream_62A {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int girlL = sc.nextInt();
        int girlR = sc.nextInt();
        
        int boyL = sc.nextInt();
        int boyR = sc.nextInt();
        
        if (Math.abs(girlL-boyR)<= 1 && (boyR <= (2*(girlL+1))) || Math.abs(girlR - boyL)<2 && (boyL <= (2*(girlR+1))) ) {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
    }

}