package java_6.problem_62A.subId_3956027;

import java.util.Scanner;

public class A62 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int al = in.nextInt();
        int ar = in.nextInt();
        int bl = in.nextInt();
        int br = in.nextInt();
        if(Math.abs(al - br) <= 1 || Math.abs(ar - bl) <= 1) {
            System.out.println("YES");
            return;
        }
        if(al - br >= 2 || ar - bl >= 2) {
            System.out.println("NO");
            return;
        }
        if(bl - ar >= 3 || br - al >= 3) {
            System.out.println("NO");
            return;
        }
        System.out.println("YES");
    }
}