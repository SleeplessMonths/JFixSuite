package java_6.problem_62A.subId_818573;

import java.util.Scanner;


public class Main{


    public static void main(String[] args) throws Exception {
        Scanner in=new Scanner(System.in);
        int gl,gr,bl,br;
        gl=in.nextInt();
        gr=in.nextInt();
        bl=in.nextInt();
        br=in.nextInt();
        boolean ok=false;
        if(gr==0 &&bl<=2) ok=true;
        else if(gl==0 && br<=2) ok=true;
        else if((br-gl>=0 && br-gl <=3) ||(gl-br==1)) ok=true;
        else if((bl-gr>=0 && bl-gr <=3) ||(gr-bl==1)) ok=true;
        if(ok)
            System.out.println("YES");
        else
            System.out.println("NO");
    }
}