package java_6.problem_284A.subId_9342960;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Codeforces284A
{
	public static void main(String[] args)
	{
		try
		{
			BufferedReader f = new BufferedReader(new InputStreamReader(System.in));
			int p = Integer.parseInt(f.readLine());
			int count = 0;
			for(int i = 2; i <= p-1; i++)
			{
				int a = i;
				boolean isGood = true;
				for(int j = 2; j < p-1; j++)
				{
					a*=i;
					a%=p;
					if(a == 1)
					{
						isGood = false;
						break;
					}
				}
				if(isGood)
					count++;
			}
			System.out.println(count);
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
	}
}