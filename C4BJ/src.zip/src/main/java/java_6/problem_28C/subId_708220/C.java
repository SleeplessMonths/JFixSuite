package java_6.problem_28C.subId_708220;

import java.util.Arrays;
import java.util.Scanner;

public class C {
    static double[][][] C;
    static double[][][] DP;
    static int[] B;
    static int m;
    static int n;

    public static double get(int w, int s, int max) {
        if (w + 1 == m)
            return Math.max(s, max);
        if (DP[w][s][max] > -0.5)
            return DP[w][s][max];
        double res = 0;
        for (int i = 0; i <= s; i++)
            res += C[s][i][m - w]
                    * get(w + 1, s - i,
                            Math.max(max, (int) (Math.ceil(i * 1.0 / B[w]))));
        return DP[w][s][max] = res;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        n = in.nextInt();
        m = in.nextInt();
        B = new int[m];
        DP = new double[m + 1][n + 1][n + 1];
        for (int i = 0; i <= m; i++)
            for (int j = 0; j <= n; j++)
                Arrays.fill(DP[i][j], -1);
        for (int i = 0; i < m; i++)
            B[i] = in.nextInt();
        C = new double[n + 1][n + 1][m + 1];
        for (int k = 1; k <= m; k++) {
            C[0][0][k] = 1;
            for (int i = 1; i <= n; i++)
                for (int j = 0; j <= n; j++)
                    if (j == 0)
                        C[i][j][k] = C[i - 1][j][k] * (k - 1) / k;
                    else
                        C[i][j][k] = C[i - 1][j - 1][k] / k + C[i - 1][j][k]
                                * (k - 1) / k;
        }
        System.out.println(get(0, n, 0));
    }
}