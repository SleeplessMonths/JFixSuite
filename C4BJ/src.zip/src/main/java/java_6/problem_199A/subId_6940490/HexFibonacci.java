package java_6.problem_199A.subId_6940490;

import java.util.Scanner;

public class HexFibonacci
{
    
    private static int[] fibs = new int[47];

    private static int fibonacci(int n)
    {
        if (n == 0)
            return 0;
        if (n == 1 || n == 2)
            return 1;
        if (fibs[n] != 0)
            return fibs[n];
        int x = fibonacci(n-1) + fibonacci(n-2);
        fibs[n] = x;
        return x;
    }
        

    public static void main(String[] args)
    {
        fibs[0] = 0;
        fibs[1] = 1;
        fibs[2] = 1;
        // Set up scanner
        Scanner sc = new Scanner(System.in); 
        // System.out.println("Input n");
        int n = sc.nextInt();
        if (n == 0 || n == 1 || n == 2)
        {
            System.out.println("I'm too stupid to solve this problem");
            return;
        }
        if (n == 3)
        {
            System.out.println("1 1 1");
            return;
        }
        
        int whichfib = 0;
        for (int i=5; i<47; i++)
        {
            if (fibonacci(i) == n)
            {
                whichfib = i;
                break;
            }
        }
            
        System.out.println(fibonacci(whichfib-4) + " " + fibonacci(whichfib-3) + " " + fibonacci(whichfib-1));
    }
}