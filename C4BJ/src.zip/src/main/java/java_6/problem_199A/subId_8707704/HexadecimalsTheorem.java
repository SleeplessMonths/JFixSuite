package java_6.problem_199A.subId_8707704;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author Computragy
 */
public class HexadecimalsTheorem {

    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            int num = Integer.parseInt(reader.readLine());
            for (int n1 = 1; n1 < num; n1++) {
                for (int n2 = 1; n2 < num; n2++) {
                    for (int n3 = 1; n3 < num; n3++) {
                        int output = n1+n2+n3;
                        if(output == num)
                        {
                            System.out.println(n1+" "+n2+" "+n3);
                            return;
                        }
                    }
                }
            }
        } catch (Exception e) {
        }
    }
}