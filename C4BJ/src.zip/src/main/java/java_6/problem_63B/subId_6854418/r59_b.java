package java_6.problem_63B.subId_6854418;

import java.io.*;
import java.util.Arrays;
import java.util.Locale;
import java.util.StringTokenizer;

public class r59_b {
	static StringTokenizer st;
	static BufferedReader br;
	static PrintWriter pw;

	public static void main(String[] args) throws IOException {
		Locale.setDefault(Locale.US);
		br = new BufferedReader(new InputStreamReader(System.in));
		pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(
				System.out)));
		
		int n=nextInt(),k=nextInt();
		Long a[]=new Long[n+2];
		for (int i = 1; i <=n; i++) {
			a[i]=nextLong();
		}
		Arrays.sort(a,1,n+1);
		int ans=0,l=n;
		for (int i = 1; i <=1000; i++) {
			while(l>0&&a[l]==k)
				l--;
			if(l<=0)
				break;
			ans++;
			//Arrays.sort(a,1,l+1);
			for (int j = 1; j <=l; j++) {
				if(a[j]!=a[j+1])
					a[j]++;
			}
//			for (int j =1; j <=n; j++) {
//				pw.print(a[j]+" ");
//			}
//			pw.println();
		}
		if(a[1]!=a[2])
			ans++;
		pw.print(ans);
		pw.close();
	}

	private static int nextInt() throws IOException {
		return Integer.parseInt(next());
	}

	private static long nextLong() throws IOException {
		return Long.parseLong(next());
	}

	private static double nextDouble() throws IOException {
		return Double.parseDouble(next());
	}

	private static String next() throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine());
		return st.nextToken();
	}
}