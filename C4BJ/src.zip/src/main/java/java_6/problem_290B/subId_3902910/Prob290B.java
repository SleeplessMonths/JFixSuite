package java_6.problem_290B.subId_3902910;

import java.util.Scanner;

public class Prob290B {
	public static void main(String[] Args) {
		Scanner scan = new Scanner(System.in);
		long x = scan.nextLong();
		long y = scan.nextLong();
		System.out.println((y + 1) % 2);
	}
}