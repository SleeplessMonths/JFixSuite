package java_6.problem_40A.subId_1146528;

import java.util.Scanner;

public class Solution {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int x = in.nextInt();
        int y = in.nextInt();

        double dist = Math.sqrt(x * x + y * y);
        int circles = (int) dist;

        //if point lies on border of segment
        if (Math.abs((double) circles - dist) < 1e-9) {
            System.out.println("black");
        } else {
            if (circles % 2 == 0) {
                System.out.println(x * y < 0 ? "black" : "white");
            } else {
                System.out.println(x * y > 0 ? "white" : "black");
            }
        }
    }
}