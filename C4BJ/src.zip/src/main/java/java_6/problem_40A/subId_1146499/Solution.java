package java_6.problem_40A.subId_1146499;

import java.util.Scanner;

public class Solution {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int x = in.nextInt();
        int y = in.nextInt();

        double dist = Math.sqrt(x * x + y * y);
        int circles = (int) dist;

        //if point lies on border of segment
        if (Math.abs((double) circles - dist) < 1e-9){
            System.out.println("black");
        } else {
            System.out.println(circles % 2 == 0 && x * y > 0 ? "black" : "white");
        }
    }
}