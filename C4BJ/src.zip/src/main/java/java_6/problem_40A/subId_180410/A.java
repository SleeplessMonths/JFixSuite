package java_6.problem_40A.subId_180410;

import java.util.Scanner;

public class A {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		double x = s.nextInt(), y = s.nextInt();
		double sig = Math.signum(x * y);
		int d = (int) Math.sqrt(x * x + y * y);
		System.out.println(sig < 0 ? (d % 2 < 1 ? "white" : "black")
				: (d % 2 < 1 ? "black" : "white"));
	}

}