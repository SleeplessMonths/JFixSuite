package java_6.problem_40A.subId_1271406;

import java.util.Scanner;


public class test2 {
 
    public static void main(String[] args) 
    {
	new test2().run();
    }
    
    void run()
    {
	Scanner in=new Scanner(System.in);
	boolean f=true;
	
	int x=in.nextInt();
	int y=in.nextInt();
	
	if(x<0)
	{
	    f=!f;
	}
	
	if(y<0)
	{
	    f=!f;
	}
	
	double r=(int)Math.sqrt(x*x+y*y);
	
	if(Math.floor(r)==Math.ceil(r))
	{
	    System.out.println("black");
	    return;
	}
	
	boolean w=true;
	
	if((int)r%2==0)
	    w=false;

	if(!f) w=!w;
	
	if(w) System.out.println("white"); else System.out.println("black");
    }
}