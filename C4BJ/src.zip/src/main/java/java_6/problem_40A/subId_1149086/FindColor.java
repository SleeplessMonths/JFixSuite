package java_6.problem_40A.subId_1149086;

import java.util.Scanner;

public class FindColor {

    void run(){
        Scanner in = new Scanner(System.in);
        int x = in.nextInt(), y = in.nextInt();
        double rad = Math.sqrt(x*x + y*y);
        System.out.println(rad +" mod: "+ rad%1);
        if(rad%1==.0 || x==0 || y==0){
            System.out.println("black");
            return;
        }
        if( (x>0 && y > 0 ) || (x<0 && y<0) ){
            if((int)rad%2 == 0) System.out.println("black");
            else System.out.println("white");
        }
        else{
            if((int)rad%2 == 0) System.out.println("white");
            else System.out.println("black");
        }
    }
    
    public static void main(String[] args) {
        new FindColor().run();
    }

}