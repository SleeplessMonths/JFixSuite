package java_6.problem_40A.subId_541426;

import java.util.Scanner;


public class p40a {
    public static void main(String[] args) {
        Scanner
        in = new Scanner(System.in);
        int x = in.nextInt();
        int y = in.nextInt();
        
        if(x == 0 || y == 0) {
            System.out.println("black");
            return;
        }
        double rad = Math.sqrt(x*x + y*y);
        
        if((x<0 && y<0) || (x>0 && y>0)) {
        
            if((long)rad %2 == 0) {
                System.out.println("black");
            }
            else System.out.println("white");
            return;
        }
        if((long)rad%2 == 0)
            System.out.println("white");
        else System.out.println("black");
    }
}