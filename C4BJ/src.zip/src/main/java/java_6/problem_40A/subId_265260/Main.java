package java_6.problem_40A.subId_265260;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws Exception {
        Scanner in = new Scanner(System.in);
        int x = in.nextInt();
        int y = in.nextInt();
        double ans=(double)Math.sqrt(x*x+y*y);            
         if((x>0&&y>0)||(x<0&&y<0)){
            if(ans%2<=1){
                System.out.print("black");
            }else{
                System.out.print("white");
            }
        }else if((x>0&&y<0)||(x<0&&y>0)){
            if(ans%2>=1||ans%2==0){
                System.out.print("black");
            }else{
                System.out.print("while");
            }
        }else{
            System.out.print("black");
        }
    }
}