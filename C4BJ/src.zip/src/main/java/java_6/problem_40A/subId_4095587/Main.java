package java_6.problem_40A.subId_4095587;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main{

	// split de array
	public static int[] atoi(String cad) {
		String read[] = cad.split(" ");
		int res[] = new int[read.length];
		for (int i = 0; i < read.length; i++) {
			res[i] = Integer.parseInt(read[i]);
		}
		return res;
	}

	// split de String
	public static String[] atos(String cad) {
		return cad.split(" ");
	}

	// parsing de String a int
	public static int parseo(String cad, int index) {
		return Integer.parseInt(cad.split(" ")[index]);
	}

	// memory status
	static String memoryStatus() {
		return (Runtime.getRuntime().totalMemory()
				- Runtime.getRuntime().freeMemory() >> 20)
				+ "/" + (Runtime.getRuntime().totalMemory() >> 20) + " MB";
	}

	// imprimir array
	static void printArrayInt(int[] array) {
		if (array == null || array.length == 0)
			return;
		for (int i = 0; i < array.length; i++) {
			if (i > 0)
				System.out.print(" ");
			System.out.print(array[i]);
		}
		System.out.println();
	}

	// impresion de datos
	static void print(Object... obj) {
		for (int i = 0; i < obj.length; i++) {
			if (i != 0)
				System.out.print(" ");
			System.out.print(obj[i]);
		}
		System.out.println();
	}

	public static int cmp(final double x, final double y, final double eps) {
		return (x <= y + eps) ? (x + eps < y) ? -1 : 0 : 1;
	}

	public static void main(String[] args) throws IOException {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		int arr[] = atoi(in.readLine());
		double dist = (double) Math.sqrt(Math.pow(arr[0], 2)
				+ Math.pow(arr[1], 2));
		double num = Math.sqrt(2);
		double res[] = new double[1005];
		res[0] = num;
		// System.out.println(dist);
		for (int i = 1; i < res.length; i++) {
			res[i] = res[i - 1] + num;
		}
		if (arr[0] == 0 || arr[1] == 0) {
			System.out.println("black");
		} else {
			if ((arr[0] >= 0 && arr[1] >= 0) || (arr[0] < 0 && arr[1] < 0)) {
				if ((double) dist / (int) dist != 1) {
					if ((int) dist % 2 == 0) {
						System.out.println("black");
					} else
						System.out.println("white");
				} else
					System.out.println("black");
				/*
				 * for (int i = 0; i < res.length - 1; i++) { if (dist >= res[i]
				 * && dist <= res[i + 1]) { if (i % 2 == 0) {
				 * System.out.println("black"); break; } else { if(cmp(dist,
				 * res[i],0.0000001)!=0 && cmp(dist, res[i+1],0.0000000001)!=0)
				 * System.out.println("white"); else
				 * System.out.println("black"); break; } } }
				 */
			} else {
				if ((int) dist % 2 != 0) {
					if ((int) (dist) % 2 == 1)
						System.out.println("black");
					else
						System.out.println("white");
				} else
					System.out.println("white");
				/*
				 * for (int i = 0; i < res.length - 1; i++) { if (dist >= res[i]
				 * && dist <= res[i + 1]) { if (i % 2 != 0) {
				 * System.out.println("black"); break; } else { if(cmp(dist,
				 * res[i],0.0000001)!=0 && cmp(dist, res[i+1],0.00000000001)!=0)
				 * System.out.println("white"); else
				 * System.out.println("black"); break; } } }
				 */
			}
		}

	}

}