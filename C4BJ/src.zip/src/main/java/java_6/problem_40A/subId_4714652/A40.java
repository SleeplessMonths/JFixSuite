package java_6.problem_40A.subId_4714652;

import java.util.Scanner;

public class A40 {
	
	public static void main (String args[]){
		Scanner in = new Scanner(System.in);
		int x=in.nextInt();
		int y=in.nextInt();
		boolean n=(x*y>=0 ? false : true);
		double r= Math.sqrt((x*x+y*y));
		for(int i=0;i<1415;i++){
			if(r==i){System.out.println("black");break;}
			
			else if(r<i)
			{
				if(i%2==1){
					if(!n)
						System.out.println("black");
					else
						System.out.println("white");
				}
				else{
					if(!n)
						System.out.println("white");
					else
						System.out.println("black");
				}
				break;
			}
		}
		
	}

}