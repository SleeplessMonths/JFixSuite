package java_6.problem_40A.subId_181127;

import java.util.Scanner;
public class C39A {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int x=sc.nextInt();
        int y=sc.nextInt();

        double r=Math.sqrt(x*x+y*y);

        boolean d=false;
        if(r == Math.floor(r))
            d=true;

        String str="";
        if(x==0 && y==0)
            str="black";
        if((x>0 && y>0)|| (x<0 && y<0)){
            if(d)
                str="black";
            else{
                if(Math.floor(r)%2==0)
                    str="black";
                else
                    str="white";
            }
        }

        else if((x<0 && y>0) || (x>0 && y<0)){
            if(d)
                str="black";
            else{
                if(Math.floor(r)%2==0)
                    str="white";
                else
                    str="black";
            }

        }

        System.out.println(str);

    }



}