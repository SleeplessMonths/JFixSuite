package java_6.problem_142B.subId_1041545;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Random;
import java.util.StringTokenizer;

public class Solution implements Runnable {
    private BufferedReader in;
    private PrintWriter out;
    private StringTokenizer st;
    private Random rnd;
    
    private int solveSmart(int n, int m) {
        int total = n * m;
        
        return (total / 2) + (total % 2);
    }
    
    final int[] dx = {1, 1, -1, -1, 2, 2, -2, -2};
    final int[] dy = {2, -2, 2, -2, 1, -1, 1, -1};
    int[][] used, mtx, mty;
    
    private boolean matching(int i, int j, int timer, int n, int m) {
        if(used[i][j] == timer) return false;
        used[i][j] = timer;
        
        for(int k = 0; k < 8; k++) {
            int ni = i + dx[k], nj = j + dy[k];
            
            if(ni < 0 || nj < 0 || ni >= n || nj >= m) continue;
            
            int ex = mtx[ni][nj], ey = mty[ni][nj];
            
            if(ex == -1 || matching(ex, ey, timer, n, m)) {
                mtx[ni][nj] = i;
                mty[ni][nj] = j;
                return true;
            }
        }
        
        return false;
    }
    
    private int solveDumb(int n, int m) {
        used = new int[n][m];
        mtx = new int[n][m];
        mty = new int[n][m];
        int res = 0, timer = 0;
        boolean[][] already = new boolean[n][m];
        
        for(int i = 0; i < n; i++) {
            Arrays.fill(mtx[i], -1);
            Arrays.fill(mty[i], -1);
        }
        
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < m; j++) {
                if((i + j) % 2 != 0) continue;
                
                for(int k = 0; k < 8; k++) {
                    int ni = i + dx[k], nj = j + dy[k];
                    
                    if(ni < 0 || nj < 0 || ni >= n || nj >= m || mtx[ni][nj] != -1) continue;
                    
                    already[i][j] = true;
                    mtx[ni][nj] = i;
                    mty[ni][nj] = j;
                    ++res;
                    break;
                }
            }
        }
        
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < m; j++) {
                if(already[i][j] || (i + j) % 2 == 0) continue;
                if(matching(i, j, ++timer, n, m)) {
                    ++res;
                }
            }
        }
        
        return (n * m) - res;
    }

    public void solve() throws IOException {
        int n = nextInt(), m = nextInt();
        
        if(n < 300 || m < 300) out.println(solveDumb(n, m));
        else out.println(solveSmart(n, m));
    }
        
    public static void main(String[] args) {
        new Solution().run();
    } 
    
    public void run() {
        try {
            in = new BufferedReader(new InputStreamReader((System.in)));
            out = new PrintWriter(System.out);
            
            st = null;
            rnd = new Random();
            
            double start = System.currentTimeMillis();
            solve();
            double total = (System.currentTimeMillis() - start) / 1000.0;
            total *= 10; // hello intel core i7-2700 4.5 Ghz :D
            
            //out.println("Total time: " + total + " sec.");
            
            out.close();
        } catch(IOException e) {
            e.printStackTrace();
        }   
    }
    
    private String nextToken() throws IOException, NullPointerException {
        while(st == null || !st.hasMoreTokens()) {
            st = new StringTokenizer(in.readLine());
        }
        
        return st.nextToken();
    }
    
    private int nextInt() throws IOException {
        return Integer.parseInt(nextToken());
    }
    
    private long nextLong() throws IOException {
        return Long.parseLong(nextToken());
    }
    
    private double nextDouble() throws IOException {
        return Double.parseDouble(nextToken());
    }

}