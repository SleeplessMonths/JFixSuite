package java_6.problem_142B.subId_1125848;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class D {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int m = in.nextInt();
        boolean[][] A = new boolean[n][m];
        int[] dx = { -1, -1, 1, 1, -2, -2, 2, 2 };
        int[] dy = { -2, 2, -2, 2, -1, 1, -1, 1 };
        int ans = 0;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++) {
                if (A[i][j])
                    continue;
                Queue<cell> Q = new LinkedList<cell>();
                Q.add(new cell(i, j, 1));
                while (!Q.isEmpty()) {
                    cell temp = Q.poll();
                    int x = temp.x;
                    int y = temp.y;
                    int t = temp.t;
                    if (A[x][y])
                        continue;
                    if (t == 1)
                        ans++;
                    A[x][y] = true;
                    for (int k = 0; k < 8; k++) {
                        int xx = x + dx[k];
                        int yy = y + dy[k];
                        if (xx < 0 || yy < 0 || xx >= n || yy >= m)
                            continue;
                        Q.add(new cell(xx, yy, -t));
                    }
                }
            }
        System.out.println(ans);
    }
}

class cell {
    int x;
    int y;
    int t;

    public cell(int i, int j, int k) {
        x = i;
        y = j;
        t = k;
    }
}