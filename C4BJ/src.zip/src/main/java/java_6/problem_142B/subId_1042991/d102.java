package java_6.problem_142B.subId_1042991;

import java.util.Arrays;
import java.util.Scanner;

public class d102 {
    public static void debug(Object... obs) {
        System.out.println(Arrays.deepToString(obs));
    }

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        
        int n=sc.nextInt();
        int m=sc.nextInt();
        
        if(n==1||m==1||(n<=2 && m<=2))
        {
            System.out.println(n*m);
            return;
        }
        if(n*m==6)
        {
            System.out.println(4);
            return;
        }
        int k=n*m+1;
        System.out.println(k/2);
    }
}