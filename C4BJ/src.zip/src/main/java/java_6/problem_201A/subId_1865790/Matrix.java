package java_6.problem_201A.subId_1865790;

import java.util.Scanner;


public class Matrix {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int num=sc.nextInt();
        int lowermax=1;
        int uppermax=1;
        int side=-1;
       do {
           side+=2;
            lowermax= uppermax;
            uppermax= (((side/2)+1)*((side/2)+1)) + ((side/2)*(side/2));
             System.out.println("L:"+lowermax);
             System.out.println("U:"+uppermax);
        } while (!(lowermax <= num && num <= uppermax ));
        
 System.out.println(side);
    }
    
}