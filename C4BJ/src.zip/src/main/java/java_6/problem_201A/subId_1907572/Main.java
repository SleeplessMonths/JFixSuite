package java_6.problem_201A.subId_1907572;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StreamTokenizer;

public class Main {
//	static Scanner in; static int next() throws Exception {return in.nextInt();};
	static StreamTokenizer in; static int next() throws Exception {in.nextToken(); return (int) in.nval;}
//	static BufferedReader in;
	static PrintWriter out;

	public static void main(String[] args) throws Exception {
//		in = new Scanner(System.in);
		in = new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
//		in = new BufferedReader(new InputStreamReader(System.in));
		out = new PrintWriter(System.out);
		
		int k = next();
		boolean[] can = new boolean[20];

		for (int i = 0; i < 20; i++) {
			if (i % 2 == 1) can[i] = (i * i + 1)/2 >= k;
			else {
				can[i] = (k % 4 == 0 && k <= 4 * (i/2 - 1) * (i/2 - 1)/2);
			}
		}

		int min = 100;
		for (int i = 0; i < 20; i++) if (can[i]) min = Math.min(min, i);

		out.println(min);

		out.close();
	}
}