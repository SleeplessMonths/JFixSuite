package java_6.problem_201A.subId_1863738;

import java.util.Scanner;

public class ClearSymmetry {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		if(x==1){
			System.out.println(1);
		}
		if(x==2){
			System.out.println(2);
		}
		if(x==3){
			System.out.println(5);
		}
		if(x==4){
			System.out.println(3);
		}
		if(x==5){
			System.out.println(3);
		}
		if(x==6){
			System.out.println(5);
		}
		if(x>=7){
			for(int k=0; true; k++){
				if(2*k*k+2*k+1>=x){
					System.out.println(2*k+1);
					return;
				}
			}
		}
	}
}