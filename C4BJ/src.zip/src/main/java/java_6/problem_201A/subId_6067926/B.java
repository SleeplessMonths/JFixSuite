package java_6.problem_201A.subId_6067926;

import java.util.Scanner;
public class B {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int x=sc.nextInt();
        if(x==3){
            System.out.println(5);
            return;
        }
        
        for (int i =1 ; i < 101; i++) {
            if((i+1)*(i+1)+i*i>=x){
                System.out.println(2*i+1);
                return;
            }
        }
    
        
        
    }
}