package java_6.problem_30A.subId_2542577;

//package acm;

import java.io.PrintWriter;
import java.util.Scanner;

public class ACM {
    
    PrintWriter out;
    Scanner in;

    
    long binpow(long a, int b){
        if (b == 0) return 1;
        if (b % 2  == 1) return (binpow(a, b-1) * a);
        else {
            long t = binpow(a, b/2);
            return (t * t);
        }
    }
    
    void solve(){
        long a = in.nextInt();
        int b = in.nextInt();
        int n = in.nextInt();
        boolean ok = false;
        for (long i = -1000; i<=1000; i++){
            long pow = 1;
            int p = 0;
            for (; p<n; p++){
                if (Math.abs(pow * i * a) > b) break;
                pow *= i;
            }
            
            if (p == n && a * pow == b){
                System.out.println(i);
                ok = true;
                break;
            }
        }
        if (!ok)
            System.out.println("No solution");
    }
    
    void run(){
        in = new Scanner(System.in);
        out = new PrintWriter(System.out);
        solve();
        out.close();
    }
    
    public static void main(String[] args) {
        new ACM().run();
    }
}