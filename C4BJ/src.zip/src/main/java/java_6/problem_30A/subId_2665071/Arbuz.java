package java_6.problem_30A.subId_2665071;

//package arbuz;

import java.util.Scanner;

public class Arbuz {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int result = 10001;
        int a = sc.nextInt();
        int b = sc.nextInt();
        int n = sc.nextInt();
        if (a == 0) {
            if (b == 0) {
                System.out.println(1);
            } else {
                System.out.println("No solution");
            }
        } else {
            if (b == 0) {
                System.out.println(0);
            } else {
                for (int i = -b; i < b; i++) {
                    if (a * Math.pow((double) i, (double) n) == b) {
                        result = i;
                        break;
                    }
                }
                if (result == 10001) {
                    System.out.println("No solution");
                } else {
                    System.out.println(result);
                }
            }
        }
    }
}