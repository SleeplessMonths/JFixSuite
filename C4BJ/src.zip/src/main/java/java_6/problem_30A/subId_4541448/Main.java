package java_6.problem_30A.subId_4541448;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {
    public static void main (String []args){
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String line[];
        double a,b,n;
        try {
            line = br.readLine().split(" ");
            a= Long.parseLong(line[0]);
            b=Long.parseLong(line[1]);
            n= Long.parseLong(line[2]);
            if(a==0 && b==0){
                System.out.println("0");
                return;
            }
            else if (a==0 && b!=0){
                System.out.println("No solution");
                return;
            }
            double res= root(b/a,n);
            
        long reslong=(long)res;
            if(reslong==res )
                System.out.println(reslong);
            else
                System.out.println("No solution");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    public static double root(double num, double root) {
        if (num < 0) {
            return -Math.pow(Math.abs(num), (1 / root));
        }
        return Math.pow(num, 1.0 / root);
    }
}