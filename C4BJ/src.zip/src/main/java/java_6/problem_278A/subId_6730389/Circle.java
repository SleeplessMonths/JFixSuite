package java_6.problem_278A.subId_6730389;

import java.util.Scanner;

public class Circle {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numberStations = scanner.nextInt();
        int[] stationsDistance = new int[numberStations];
        for (int i = 0; i < stationsDistance.length; i++) {
            stationsDistance[i] = scanner.nextInt();
        }
        // from need min to need max
        int from = scanner.nextInt();
        int to = scanner.nextInt();
        
        //sort
        if(from > to){
            int temp = from;
            from = to;
            to = temp;
        }
        
        int resultOfMin = 0;
        int resultOfMax = 0;
        
        for (int i = from - 1; i < to - 1; i++) {
//          System.out.println("MIN: " + i );
            resultOfMin += stationsDistance[i];
        }   
        
        for (int i = from - 1; i >= 1 ; i--) {
//          System.out.println("MAX: " + i );
            resultOfMax += stationsDistance[i];
        }
        
        for (int i = numberStations - 1; i >= to - 1; i--) {
//          System.out.println("MAX: " + i );
            resultOfMax += stationsDistance[i];
        }
        
//      System.out.println("RESULT MIN : " + resultOfMin);
//      System.out.println("RESULT MAX : " + resultOfMax);
        if(resultOfMin < resultOfMax){
            System.out.println(resultOfMin);
        }
        else{
            System.out.println(resultOfMax);
        }
        
    }

}