package java_6.problem_278A.subId_6828127;

import java.util.Scanner;

public class Panoramix {
    public static void main(String[] Args) {
        Scanner scan = new Scanner(System.in);
        int x = scan.nextInt();
        int[] arr = new int[x];
        for (int i = 0; i < x; i++)
            arr[i] = scan.nextInt();
        int a = scan.nextInt() - 1;
        int b = scan.nextInt() - 1;

        int first = 0;
        int second = 0;

        if (a > b) {
            int temp = a;
            a = b;
            b = temp;
        }

        for (int i = a; i < b; i++)
            first += arr[i % x];
        for (int i = b; i < a + x; i++)
            second += arr[i % x];

        if(first<second) System.out.println(first);
        if(second<first) System.out.println(second);
    }
}