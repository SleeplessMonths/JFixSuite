package java_6.problem_171B.subId_3608417;

import java.util.Scanner;


    public class Star {
        Scanner in =new Scanner(System.in);
        public static void main(String args[]){
            new Star().go();
        }
        public void go(){
            int count=1;
            int prev=0;
                int a=in.nextInt();
                for(int i=1;i<= 5*(a-1)+1;i++){
                    int t=count;
                    count=prev+count;
                    prev=t;
                    
                }
                System.out.println(count);
        }

}