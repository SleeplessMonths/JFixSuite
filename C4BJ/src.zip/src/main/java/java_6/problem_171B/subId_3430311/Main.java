package java_6.problem_171B.subId_3430311;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class Main {
	public static void main(String[] args) throws IOException {
		(new Main()).solve();
	}

	public Main() {
	}
	
	MyReader in = new MyReader();
	PrintWriter out = new PrintWriter(System.out);
	
	void solve() throws IOException {
		//BufferedReader in = new BufferedReader(new
		//InputStreamReader(System.in));
		//Scanner in = new Scanner(System.in);

		//Scanner in = new Scanner(new FileReader("forbidden-triples.in"));
		//PrintWriter out = new PrintWriter("forbidden-triples.out");
		int n = in.nextInt();
		int d = 12;
		int res = 1;
		for (int i = 2; i <= n; i++) {
			res += d;
			d *= 2;
		}
		
		out.println(res);
				
		out.close();
	}	
	
	int reverse(int a) {
		int res = 0;
		while (a > 0) {
			res = res * 10 + a % 10;
			a /= 10;
		}
		return res;
	}

};

class MyReader {
	private BufferedReader in;
	String[] parsed;
	int index = 0;

	public MyReader() {
		in = new BufferedReader(new InputStreamReader(System.in));
	}

	public int nextInt() throws NumberFormatException, IOException {
		if (parsed == null || parsed.length == index) {
			read();
		}
		return Integer.parseInt(parsed[index++]);
	}

	public long nextLong() throws NumberFormatException, IOException {
		if (parsed == null || parsed.length == index) {
			read();
		}
		return Long.parseLong(parsed[index++]);
	}
	
	public String nextString() throws IOException {
		if (parsed == null || parsed.length == index) {
			read();
		}
		return parsed[index++];
	}

	private void read() throws IOException {
		parsed = in.readLine().split(" ");
		index = 0;
	}

	public String readLine() throws IOException {
		return in.readLine();
	}
};