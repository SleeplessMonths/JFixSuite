package java_6.problem_171B.subId_3608301;

import java.util.Scanner;


public class Star {
	private static Scanner in = new Scanner(System.in);
	public static void main(String[] args) {
		int a = in.nextInt();
		int ret = 11*a*a - 21*a + 11;
		System.out.println(ret);
	}
}