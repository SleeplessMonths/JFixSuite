package java_6.problem_68A.subId_482013;

import java.util.Scanner;

/**
 *
 * @author epiZend
 */
public class Irrational {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int min = Integer.MAX_VALUE;
        for (int i = 0; i < 4; i++) {
            int n = sc.nextInt();
            if (n < min) {
                min = n;
            }
        }
        int low = sc.nextInt();
        int high = sc.nextInt();
        System.out.println(Math.max(0, Math.min(high, min)-low));
    }
}