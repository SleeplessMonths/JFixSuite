package java_6.problem_68A.subId_472952;

import java.util.Scanner;


public class A {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int minp = 1001;
		for (int i=0;i<4;i++) {
			minp = Math.min(minp, sc.nextInt());
		}
		int low = sc.nextInt();
		int high = sc.nextInt();
		
		if (minp < low)
			System.out.println(0);
		else if (high == 0)
			System.out.println(1);
		else
			System.out.println(Math.min(minp, high) - low);				
	}
}