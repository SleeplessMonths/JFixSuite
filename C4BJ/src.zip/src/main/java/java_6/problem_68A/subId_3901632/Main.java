package java_6.problem_68A.subId_3901632;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class Main {
	public static void main(String[] args) throws IOException {
		(new Main()).solve();
	}

	public Main() {
	}
	
	MyReader in = new MyReader();
	PrintWriter out = new PrintWriter(System.out);
	
	void solve() throws IOException {
		//BufferedReader in = new BufferedReader(new
		//InputStreamReader(System.in));
		//Scanner in = new Scanner(System.in);
		int min = Integer.MAX_VALUE;
		for (int i = 0; i < 4; i++) {
			int t = in.nextInt();
			if (t < min) {
				min = t;
			}
		}
		int a = in.nextInt();
		int b = in.nextInt() - 1;
		if (min < a) {
			min = a;
		}
		b = Math.min(b, min);
		out.println(b - a);
		
		out.close();
		
	}

	
};

class MyReader {
	private BufferedReader in;
	String[] parsed;
	int index = 0;

	public MyReader() {
		in = new BufferedReader(new InputStreamReader(System.in));
	}

	public int nextInt() throws NumberFormatException, IOException {
		if (parsed == null || parsed.length == index) {
			read();
		}
		return Integer.parseInt(parsed[index++]);
	}

	public long nextLong() throws NumberFormatException, IOException {
		if (parsed == null || parsed.length == index) {
			read();
		}
		return Long.parseLong(parsed[index++]);
	}
	
	public double nextDouble() throws NumberFormatException, IOException {
		if (parsed == null || parsed.length == index) {
			read();
		}
		return Double.parseDouble(parsed[index++]);
	}
	
	public String nextString() throws IOException {
		if (parsed == null || parsed.length == index) {
			read();
		}
		return parsed[index++];
	}

	private void read() throws IOException {
		parsed = in.readLine().split(" ");
		index = 0;
	}

	public String readLine() throws IOException {
		return in.readLine();
	}
};