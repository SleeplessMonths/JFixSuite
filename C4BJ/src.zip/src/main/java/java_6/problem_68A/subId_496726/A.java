package java_6.problem_68A.subId_496726;

import java.util.Arrays;
import java.util.Scanner;

public class A {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] array = new int[4];
        array[0]=sc.nextInt();
        array[1]=sc.nextInt();
        array[2]=sc.nextInt();
        array[3]=sc.nextInt();
        int low=sc.nextInt();
        int hi=sc.nextInt();
        //StringBuilder SB = new StringBuilder();
        Arrays.sort(array);
        int k = array[0]-low;
        if(k<0)k=0;
        System.out.print(k);
    }
    

}