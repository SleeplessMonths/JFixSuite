package java_6.problem_68A.subId_351599;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.InputStreamReader;
import java.util.Scanner;

/**
 *
 * @author mina
 */
public class Prob1 {

    
    public static int getMinOf2(int x,int y){
        if(x<y)
            return x;
        else
            return y;
    }
    public static int getMin(int p1, int p2, int p3, int p4){
        return getMinOf2(getMinOf2(p1, p2), getMinOf2(p3, p4));
        
    }
    
    public static int solve (int p1, int p2, int p3, int p4, int a, int b){
        return getMin(p1, p2, p3, p4)-a;
    }
    
    
    /**
     * 
     * @param args 
     */
    public static void main(String [] args){
        
        
        Scanner in = new Scanner(new InputStreamReader(System.in));
        int p1= in.nextInt();
        int p2= in.nextInt();
        int p3= in.nextInt();
        int p4= in.nextInt();
        int a=in.nextInt();
        int b=in.nextInt();
    
        int x=solve(p1, p2, p3, p4, a, b);
        if (x<0)
            System.out.println(0);
        else
            System.out.println(x);
                
    }
    
    
}