package java_6.problem_68A.subId_950832;

import java.util.Scanner;


public class Prob068A
{
    public static void main( String[] Args )
    {
        Scanner scan = new Scanner( System.in );
        int min = scan.nextInt();
        for ( int x = 0; x < 3; x++ )
            min = Math.min( min, scan.nextInt() );

        int start = scan.nextInt();
        min = Math.min( min, scan.nextInt() );

        if ( min < start )
            System.out.println( 0 );
        else
            System.out.println( min - start );
    }
}