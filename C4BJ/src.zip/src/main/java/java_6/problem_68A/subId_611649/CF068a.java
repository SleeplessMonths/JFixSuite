package java_6.problem_68A.subId_611649;

import java.util.Scanner;

public class CF068a {
	
	private void run() {
		Scanner sc = new Scanner(System.in);
		
		sc.close();
	}

	public static void main(String args[]) {
		new CF068a().run();
	}

}