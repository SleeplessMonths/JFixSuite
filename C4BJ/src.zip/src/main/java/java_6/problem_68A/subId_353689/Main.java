package java_6.problem_68A.subId_353689;

import java.util.Scanner;


public class Main {
    public static void main(String[]args){
        
        Scanner sc = new Scanner (System.in);
        int p1 = sc.nextInt();
        int p2 = sc.nextInt();
        int p3 = sc.nextInt();
        int p4 = sc.nextInt();
        int a = sc.nextInt();
        int b = sc.nextInt();
        int count = 0;
        for (int i = a; i<b; i++){
            count = count + f(i, p1, p2, p3, p4);
        }
        System.out.println(count);
        
    }
    
    public static int f(int x, int p1, int p2, int p3, int p4){
        
        if (x == ((((x % p1) % p2) % p3) % p4)){return 1;} else return 0;
    }
}