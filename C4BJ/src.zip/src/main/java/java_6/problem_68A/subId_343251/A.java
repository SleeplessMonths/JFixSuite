package java_6.problem_68A.subId_343251;

//package cf.r62;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import static java.lang.Integer.parseInt;

public class A {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String[] t = br.readLine().split("[ ]+");
		int p = 1000 + 1; for (int i = 0; i < 4; i++) p = Math.min(p, parseInt(t[i]));
		int a = Math.min(parseInt(t[4]), parseInt(t[5]));
		int b = Math.max(parseInt(t[4]), parseInt(t[5]));
		System.out.println(Math.max(0, Math.min(p, b) - a));
	}
}