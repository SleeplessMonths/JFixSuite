package java_6.problem_68A.subId_372516;

import java.util.Arrays;
import java.util.Scanner;

public class A68 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] p = new int[4];
		p[0] = sc.nextInt();
		p[1] = sc.nextInt();
		p[2] = sc.nextInt();
		p[3] = sc.nextInt();
		int a = sc.nextInt();
		int b = sc.nextInt();
		Arrays.sort(p);
		int count = p[0]-a;
		if (count>0) System.out.print(count); else System.out.println(0);
	}

}