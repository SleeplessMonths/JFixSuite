package java_6.problem_68A.subId_498370;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Scanner;

public class A {

	public static void main(String[] args) {
		Scanner sc = new Scanner(new BufferedReader(new InputStreamReader(
				System.in)));
		int[] p = new int[4];
		for (int i = 0; i < 4; i++) {
			p[i] = sc.nextInt();
		}
		Arrays.sort(p);
		int a = sc.nextInt();
		int b = sc.nextInt();
		if (a >= p[0])
			System.out.println(0);
		else {
			if (b > p[0])
				b = p[0];
			System.out.println(b - a);
		}
	}

}