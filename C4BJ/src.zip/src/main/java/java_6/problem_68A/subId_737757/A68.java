package java_6.problem_68A.subId_737757;

import java.util.Scanner;
public class A68 {
	
	public static void main(String args[]){
		Scanner in  = new Scanner(System.in);
		int min = Integer.MAX_VALUE;
		for(int i =1;i<=4;i++) min=Math.min(min,in.nextInt());
		int a=in.nextInt();
		int b=in.nextInt();
		int ans = Math.min(min-a,b-a);
		if (ans<0) ans=0;
		System.out.println(ans);
	}

}