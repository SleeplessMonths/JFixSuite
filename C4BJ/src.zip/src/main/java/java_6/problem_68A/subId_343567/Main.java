package java_6.problem_68A.subId_343567;

import java.io.*;
import java.util.Scanner;

public class Main{
  public static void main(String[] argv) throws IOException{
    new Main().run();
  }
  PrintWriter pw;
  Scanner sc;
  public void run() throws IOException{
    boolean oj = true;//System.getProperty("ONLINE_JUDGE") != null;
    Reader reader = oj ? new InputStreamReader(System.in) : new FileReader("input.txt");
    Writer writer = oj ? new OutputStreamWriter(System.out) : new FileWriter("output.txt");
    sc = new Scanner(reader);
    pw = new PrintWriter(writer);

    int min = 1001;
    for(int i=0;i<4;i++){
	min = Math.min(min,sc.nextInt());
}
	int a = sc.nextInt();
    min = Math.min(min,sc.nextInt());
pw.println(Math.max(0,min-a));
    pw.close();
  }
  
}