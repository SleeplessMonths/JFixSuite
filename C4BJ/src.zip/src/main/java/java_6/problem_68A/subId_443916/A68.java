package java_6.problem_68A.subId_443916;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class A68 {
	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		PrintWriter pw = new PrintWriter(System.out);
int p1=sc.nextInt();
int p2=sc.nextInt();
int p3=sc.nextInt();
int p4=sc.nextInt();
int a=sc.nextInt();
int b=sc.nextInt();
int i=0;
int TT=0;
for(i=a;i<b;i++){
	if(i==((((i % p1)%p2)%p3)% p4)){
		TT=TT+1;
	}
}
pw.print(TT);
pw.close();
sc.close();
	}
}