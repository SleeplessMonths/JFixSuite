package java_6.problem_68A.subId_705770;

import java.util.Scanner;
public class irrational {
public static void main(String[] args)
{
    Scanner input = new Scanner(System.in);
    int m1 = input.nextInt();
    int m2 = input.nextInt();
    int m3 = input.nextInt();
    int m4 = input.nextInt();
    int[] mods = {m1, m2, m3, m4};
    int min = 2000000000;
    for(int i: mods)
        if(i < min)
            min = i;
    int a = input.nextInt();
    int b = input.nextInt();
    int difference = min - a;
    if(difference < 0)
        difference = 0;
    System.out.println(difference);
}
}