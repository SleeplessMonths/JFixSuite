package java_6.problem_68A.subId_792040;

import java.util.Scanner;

public class Temp {
    public static void main(String args[]){
        Scanner in = new Scanner(System.in);
        int min=in.nextInt();
        for (int i=0;i<3;++i){
            int x=in.nextInt();
            if (x<min)
                min=x;
        }
        int a = in.nextInt();
        min-=a;
        if (min<0) min=0;
        System.out.print(min);
    }
}