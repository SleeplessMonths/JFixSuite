package java_6.problem_68A.subId_343983;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.Arrays;

public class Cf68A {
     public static void main( String[ ] args ) throws Throwable {
         BufferedReader bIn = new BufferedReader( new InputStreamReader( System.in ) );
         PrintStream out = new PrintStream( System.out );

         String sp[ ] = bIn.readLine( ).split( " " );
         int a[ ] = new int[ 4 ];
         a[ 0 ] = Integer.parseInt( sp[ 0 ] );
         a[ 1 ] = Integer.parseInt( sp[ 1 ] );
         a[ 2 ] = Integer.parseInt( sp[ 2 ] );
         a[ 3 ] = Integer.parseInt( sp[ 3 ] );
          
         int start = Integer.parseInt( sp[ 4 ] );
         int end = Integer.parseInt( sp[ 5 ] );
         

         int count = 0;
         /*
         for ( int i = start; i <= end; ++i ) {
             boolean ok = true; 
             for ( int j = 0; j < a.length; ++j ) {
                  if ( i >= a[ j ] ) {
                      ok = false;
                      break;
                  }
             }

             if ( ok ) ++count;
             
         }
         */
         Arrays.sort( a );
         if ( a[ 0 ] > start ) {
              out.println( a[ 0 ] - start );
         } else {
             out.println( 0 );
         }

         //out.println( count );
         
     }
}