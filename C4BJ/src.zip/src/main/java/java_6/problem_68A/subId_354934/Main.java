package java_6.problem_68A.subId_354934;

import java.util.Random;
import java.util.Scanner;

public class Main {
static int as[];
static Random r;
    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        int a1=in.nextInt();
        int a2=in.nextInt();
        int a3=in.nextInt();
        int a4=in.nextInt();
        int x=in.nextInt();
        int y=in.nextInt();
        int ans=0;
        for(int i=x;i<=y;i++){
            ans+=i%a1%a2%a3%a4;
        }
        System.out.print(ans);

    }
}