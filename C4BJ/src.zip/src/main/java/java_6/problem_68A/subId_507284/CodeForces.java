package java_6.problem_68A.subId_507284;

/**
 * Created by IntelliJ IDEA.
 * User: shakhov
 * Date: 15.06.2011
 * Time: 15:22:46
 * To change this template use File | Settings | File Templates.
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Locale;

public class CodeForces {

    public void solve() throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String[] arr = in.readLine().split(" ");
        int min=1001;
        for(int i=0;i<4;i++){
            int val=Integer.parseInt(arr[i]);
            if(val<min) min=val;
        }
        int a =Integer.parseInt(arr[4]);
        int b =Integer.parseInt(arr[5]);
        int res=(min>a)? min-a : 0;
        if(res>b-a) res=b-a;


        System.out.println(res);
    }


    public void run() {
        try {
            solve();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] arg) {
        Locale.setDefault(Locale.US);
        new CodeForces().run();
    }
}