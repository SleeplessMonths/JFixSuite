package java_6.problem_68C.subId_360714;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Main {
    static int n;
    static int[][] A;
    static int[][] L;
    static int[][] H;
    static int best = -1;
    static int Sum[];

    public static void get2(int start, int end, int sum, int cost) {
        if (end == n) {
            if (sum != 0)
                return;
            get(start + 1, cost);
            return;
        }
        for (int i = L[start][end]; i <= H[start][end] && i <= sum; i++) {
            Sum[end] += i;
            int add = 0;
            if (i != 0)
                add += A[start][end] + i * i;
            get2(start, end + 1, sum - i, cost + add);
            Sum[end] -= i;
        }
    }

    public static void get(int index, int cost) {
        if (index == (n - 1)) {
            best = Math.max(best, cost);
            return;
        }
        get2(index, index + 1, Sum[index], cost);
    }

    public static void main(String[] args) throws NumberFormatException,
            IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        n = Integer.parseInt(in.readLine());
        L = new int[n][n];
        H = new int[n][n];
        A = new int[n][n];
        Sum = new int[n];
        for (int i = 0; i < n; i++)
            Arrays.fill(L[i], Integer.MAX_VALUE);
        while (true) {
            String s = in.readLine();
            if (s == null || s.length() == 0)
                break;
            String[] S = s.split(" ");
            int x = Integer.parseInt(S[0]) - 1;
            int y = Integer.parseInt(S[1]) - 1;
            L[x][y] = Integer.parseInt(S[2]);
            H[x][y] = Integer.parseInt(S[3]);
            A[x][y] = Integer.parseInt(S[4]);
        }
        for (int i = 2; i <= 2; i++) {
            Sum[0] = i;
            get(0, 0);
            if (best != -1) {
                System.out.println(i + " " + best);
                break;
            }
        }
        if (best == -1)
            System.out.println("-1 -1");
    }

}