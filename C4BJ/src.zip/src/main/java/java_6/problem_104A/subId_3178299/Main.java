package java_6.problem_104A.subId_3178299;

import java.util.Scanner;
public class Main {

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Scanner scan = new Scanner(System.in);
        int n1 = Integer.parseInt(scan.next());
        n1-=12;
        if (n1>0){
            if (n1<=9){
                System.out.println(4);
            }
            else if (n1==10){
                System.out.println(15);
            }
            else if (n1==11){
                System.out.println(4);
            }
            else {
                System.out.println(0);
            }
            
        }
        else {
            System.out.println(0);
        }
    }

}