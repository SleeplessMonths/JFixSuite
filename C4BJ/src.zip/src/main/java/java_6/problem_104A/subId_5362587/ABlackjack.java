package java_6.problem_104A.subId_5362587;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ABlackjack {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int x = Integer.parseInt(reader.readLine());
        x -= 10;
        if (x <= 0 || x > 11) {
            System.out.println(0);
            return;
        }
        if (x == 1) {
            System.out.println(8);
        } else if (x < 10) {
            System.out.println(4);
        } else if (x == 10) {
            System.out.println(15);
            return;
        } else if (x == 11) {
            System.out.println(4);
        }
    }

}