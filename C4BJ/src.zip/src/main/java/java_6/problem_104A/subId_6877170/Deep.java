package java_6.problem_104A.subId_6877170;

import java.util.Scanner;
public class Deep {
public static void main(String[]args){
    Scanner s=new Scanner(System.in);
    
    int n=s.nextInt();
    if(n<=10)
        System.out.printf("0");
    else if(n==20)
        System.out.printf("15");
    else
        System.out.printf("4");
        
}
}