package java_6.problem_104A.subId_3471545;

import java.util.Scanner;


public class A_104 {
	
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		
		final int n = sc.nextInt();
		
		final int next = n - 10;
		
		if(next <= 0 || next > 10){
			System.out.println(-1);
		}else{
			System.out.println(next == 10 ? 15 : 4);	
		}
		sc.close();
	}

}