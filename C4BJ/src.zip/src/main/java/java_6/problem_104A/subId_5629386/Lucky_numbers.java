package java_6.problem_104A.subId_5629386;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lucky_numbers {

  
    public static void main(String[] args) throws IOException {
 BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
 int n= Integer.parseInt(br.readLine());
 int [] ar = new int[55];
 
 ar[0]=1; 
 ar[1]=1;
 ar[2]=1;
 ar[3]=1;
 ar[4]=2;
 ar[5]=2;
 ar[6]=2;
 ar[7]=2;
 ar[8]=3;ar[9]=3 ;ar[10]=3;ar[11]=3;ar[12]=4;ar[13]=4;ar[14]=4;ar[15]=4;
 ar[16]=5;ar[17]=5;ar[18]=5;ar[19]=5;ar[20]=6;ar[21]=6;
 ar[22]=6; ar[23]=6;ar[24]=7;ar[25]=7;ar[26]=7;ar[27]=7;
 ar[28]=8; ar[29]=8;ar[30]=8;ar[31]=8;ar[32]=9;ar[33]=9;ar[34]=9;ar[35]=9;
 ar[36]=10;ar[37]=10;ar[38]=10;ar[39]=10;ar[40]=10;ar[41]=10;ar[42]=10;ar[43]=10;ar[44]=10;
 ar[45]=10;ar[46]=10;ar[47]=10;
 ar[48]=10;ar[49]=10;ar[50]=10;ar[51]=11;ar[52]=11;ar[53]=11;ar[54]=11;
 int count=0;
        for (int i=0; i<ar.length-1;i++)
        {
            if (10+ar[i]==n)
                count++;
        }     
        System.out.println(count);
    }
}