package java_6.problem_104A.subId_4735806;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
	static BufferedReader reader = new BufferedReader(new InputStreamReader(
			System.in));

	public static int toInt(String str) {
		return Integer.parseInt(str);
	}

	public static String toString(int x) {
		return String.valueOf(x);
	}

	public static boolean isVowel(char ch) {
		return ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u';
	}

	public static void main(String[] args) throws IOException {
		int n = toInt(reader.readLine());

		if (n < 11) {
			System.out.println(0);
			return;
		}

		if (n < 20 || n == 21) {
			System.out.println(4);
			return;
		}

		System.out.println(4 + 4 + 3 + 4);
	}
}