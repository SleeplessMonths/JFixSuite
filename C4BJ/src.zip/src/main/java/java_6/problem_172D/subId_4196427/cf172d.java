package java_6.problem_172D.subId_4196427;

import java.util.Scanner;
public class cf172d {
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    int a = in.nextInt();
    int n = in.nextInt();
    int[] best = new int[a+n];
    for(int i=1; i*i<a+n; i++)
      for(int j=i*i; j<a+n; j+=i*i)
        best[j]=i*i;
    int ans = 0;
    for(int i=a; i<a+n; i++)
      ans += i/best[i];
    System.out.println(ans);
  }
}