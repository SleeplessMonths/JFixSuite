package java_6.problem_45I.subId_9051458;

import java.util.Scanner;
public class maximus {
    public static void main(String [] args){
    	Scanner in=new Scanner(System.in);
    	int n=in.nextInt();
    	int array[]=new int[n];
    	int min=Integer.MIN_VALUE;
    	int neg=0;int zero=0;
    	for(int i=0;i<n;i++){
    	array[i]=in.nextInt();
    	if(array[i]<0)neg++;
    	if(array[i]==0)zero++;
    	if(array[i]<0)
    	min=Math.max(array[i],min);
    	}
    	boolean flag=true;
    	StringBuilder sb=new StringBuilder();
    	for(int i=0;i<n;i++){
    	  if(neg%2==1 && array[i]==min && flag|| array[i]==0){
    	  	flag=false;
    	  	continue;	
    	  }
    		sb.append(array[i]+" ");
    	}
    	if(n==1 && array[0]<0)sb.append(array[0]);
    	else if(neg==1 && zero+neg==n || zero==n)sb.append(0);
    	System.out.print(sb);
    }
}