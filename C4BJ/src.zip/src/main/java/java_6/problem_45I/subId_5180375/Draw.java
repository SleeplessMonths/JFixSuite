package java_6.problem_45I.subId_5180375;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Draw
{

    public static void main (String[] args) throws java.lang.Exception
    {
        Scanner scanner = new Scanner(System.in);
        int nb = scanner.nextInt();
        List<Integer> nbs = new ArrayList<Integer>();
        String s = "";
        for(int i = 0 ; i < nb ; i++) {
            nbs.add(scanner.nextInt());
        }
        Collections.sort(nbs);
        if(nbs.size() == 2 && nbs.get(nbs.size()-1) == 0) {
            s = "0";
        } else {
        for(int i = nbs.size()-1 ; i >= 0 ; i-- ) {
            Integer a = nbs.get(i);
            if(a < 0) 
                break;
            else if (a > 0) {
                nbs.remove(a);
                s+=a+" ";
            } else {
                nbs.remove(a);
            }
        }
        if(nbs.size()>1) {
            int l = nbs.size()-1;
            int z = (l%2==0?1:0);
            for(int i = l ; i >= z ; i--) {
                s+=nbs.get(i)+" ";
            }
        }
        if(nbs.size()== 0 && s.equals("")) {
            s = "0";
        } else if(s.equals("")) {
            s = nbs.get(0)+"";
        }
        }
        System.out.println(s);
    }
}