package java_6.problem_45I.subId_2107837;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;


public class I {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        if (n==1) {
            System.out.println(sc.nextInt());
            return;
        }
        int[]a = new int[n];
        ArrayList<Integer> ans = new ArrayList<Integer>();
        int t = 0;
        for (int i = 0; i < n; i++) {
            int k = sc.nextInt();
            if (k > 0)
                ans.add(k);
            else if (k < 0)
                a[t++] = k;
        }
        Arrays.sort(a, 0, t);
        if (t % 2==0) {
            for (int i = 0; i < t; i++) {
                ans.add(a[i]);
            }
        }
        else {
            for (int i = t-1; i >= 1; i--) {
                ans.add(a[i]);
            }
        }
        if (ans.isEmpty())
            System.out.println(0);
        else
            for (int i : ans) {
                System.out.print(i+" ");
            }
    }
}