package java_6.problem_46A.subId_4824737;

import java.util.Scanner;

public class BallGame {
	
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);  
		 
	    int n  = sc.nextInt();
	    int thrown = 0;
	    int person = 1;
	    
	    while(thrown<n-2)
	    {   
	    	person = (person + (thrown+1)) % n;
	    	System.out.print(person+" ");
	    	
	    	thrown++;
	    }
	    
	    System.out.print(person);
		
	}

}