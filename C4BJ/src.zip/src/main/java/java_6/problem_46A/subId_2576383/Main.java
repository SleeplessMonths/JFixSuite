package java_6.problem_46A.subId_2576383;

import java.util.Scanner;

public class Main {

	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int in=1;
		int aumento=1;
		for(int i=0;i<n-1;i++){
			if(in+aumento>=n){
				in=(in+aumento)%n;
			}else{
				in=aumento+in;
			}
			System.out.println(in);
			aumento++;
		}
		
	}

}