package java_6.problem_46A.subId_4824743;

import java.util.Scanner;

public class BallGame {
    
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);  
         
        int n  = sc.nextInt();
        int thrown = 0;
        int person = 1;
        
        while(thrown<n-1)
        {   
            person = (person + (thrown+1)) % n;
            
            if(thrown<n-2)
            System.out.print(person+" ");
            
            thrown++;
        }
        
        System.out.print(person);
        
    }

}