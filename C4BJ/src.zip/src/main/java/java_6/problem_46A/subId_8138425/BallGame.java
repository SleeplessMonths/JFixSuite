package java_6.problem_46A.subId_8138425;

import java.util.Scanner;
public class BallGame 
{
    public static void main(String args[])
    {
        Scanner input=new Scanner(System.in);
        int n=input.nextInt();
        int count=1;
        int kidBall=1;
        
        for (int i=1;i<=n-1;i++)
        {
            kidBall=(kidBall+count)%n;
            count++;
            System.out.printf("%d %s",kidBall," ");
        }//end for
    }//end main

}//end class