package java_6.problem_46A.subId_1965609;

import java.util.Scanner;

public class A43 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = 1;
        int x = 1;
        String s = "";
        for (int i = 0; i < n - 1; i++) {
            x += (m++);
            x %= n;
            if (x == 0)
                x++;
            s += " " + x;
        }
        System.out.println(s.substring(1));
    }

}