package java_6.problem_46A.subId_7680389;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader (new InputStreamReader (System.in));
        int n = Integer.parseInt(br.readLine());
        int x=1;
        for (int i = 1; i < n; i++) {
            x+=i;
            if(i<n-1)
            System.out.print((x%n)+" ");
            else
             System.out.print((x%n));   
            
            
        }
    }
    
}