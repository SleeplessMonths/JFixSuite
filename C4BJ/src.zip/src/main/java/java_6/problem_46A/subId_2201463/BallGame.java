package java_6.problem_46A.subId_2201463;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BallGame{
    public static void main(String args[])throws IOException{
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(in.readLine());
        int x = 1;
        int arr[] = new int[n];
        for(int i=1;i<n;i++){
            x=(x+i)%n;
            arr[i-1]=x;
        }
        for(int i=0;i<n-2;i++)
            System.out.print(arr[i]+" ");
        System.out.println(arr[n-2]);
    }
}