package java_6.problem_36A.subId_565825;

import java.io.*;

public class A {
    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new FileReader("input.txt"));
        PrintWriter out = new PrintWriter(new File("output.txt"));
        in.readLine();
        String s = in.readLine();
        String[] S = s.split("1");
        for (int i = 2; i < S.length - 1; i++) {
            if (!S[i].equals(S[i - 1])) {
                out.println("NO");
                out.flush();
                return;
            }
        }
        out.println("YES");
        out.flush();
    }
}