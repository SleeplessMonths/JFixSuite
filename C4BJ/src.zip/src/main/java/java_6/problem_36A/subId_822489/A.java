package java_6.problem_36A.subId_822489;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;
public class A {
	public static void main(String[] args) throws IOException {
		Scanner s = new Scanner(new File("input.txt"));
		PrintStream out = new PrintStream(new File("output.txt"));
		int n = s.nextInt();
		String st = s.next();
		int diff = -1, last = -1;
		for (int i = 0; i < n; i++) {
			if (st.charAt(i)=='1') {
				if (last != -1) {
					int d = i - last;
					if (diff != -1 && diff != d) {
						System.out.println("NO");
						return;
					}
					diff = d;
				}
				last = i;
			}
		}
		out.println("YES");
	}
}