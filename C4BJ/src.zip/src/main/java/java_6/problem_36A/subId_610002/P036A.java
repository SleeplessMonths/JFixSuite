package java_6.problem_36A.subId_610002;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class P036A {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner inScanner = new Scanner(new File("input.txt"));
        PrintWriter writer = new PrintWriter("output.txt");
        inScanner.nextInt();
        String line = inScanner.next();
        int start = line.indexOf('1');
        int second = line.indexOf('1', start + 1);
        int step = second - start;
        int last = line.lastIndexOf('1');
        for (int i = start; i <= last; i++) {
            if (line.charAt(i) == '1' ^ (i - start) % step != 0) {
                writer.println("NO");
                writer.close();
                return;
            }
        }
        writer.println("YES");
        writer.close();
    }
}