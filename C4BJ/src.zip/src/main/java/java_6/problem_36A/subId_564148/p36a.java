package java_6.problem_36A.subId_564148;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;


public class p36a {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner in  = new Scanner(new File("input.txt"));
        PrintWriter out = new PrintWriter(new File("output.txt"));
        //Scanner in  = new Scanner(System.in);
        int n = in.nextInt();
        char[] x = in.next().toCharArray();
        int start = 0;
        for (int i = 0; i < x.length; i++) {
            if(x[i] == '1') {
                start = i;
                break;
            }
        }
        int diff = -1;
        int i;
        for (i = start+1; i < x.length; i++) {
            if(x[i] == '1') {
                diff = i-start;
                break;
            }
        }
        int prev = i;
        i++;
        for (;  i< x.length; i++) {
            if(x[i] == '1') {
                if(i-prev == diff)
                {
                    prev = i;
                    continue;
                } else {
                    out.println("NO");
                    return;
                }
            }
        }
        out.println("YES");
        out.flush();
    }
}