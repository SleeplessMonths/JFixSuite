package java_6.problem_36A.subId_565814;

import java.io.*;

public class A {
    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new FileReader("input.txt"));
        PrintWriter out = new PrintWriter(new File("output.txt"));
        in.readLine();
        String s = in.readLine().replace("0", " ").trim();
        s = s.replace(" ", ",");
        while (s.contains("11"))
            s = s.replace("11", "1");
        s = s.replace("1", " ").trim();
        String[] S = s.split(" ");
        for (int i = 1; i < S.length; i++) {
            if (!S[i].equals(S[i - 1])) {
                out.println("NO");
                out.flush();
                return;
            }
        }
        out.println("YES");
        out.flush();
    }
}