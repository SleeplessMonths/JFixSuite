package java_6.problem_36A.subId_2712802;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    public static void main(String[] args) throws IOException {
//      Scanner sc = new Scanner(System.in);
//      int n = sc.nextInt();
//      String ss = sc.nextLine();

        BufferedReader br =  new BufferedReader(new InputStreamReader(System.in));
    //  int n = Integer.parseInt(br.readLine());
    //  String ss = br.readLine();
        
//      
//      ss = ss.substring(ss.indexOf("1"), ss.lastIndexOf("1") + 1);
//
//      int sum = -1;
//      for (int i = 0; i < ss.length(); ++i) {
//          int sum1 = 0;
//
//          if (ss.charAt(i) == '0') {
//
//              for (int j = i; j < ss.length(); ++j) {
//                  if (ss.charAt(j) == '0') {
//                      sum1++;
//                  } else
//                      break;
//              }
//
//              if (sum == -1)
//                  sum = sum1;
//              else if (sum != sum1) {
//                  System.out.println("NO");
//                  return;
//              }
//          }
//      }
        System.out.println("YES");
    }
}