package java_6.problem_36A.subId_524615;

import java.io.*;

public class Main {
//  private static StreamTokenizer in;
    private static PrintWriter out;
    private static BufferedReader inB;
    
//  private static int nextInt() throws Exception{
//      in.nextToken();
//      return (int)in.nval;
//  }
//  
//  private static String nextString() throws Exception{
//      in.nextToken();
//      return in.sval;
//  }
    
    static{
//      in = new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
//      inB = (new BufferedReader(new InputStreamReader(System.in)));
//      out = new PrintWriter(System.out);
        try {
            inB = (new BufferedReader(new InputStreamReader(new FileInputStream("input.txt"))));
            out = new PrintWriter(new FileOutputStream("output.txt"));
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    private static int gcd(int a, int b) {
        if(a == 0)return b;
        return gcd(b%a, a);
    }
    
    public static void main(String[] args)throws Exception{
        int n = Integer.parseInt(inB.readLine());
        char[] c = inB.readLine().toCharArray();
        
        int i=0;
        for(;c[i] == '0';i++);
        
        int first = -1;
        int last = i;
        ++i;
        for(;i<c.length;++i) {
            if(c[i] == '0')continue;
            if(first == -1) {
                first = i - last;
                last = i;
                continue;
            }
            if(i-last != first) {
                System.out.println("NO");
                return;
            }
            last = i;
        }
        
        out.println("YES");
        out.flush();
    }
}