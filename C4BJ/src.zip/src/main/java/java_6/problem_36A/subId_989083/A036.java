package java_6.problem_36A.subId_989083;

import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class A036 {
	public static void main(String[] args) throws Exception {
		Scanner in = new Scanner(new File("input.txt"));
		int prev = -1,diff = -1;
		in.next();
		String line = in.next();
		for(int x = 0;x<line.length();x++) {
			if(line.charAt(x)=='1') {
				if(prev==-1) {
					prev = x;
				}
				else if(diff==-1) {
					diff = x-prev;
				}
				else {
					if(diff!=x-prev) {
						System.out.println("NO");
						return;
					}
				}
				prev = x;
			}
		}
		PrintWriter out = new PrintWriter("output.txt");
	out.println("YES");
		out.close();
	}
}