package java_6.problem_250A.subId_3966739;

import java.util.ArrayList;
import java.util.Scanner;

public class A250 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        ArrayList<Integer> sizes = new ArrayList<Integer>();
        int neg = 0;
        int pos = 0;
        for (int i = 0; i < n; i++) {
            int a = in.nextInt();
            if (a < 0)
                ++neg;
            else
                ++pos;
            if (neg > 2) {
                sizes.add((neg - 1 + pos));
                pos = 0;
                neg = 1;
            }
        }
        if (pos > 0)
            sizes.add(neg + pos);
        System.out.println(sizes.size());
        for (int s : sizes) {
            System.out.print(s + " ");
        }
        System.out.println();
    }
}