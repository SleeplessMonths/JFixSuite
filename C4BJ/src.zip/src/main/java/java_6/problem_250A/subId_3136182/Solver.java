package java_6.problem_250A.subId_3136182;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

/**
 *
 * @author Artem_Mikhalevitch
 */
public class Solver extends ASolver {

    int n;
    int[] a;
    int negativeCount = 0;

    public static void main(String[] args) {
        Solver s = new Solver();
        s.init();
        if (s.readData()) {
            //s.writeData(s.solve());
            s.solve();
        }
    }

    @Override
    public void init() {
        super.init();
    }

    @Override
    public boolean readData() {
        try {
            n = nextInt();
            a = new int[n];
            for (int i = 0; i < n; i++) {
                a[i] = nextInt();
                if (a[i] < 0) {
                    negativeCount++;
                }
            }

        } catch (IOException ex) {
            System.out.println(ex.getCause());
            System.out.println(ex.getMessage());
            return false;
        }
        return true;
    }

    public void solve() {
        String result = "";
        if (negativeCount % 2 == 1) {
            negativeCount++;
        }
        this.writeData(negativeCount / 2);
        int last = 0;
        int k = 0;
        int negative = 0;
        for (int i = 0; i < n; i++) {
            if (a[i] >= 0) {
                k++;
            } else if (negative == 2) {
                result += k + " ";
                negative = 0;
                k = 0;
                i--;
                last = i;
            } else {
                negative++;
                k++;
            }
        }
        if (k == n) {
            result += k;
        } else if (last != n - 1) {
            result += (n - 1 - last);
        }
        this.writeData(result.trim());
        //return result;

    }
}

abstract class ASolver {

    protected StringTokenizer tokens;
    protected BufferedReader input;
    protected PrintWriter output;

    public void init() {
        input = new BufferedReader(new InputStreamReader(System.in));
    }

    public abstract boolean readData();

    public void writeData(String result) {
        System.out.println(result);
    }

    public void writeData(int result) {
        System.out.println(result);
    }

    public void writeData(long result) {
        System.out.println(result);
    }

    public void writeData(double result) {
        System.out.println(result);
    }

    public int nextInt() throws IOException {
        return Integer.parseInt(next());
    }

    public double nextDouble() throws IOException {
        return Double.parseDouble(next());
    }

    public long nextLong() throws IOException {
        return Long.parseLong(next());
    }

    public String next() throws IOException {
        while (tokens == null || !tokens.hasMoreTokens()) {
            tokens = new StringTokenizer(input.readLine());
        }
        return tokens.nextToken();
    }

    public long infinityImitator(long a, long b) {
        if (a == Long.MIN_VALUE) {
            return Long.MIN_VALUE;
        } else {
            return a + b;
        }
    }

    public int infinityImitator(int a, int b) {
        if (a == Integer.MIN_VALUE) {
            return Integer.MIN_VALUE;
        } else {
            return a + b;
        }
    }

    public long max(long... a) {
        long result = Long.MIN_VALUE;
        for (int i = 0; i < a.length; i++) {
            result = Math.max(result, a[i]);
        }
        return result;
    }

    public int max(int... a) {
        int result = Integer.MIN_VALUE;
        for (int i = 0; i < a.length; i++) {
            result = Math.max(result, a[i]);
        }
        return result;
    }
}