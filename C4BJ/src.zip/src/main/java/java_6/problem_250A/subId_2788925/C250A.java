package java_6.problem_250A.subId_2788925;

import java.io.BufferedInputStream;
import java.util.Arrays;

public class C250A {

	public void solve() throws Exception {
		int n = nextInt();
		int[] arr = new int[n];
		int count = 0;
		for (int i = 0; i < n; i++) {
			arr[i] = nextInt();
			if (arr[i] < 0) {
				count++;
			}
		}
		println(count / 3 + 1);
		int akt = 0;
		int last = 0;
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] < 0) {
				akt++;
				if (akt == 3) {
					print(i - last + " ");
					sum += i - last;
					last = i;
					akt = 1;
				}
			}
			
		}
		if (sum < n) {
			print(n - sum);
		}
	}

	// ------------------------------------------------------

	void debug(Object... os) {
		System.err.println(Arrays.deepToString(os));
	}

	void print(Object... os) {
		if (os != null && os.length > 0)
			System.out.print(os[0].toString());
		for (int i = 1; i < os.length; ++i)
			System.out.print(" " + os[i].toString());
	}

	void println(Object... os) {
		print(os);
		System.out.println();
	}

	BufferedInputStream bis = new BufferedInputStream(System.in);

	String nextWord() throws Exception {
		char c = (char) bis.read();
		while (c <= ' ')
			c = (char) bis.read();
		StringBuilder sb = new StringBuilder();
		while (c > ' ') {
			sb.append(c);
			c = (char) bis.read();
		}
		return new String(sb);
	}

	String nextLine() throws Exception {
		char c = (char) bis.read();
		while (c <= ' ')
			c = (char) bis.read();
		StringBuilder sb = new StringBuilder();
		while (c != '\n' && c != '\r') {
			sb.append(c);
			c = (char) bis.read();
		}
		return new String(sb);
	}

	int nextInt() throws Exception {
		return Integer.parseInt(nextWord());
	}

	long nextLong() throws Exception {
		return Long.parseLong(nextWord());
	}
	
	public static void main(String[] args) throws Exception {
		new C250A().solve();
	}
}