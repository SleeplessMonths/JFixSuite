package java_6.problem_250A.subId_3130966;

import java.util.ArrayDeque;
import java.util.Scanner;


public class A {
	public static void main(String[] args) {
		new A();
	}
	A() {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		ArrayDeque<Integer> q = new ArrayDeque<Integer>();
		int cnt = 0, size = 0;
		for (int i = 0; i < n; i++) {
			int a = sc.nextInt();
			if (a < 0)
				cnt++;
			if (cnt < 3) {
				size++;
			}
			else {
				q.add(size);
				size = (cnt = 0) + 1;
			}
		}
		System.out.println(q.size());
		for (Integer i: q)
			System.out.print(i + " ");
	}
}