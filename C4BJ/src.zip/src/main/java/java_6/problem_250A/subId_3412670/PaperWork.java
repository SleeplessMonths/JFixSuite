package java_6.problem_250A.subId_3412670;

import java.io.*;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class PaperWork {
    
    public static void main( String[] args ) throws IOException {
        
        BufferedReader in = new BufferedReader( new InputStreamReader( System.in ) );
        PrintWriter out = new PrintWriter( new BufferedWriter( new OutputStreamWriter( System.out ) ) );
        
        int n = Integer.parseInt( in.readLine() );
        StringTokenizer tokens = new StringTokenizer( in.readLine() );
        int[] a = new int[ n ];
        
        for( int i = 0; i < n; i++ ) {
            a[ i ] = Integer.parseInt( tokens.nextToken() );
        }
        
        int counter = 0;
        
        for( int i = 0; i < n; i++ ) {
            
            if( a[ i ] < 0 )
                counter++;
            
        }
        
        int folders = ( int )Math.ceil( counter / 2.0 );
        
        int folderCount = 0;
        int negCounter = 0;
        ArrayList<Integer> sizes = new ArrayList<Integer>();
        
        for( int i = 0; i < n; i++ ) {
            
            if( a[ i ] < 0 )
                negCounter++;
            
            if( negCounter > 2 ) {
                sizes.add( folderCount );
                folderCount = 0;
                negCounter = 1;
            }
            
            folderCount++;
            
        }
        
        sizes.add( folderCount );
        
        out.println( folders );
        
        for( int i = 0; i < sizes.size(); i++ ) {
            
            if( i != sizes.size() - 1 )
                out.print( sizes.get( i ) + " " );
            else
                out.print( sizes.get( i ) );
            
        }
        out.println();
        out.flush();
        out.close();
    }
}