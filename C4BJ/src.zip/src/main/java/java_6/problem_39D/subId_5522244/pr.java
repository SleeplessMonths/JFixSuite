package java_6.problem_39D.subId_5522244;

import java.util.Scanner;
public class pr {
    public static void main(String [] args)
    {
    Scanner sc=new Scanner(System.in);
    double x1,x2,y1,y2,z1,z2;
    x1=sc.nextDouble();
    y1=sc.nextDouble();
    z1=sc.nextDouble();
    x2=sc.nextDouble();
    y2=sc.nextDouble();
    z2=sc.nextDouble();
    double a=x1-x2;
    double b=y1-y2;
    double c=z1-z2;
    double ans=Math.sqrt(a*a+b*b+c*c);
    if(ans>1)System.out.print("NO");
    else System.out.print("YES");
    
    }
    
}