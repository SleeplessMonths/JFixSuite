package java_6.problem_65A.subId_2004663;

import java.util.Scanner;

public class A {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        int d = sc.nextInt();
        int e = sc.nextInt();
        int f = sc.nextInt();
        if (b == 0 || d == 0 || f == 0)
            System.out.println("Hermione");
        else {
            if (a == 0 || b == 0 || c == 0)
                System.out.println("Ron");
            else {
                double x = (double) b / (double) a;
                double y = (double) d / (double) c;
                double z = (double) f / (double) e;
                if (x * y * z > 1.0d)
                    System.out.println("Ron");
                else
                    System.out.println("Hermione");
            }
        }
    }
}