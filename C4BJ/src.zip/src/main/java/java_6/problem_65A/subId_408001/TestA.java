package java_6.problem_65A.subId_408001;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;


public class TestA {

	public void run()throws Exception{

		BufferedReader br = null;
		File file = new File("input.txt");
		if(file.exists()){
			br = new BufferedReader(new FileReader("input.txt"));
		}
		else{
			br = new BufferedReader(new InputStreamReader(System.in));
		}
		
		String line = br.readLine();
		String[] lines = line.split(" ");
		double a = Integer.parseInt(lines[0]);
		double b = Integer.parseInt(lines[1]);
		double c = Integer.parseInt(lines[2]);
		double d = Integer.parseInt(lines[3]);
		double e = Integer.parseInt(lines[4]);
		double f = Integer.parseInt(lines[5]);
		if(c == 0 && d > 0){
			System.out.println("Ron");
			return ;
		}
		if(b == 0 || d == 0 || f == 0){
			System.out.println("Hermione");
			return ;
		}
		if(a == 0 || c == 0 || e == 0){
			System.out.println("Ron");
			return;
		}
		

		
		double ab = b/ a;
		double cd = d/c;
		double ef = f/e;
		double res = ab * cd * ef;
		if(res > 1){
			System.out.println("Ron");
		}
		else{
			System.out.println("Hermione");
		}
		
		
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		TestA t = new TestA();
		t.run();
	}

}