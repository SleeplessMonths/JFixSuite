package java_6.problem_65A.subId_431103;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StreamTokenizer;

public class Main {
//	static Scanner in;
	static PrintWriter out;
	static StreamTokenizer in; static int next() throws Exception {in.nextToken(); return (int) in.nval;}

	public static void main(String[] args) throws Exception {
//		in = new Scanner(System.in);
		out = new PrintWriter(System.out);
		in = new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
		
		int[] x = new int[3];
		int[] y = new int[3];
		for (int i = 0; i < 3; i++) {
			x[i] = next();
			y[i] = next();
		}
		
		String[] answ = new String[] {"Hermione", "Ron"};
		if (x[1] == 0 && y[1] != 0) out.println(answ[1]);
		else {
			if (y[1] == 0) out.println(answ[0]);
			else {
				if (x[0] == 0 && y[0] != 0) out.println(answ[1]);
				else if (y[1] == 0) out.println(answ[0]);
				else {
					if (x[2] == 0 && y[2] != 0) out.println(answ[1]);
					else if (y[2] == 0) out.println(answ[0]);
					else {
						if (y[0] * y[1] * y[2] > x[0] * x[1] * x[2]) out.println(answ[1]);
						else out.println(answ[0]);
					}
				}
			}
		}

		out.close();
	}
}