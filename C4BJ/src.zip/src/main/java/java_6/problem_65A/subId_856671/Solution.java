package java_6.problem_65A.subId_856671;

import java.io.PrintWriter;
import java.util.Scanner;

public class Solution {
    static final double eps = 1e-10;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        PrintWriter out = new PrintWriter(System.out);

        double a = in.nextDouble();
        double b = in.nextDouble();
        double after1 = b / a;
        double c = in.nextDouble();
        double d = in.nextDouble();
        double after2 = (d / c) * after1;
        double e = in.nextDouble();
        double f = in.nextDouble();
        double after3 = (f / e) * after2;

        if ((a < eps && b > eps && d > eps) || (c < eps && d > eps) || (e < eps && b > eps && d > eps) || after3 > 1.)
            out.print("Ron");
        else
            out.print("Hermione");

        out.close();
    }
}