package java_6.problem_65A.subId_609975;

import java.util.Scanner;

public class P065A {

    public static void main(String[] args) {
        Scanner inScanner = new Scanner(System.in);
        int a = inScanner.nextInt();
        int b = inScanner.nextInt();
        int c = inScanner.nextInt();
        int d = inScanner.nextInt();
        int e = inScanner.nextInt();
        int f = inScanner.nextInt();
        if (c == 0 && d > 0)
            System.out.println("Ron");
        else if ((double) (b) / a * d / c * f / e > 1)
            System.out.println("Ron");
        else
            System.out.println("Hermione");
    }
}