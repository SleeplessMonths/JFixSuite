package java_6.problem_65A.subId_337443;

import java.io.PrintStream;
import java.util.Scanner;

public class main
{
	public static Scanner in;
	public static PrintStream out;
   
	public static void test()
	{
		long a,b,c,d,e,f;
		a = in.nextInt();
		b = in.nextInt();
		c = in.nextInt();
		d = in.nextInt();
		e = in.nextInt();
		f = in.nextInt();
		
		if ((b*d*f > a*c*e)||((a==0 && b>0)||(c==0 && d>0)||(e==0 && f>0)))
		{
			out.println("Ron");
		}
		else
		{
			out.println("Hermione");
		}
	}
       
	public static void main(String args[])
	{
		try
		{
			//in = new Scanner(new File("in.txt"));
			//out = new PrintStream(new File("out.txt"));
			in = new Scanner(System.in);
			out = System.out;
		}
		catch (Exception e)
		{
			return;
		}
	   
	   
		test();
	}
}