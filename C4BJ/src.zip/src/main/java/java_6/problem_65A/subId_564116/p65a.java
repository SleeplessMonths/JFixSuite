package java_6.problem_65A.subId_564116;

import java.util.Scanner;


public class p65a {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double a = in.nextInt();
        double b = in.nextInt();
        double c = in.nextInt();
        double d = in.nextInt();
        double e = in.nextInt();
        double f = in.nextInt();
        
        
        double toLead = b/a;
        double toGold = d/c;
        double toSand = f/e;
        
        if(toLead == 0) {
            if(toGold> 1e20) {
                System.out.println("Ron");
            } else System.out.println("Hermione");
            return;
        }
        else if(toLead>1e20){
            if(toGold == 0) {
                System.out.println("Hermione");
            } else System.out.println("Ron");
            return;
        } else {
            if(toGold > 1e20) {
                System.out.println("Ron");
            } else if(toGold == 0) {
                System.out.println("Hermione");
            } else {
                double x = toGold*toLead*toSand;
                if(x>1) {
                    System.out.println("Ron");
                } else System.out.println("Hermione");
            }
        }
        
    }
}
// 0 333 0 0 0 0

// 0 0 0 493 0 0