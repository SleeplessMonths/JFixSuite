package java_6.problem_65A.subId_654179;

import java.util.Scanner;


public class Main {
    static double eps = 1e-9;
    static double inf = 1 << 29;
    public static void main(String[] args) {        
        Scanner r = new Scanner(System.in);
        
        double[] a = new double[6];
        for(int i = 0; i < 6; i++)
            a[i] = r.nextDouble();
        
        double[] f = new double[3];
        for(int i = 0; i < 6; i+=2){
            if(a[i] < eps){
                if(a[i+1] > 0)f[i/2] = inf;
                else{
                    if(i == 1)f[i/2] = 1;
                    else f[i/2] = 0;
                }
            }else f[i/2] = a[i+1]/a[i]; 
        }
        
        double res = 1;
        for(int i = 0; i < 3; i++)
            res *= f[i];
//      System.out.println(Arrays.toString(f)); 
        
        if(res > 1.0)System.out.println("Ron");
        else System.out.println("Hermione");
    }
}