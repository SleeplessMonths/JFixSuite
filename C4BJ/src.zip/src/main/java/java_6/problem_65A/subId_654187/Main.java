package java_6.problem_65A.subId_654187;

import java.util.Scanner;


public class Main {
    static double eps = 1e-9;
    static double inf = 1 << 29;
    public static void main(String[] args) {        
        Scanner r = new Scanner(System.in);
        
        double[] a = new double[6];
        for(int i = 0; i < 6; i++)
            a[i] = r.nextDouble();
        
        double start = a[0];
        double test = start;
        for(int i = 0; i < 6; i+=2)
            test = test*a[i+1]/a[i];
        
        if(test > start)System.out.println("Ron");
        else System.out.println("Hermione");
    }
}