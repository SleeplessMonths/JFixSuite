package java_6.problem_65A.subId_459070;

import java.util.Scanner;

public class A {
	public static void main(String[] args){
		Scanner in = new Scanner(System.in);
		int A = in.nextInt();
		int B = in.nextInt();
		int C = in.nextInt();
		int D = in.nextInt();
		int E = in.nextInt();
		int F = in.nextInt();
		if(A*C*E < B*D*F)
			System.out.println("Ron");
		else
			System.out.println("Hermione");
	}
}