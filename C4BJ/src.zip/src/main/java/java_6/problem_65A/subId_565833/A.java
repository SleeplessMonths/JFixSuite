package java_6.problem_65A.subId_565833;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class A {

    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String[] S = in.readLine().split(" ");
        int a = Integer.parseInt(S[0]);
        int b = Integer.parseInt(S[1]);
        int c = Integer.parseInt(S[2]);
        int d = Integer.parseInt(S[3]);
        int e = Integer.parseInt(S[4]);
        int f = Integer.parseInt(S[5]);
        if (d == 0) {
            System.out.println("Hermione");
        } else {
            if (c == 0)
                System.out.println("Ron");
            else {
                if (b == 0)
                    System.out.println("Hermione");
                else {
                    if (a == 0)
                        System.out.println("Ron");
                    else {
                        if (a * c * f > b * d * e)
                            System.out.println("Ron");
                        else
                            System.out.println("Hermione");
                    }
                }
            }
        }
    }
}