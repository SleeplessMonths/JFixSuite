package java_6.problem_213B.subId_2001022;

import java.util.Arrays;
import java.util.Scanner;

public class Numbers {
	static long[][] p = new long[101][101], memo;
	static long[] pow = new long[101];
	static int[] a;
	static long MOD = (long)1e9 + 7;
	public static void main(String[] args){
		Scanner reader = new Scanner(System.in);
		fill();
		
		int n = reader.nextInt();
		a = new int[10];
		int[] c = new int[11];
		for(int i = 0; i < 10; i++, c[i]=c[i-1]+a[i-1])
			a[i] = reader.nextInt();
		
		memo = new long[n+1][11];
		
		long sum = 0;
		for(int i = 0; i < n; i++){
			for(int j = 1; j < 10; j++){
				int addBack = a[j] > 0?1:0;
				a[j] -= addBack;
				
				for(long[] x:memo)Arrays.fill(x,-1);
				sum = (sum + f(i,0))%MOD;
				
				a[j] += addBack;
			}
		}
		
		
//		for(int i = Math.max(0,c[10]-1); i < n; i++){
//			for(int j = 1; j < 10; j++){
//				long m = 1;
//				int sub = c[10]-(a[j]>0?1:0);
//				
//				if(sub > i)
//					continue;
//				
//				for(int k = 0; k < 10; k++){
//					m = (m*p[i-c[k]+(k>j&&a[j]>0?1:0)][a[k]-(k==j&&a[j]>0?1:0)])%MOD;
//					System.out.println(i + " " + j + " " + (i-c[k]+(k>j&&a[j]>0?1:0)));
//				}
//				
//				m = (m*pow[i-sub])%MOD;
//				sum = (sum + m)%MOD;
//			}
//		}
//		
		System.out.println(sum);
	}
	
	public static void fill(){
		for(int i = 0; i < p.length; i++){
			p[i][0] = 1;
			for(int j = 1; j <= i; j++)
				p[i][j] = p[i-1][j] + p[i-1][j-1];
		}
		
		pow[0] = 1;
		for(int i = 1; i < pow.length; i++)
			pow[i] = (pow[i-1]*10)%MOD;
	}
	
	public static long f(int n, int m){
		if(n < 0)
			return 0;
		if(memo[n][m] == -1){
			if(m == 10){
				memo[n][m] = n==0?1:0;
			}else{
				long sum = 0;
				for(int i = a[m]; i <= n; i++)
					sum = (sum + f(n-i, m+1) * p[n][i])%MOD;
				memo[n][m] = sum;
			}
		}
		return memo[n][m];
	}
}