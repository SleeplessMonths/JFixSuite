package java_6.problem_213B.subId_1976058;

import java.util.Arrays;
import java.util.Scanner;
public class B {

    public static final int MOD = 1000000007;
    public static final int MAX_N = 100;
    static int[][] C = new int[MAX_N+1][MAX_N+1];
    static {
        for (int n=0; n<=MAX_N; n++) {
            C[n][0] = C[n][n] = 1;
            for (int k=1; k<n; k++) {
                C[n][k] = (C[n-1][k-1]+C[n-1][k])%MOD;
            }
        }
    }

    public B() throws Exception {
        int n = in.nextInt();
        int[] a = new int[10];
        for (int i=0; i<10; i++) a[i] = in.nextInt();
        long[][] dp = new long[11][n+1];
        dp[10][0] = 1;
        for (int i=9; i>=0; i--) {
            for (int j=a[i]; j<=n; j++) {
                for (int k=j; k<=n; k++) {
                    dp[i][k] = (dp[i][k]+dp[i+1][k-j]*C[k-(i==0&&k>0?1:0)][j])%MOD;
                }
            }
        }
        long ans = 0;
        for (int i=0; i<=n; i++) {
            ans = (ans+dp[0][i])%MOD;
        }
        System.out.println(ans);
    }

    Scanner in = new Scanner(System.in);
    public static void main(String[] args) throws Exception { // {{{
        new B();
    } // }}}
    public static void debug(Object... arr) { // {{{
        System.err.println(Arrays.deepToString(arr));
    } // }}}
}