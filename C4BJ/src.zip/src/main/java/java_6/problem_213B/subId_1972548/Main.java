package java_6.problem_213B.subId_1972548;

import java.util.Arrays;
import java.util.Scanner;

public class  Main  {
	
	//ArrayList<Integer> lis = new ArrayList<Integer>();
	//ArrayList<String> lis = new ArrayList<String>();
	//ArrayList<test> lis = new ArrayList<test>();
//	static long sum=0;
//	static boolean f=false;
	//static String s[],r="";
//	static int dx[]={1,-1,0,0,1,1,-1,-1};
  //  static int dy[]={0,0,1,-1,1,-1,1,-1},n,m,w=0;
	//throws IOException
	
	
public  static void main(String[] args)  {
   //googlein.txt C-small-attempt0.in
//	Scanner sc =new Scanner(new File("file.txt"));
	 Scanner sc =new Scanner(System.in);
	  //File file = new File("file.txt");
	//	PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
	//	sc.useDelimiter("(\\s)+|[,]");
		 
	  while(sc.hasNext()){
		   //long sum=0;
	//	  int n=sc.nextInt(),m=sc.nextInt(),k=sc.nextInt();
	int	   n=sc.nextInt(),a[]=new int[10];
		for(int i=0;i<10;i++){
		  a[i]=sc.nextInt(); 
		}
		
	 long dp[][]=new long[10][n+1],m=1000000007,com[][]=new long[101][101];
	 
	 
		com[0][0]=1;
		for(int i=1;i<101;i++)
		{
			com[i][0]=com[i][i]=1;
			for(int j=1;j<i;j++)
				com[i][j]=(com[i-1][j-1]+com[i-1][j])%m;
		}
	 
	 for(int i=a[9];i<=n;i++)dp[9][i]=1;
	
	 for(int i=8; 0<=i ;i--){
		 
		 for(int t=0; t<=n; t++) {
			 for(int j=a[i]; j<=t; j++){
				int z= t - (i==0? 1:0);
			dp[i][t]+=( dp[i+1][t-j] *com[ z<0 ? 0:z ][j] )%m ;
			dp[i][t]%=m;
			 }
		}
	 }
	 
	// for(int i=9; 0<=i ;i--)db(dp[i]);
	 
	 for(int i=1; i<=n ;i++){ dp[0][0]+=dp[0][i];  dp[0][0]%=m; }
	 
		System.out.println( dp[0][0] );
		
		 }
		

}
	// db("Case #"+(k)+": "+c);
	 //	pw.println("Case #"+(k)+": "+c);
	 	
	 	//pw.flush();
	 	//pw.close();   
    static void db(Object... os){
	         System.err.println(Arrays.deepToString(os));
 
	}

}