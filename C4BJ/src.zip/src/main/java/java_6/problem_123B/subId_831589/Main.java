package java_6.problem_123B.subId_831589;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Random;
import java.util.StringTokenizer;

public class Main implements Runnable {
	private BufferedReader in;
	private PrintWriter out;
	private StringTokenizer st;
	private Random rnd;
	
	final long inf = 10000000000L;
	
	private long calcAns(long start, long end, long a) {
		long res = 0;
		
		//out.println(start + " " + end + " " + a);
		
		long line1 = (start + inf * a) / a;
		long line2 = (end + inf * a) / a;
		
		res = Math.abs(line1 - line2);
		
		//out.println(line1 + " " + line2 + " " + res);
		
		return res;
	}
	
	public void solve() throws IOException {
		long a = nextInt(), b = nextInt();
		
		long x0 = nextInt(), y0 = nextInt(), x1 = nextInt(), y1 = nextInt();
		
		long result = Math.max(calcAns(x0 + y0, x1 + y1, 2 * a), calcAns(x0 - y0, x1 - y1, 2 * b));

		out.println(result);
		
		
		
		/*for(int i = 15; i >= -15; i--) {
			for(int j = -15; j <= 15; j++) {
				int sum = Math.abs(i + j);
				int diff = Math.abs(j - i);
				int bad = 0;
				
				if(sum % (2 * a) == 0) bad++;
				if(diff % (2 * b) == 0) bad++;
				
				
				if(j == x0 && i == y0) out.print('S');
				else if(j == x1 && i == y1) out.print('E');
				else if(bad == 1) out.print('x');
				else if(bad == 2) out.print('X');
				else out.print('.');
			}
			out.println();
		}*/
	}
		
	public static void main(String[] args) {
		new Main().run();
	} 
	
	public void run() {
		try {
			//in = new BufferedReader(new FileReader("input.txt"));
			//out = new PrintWriter(new FileWriter("output.txt"));
			
			in = new BufferedReader(new InputStreamReader((System.in)));
			out = new PrintWriter(System.out);
			
			st = null;
			rnd = new Random();
			
			solve();
			
			out.close();
		} catch(IOException e) {
			e.printStackTrace();
		}	
	}
	
	private String nextToken() throws IOException, NullPointerException {
		while(st == null || !st.hasMoreTokens()) {
			st = new StringTokenizer(in.readLine());
		}
		
		return st.nextToken();
	}
	
	private int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}
	
	private long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}
	
	private double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

}