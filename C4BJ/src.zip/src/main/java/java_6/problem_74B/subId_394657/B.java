package java_6.problem_74B.subId_394657;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 * @author Vitaly Zubchevskiy
 *         Created at 8:59 17.04.11
 */
public class B
{
    public static void main(String[] args) throws IOException
    {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Scanner firstLine = new Scanner(reader.readLine());
        int n = firstLine.nextInt();
        int z = firstLine.nextInt();
        int k = firstLine.nextInt();

        boolean toHead = reader.readLine().trim().equalsIgnoreCase("to head");
        char[] train = reader.readLine().trim().toCharArray();
        int[] stop = new int[train.length];
        int sLen = 0;
        for (int i = 0; i < train.length; i++)
            if (train[i] == '1')
                stop[sLen++] = i+1;

        int step = simulate(n, z, k, toHead, stop, sLen);
        if (step >= 0)
            System.out.println("Controller " + step);
        else
            System.out.println("Stowaway");

        ///   4
        // 0100001

    }

    private static int simulate(int n, int z, int k, boolean toHead, int[] stop, int sLen)
    {
        if (z == k || n == 1)
            return 0;

        int prev = 0;
        for (int i = 0; i < sLen; i++)
        {
            int peregon = stop[i] - prev;
            if (toHead && z < k)
            {
                if (k - 1 < peregon)
                    return prev+ k-1;
            }
            else if (toHead)
            {
                if (k - 1 + n - 1 < peregon)
                    return prev+k - 1 + n - 1;
            }
            else if (!toHead && z > k)
            {
                if (n - k < peregon)
                    return prev+n-k;

            }
            else
            {
                if (2 * n - k - 1 < peregon)
                    return prev+ 2 * n - k - 1;
            }


            prev = stop[i];
            k = k + (toHead ? -1 : 1) * peregon;
            if (k < 1)
            {
                k = 2-k;
                toHead = !toHead;
            }
            else if (k > n)
            {
                k = n - 1 - (k - n);
                toHead = !toHead;
            }
            if (toHead)
                z = n;
            else
                z = 1;
        }
        return -1;
    }
}