package java_6.problem_74B.subId_709000;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Scanner;

public class A {

	private int[][][][] memo;
	private boolean[] move;
	private int n;

	private void work() {
		Scanner sc = new Scanner(new BufferedReader(new InputStreamReader(
				System.in)));

		while (sc.hasNextInt()) {
			n = sc.nextInt();
			int s = sc.nextInt() - 1;
			int c = sc.nextInt() - 1;
			sc.next();
			char d = sc.next().charAt(0);
			String m = sc.next();
			move = new boolean[m.length()];
			for (int i = 0; i < move.length; i++) {
				move[i] = m.charAt(i) == '0';
			}
			memo = new int[2][n][n][move.length];
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					Arrays.fill(memo[0][i][j], -1);
					Arrays.fill(memo[1][i][j], -1);
				}
			}
			int res = go(d == 'h' ? 0 : 1, c, s, 0);
			if (res >= move.length)
				System.out.println("Stowaway");
			else
				System.out.println("Controller " + (res + 1));
		}
	}

	private int go(int d, int c, int s, int t) {
		if (c == s)
			return 0;
		if (t == move.length)
			return 1;
		if (memo[d][c][s][t] >= 0)
			return memo[d][c][s][t];
		int ret = 0;
		int nd, nc;
		if (c == 0) {
			nd = 1;
			nc = 1;
		} else if (c == n - 1) {
			nd = 0;
			nc = n - 2;
		} else {
			nd = d;
			nc = c + (d == 0 ? -1 : 1);
		}
		if (move[t]) {
			for (int i = s - 1; i <= s + 1; i++) {
				if (i >= 0 && i < n && i != nc && i != c) {
					int tt = 1 + go(nd, nc, i, t + 1);
					if (tt > ret)
						ret = tt;
				}
			}
		} else {
			for (int i = 0; i < n; i++) {
				if (nc != i && c != i) {
					int tt = 1 + go(nd, nc, i, t + 1);
					if (tt > ret)
						ret = tt;
				}
			}
		}
		return memo[d][c][s][t] = ret;
	}

	public static void main(String[] args) {
		new A().work();
	}

}