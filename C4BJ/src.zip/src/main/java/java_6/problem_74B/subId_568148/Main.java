package java_6.problem_74B.subId_568148;

import java.util.Scanner;

public class Main {

	public void run() {
		int n = cin.nextInt();
		int m = cin.nextInt();
		int k = cin.nextInt();
		int t = m;
		m = k;
		k = t;
		cin.next();
		String s = cin.next();
		int dir = 0;
		if (s.compareTo("tail") == 0) {
			dir = 1;
		}
		char[] str = cin.next().toCharArray();
		boolean flag = true;
		for (int i = 0; i < str.length && flag; ++i) {
			if (str[i] == '1') {
				if (dir == 0) k = n;
				else k = 1;
				if (dir == 0) {
					if (m == 1) {
						++m;
						dir = 1;
					}
					else --m;
				}
				else {
					if (m == n) {
						--m;
						dir = 0;
					}
					else ++m;
				}
			}
			else {
				if (k > m && k != n) ++k;
				else if (k < m && k != 1) --k;
				if (dir == 0) {
					if (m == 1) {
						++m;
						dir = 1;
					}
					else --m;
				}
				else {
					if (m == n) {
						--m;
						dir = 0;
					}
					else ++m;
				}
				if (k == m) {
					System.out.println("Controller " + (i + 1));
					flag = false;
				}
			}
		}
		if (flag) {
			System.out.println("Stowaway");
		}
	}

	public static void main(String[] args) {
		new Main().run();
	}

	Scanner cin = new Scanner(System.in);
}