package java_6.problem_74B.subId_622813;

import java.util.Scanner;

public class B {

    private void print(boolean dp[][]) {
        for (int i = 0; i < dp.length; i++) {
            for (int j = 0; j < dp[0].length; j++) {
                System.out.print(dp[i][j] ? "T " : "F ");
            }
            System.out.println();
        }
    }
    
    private void run() {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(), k = sc.nextInt(), m = sc.nextInt();
        m--; k--;
        sc.next();
        String foward = sc.next();
        char[] b = sc.next().toCharArray();

        int t = (foward.equals("head") ? -1 : 1);
        boolean[][] dp = new boolean[b.length + 1][n];
        dp[0][k] = true;
        for (int i = 1; i < dp.length; i++) {
            if (i!=1 && (m == 0 || m == n - 1))
                t *= -1;
            m += t;
            if (b[i - 1] == '0') {
                for (int j = 0; j < n; j++) {
                    if (dp[i-1][j] == false)
                        continue;
                    for (int j2 = -1; j2 <= 1; j2++) {
                        k = j2 + j;
                        if (0 <= k && k < n) {
                            if(k != m && k != m-t)
                                dp[i][k] = true;
                            else 
                                dp[i][k] = false;
                        }
                    }
                }
            } else {
                for (int j = 0; j < n; j++) {
                    dp[i][j] = true;
                }
                dp[i][m] = false;
            }
        }
        boolean check = false;
        for (int h = 0; h < dp.length; h++) {
            check = false;
            for (int i = 0; i < n; i++) {
                if (dp[h][i]) {
                    check = true;
                    break;
                }
            }
            if(!check) {
                System.out.println("Controller "+(h));
                break;
            }
        }
        if(check)
            System.out.println("Stowaway");
        print(dp);
        sc.close();
    }

    public static void main(String args[]) {
        new B().run();
    }

}