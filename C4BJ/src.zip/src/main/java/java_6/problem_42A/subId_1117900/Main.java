package java_6.problem_42A.subId_1117900;

import java.util.Scanner;

public class Main{
	public static void main(String[] args){
		Scanner in = new Scanner(System.in);
		
		int n = in.nextInt();
		int v = in.nextInt();
		
		int[] a = new int[100];
		int[] b = new int[100];
		
		for (int i = 0; i<n; i++)
			a[i] = in.nextInt();
			
		for (int i = 0; i<n; i++)
			b[i] = in.nextInt();
		
		double l = 0, r = v; 
		double ans = 0;
		double eps = 1e-7;
		
		while (r-l>eps){
			double m = (l+r)/2.0;
			double sum = 0;
			boolean ok = true;
			
			for (int i = 0; i<n; i++)
				if (a[i]*m<=b[i]) sum+=a[i]*m; else ok = false;
			
			if (ok) { ans = sum; l=m+eps;} else r=m-eps;
			
		} 
		
		System.out.println(ans);
	}
}