package java_6.problem_42A.subId_200493;

import java.io.*;

public class Solution {

    StreamTokenizer in;
    PrintWriter out;

    public static void main(String[] args) throws Exception {
        new Solution().run();
    }

    public void run() throws Exception {
        in = new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
        out = new PrintWriter(new OutputStreamWriter(System.out));
        solve();
        out.flush();
    }

    int nextInt() throws Exception {
        in.nextToken();
        return (int) in.nval;
    }

    public void solve() throws Exception {
        int n = nextInt();
        double v = nextInt();
        int [] a = new int [n];
        int [] b = new int [n];
        for (int i=0; i<n; i++)
            a[i]=nextInt();
        for (int i=0; i<n; i++)
            b[i]=nextInt();
        double min=Double.MAX_VALUE;
        for (int i=0; i<n;i++)
            if (b[i]/a[i]<min) min=(double) b[i]/a[i];
        double sup=0;
        for (int i=0; i<n;i++)
            sup +=a[i]*min;
        out.println(Math.min(sup, v));
    }

}