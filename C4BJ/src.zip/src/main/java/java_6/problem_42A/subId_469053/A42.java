package java_6.problem_42A.subId_469053;

import java.util.Arrays;
import java.util.Scanner;

public class A42 {
     public static void main(String[]args){
         Scanner sc = new Scanner(System.in);
         
         int n = sc.nextInt();
         int percent = sc.nextInt();
         int[]a = new int[n];
         int[]b = new int[n];
         int S = 0;
         for (int i = 0; i<n; i++){
             a[i] = sc.nextInt();
             S += a[i];
         }
         for (int i = 0; i<n; i++){
             b[i] = sc.nextInt();
         }
         double[]q = new double[n];
         for (int i= 0; i<n; i++){
             q[i] = b[i]/a[i];
         }
         Arrays.sort(q);
         double min = q[0];
         double supe = 0;
         for (int i = 0; i<n; i++){
             supe += min*a[i];
         }
         if (supe>percent)supe = percent;
         System.out.println(supe);
     }
}