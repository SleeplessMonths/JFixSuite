package java_6.problem_42A.subId_1994299;

import java.util.Scanner;


public class A {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int V = sc.nextInt();
        int[]a = new int[n+1], b = new int[n+1];
        int sum_a = 0;
        for (int i = 1; i <= n; i++) {
            a[i] = sc.nextInt();
            sum_a += a[i];
        }
        for (int i = 1; i <= n; i++) {
            b[i] = sc.nextInt();
        }
        double x = V*1.0/sum_a;
        for (int i = 1; i <= n; i++) {
            x = Math.min(x, b[i]/a[i]);
        }
        System.out.println(sum_a*x);
    }

}