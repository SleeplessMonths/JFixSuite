package java_6.problem_42A.subId_199197;

import java.io.*;
import java.util.Locale;

public class Solution {

    StreamTokenizer in;
    PrintWriter out;

    public static void main(String[] args) throws Exception {
        new Solution().run();
    }

    int nextInt() throws Exception {
        in.nextToken();
        return (int) in.nval;
    }

    public void run() throws Exception {
        in = new StreamTokenizer (new BufferedReader(new InputStreamReader(System.in)));
        out = new PrintWriter (new OutputStreamWriter(System.out));
        solve();
        out.flush();
    }

    public void solve() throws Exception {
        Locale.setDefault(Locale.US);
        int n = nextInt();
        int v = nextInt();
        int [] a = new int [30];
        int [] b = new int [30];
        for(int i=0;i<n;i++)
        {
            a[i]=nextInt();
        }
        for(int i=0;i<n;i++)
        {
            b[i]=nextInt();
        }
        double min=v;
        for (int i=0; i<n; i++)
            if (b[i]/a[i]<min) min=(double)(b[i]/a[i]);
        double sum=0;
        for (int i=0;i<n;i++)
            sum +=min*a[i];
        if (sum>v) sum=v;
        out.printf("%1.5f",sum);
    }

}