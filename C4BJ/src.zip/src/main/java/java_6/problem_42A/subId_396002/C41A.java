package java_6.problem_42A.subId_396002;

import java.io.BufferedReader;
import java.io.InputStreamReader;
public class C41A{
    static BufferedReader br;
    public static void main(String args[])throws Exception{
        br=new BufferedReader(new InputStreamReader(System.in));
        int nn[]=toIntArray();
        int n=nn[0];
        int v=nn[1];
        int a[]=toIntArray();
        int b[]=toIntArray();

        double min=Double.MAX_VALUE;
        for(int i=0;i<a.length;i++){
            if(b[i]/a[i]<min){
                min=b[i]/a[i];
            }
        }
        double res=0.0;
        for(int i=0;i<a.length;i++){
            res+=min*a[i];
        }
        if(res>v)
            res=v;
        System.out.println(res);
    }


    /****************************************************************/
    public static int[] toIntArray()throws Exception{
       String str[]=br.readLine().split(" ");
       int k[]=new int[str.length];
       for(int i=0;i<str.length;i++){
            k[i]=Integer.parseInt(str[i]);
       }
       return k;
    }
    public static int toInt()throws Exception{
       return Integer.parseInt(br.readLine());
    }
    public static long[] toLongArray()throws Exception{
       String str[]=br.readLine().split(" ");
       long k[]=new long[str.length];
       for(int i=0;i<str.length;i++){
            k[i]=Long.parseLong(str[i]);
       }
       return k;
    }
    public static long toLong()throws Exception{
       return Long.parseLong(br.readLine());
    }
    public static double[] toDoubleArray()throws Exception{
       String str[]=br.readLine().split(" ");
       double k[]=new double[str.length];
       for(int i=0;i<str.length;i++){
            k[i]=Double.parseDouble(str[i]);
       }
       return k;
    }
    public static double toDouble()throws Exception{
       return Double.parseDouble(br.readLine());
    }
    public static String toStr()throws Exception{
       return br.readLine();
    }
    public static String[] toStrArray()throws Exception{
       String str[]=br.readLine().split(" ");
       return str;
    }
    /****************************************************************/

}