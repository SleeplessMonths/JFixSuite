package java_6.problem_42A.subId_200272;

import java.util.Scanner;

public class guiltykitchen{
	
	public static void main(String[] args){
		
		Scanner sin = new Scanner(System.in);
		int n = sin.nextInt(), v = sin.nextInt();
		int[] res = new int[n];
		int sum = 0;
		for(int i = 0; i < n; i++){
			res[i] = sin.nextInt();
			sum += res[i];
		}
		double[] x = new double[n];
		double min = 1000.0;
		for(int i = 0; i < n; i++){
			x[i] = ((double)(sin.nextInt()))/res[i];
			min = Math.min(x[i], min);
		}
		double ret = min*sum;
		if(ret > v)
			System.out.println(v+".0");
		else
			System.out.printf("%.1f\n",ret);
	}
}