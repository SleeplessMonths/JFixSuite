package java_6.problem_42A.subId_199547;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StreamTokenizer;


public class Main {
    private static StreamTokenizer in;
    private static PrintWriter out;
    
    private static int nextInt() throws Exception{
        in.nextToken();
        return (int) in.nval;
    }
    
    private static String nextString() throws Exception{
        in.nextToken();
        return in.sval;
    }
    
    static{
        in = new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
        out = new PrintWriter(System.out);
    }
    
    public static void main(String[] args) throws Exception {
        int n = nextInt(), v = nextInt();
        int[] masa = new int[n];
        int[] masb = new int[n];
        for(int i = 0; i<n; i++){
            masa[i] = nextInt();
        }
        for(int i = 0; i<n; i++){
            masb[i] = nextInt();
        }
        
        float[] f = new float[n];
        
        for(int i = 0; i<n; i++){
            f[i] = (float)masa[i] / (float)masb[i];
        }
        float max = 0;
        int ind = 0;
        for(int i = 0; i<n; i++){
            if(f[i]>max){
                max = f[i];
                ind = i;
            }
        }
        
        float res = 1 / max;
        res = res * masa[ind];
        System.out.println(Math.min(res * n, v));
        
    }
}