package java_6.problem_54D.subId_247081;

import java.util.Scanner;

public class C50D {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int k=sc.nextInt();
        String p=sc.next();
        String or=sc.next();
        String res="";
        int l=0;
        int count=0;
        char cc;
        int ind=0;
        boolean ff=false,f=false;
        for(int i=0;i<p.length()-1;i++){
            if(p.charAt(i)!=p.charAt(i+1)){
                ff=true;
                break;
            }
        }
        if(p.length()==1 || !ff)
            cc = (p.charAt(0)=='a' ) ? 'b':'a';
        else
            cc=p.charAt(p.length()-1);

        ff=false;
        for(int i=0;i<or.length();i++){
                if(or.charAt(i)=='1'){

                    if( i==or.length()-1 && i+p.length()>n ){
                       res="No solution";
                       f=true;
                       break;
                    }
                    else{

                        if(count==0){
                            res=res+p;
                            ind=i;
                            count=1;
                        }
                        else{
                            if( i+p.length()<=n && (res.substring(i,res.length()).equals(p.substring(0,res.length()-i)))){
                                res+=p.substring(res.length()-i,p.length());
                                for(int h=ind+1;h<res.length()-p.length();h++){
                                    if(res.substring(h,h+p.length()).equals(p)){
                                        f=true;
                                        res="No solution";
                                        ff=true;

                                    }
                                }
                                if(ff)break;
                                ind=i;

                            }
                            else{
                                f=true;
                                 res="No solution";
                                 break;
                            }

                        }
                     }
                }
         else{
                    
                    if(i==0 ||res.length()<=i)
                        res+=String.valueOf(cc);
              
 
        }
        }
        if(!f){
            for(int i=or.length();i<n;i++)
                res+=String.valueOf(cc);
            }
        System.out.println(res);


    }
}