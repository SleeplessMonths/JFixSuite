package java_6.problem_80B.subId_7009887;

import java.util.Scanner;


public class r69_b {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String s=sc.next(),s1="",s2="";
	s+=":";
	int h[]=new int[3],k=0;
	for (int i = 0; i < s.length(); i++) {
		if(s.charAt(i)!=':')
			s1+=s.charAt(i);
		else{
			h[++k]=Integer.parseInt(s1);
			s1="";
		}
	}
	if(h[1]>12)
		h[1]-=12;
	double ans1=h[2]/2.0+30*h[1];
	int ans2=6*h[2];
	if(Math.abs(ans1-360)< 1e-8)
		ans1=0;
	System.out.printf("%.9f",ans1);
	System.out.print(" "+ans2);
}
}