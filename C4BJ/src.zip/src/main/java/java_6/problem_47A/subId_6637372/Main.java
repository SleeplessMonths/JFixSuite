package java_6.problem_47A.subId_6637372;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static ArrayList<Integer> tri = new ArrayList<Integer>();
    
    public static void init() {
        for(int i = 0; i <= 30; i++) {
            tri.add(i*(i+1)/2);
        }
    }
    
    public static void main (String[] args) {
        init();
        Scanner sc = new Scanner(System.in);
        while(sc.hasNext()) {
            int n = sc.nextInt();
            System.out.println((tri.contains(n)) ? "YES" : "NO"); 
        }
    }
}