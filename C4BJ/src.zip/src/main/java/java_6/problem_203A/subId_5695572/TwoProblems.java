package java_6.problem_203A.subId_5695572;

import java.util.Scanner;

public class TwoProblems
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int x = input.nextInt();
		int t = input.nextInt();
		int a = input.nextInt();
		int b = input.nextInt();
		int da = input.nextInt();
		int db = input.nextInt();
		if (x == 0)
		{
			System.out.println("YES");
			return;
		}
		int temp;
		for (int i = 0; i < t; ++i)
		{
			for (int j = 0; j < t; ++j)
			{
				temp = a - i * da + b - j * db;
				if (x == temp)
				{
					System.out.println("YES");
					return;
				}
				if (x > temp)
				{
					break;
				}
			}
		}
		System.out.println("NO");
	}
}