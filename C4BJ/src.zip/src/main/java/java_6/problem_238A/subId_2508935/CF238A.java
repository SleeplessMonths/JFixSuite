package java_6.problem_238A.subId_2508935;

import java.util.*;

public class CF238A {
    static long M = 1000L*1000*1000+7;
    public static void main(String[] args) throws Exception {
        Scanner in = new Scanner(System.in);
        long n = in.nextInt();
        long m = in.nextInt();
        long p2 = pow(2, m)-1;

        long ans = 1;
        for(int i=0; i<n; i++) {
            ans = (ans*p2)%M;
            p2--;
        }
        System.out.println(ans);
    }
    static long pow(long base, long exp) {
        if(exp == 0) return 1;
        if(exp%2==1) return (base*pow(base, exp-1))%M;
        return pow( (base*base)%M, exp/2);
    }

    public static <T> List<T> list() { return new ArrayList<T>(); }
    public static <K,V> Map<K,V> map() { return new HashMap<K,V>(); }
    public static int i(String s) { return Integer.parseInt(s); }
    public static long l(String s) { return Long.parseLong(s); }
}