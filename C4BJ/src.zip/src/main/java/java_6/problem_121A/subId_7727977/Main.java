package java_6.problem_121A.subId_7727977;

import java.io.*;
import java.util.StringTokenizer;

public class Main {

    public static void main(String[] args) throws IOException {

        InputStream inputStream = System.in;
        OutputStream outputStream = System.out;
        InputReader scn = new InputReader(inputStream);
        PrintWriter prn = new PrintWriter(outputStream);
        II__ASC__II Mechanism = new II__ASC__II();
        Mechanism.Process(scn, prn);
        prn.close();
    }
}

class II__ASC__II {

    public void Process(InputReader scn, PrintWriter prn) throws IOException {
        long a=scn.nextInt(),b=scn.nextInt(),sum=0;
        for(long i=a;i<b+1;++i){
                if(i<=4 && i>0){
                    sum+=4;
                }else{
                    sum+=7;
                }
        }
        prn.println(sum);
    }
    
    boolean islucky(long n){
        while (n>0){
            if (!(n%10==4 || n%10==7)){
                return false;
            }
            n=n/10;
        }
        return true;
    }
}

class InputReader {

    public BufferedReader reader;
    public StringTokenizer tokenizer;

    public InputReader(InputStream stream) {
        reader = new BufferedReader(new InputStreamReader(stream), 32768);
        tokenizer = null;
    }

    public String next() {
        while (tokenizer == null || !tokenizer.hasMoreTokens()) {
            try {
                tokenizer = new StringTokenizer(reader.readLine());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return tokenizer.nextToken();
    }

    public String nextLine() throws IOException {
        return reader.readLine();
    }

    public int nextInt() {
        return Integer.parseInt(next());
    }

    public long nextLong() {
        return Long.parseLong(next());
    }

    public double nextDouble() {
        return Double.parseDouble(next());
    }

    public Integer toInt(String s) {
        return Integer.parseInt(s.trim());
    }

    public Long toLong(String s) {
        return Long.parseLong(s.trim());
    }

    public Double toDouble(String s) {
        return Double.parseDouble(s.trim());
    }

    public int[] getIntArray(String line) {
        String s[] = line.split(" ");
        int a[] = new int[s.length];
        for (int i = 0; i < s.length; ++i) {
            a[i] = Integer.parseInt(s[i]);
        }
        return a;
    }

    public Integer[] getIntegerArray(String line) {
        String s[] = line.split(" ");
        Integer a[] = new Integer[s.length];
        for (int i = 0; i < s.length; ++i) {
            a[i] = Integer.parseInt(s[i]);
        }
        return a;
    }

    public Double[] getDoubleArray(String line) {
        String s[] = line.split(" ");
        Double a[] = new Double[s.length];
        for (int i = 0; i < s.length; ++i) {
            a[i] = Double.parseDouble(s[i]);
        }
        return a;
    }

    public Long[] getLongArray(String line) {
        String s[] = line.split(" ");
        Long a[] = new Long[s.length];
        for (int i = 0; i < s.length; ++i) {
            a[i] = Long.parseLong(s[i]);
        }
        return a;
    }

    public Long getMaxFromLongArray(Long a[]) {
        Long max = Long.MIN_VALUE;
        for (int i = 0; i < a.length; ++i) {
            if (max < a[i]) {
                max = a[i];
            }
        }
        return max;
    }

    public Long getMinFromLongArray(Long a[]) {
        Long min = Long.MAX_VALUE;
        for (int i = 0; i < a.length; ++i) {
            if (min > a[i]) {
                min = a[i];
            }
        }
        return min;
    }

    public Integer getMaxFromIntegerArray(Integer a[]) {
        Integer max = Integer.MIN_VALUE;
        for (int i = 0; i < a.length; ++i) {
            if (max < a[i]) {
                max = a[i];
            }
        }
        return max;
    }

    public Integer getMinFromIntegerArray(Integer a[]) {
        Integer min = Integer.MAX_VALUE;
        for (int i = 0; i < a.length; ++i) {
            if (min > a[i]) {
                min = a[i];
            }
        }
        return min;
    }

    long modPow(long a, long x, long p) {
        long res = 1;
        while (x > 0) {
            if (x % 2 != 0) {
                res = (res % p * a % p) % p;
            }
            a = (a % p * a % p) % p;
            x /= 2;
        }
        return res;
    }

    long modInverse(long a, long p) {
        return modPow(a, p - 2, p);
    }

    long modBinomial(long n, long k, long p) {
        long numerator = 1; // n * (n-1) * ... * (n-k+1)
        for (long i = 0; i < k; i++) {
            numerator = (numerator % p * (n - i) % p) % p;
        }
        long denominator = 1; // k!
        for (long i = 1; i <= k; i++) {
            denominator = (denominator % p * i % p) % p;
        }
        return (numerator % p * modInverse(denominator, p) % p) % p;
    }

    public long calculate(long k, long n) {
        return (modBinomial(n, k, 1000000007));
    }
}