package java_6.problem_42B.subId_2953996;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Arrays;

public class ProblemB {
	
	static int[] dx = {-1, -1, -1, 0, 0, 0, 1, 1, 1};
	static int[] dy = {-1, 0, 1, -1, 0, 1, -1, 0, 1};
	
	public static void main(String[] args) throws IOException {
		BufferedReader s = new BufferedReader(new InputStreamReader(System.in));
		PrintWriter out = new PrintWriter(System.out);
		
		String[] p = s.readLine().split(" ");
		int[][] pos = new int[4][2];
		for (int i = 0 ; i < 4 ; i++) {
			pos[i][0] = p[i].charAt(0) - 'a';
			pos[i][1] = p[i].charAt(1) - '1';
		}
		
		out.println(solve(pos) ? "CHECKMATE" : "OTHER");
		out.flush();
	}
	
	
	
	private static boolean solve(int[][] pos) {
		boolean mate = true;
		for (int d = 0 ; d < 9 ; d++) {
			pos[3][0] += dx[d];
			pos[3][1] += dy[d];
			if (0 <= pos[3][0] && pos[3][0] <= 7 && 0 <= pos[3][1] && pos[3][1] <= 7) {
				if (!taken(pos)) {
					mate = false;
					break;
				}
			}
			pos[3][0] -= dx[d];
			pos[3][1] -= dy[d];
		}
		return mate;
	}



	private static boolean taken(int[][] pos) {
		boolean taken = false;
		boolean[][] ex = new boolean[8][8];
		for (int i = 0 ; i <= 3 ; i++) {
			ex[pos[i][0]][pos[i][1]] = true;
		}
		for (int i = 0 ; i <= 2 ; i++) {
			if (pos[i][0] == pos[3][0] && pos[i][1] == pos[3][1]) {
				continue;
			}
			int dx = Math.abs(pos[i][0] - pos[3][0]);
			int dy = Math.abs(pos[i][1] - pos[3][1]);
			if (i == 0 || i == 1) {
				if (dx >= 1 && dy >= 1) {
					continue;
				}
				boolean isok = true;
				if (dx == 0) {
					int min = Math.min(pos[i][0], pos[3][0]);
					int max = Math.max(pos[i][0], pos[3][0]);
					for (int x = min+1 ; x <= max-1 ; x++) {
						if (ex[x][pos[i][1]]) {
							isok = false;
							break;
						}
					}
				} else {
					int min = Math.min(pos[i][1], pos[3][1]);
					int max = Math.max(pos[i][1], pos[3][1]);
					for (int y = min+1 ; y <= max-1 ; y++) {
						if (ex[pos[i][0]][y]) {
							isok = false;
							break;
						}
					}
				}
				if (!isok) {
					continue;
				}
			} else {
				if (dx >= 2 || dy >= 2) {
					continue;
				}
			}
			taken = true;
		}
		return taken;
	}



	public static void debug(Object... os){
		System.err.println(Arrays.deepToString(os));
	}
}