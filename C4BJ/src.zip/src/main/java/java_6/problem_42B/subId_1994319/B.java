package java_6.problem_42B.subId_1994319;

import java.util.Scanner;


public class B {

    static int king1_v,king1_h;
    static int[][]under_bit;
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String rook1 = sc.next();
        String rook2 = sc.next();
        String king1 = sc.next();
        String king2 = sc.next();
        under_bit = new int[9][9];
        int rook1_v = rook1.codePointAt(0)-96, rook1_h = rook1.codePointAt(1)-48;
        king1_v = king1.codePointAt(0)-96;
        king1_h = king1.codePointAt(1)-48;
        int king2_v = king2.codePointAt(0)-96;
        int king2_h = king2.codePointAt(1)-48;
        int rook2_v = rook2.codePointAt(0)-96, rook2_h = rook2.codePointAt(1)-48;
        try_(rook1_h, rook1_v);
        try_(rook2_h, rook2_v);
        int[]dx = {1, 1, -1, -1, 1, -1, 0, 0};
        int[]dy = {1, -1, 1, -1, 0, 0, 1, -1};
        for (int i = 0; i < 8; i++) {
            int x = king1_v+dx[i], y = king1_h+dy[i];
            if (x >= 1 && x <= 8 && y >= 1 && y <= 8)
                under_bit[y][x]++;
        }
//      for (int i = 1; i <= 8; i++) {
//          for (int j = 1; j <= 8; j++) {
//              System.out.print(under_bit[i][j]);
//          }
//          System.out.println();
//      }
        if (under_bit[king2_h][king2_v]==0)
            System.out.println("OTHER");
        else {
            for (int i = 0; i < 8; i++) {
                int x = king2_v+dx[i], y = king2_h+dy[i];
                if (x >= 1 && x <= 8 && y >= 1 && y <= 8) {
                    if (x==rook1_v && y==rook1_h || x==rook2_v && y==rook2_h) {
                        if (under_bit[y][x]==1) {
                            System.out.println("OTHER");
                            return;
                        }
                    }
                    else {
                        if (under_bit[y][x]==0) {
                            System.out.println("OTHER");
                            return;
                        }
                    }
                }
            }
            System.out.println("CHECKMATE");
        }
        
    }
    private static void try_(int h, int v) {
        for (int i = v; i <= 8; i++) {
            if (h==king1_h && i==king1_v)
                break;
            under_bit[h][i]++;
        }
        for (int i = v-1; i >= 1; i--) {
            if (h==king1_h && i==king1_v)
                break;
            under_bit[h][i]++;
        }
        for (int i = h; i <= 8; i++) {
            if (v==king1_v && i==king1_h)
                break;
            under_bit[i][v]++;
        }
        for (int i = h-1; i >= 1; i--) {
            if (v==king1_v && i==king1_h)
                break;
            under_bit[i][v]++;
        }
    }
}/*
a6 b4 a4 a8
d3 f5 d5 a1
*/