package java_6.problem_42B.subId_957031;

import java.util.Scanner;

public class B {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String in;
        int[] x = new int[4], y = new int[4];
        for (int i = 0; i < 4; i++) {
            in = sc.next();
            x[i] = in.charAt(0) - 'a' + 1;
            y[i] = in.charAt(1) - '0';
        }
        int[] dx = { -1, -1, -1, 0, 0, 0, 1, 1, 1 };
        int[] dy = { -1, 0, 1, -1, 0, 1, -1, 0, 1 };
        boolean can = false;
        for (int i = 0; i < 9; i++) {
            int nx = x[3] + dx[i];
            int ny = y[3] + dy[i];
            boolean fir = false, sec = false;
            if (nx >= 1 && nx <= 8 && ny >= 1 && ny <= 8) {
                if (nx == x[2] && ny == y[2])
                    continue;
                if (nx == x[0] && ny == y[0])
                    fir = true;
                if (nx == x[1] && ny == y[1])
                    sec = true;
                if ((nx == x[0] && !fir && !(x[2] == nx
                        && y[2] > Math.min(ny, y[0]) && y[2] < Math.max(ny,
                        y[0])))
                        || (nx == x[1] && !sec && !(x[2] == nx
                                && y[2] > Math.min(ny, y[1]) && y[2] < Math
                                .max(ny, y[1])))
                        || (ny == y[0] && !fir && !(y[2] == ny
                                && x[2] > Math.min(nx, x[0]) && x[2] < Math
                                .max(nx, x[0])))
                        || (ny == y[1] && !sec && !(y[2] == ny
                                && x[2] > Math.min(nx, x[1]) && x[2] < Math
                                .max(nx, x[1])))
                        || (nx + ny) == (x[2] + y[2])
                        || (nx - ny) == (x[2] - y[2])
                        || (nx == x[2] && Math.abs(ny - y[2]) == 1)
                        || (ny == y[2] && Math.abs(nx - x[2]) == 1))
                    continue;
                can = true;
            }
        }
        if (can) {
            System.out.println("OTHER");
        } else {
            System.out.println("CHECKMATE");
        }
    }
}