package java_6.problem_42B.subId_876062;

import java.util.Arrays;
import java.util.Scanner;

public class B {
    public static void rook(int x, int y, boolean[][] V, boolean[][] B) {
        for (int i = x - 1; i >= 0; i--) {
            V[i][y] = false;
            if (B[i][y])
                break;
        }
        for (int i = x + 1; i < 8; i++) {
            V[i][y] = false;
            if (B[i][y])
                break;
        }
        for (int j = y - 1; j >= 0; j--) {
            V[x][j] = false;
            if (B[x][j])
                break;
        }
        for (int j = y + 1; j < 8; j++) {
            V[x][j] = false;
            if (B[x][j])
                break;
        }
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String r1 = in.next();
        int x1 = r1.charAt(0) - 'a';
        int y1 = r1.charAt(1) - '1';
        String r2 = in.next();
        int x2 = r2.charAt(0) - 'a';
        int y2 = r2.charAt(1) - '1';
        String k1 = in.next();
        int xk1 = k1.charAt(0) - 'a';
        int yk1 = k1.charAt(1) - '1';
        String k2 = in.next();
        int xk2 = k2.charAt(0) - 'a';
        int yk2 = k2.charAt(1) - '1';
        boolean[][] V = new boolean[8][8];
        boolean[][] B = new boolean[8][8];
        B[x1][y2] = B[x2][y2] = B[xk1][yk1] = true;
        for (int i = 0; i < 8; i++)
            Arrays.fill(V[i], true);
        rook(x1, y1, V, B);
        rook(x2, y2, V, B);
        int[] dx = { 0, 0, 1, -1, 1, 1, -1, -1 };
        int[] dy = { 1, -1, 0, 0, 1, -1, 1, -1 };
        boolean can = false;
        for (int i = 0; i < 8; i++) {
            int X = xk1 + dx[i];
            int Y = yk1 + dy[i];
            if (X < 0 || Y < 0 || X == 8 || Y == 8)
                continue;
            V[X][Y] = false;
        }
        for (int i = 0; i < 8; i++) {
            int X = xk2 + dx[i];
            int Y = yk2 + dy[i];
            if (X < 0 || Y < 0 || X == 8 || Y == 8)
                continue;
            can |= V[X][Y];
        }
        if (!can && !V[xk2][yk2])
            System.out.println("CHECKMATE");
        else
            System.out.println("OTHER");

    }
}