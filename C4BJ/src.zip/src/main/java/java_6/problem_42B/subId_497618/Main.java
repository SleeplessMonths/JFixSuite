package java_6.problem_42B.subId_497618;

import java.io.*;
import java.math.BigInteger;
import java.util.StringTokenizer;

public class Main {
    FastScanner in = new FastScanner(System.in);
    PrintWriter out = new PrintWriter(System.out);

    public static void main(String[] args) {
        new Main().solve();
    }

    void solve() {
        int[][] WKT = new int[8][8];

        String WTura1 = in.next();
        String WTura2 = in.next();
        String WKing = in.next();
        String BKing = in.next();

        int x = 0;
        int y = 0;
        // ////////////////////////////////////////////
        x = getCor(WKing)[0];
        y = getCor(WKing)[1];

        WKT[x][y] = 9;
        int tmpx = -1, tmpy = -1;

        tmpx = x - 1;
        tmpy = y - 1;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            WKT[tmpx][tmpy] = 9;
        }

        tmpx = x - 1;
        tmpy = y;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            WKT[tmpx][tmpy] = 9;
        }

        tmpx = x - 1;
        tmpy = y + 1;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            WKT[tmpx][tmpy] = 9;
        }

        tmpx = x;
        tmpy = y - 1;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            WKT[tmpx][tmpy] = 9;
        }

        tmpx = x;
        tmpy = y + 1;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            WKT[tmpx][tmpy] = 9;
        }

        tmpx = x + 1;
        tmpy = y;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            WKT[tmpx][tmpy] = 9;
        }

        tmpx = x + 1;
        tmpy = y + 1;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            WKT[tmpx][tmpy] = 9;
        }

        tmpx = x + 1;
        tmpy = y - 1;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            WKT[tmpx][tmpy] = 9;
        }
        WKT[x][y] = 1;
        // /////////////////////////////////////////////
        int[][] TT1 = new int[8][8];
        x = getCor(WTura1)[0];
        y = getCor(WTura1)[1];
        TT1[x][y] = 9;
        int KX = getCor(WKing)[0];
        int KY = getCor(WKing)[1];
        if (x < KX)
        for (int i = 0; i < 8; i++) {
            if (WKT[i][y] == 1)
                break;
            else
                TT1[i][y] = 9;
        }
        else 
        for(int i = 7; i>=0; i--){
            if (WKT[i][y] == 1)
                break;
            else
                TT1[i][y] = 9;
        }
        
        if (y < KY){
            for (int i = 0; i<8; i++){
                if (WKT[x][i]==1)
                    break;
                else TT1[x][i] = 9;
                
            }
        }
        else
        for (int i = 7; i >= 0; i--) {
            if (WKT[x][i] == 1)
                break;
            else
                TT1[x][i] = 9;
        }
        TT1[x][y] = 1;
        // /////////////////////////////////////////////
        int[][] TT2 = new int[8][8];
        x = getCor(WTura2)[0];
        y = getCor(WTura2)[1];
        TT2[x][y] = 9;
        if (x < KX)
        for (int i = 0; i < 8; i++) {
            if (WKT[i][y] == 1)
                break;
            else
                TT2[i][y] = 9;
        }
        else
            for (int i = 7; i >= 0; i--) {
                if (WKT[i][y] == 1)
                    break;
                else
                    TT2[i][y] = 9;
            }
        
        if (y < KY){
            for (int i = 0; i<8; i++){
                if (WKT[x][i]==1)
                    break;
                else TT2[x][i] = 9;
                
            }
        }
        else
        for (int i = 7; i >= 0; i--) {
            if (WKT[x][i] == 1)
                break;
            else
                TT2[x][i] = 9;
        }
        TT2[x][y] = 1;
        // ////////////////////////////////////////////
        int[][] black = new int[8][8];
        x = getCor(BKing)[0];
        y = getCor(BKing)[1];
        black[x][y] = 5;
        tmpx = -1;
        tmpy = -1;
        tmpx = x - 1;
        tmpy = y - 1;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            black[tmpx][tmpy] = 5;
        }
        tmpx = x - 1;
        tmpy = y;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            black[tmpx][tmpy] = 5;
        }
        tmpx = x - 1;
        tmpy = y + 1;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            black[tmpx][tmpy] = 5;
        }
        tmpx = x;
        tmpy = y - 1;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            black[tmpx][tmpy] = 5;
        }
        tmpx = x;
        tmpy = y + 1;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            black[tmpx][tmpy] = 5;
        }
        tmpx = x + 1;
        tmpy = y;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            black[tmpx][tmpy] = 5;
        }
        tmpx = x + 1;
        tmpy = y + 1;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            black[tmpx][tmpy] = 5;
        }
        tmpx = x + 1;
        tmpy = y - 1;
        if (tmpx >= 0 && tmpy >= 0 && tmpx <= 7 && tmpy <= 7) {
            black[tmpx][tmpy] = 5;
        }
        black[x][y] = 1;
        // /////////////////////////////////////////////
        boolean f = false;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (black[i][j] == 1){
                    if (WKT[i][j]==0 && TT1[i][j]==0 && TT2[i][j]==0)f = true;
                }
                if (black[i][j] == 5){
                    if (WKT[i][j]==0 && TT1[i][j]==0 && TT2[i][j]==0)f = true;
                    if (WKT[i][j]==1)f = true;
                    if (TT1[i][j]==1){
                        x = i;
                        y = j;
                        if (WKT[x][y]==0 && TT2[x][y]==0)f = true;
                    }
                    if (TT2[i][j]==1){
                        x = i;
                        y = j;
                        if (WKT[x][y]==0 && TT1[x][y]==0)f = true;
                    }
                }
            }
        }
        if (f)System.out.println("OTHER");
        else System.out.println("CHECKMATE");
        // ////////////////////////////////////////////
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                System.out.print(WKT[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                System.out.print(TT1[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                System.out.print(TT2[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                System.out.print(black[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static int[] getCor(String a) {
        char c = a.charAt(0);
        int x = 0;
        int y = Integer.parseInt("" + a.charAt(1)) - 1;
        if (c == 'a') {
            x = 0;
        }
        if (c == 'b') {
            x = 1;
        }
        if (c == 'c') {
            x = 2;
        }
        if (c == 'd') {
            x = 3;
        }
        if (c == 'e') {
            x = 4;
        }
        if (c == 'f') {
            x = 5;
        }
        if (c == 'g') {
            x = 6;
        }
        if (c == 'h') {
            x = 7;
        }
        return new int[] { x, y };
    }
}

// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

class FastScanner {
    BufferedReader br;
    StringTokenizer st;

    FastScanner(InputStream in) {
        br = new BufferedReader(new InputStreamReader(in));
    }

    String next() {
        while (st == null || !st.hasMoreTokens()) {
            try {
                st = new StringTokenizer(br.readLine());
            } catch (IOException e) {
                System.err.println(e);
                return "";
            }
        }
        return st.nextToken();
    }

    int nextInt() {
        return Integer.parseInt(next());
    }

    long nextLong() {
        return Long.parseLong(next());
    }

    double nextDouble() {
        return Double.parseDouble(next());
    }

    float nextFloat() {
        return Float.parseFloat(next());
    }

    BigInteger nextBigInt() {
        return new BigInteger(next());
    }

    void close() {
        try {
            br.close();
        } catch (IOException e) {
        }
    }
}