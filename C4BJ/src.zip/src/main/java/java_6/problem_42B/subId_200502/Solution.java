package java_6.problem_42B.subId_200502;

import java.io.*;

public class Solution {

    StreamTokenizer in;
    PrintWriter out;

    public static void main(String[] args) throws Exception {
        new Solution().run();
    }

    public void run() throws Exception {
        in = new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
        out = new PrintWriter(new OutputStreamWriter(System.out));
        solve();
        out.flush();
    }

    int preobr(char r) throws Exception {
        if (r=='a') {
                 return 1;
            } else
                if (r=='b') {
                    return 2;
                } else
                    if (r=='c') {
                        return 3;
                    } else
                        if (r=='d') {
                            return 4;
                        } else
                            if (r=='e') {
                                return 5;
                            } else
                                if (r=='f') {
                                    return 6;
                                } else
                                    if (r=='g') {
                                        return 7;
                                    } else
                                        if (r=='h') {
                                            return 8;
                                        } else
        return 0;
    }

    public void solve() throws Exception {
        in.ordinaryChars('1', 'h');
        in.wordChars('1', 'h');
        int [] [] a =new int [10][10];
        in.nextToken();
        String s=in.sval;
            char y1= (char)s.charAt(0);
            char x1= (char)s.charAt(1);
        in.nextToken();
        s=in.sval;
            char y2= (char)s.charAt(0);
            char x2= (char)s.charAt(1);
        in.nextToken();
        s=in.sval;
            char y3= (char)s.charAt(0);
            char x3= (char)s.charAt(1);
        in.nextToken();
        s=in.sval;
            char y4= (char)s.charAt(0);
            char x4= (char)s.charAt(1);

            int korx=x3-'0';
            a[korx][preobr(y3)]=2;
            a[korx+1][preobr(y3)]=3;
            a[korx+1][preobr(y3)+1]=3;
            a[korx+1][preobr(y3)-1]=3;
            a[korx][preobr(y3)+1]=3;
            a[korx][preobr(y3)-1]=3;
            a[korx-1][preobr(y3)+1]=3;
            a[korx-1][preobr(y3)]=3;
            a[korx-1][preobr(y3)-1]=3;

            int lad1x=x1-'0';
            a[lad1x][preobr(y1)]=1;
            int i=lad1x;
            while ((i<8)&&(a[i+1][preobr(y1)]!=2))
            {
                a[++i][preobr(y1)]=3;
            }
            i=lad1x;
            while ((i>1)&&(a[i-1][preobr(y1)]!=2))
            {
                a[--i][preobr(y1)]=3;
            }
            i=preobr(y1);
            while ((i<8)&&(a[lad1x][i+1]!=2))
            {
                a[lad1x][++i]=3;
            }
            i=preobr(y1);
            while ((i>1)&&(a[lad1x][i-1]!=2))
            {
                a[lad1x][--i]=3;
            }
            int lad2x=x2-'0';
            a[lad2x][preobr(y2)]=1;
            i=lad2x;
            while ((i<8)&&(a[i+1][preobr(y2)]!=2))
            {
                a[++i][preobr(y2)]=3;
            }
            i=lad2x;
            while ((i>1)&&(a[i-1][preobr(y2)]!=2))
            {
                a[--i][preobr(y2)]=3;
            }
            i=preobr(y2);
            while ((i<8)&&(a[lad2x][i+1]!=2))
            {
                a[lad2x][++i]=3;
            }
            i=preobr(y2);
            while ((i>1)&&(a[lad2x][i-1]!=2))
            {
                a[lad2x][--i]=3;
            }
            for (int j=0; j<10;j++)
                   a[j][0]=3;
             for (int j=0; j<10;j++)
                   a[j][9]=3;
            for (int k=0; k<10;k++)
                   a[0][k]=3;
             for (int k=0; k<10;k++)
                   a[9][k]=3;
            if (a[x4-'0'][preobr(y4)]==3)
            {
                int korx2=x4-'0';
                if ((a[korx2+1][preobr(y4)+1]==3)&&(a[korx2+1][preobr(y4)]==3)&&
                        (a[korx2+1][preobr(y4)-1]==3)&&(a[korx2][preobr(y4)+1]==3)&&
                        (a[korx2][preobr(y4)-1]==3)&&(a[korx2-1][preobr(y4)+1]==3)&&
                        (a[korx2-1][preobr(y4)]==3)&&(a[korx2-1][preobr(y4)-1]==3))
                    out.println("CHECKMATE");
                else out.println("OTHER");
            } else out.println("OTHER");

    }

}