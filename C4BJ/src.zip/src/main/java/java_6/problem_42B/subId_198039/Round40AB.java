package java_6.problem_42B.subId_198039;

import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Madi
 */
public class Round40AB {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] in = sc.nextLine().split(" ");

        int x1 = in[0].charAt(0) - 'a';
        int y1 = Integer.parseInt("" + in[0].charAt(1)) - 1;
        int x2 = in[1].charAt(0) - 'a';
        int y2 = Integer.parseInt("" + in[1].charAt(1)) - 1;
        int x3 = in[2].charAt(0) - 'a';
        int y3 = Integer.parseInt("" + in[2].charAt(1)) - 1;
        int x4 = in[3].charAt(0) - 'a';
        int y4 = Integer.parseInt("" + in[3].charAt(1)) - 1;

        boolean[][] k = new boolean[8][8];

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i == y1 || i == y2) {
                    k[i][j] = true;
                }

                if (j == x1 || j == x2) {
                    k[i][j] = true;
                }

                if (Math.abs(j - x3) <= 1 && Math.abs(i - y3) <= 1) {
                    k[i][j] = true;
                }
            }
        }

        if (x1 == x3) {
            if (y1 > y3) {
                for (int i = y3 - 2; i >= 0; i--) {
                    k[i][x3] = false;
                }
            } else {
                for (int i = y3 + 2; i < 8; i++) {
                    k[i][x3] = false;
                }
            }
        }
        
        if (y1 == y3) {
            if (x1 > x3) {
                for (int i = x3 - 2; i >= 0; i--) {
                    k[y3][i] = false;
                }
            } else {
                for (int i = x3 + 2; i < 8; i++) {
                    k[y3][i] = false;
                }
            }
        }
        
        if (y2 == y3) {
            if (x2 > x3) {
                for (int i = x3 - 2; i >= 0; i--) {
                    k[y3][i] = false;
                }
            } else {
                for (int i = x3 + 2; i < 8; i++) {
                    k[y3][i] = false;
                }
            }
        }
        
        if (x2 == x3) {
            if (y2 > y3) {
                for (int i = y3 - 2; i >= 0; i--) {
                    k[i][x3] = false;
                }
            } else {
                for (int i = y3 + 2; i < 8; i++) {
                    k[i][x3] = false;
                }
            }
        }

        boolean check = true;
        if (x4 - 1 >= 0 && !k[y4][x4 - 1]) {
            check = false;
        }

        if (x4 + 1 < 8 && !k[y4][x4 + 1]) {
            check = false;
        }

        if (y4 - 1 >= 0 && !k[y4 - 1][x4]) {
            check = false;
        }

        if (y4 + 1 < 8 && !k[y4 + 1][x4]) {
            check = false;
        }

        if (!k[y4][x4]) {
            check = false;
        }

        if (check) {
            boolean kk = false;

            if (x1 != x2 && y1 != y2 && !(Math.abs(x1 - x3) <= 1 && Math.abs(y1 - y3) <= 1)) {
                if (Math.abs(x4 - x1) <= 1 && Math.abs(y4 - y1) <= 1) {
                    kk = true;
                }
            }

            if (x1 != x2 && y1 != y2 && !(Math.abs(x2 - x3) <= 1 && Math.abs(y2 - y3) <= 1)) {
                if (Math.abs(x4 - x2) <= 1 && Math.abs(y4 - y2) <= 1) {
                    kk = true;
                }
            }

            if (kk) {
                System.out.println("OTHER");
            } else {
                System.out.println("CHECKMATE");
            }

        } else {
            System.out.println("OTHER");
        }


    }
}