package java_6.problem_171D.subId_3429171;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class P171D_BrokenChecker {

    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int a = Integer.parseInt(in.readLine());
        System.out.println(f(a));
    }
    
    public static int f(int a) {
        return 1;
    }
}