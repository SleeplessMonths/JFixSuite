package java_6.problem_171D.subId_3751895;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class d{
public static void main(String args[]) throws IOException{
BufferedReader lector = new BufferedReader(new InputStreamReader(System.in));
String t = lector.readLine();
System.out.println(t);
}
}