package java_6.problem_171D.subId_3608348;

import java.util.Scanner;

public class BrokenChecker {
	private static Scanner in = new Scanner(System.in);

	public static void main(String[] args) {
		int a = in.nextInt();
		
		//1: 1
		//2: 2
		//3: 2
		//4: 
		//5: 
		
		int[] ret = new int[6];
		ret[1] = 2;
		ret[2] = 1;
		ret[3] = 1; //for sure
		ret[4] = 2; //for sure
		ret[5] = 1; //test 5
		
		System.out.println(ret[a]);
	}
}