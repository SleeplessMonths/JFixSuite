package java_6.problem_171D.subId_3608460;

import java.util.Scanner;


public class Brokenchecker {
    Scanner in =new Scanner(System.in);
    public static void main(String args[]){
        new Brokenchecker().go();
    }
    public void go(){
        int b[]= new int[6];
        b[1]=1;
        b[2]=1;
        b[3]=2;
        b[4]=3;
        b[5]=3;
        int count=1;
        int prev=0;
            int a=in.nextInt();
            System.out.println(b[a]);
    }
}