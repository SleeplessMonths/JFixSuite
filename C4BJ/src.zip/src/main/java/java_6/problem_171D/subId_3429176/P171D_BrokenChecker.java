package java_6.problem_171D.subId_3429176;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class P171D_BrokenChecker {

    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int a = Integer.parseInt(in.readLine());
        System.out.println(f(a));
    }
    
    public static int f(int a) {
        if (a == 1) return 2;
        if (a == 2) return 3;
        if (a == 3) return 1;
        if (a == 4) return 2;
        return 3;
    }
}