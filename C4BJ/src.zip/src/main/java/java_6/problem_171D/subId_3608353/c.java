package java_6.problem_171D.subId_3608353;

import java.util.Scanner;
public class c {

	/**
	 * @param args
	 */
	static Scanner in=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=in.nextInt();
		if(n==3)System.out.println(1);
		else if(n==1) System.out.println(2);
		else System.out.println(0);
	}

}