package java_6.problem_178D1.subId_1664583;

import java.io.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.StringTokenizer;

public class Main {
    Scanner in;
    PrintWriter out;

    void setIn(String fI) {

        try {
            in = new Scanner(new FileInputStream(new File(fI)));
        } catch (FileNotFoundException e) {
            throw new Error(e);
        }
    }

    void setIn() {
        in = new Scanner(System.in);
    }

    void setOut(String fO) {
        try {
            out = new PrintWriter(new FileWriter(fO));
        } catch (IOException e) {
            throw new Error(e);
        }
    }

    void setOut() {
        out = new PrintWriter(System.out);
    }

    class Scanner {
        StringTokenizer st;
        BufferedReader in;
        String del;

        Scanner(InputStream is) {
            in = new BufferedReader(new InputStreamReader(is));
            st = null;
            del = " \t\n\r\f";
        }

        void setDelimiters(String del) {
            this.del = del;
        }

        String next() {
            if (st == null || !st.hasMoreTokens()) {
                st = new StringTokenizer(nextLine(), del);
            }
            return st.nextToken();
        }

        String nextLine() {
            try {
                st = null;
                return in.readLine();
            } catch (IOException e) {
                throw new Error(e);
            }
        }

        boolean hasNext() {
            try {
                return in.ready() || (st != null && st.hasMoreTokens());
            } catch (IOException e) {
                throw new Error(e);
            }
        }

        int nextInt() {
            return Integer.parseInt(next());
        }

        long nextLong() {
            return Long.parseLong(next());
        }

        BigInteger nextBigInteger() {
            return new BigInteger(next());
        }

        BigDecimal nextBigDecimal() {
            return new BigDecimal(next());
        }

        int[] nextIntArray(int len) {
            int[] a = new int[len];
            for (int i = 0; i < len; i++) {
                a[i] = nextInt();
            }
            return a;
        }

        double nextDouble() {
            return Double.parseDouble(next());
        }
    }

    public static void main(String[] args) {
        new Main().run();
    }

    void run() {
        setIn();
        setOut();
        try {
            solve();
        } finally {
            out.close();
        }
    }

    int s;
    boolean used[];
    int n;

    boolean isMagic(int[] b) {
        int[] a[] = new int[n][n];
        int index = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = b[index++];
            }
        }
        int d1 = 0;
        int d2 = 0;
        for (int i = 0; i < n; i++) {
            int curS1 = 0;
            int curS2 = 0;
            for (int j = 0; j < n; j++) {
                curS1 += a[i][j];
                curS2 += a[j][i];
            }
            if (curS1 != s || curS2 != s) {
                return false;
            }
            d1 += a[i][i];
            d2 += a[i][n - i - 1];
        }
        return d1 == s && d2 == s;
    }

    class Solution extends Exception {
    }

    int[] sourse;

    void out(int[] a) {
        for (int i = 0; i < a.length; i++) {
            out.print(a[i] + " ");
        }
        out.println();
        return;
    }

    void go(int[] a, int cnt) throws Solution {
        if (cnt == a.length) {
            if (isMagic(a)) {
                int index = 0;
                for (int i = 0; i < n; i++) {
                    for (int j = 0; j < n; j++) {
                        out.print(a[index++] + " ");
                    }
                    out.println();
                }
                throw new Solution();
            }
            return;
        }
        for (int i = 0; i < sourse.length; i++) {
            if (!used[i]) {
                used[i] = true;
                a[cnt] = sourse[i];
                go(a, cnt + 1);
                used[i] = false;
            }
        }

    }

    void solve() {
        n = in.nextInt();
        int[] a = in.nextIntArray(n * n);
        for (int i = 0; i < a.length; i++) {
            s += a[i];
        }
        s /= n;
        sourse = a.clone();
        if (n <= 3) {
            used = new boolean[n * n];
            try {
                go(new int[n * n], 0);
            } catch (Solution e) {
            }
            return;
        }

    }
}