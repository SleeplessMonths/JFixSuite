package java_6.problem_139A.subId_8543447;

import java.util.Scanner;

public class Codeforce{
public static void main(String[] args){
    Scanner s=new Scanner(System.in);
    int n=s.nextInt();
    int[] a=new int[7];
    for(int i=0;i<7;i++){
        a[i]=s.nextInt();
    }
    int count=0;
    int i=0;
    while(count<n){
        count=count+a[i%7];
        i++;
    }
    if(i==7)
    System.out.print(7);
    else
        System.out.print(i%7);
}
}