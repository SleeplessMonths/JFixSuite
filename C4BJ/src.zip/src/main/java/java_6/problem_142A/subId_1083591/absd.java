package java_6.problem_142A.subId_1083591;

import java.util.Scanner;


public class absd {

    
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        
        long n = s.nextLong();
        long min = Long.MAX_VALUE;
        long max = Long.MIN_VALUE;
        
        for (long a = 1; a * a * a <= n; a++) {
            if(n%a==0){
                for (long b = 1; b * b <= n/a; b++) {
                    if((n/a)%b==0){
                        long c = n/a/b;
                        long r1 = (a+1)*(b+2)*(c+2);
                        long r2 = (a+2)*(b+1)*(c+2);
                        long r3 = (a+2)*(b+2)*(c+1);
                        min = Math.min(min, r1);
                        min = Math.min(min, Math.min(r2, r3));
                        max = Math.max(max, r1);
                        max = Math.max(max, Math.max(r2, r3));
                    }
                }
                
            }
        }
        System.out.println(min+" "+max);
    }

}