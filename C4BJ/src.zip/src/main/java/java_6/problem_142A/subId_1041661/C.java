package java_6.problem_142A.subId_1041661;

import java.util.Arrays;
import java.util.Scanner;

public class C {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        long n = in.nextInt();
        long min = Integer.MAX_VALUE;
        long max = Integer.MIN_VALUE;
        for (long i = 1; i * i <= n; i++) {
            if (n % i != 0)
                continue;
            for (long j = 1; j * j * i <= n; j++) {
                if ((n / i) % j != 0)
                    continue;
                long[] x = { i, j, n / i / j };
                Arrays.sort(x);
                long totMax = (x[2] + 1) * (x[0] + 2) * (x[1] + 2);
                long totMin = (x[0] + 1) * (x[2] + 2) * (x[1] + 2);
                min = Math.min(totMin - n, min);
                max = Math.max(totMax - n, max);
            }
        }
        System.out.println(min + " " + max);
    }
}