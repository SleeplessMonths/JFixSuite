package java_6.problem_142A.subId_1097284;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Built using CHelper plug-in
 * Actual solution is at the top
 * @author codeKNIGHT
 */
public class Main {
	public static void main(String[] args) {
		InputStream inputStream = System.in;
		OutputStream outputStream = System.out;
		Scanner in = new Scanner(inputStream);
		PrintWriter out = new PrintWriter(outputStream);
		Task solver = new Task();
		solver.solve(1, in, out);
		out.close();
	}
}

class Task {
	public void solve(int testNumber, Scanner in, PrintWriter out) {
        int n=in.nextInt();
        int a,b,c;
        long max=0,min=Integer.MAX_VALUE,k;
        int ar[]=new int[3];
        for(a=1;a*a<=n;a++)
        {
            if(n%a==0)
                for(b=a;b*b<=(n/a);b++)
                    if((n/a)%b==0)
                    {
                        c=(n/a)/b;
                        ar[0]=a;ar[1]=b;ar[2]=c;
                        Arrays.sort(ar);
                        max=Math.max(max,(ar[2]+1)*(ar[1]+2)*(ar[0]+2)-n);
                        min=Math.min(min,(ar[0]+1)*(ar[1]+2)*(ar[2]+2)-n);
                    }

        }
        out.println(min+" "+max);
	}
}