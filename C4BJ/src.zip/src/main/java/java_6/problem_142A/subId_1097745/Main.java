package java_6.problem_142A.subId_1097745;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String... args) {
        Scanner scanner = new Scanner(System.in);
        Long n = new Long(scanner.nextLine());
        Long max = 8*n+9;
        Long min = max;
        for (Long a : dividers(n)) {
            for (Long b : dividers(n/a)) {
                for (Long c : dividers(b)) {
                    if (a*b*c!=n) continue;
                    Long buf = (a+1)*(b+2)*(c+2) - n;
                    if (buf < min) min = buf;
                }
            }
        }
        System.out.println(min + " " + max);
    }

    static List<Long> dividers(long x) {
        LinkedList<Long> ret = new LinkedList<Long>();
        for (long i = 1; i < (int)Math.sqrt(x) + 1; i++) {
            if (x%i==0) {ret.add(x/i);ret.add(x/ret.getLast());}
        }
        return ret;
    }
}