package java_6.problem_142A.subId_1509318;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class Solution {
    public static void main(String[] args) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter out = new PrintWriter(System.out);

        long n = Integer.parseInt(in.readLine());

        long min = Integer.MAX_VALUE, max = 2 * (n + 1 + n + 1 + n + 1) + (n + 1 + 1 + n + 1);

        for (long a = 1; a * a * a <= n; a++)
            if (n % a == 0)
                for (long b = 1; b * b <= n / a; b++)
                    if ((n / a) % b == 0) {
                        long c = (n / a) / b, locMin = (2 * (a + 1) * (b + 2) + 2 * c * (a + 1) + b * c);
                        min = Math.min(min, locMin);
                    }

        out.println(min + " " + max);
        out.close();
    }
}