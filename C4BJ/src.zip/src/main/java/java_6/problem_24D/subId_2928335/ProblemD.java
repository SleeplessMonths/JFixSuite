package java_6.problem_24D.subId_2928335;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Arrays;

public class ProblemD {

	public static void main(String[] args) throws IOException {
		BufferedReader s = new BufferedReader(new InputStreamReader(System.in));
		PrintWriter out = new PrintWriter(System.out);

		String[] line = s.readLine().split(" ");
		int n = Integer.valueOf(line[0]);
		int m = Integer.valueOf(line[1]);
		
		String[] now = s.readLine().split(" ");
		int y = Integer.valueOf(now[0]);
		int x = Integer.valueOf(now[1]);
		
		if (y == n) {
			out.println(0);
			out.flush();
			return;
		} else if (m == 1) {
			out.println((y - n) * 2);
			out.flush();
			return;
		}
		
		
		double[] z = new double[m];
		for (int i = n-1 ; i >= y ; i--) {
			double[] a = new double[m];
			double[] b = new double[m];
			double[] c = new double[m];
			double[] d = new double[m];
			for (int j = 0 ; j < m ; j++) {
				double hand = 4;
				if (j == 0 || j == m - 1) {
					hand = 3;
				}
				b[j] = 1.0d * (hand - 1) / hand;
				d[j] = 1.0d + z[j] / hand;
				if (j >= 1) {
					a[j] = -1.0d / hand;
				}
				if (j <= m - 2) {
					c[j] = -1.0d / hand;
				}
			}
			z = solveTridiagonal(a, b, c, d);
		}
		out.println(z[x-1]);
		out.flush();
	}

	private static double[] solveTridiagonal(double[] a, double[] b, double[] c, double[] d) {
		int n = a.length;
		double[] answer = new double[n];
		for (int i = 1 ; i < n ; i++) {
			double m = a[i] / b[i-1];
			b[i] = b[i] - m * c[i-1];
			d[i] = d[i] - m * d[i-1];
		}
		answer[n-1] = d[n-1] / b[n-1];
		for (int i = n - 2 ; i >= 0 ; i--) {
			answer[i] = (d[i] - c[i] * answer[i+1]) / b[i];
		}
		return answer;
	}

	public static void debug(Object... os){
		System.err.println(Arrays.deepToString(os));
	}
}