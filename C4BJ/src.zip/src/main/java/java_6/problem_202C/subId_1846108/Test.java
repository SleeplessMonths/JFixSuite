package java_6.problem_202C.subId_1846108;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class Test {
	static BufferedReader reader;
	static StringTokenizer tokenizer;
	static PrintWriter writer;

	static int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	static long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	static double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	static String nextToken() throws IOException {
		while (tokenizer == null || !tokenizer.hasMoreTokens()) {
			tokenizer = new StringTokenizer(reader.readLine());
		}
		return tokenizer.nextToken();
	}

	public static void main(String[] args) throws IOException {
		reader = new BufferedReader(new InputStreamReader(System.in));
		tokenizer = null;
		writer = new PrintWriter(System.out);
		solve();
		reader.close();
		writer.close();
	}

	private static void solve() throws IOException {
		int x = nextInt();
		int n=0;
		for(n=1;n<10000;n+=2)
		{
			int f = (n-1)/2;
			if(f%2==0 && 2*f*f+2*f+1>=x)
			{
				break;
			}
			if(f%2==1 && 2*(f-1)*(f-1)+4*f+2*(f-1)+1>=x)
			{
				break;
			}
		}
		if(x==2 || x==3)
		{
			writer.println(5);
		}
		else
		{
			writer.println(n);
		}
	}
}