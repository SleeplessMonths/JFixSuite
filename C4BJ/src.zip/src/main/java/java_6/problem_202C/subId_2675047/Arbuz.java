package java_6.problem_202C.subId_2675047;

//package arbuz;

import java.util.Scanner;

public class Arbuz {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] Capacity = new int[101];
        int i;
        for (i = 0; i < 101; i++) {
            Capacity[i] = (int) (Math.pow(i, 2) + 1) / 2;
        }
        int x = sc.nextInt();
        if (x == 3) {
            System.out.println(5);
        } else {
            i = 0;
            while (x > Capacity[i]) {
                i += 2;
            }
            System.out.println(i);
        }
    }
}