package java_6.problem_202C.subId_1847977;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int x = sc.nextInt();
        
        if (x==3)
            System.out.print(3);
        else
        {
            int i = 1;
            while(true) 
            {
                if (i*i/2+1 >= x)
                {
                    System.out.print(i);
                    break;
                }
                i+=2;
            }
        }
    }
}