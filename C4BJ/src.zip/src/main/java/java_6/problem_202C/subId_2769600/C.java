package java_6.problem_202C.subId_2769600;

import java.util.Scanner;

public class C {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        int n = 0;
        if(x == 1){
            n = 1;
        }else if (x == 2) {
            n = 3;
        }else if (x == 3) {
            n = 5;
        }else {
            n = (int) Math.ceil(Math.sqrt(2*x-1));
        }
        System.out.println(n);
    }
}