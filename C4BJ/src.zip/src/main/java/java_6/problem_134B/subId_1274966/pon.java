package java_6.problem_134B.subId_1274966;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.util.List;
import java.util.Scanner;

import static java.lang.System.out;

public class pon {

    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static Scanner sc = new Scanner(System.in);

    public static String getString() {
        try {
            return br.readLine();
        } catch (Exception e) {
        }
        return "";
    }

    public static Integer getInt() {
        try {
            return Integer.parseInt(br.readLine());
        } catch (Exception e) {
        }
        return 0;
    }

    public static Integer[] getIntArr() {
        try {
            String temp[] = br.readLine().split(" ");
            Integer temp2[] = new Integer[temp.length];
            for (int i = 0; i < temp.length; i++) {
                temp2[i] = Integer.parseInt(temp[i]);
            }
            return temp2;
        } catch (Exception e) {
        }
        return null;
    }

    public static int getMax(Integer[] ar) {
        int t = ar[0];
        for (int i = 0; i < ar.length; i++) {
            if (ar[i] > t) {
                t = ar[i];
            }
        }
        return t;
    }

    public static void printList(List<Integer> a) {
        System.out.println(a.toString().replace("[", "").replace("]", "").replace(",", ""));
    }

    public static void print(Object a) {
        out.println(a);
    }

    public static int nextInt() {
        return sc.nextInt();
    }

    public static BigInteger getFact(long in) {
        BigInteger ot = new BigInteger("1");
        for (Integer i = 1; i <= in; i++) {
            ot = ot.multiply(new BigInteger(i.toString()));
        }
        return ot;
    }

    public static String gbase(int a, int base) {
        String out = "";
        int temp = a;
        while (temp > 0) {
            out = temp % base + out;
            temp /= base;
        }
        return out;
    }

    public static void main(String[] ar) {
        int input = getInt();
        int out=Integer.MAX_VALUE;
        for (int i = 1; i <= input; i++) {
            int a = input;
            int b = i;
            int c = a % b;
            int step = a / b;            
            while (c > 0) {
                a = b;
                b = c;
                c= a%b;
                step += a / b;
            }
            //print(step);
            if(step!=1){
                //print(step);
                out=Math.min(out,step);
            }
        }
        print (out-1);
    }
}