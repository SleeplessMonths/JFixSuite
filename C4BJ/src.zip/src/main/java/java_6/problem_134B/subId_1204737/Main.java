package java_6.problem_134B.subId_1204737;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.StringTokenizer;

public class Main
{	
	public BufferedReader in;
	public PrintStream out;
	
	public int calc(int a, int b)
	{
		if (a<b)
		{
			return calc(b,a);
		}
		
		if (b==0)
		{
			return -1;
		}
		
		if (b==1)
		{
			return a-b;
		}
		
		return  calc(b, a% b) + a/b;
	}
	
	public void test()
	{
		int n = readInt();
		int min = n-1;
		int c;
		
		for (int k=2; k<n; k++)
		{
			c = calc(n,k);
			if ((c>=0)&&(c<min))
			{
				min = c;
			}
		}
		
		out.println(min);
	}
    
	public void run()
	{
		try
		{
			in = new BufferedReader(new InputStreamReader(System.in));
			out = System.out;
			
			//in = new BufferedReader(new FileReader("in.txt"));
			//out = new PrintStream(new File("out.txt"));
			
			
		}
		catch (Exception e)
		{
			return;
		}
		
		//while (true)
		{
			//int t = readInt(); for (int i=0; i<t; i++)					
			{
				test();
			}
		}
	}
	
	public static void main(String args[])
	{
		new Main().run();
	}
	
	private StringTokenizer tokenizer = null;
	
	public int readInt() 
	{
        return Integer.parseInt(readToken());
    }
   
    public long readLong() 
	{
        return Long.parseLong(readToken());
    }
   
    public double readDouble() 
	{
        return Double.parseDouble(readToken());
    }
   
	public String readLn()
	{	
		try
		{
			String s;
			while ((s = in.readLine()).length()==0);
			return s;
		}
		catch (Exception e)
		{
			return "";
		}
	}
	
    public String readToken() 
	{
		try
		{
			while (tokenizer == null || !tokenizer.hasMoreTokens()) 
			{
				tokenizer = new StringTokenizer(in.readLine());
			}
			return tokenizer.nextToken();
		}
		catch (Exception e)
		{
			return "";
		}
    }
	
	public int[] readIntArray(int n)
	{
		int[] x = new int[n];
		readIntArray(x, n);
		return x;
	}
	
	public void readIntArray(int[] x, int n)
	{
		for (int i=0; i<n; i++)
		{
			x[i] = readInt();
		}
	}
}