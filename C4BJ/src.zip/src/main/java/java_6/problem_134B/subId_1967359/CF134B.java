package java_6.problem_134B.subId_1967359;

/**
 * @author Juan Sebastian Beltran Rojas
 * @mail jsbeltran.valhalla@gmail.com
 * @veredict No enviado
 * @problemId 134B
 * @problemName Pairs of Numbers
 * @judge http://www.codeforces.com/
 * @category math
 * @level easy
 * @date 01/08/2012
 **/

import java.io.BufferedReader;
import java.io.InputStreamReader;

import static java.lang.Integer.MAX_VALUE;
import static java.lang.Integer.parseInt;
import static java.lang.Math.max;
import static java.lang.Math.min;

public class CF134B{
	static int f(int a,int b){
		int c;
		if(a==1||b==1)return max(a,b)-1;
		if(a>b&&a%b!=0&&(c=f(a%b,b))!=MAX_VALUE)return c+a/b;
		if(b>a&&b%a!=0&&(c=f(a,b%a))!=MAX_VALUE)return c+b/a;
		return MAX_VALUE;
	}
	public static void main(String args[]) throws Throwable{
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		int n=parseInt(in.readLine()),r=MAX_VALUE;
		for(int i=1;i<n;i++)r=min(r,f(n,i));
		System.out.println(r);
	}
}