package java_6.problem_168A.subId_8287161;

import java.util.Scanner;

public class Main {



	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		int n=scanner.nextInt();
		int x=scanner.nextInt();
		int y=scanner.nextInt();
		scanner.close();		
		
		System.out.println((int) Math.ceil(n*y/(double)100)-x);
		
	}
}