package java_6.problem_168A.subId_8287227;

import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int x = in.nextInt();
		int y = in.nextInt();
		
		//System.out.println("n:" + n);
		//System.out.println("x:" + x);
		//System.out.println("y:" + y);
		
		double a = (y*n)/100.0;
		
		double puppets = a - x;
		
		//System.out.println(a);
		//System.out.println(puppets);
		int p = (int)Math.ceil(puppets);
		System.out.println(p);
		
	}

}