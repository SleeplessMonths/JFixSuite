package java_6.problem_168A.subId_8287100;

import java.util.Scanner;


public class Main1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner input;
                input = new Scanner(System.in);
      
                double n=input.nextDouble();
                double x=input.nextDouble();
                double y=input.nextDouble();
                double ne=y*n/100;
                
                
                if(x>=ne)
                    System.out.println(0);
                else
                    System.out.println((int)(Math.floor(ne-x) + 1));
      
    }
    
}