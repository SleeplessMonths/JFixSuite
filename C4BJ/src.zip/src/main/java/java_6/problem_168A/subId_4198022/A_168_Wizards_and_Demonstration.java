package java_6.problem_168A.subId_4198022;

import java.util.Scanner;

public class A_168_Wizards_and_Demonstration {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int x = sc.nextInt();
		int y = sc.nextInt();
		int clone = (int) (Math.ceil((n * y) / 100) - x);
		if (clone > 0)
			System.out.println(clone);
		else
			System.out.println(0);
	}
}