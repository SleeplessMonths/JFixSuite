package java_6.problem_168A.subId_5324760;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String[] s = in.readLine().split(" ");
        int n, x, y;
        n = Integer.parseInt(s[0]);
        x = Integer.parseInt(s[1]);
        y = Integer.parseInt(s[2]);
        
        int needed = Math.round(n * y / 100);

        System.out.println(needed <= x ? 0 : needed - x);
    }
}