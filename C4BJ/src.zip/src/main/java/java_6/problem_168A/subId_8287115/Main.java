package java_6.problem_168A.subId_8287115;

import java.util.Scanner;

public class Main {
	public static void main(String[] argu){
		Scanner scanner = new Scanner(System.in);
		long n = scanner.nextInt();
		int x = scanner.nextInt();
		int y = scanner.nextInt();
		
		long k =(long)Math.ceil(n*y*1.0/100);
		System.out.println(k-x);
		
	}
}