package java_6.problem_168A.subId_8287232;

import java.util.Scanner;

public class Main {
    
    public static void main (String[] args)
	{ 
        Scanner in = new Scanner(System.in);
        int num = in.nextInt();
        int wiz = in.nextInt();
        int per = in.nextInt();
        double clones = 0;
        int answer = 0;
        clones = (per / 100.0) * num - wiz;
        answer = (int) Math.ceil(clones);
        System.out.println(answer);   
	}
}