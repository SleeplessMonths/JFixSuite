package java_6.problem_168A.subId_8287165;

import java.util.Scanner;

/**
 *
 * @author sahil
 */
public class Main1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner input;
                input = new Scanner(System.in);
      
                int n=input.nextInt();
                int x=input.nextInt();
                int y=input.nextInt();
                double ne=(float)(y)*(float)(n)/100;
                
                
                if((float)(x)>=ne)
                    System.out.println(0);
                else
                {
                    if(ne==(int)(ne))
                        System.out.println((int)((Math.floor(ne-x)) + 1));
                    else
                    System.out.println((int)(Math.ceil(ne-x)));
                }
                
                
        // TODO code application logic here
    }
    
}