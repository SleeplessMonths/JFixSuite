package java_6.problem_168A.subId_8287143;

public class Main {

	public static void main(String[] args) {
		java.util.Scanner input = new java.util.Scanner(System.in);
		
		float pop = input.nextFloat();
		float wiz = input.nextInt();
		float per = input.nextFloat();
		
		float needed = pop * (per/100);
		if(needed % 1 != 0) needed = needed - (needed % 1) + 1;
		
		int clones = (int)(needed) - (int)(wiz);
		
		System.out.println(clones);

	}

}