package java_6.problem_168A.subId_8287368;

// Oct 17, question A
// java Main < input.txt < myoutput.txt

import java.util.Scanner;

public class Main {

    public static void pn (Object o) {System.out.println(o);}
    
    public static void main(String[] args)  throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int x = scan.nextInt();
        int y = scan.nextInt();
        
        pn( ( (y*n) / 100) - x + ( (y*n)%100 > 0 ? 1 : 0));
    }
}