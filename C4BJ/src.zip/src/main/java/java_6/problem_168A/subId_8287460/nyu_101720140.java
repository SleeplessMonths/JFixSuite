package java_6.problem_168A.subId_8287460;

import java.util.Scanner;

public class nyu_101720140 {
	public static void main (String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();		//city population
		int x = scanner.nextInt();		//number of wizards
		int y = scanner.nextInt();		//percentage over 100
		double percentage = (double)y / 100.0d;
		//percentage = percentage - ((double)x / (double)n);
		double temp = (double)n * percentage;
		n = (int)(Math.ceil(temp-x));
		System.out.println(n);
	}
}