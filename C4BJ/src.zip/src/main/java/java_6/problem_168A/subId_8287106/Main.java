package java_6.problem_168A.subId_8287106;

// Oct 17, question A
// java Main < input.txt < myoutput.txt

import java.util.Scanner;

public class Main {

    // Shortened functions for printing
    public static void p (Object o) {System.out.print(o);} 
    public static void pn (Object o) {System.out.println(o);}
    
    public static void main(String[] args)  throws Exception {
        Scanner scan = new Scanner(System.in);
        long n = (long) scan.nextInt();
        long x = (long) scan.nextInt();
        long y = (long) scan.nextInt();
        
        pn( (int) ((Math.ceil((y*n)/100.0)) - x) );
    }
}