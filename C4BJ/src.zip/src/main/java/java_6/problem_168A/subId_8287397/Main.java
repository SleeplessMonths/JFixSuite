package java_6.problem_168A.subId_8287397;

import java.util.Scanner;

public class Main {
	
	public static void main(String[] asd) throws Exception
	{
		Scanner in = new Scanner(System.in);
		int citizens = in.nextInt();
		int wizards = in.nextInt();
		int percent = in.nextInt();
		
		//System.out.println(citizens);
		//System.out.println(wizards);
		//System.out.println(percent);
		
		
		float numWizardsNeeded = (percent * citizens) / (float)100;
		//System.out.println(numWizardsNeeded);
		float clones = numWizardsNeeded - wizards;
		System.out.println((int)Math.ceil(clones));
		
	}	
}