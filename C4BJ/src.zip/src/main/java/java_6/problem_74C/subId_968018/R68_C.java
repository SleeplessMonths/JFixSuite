package java_6.problem_74C.subId_968018;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class R68_C {
    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String[] s = in.readLine().split(" ");
        int n = Integer.parseInt(s[0]) - 1;
        int m = Integer.parseInt(s[1]) - 1;
        if(n>m){
            int t = n;
            n = m;
            m = n;
        }
        int tot = 2 * (n+m);
        DisjointSets1 t = new DisjointSets1(tot);
        for (int i = 0; i < tot; i++) {
            t.makeSet(i);
        }
        for (int i = 0; i < (n+m); i++) {
            int k = (tot-i)%tot;
            if (t.find(i) != t.find(k))
                t.union(i, k);
        }
        int l = 0;
        for (int i = n; i < (n+n+m); i++) {
            int k = (n-l)<0?n-l+tot:n-l;
            if (t.find(i) != t.find(k))
                t.union(i, k);
            l++;
        }   
        System.out.println(t.countDSets());
    }
}

class DisjointSets1 {
    // if the integer elements can be indexes in array map them.
    static int[] parent;
    static int[] rank;
    static int[] size;

    public DisjointSets1(int n) {
        parent = new int[n];
        rank = new int[n];
        size = new int[n];
    }

    public static void makeSet(int x) {
        parent[x] = x;
        rank[x] = 0;
        size[x] = 1;
    }

    public static int find(int x) {
        if (x != parent[x])
            parent[x] = find(parent[x]);
        return parent[x];
    }

    static void union(int x, int y) {
        int px = find(x);
        int py = find(y);
        if (rank[px] > rank[py]) {
            parent[py] = px;
            size[px] += size[py];
        } else {
            parent[px] = py;
            size[py] += size[px];
        }
        if (rank[px] == rank[py])
            rank[py] = rank[py] + 1;
    }

    public int countDSets() {
        int c = 0;
        for (int i = 0; i < parent.length; i++)
            if (parent[i] == i)
                c++;
        return c;
    }
}