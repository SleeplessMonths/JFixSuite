package java_6.problem_74C.subId_809517;

import java.io.DataInputStream;
import java.io.InputStream;
import java.util.Scanner;
public class Main
{
    int[] more;
    public static void main(String[]args) throws Exception
    {
        Main s = new Main();
        s.gimmiepoints();
    }
    
    public void gimmiepoints() throws Exception
    {
        //Parser in = new Parser(System.in);
        StringBuilder out = new StringBuilder();
        Scanner in = new Scanner(System.in);
        while(in.hasNext()){
            long a = in.nextLong();
            long b = in.nextLong();
            if(a==b) System.out.println(a);
            else if( a == 1) System.out.println(b);
            else if(b == 1) System.out.println(a);
            else System.out.println(2);
            
        }
    }
    
}

class Parser
{
   final private int BUFFER_SIZE = 1 << 16;

   private DataInputStream din;
   private byte[] buffer;
   private int bufferPointer, bytesRead;

   public Parser(InputStream in)
   {
      din = new DataInputStream(in);
      buffer = new byte[BUFFER_SIZE];
      bufferPointer = bytesRead = 0;
   }

   public long nextLong() throws Exception
   {
      long ret = 0;
      byte c = read();
      while (c <= ' ') c = read();
      boolean neg = c == '-';
      if (neg) c = read();
      do
      {
         ret = ret * 10 + c - '0';
         c = read();
      } while (c > ' ');
      if (neg) return -ret;
      return ret;
   }

   public int nextInt() throws Exception
   {
      int ret = 0;
      byte c = read();
      while (c <= ' ') c = read();
      boolean neg = c == '-';
      if (neg) c = read();
      do
      {
         ret = ret * 10 + c - '0';
         c = read();
      } while (c > ' ');
      if (neg) return -ret;
      return ret;
   }
   public String next() throws Exception
   {
      StringBuilder ret =  new StringBuilder();
      byte c = read();
      while (c <= ' ') c = read();
      do
      {
         ret = ret.append((char)c);
         c = read();
      } while (c > ' ');
      //System.out.println(ret + "!!!!!!");
      return ret.toString();
   }
   public char nextChar() throws Exception
   {
      byte c = read();
      while (c <= ' ') c = read();
      char ret = (char)c;
      return ret;
   }
   private void fillBuffer() throws Exception
   {
      bytesRead = din.read(buffer, bufferPointer = 0, BUFFER_SIZE);
      if (bytesRead == -1) buffer[0] = -1;
   }

   private byte read() throws Exception
   {
      if (bufferPointer == bytesRead) fillBuffer();
      return buffer[bufferPointer++];
   }
}