package java_6.problem_132C.subId_929722;

import java.util.Scanner;

public class Problem {


	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		char[] code = in.next().toCharArray();
		int m = code.length;            
		int n = in.nextInt();
		int[][][] pd = new int[m+1][n+1][2];
		for(int i = 0; i <= m; i++) {
			for(int j = 0; j <= n; j++) {
				pd[i][j][0] = -1<<30;
				pd[i][j][1] = -1<<30;
			}
		}
		pd[0][0][0] = 0;
		for(int i = 1; i <= m; i++) {
			for(int j = 0; j <= n; j++) {
				for(int k = 0; k <= j; k++) {
					char next = 'T';
					if(k%2 == 0 && code[i-1]=='F' || k%2 == 1 && code[i-1]=='T') next = 'F';
					if(next == 'F') {
						pd[i][j][0] = Math.max(pd[i][j][0], pd[i-1][j-k][0]+1);
						pd[i][j][1] = Math.max(pd[i][j][1], pd[i-1][j-k][1]-1);
					}else {
						pd[i][j][0] = Math.max(pd[i][j][0], pd[i-1][j-k][1]);
						pd[i][j][1] = Math.max(pd[i][j][1], pd[i-1][j-k][0]);
					}
				}
			}
		}
		System.out.println(Math.max(pd[m][n][0],pd[m][n][1]));
		in.close();
	}
}