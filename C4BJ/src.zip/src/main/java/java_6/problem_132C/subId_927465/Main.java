package java_6.problem_132C.subId_927465;

import java.util.Scanner;

public class Main {

  public static void main(String args[]) {
    (new Main()).solve();
  }

  void solve() {

    Scanner cin = new Scanner(System.in);

    while( cin.hasNext() ) {

      String s = cin.next();
      int k = cin.nextInt();
      int n = s.length();

      int inf = 10000;

      int dp[][][] = new int[n+1][k+1][2];
      for(int i=0; i<=n; ++i) {
        for(int j=0; j<=k; ++j) {
          dp[i][j][0] = -inf;
          dp[i][j][1] = inf;
        }
      }
      dp[0][0][0] = dp[0][0][1] = 0;

      int Tsum = 0;

      for(int i=0; i<n; ++i) {
        int curT = s.charAt(i) == 'T' ? 1 : 0;
        int curF = 1 - curT;
        Tsum += curT;
        for(int j=0; j<=k; ++j) {
          if( dp[i][j][0] == inf ) { continue; }
          int dir = (Tsum + j) % 2 == 1 ? -1 : 1;
          dp[i+1][j][0] = Math.max(dp[i+1][j][0], dp[i][j][0] + curF * dir);
          dp[i+1][j][1] = Math.min(dp[i+1][j][1], dp[i][j][1] + curF * dir);
          // flip;
          if( j < k ) {
            dp[i+1][j+1][0] = Math.max(dp[i+1][j+1][0], dp[i][j][0] - curT * dir);
            dp[i+1][j+1][1] = Math.min(dp[i+1][j+1][1], dp[i][j][1] - curT * dir);
          }
        }
      }

      int ret = Math.max(Math.abs(dp[n][k][0]), Math.abs(dp[n][k][1]));
      System.out.println(ret);

    }

  }

}