package java_6.problem_132C.subId_1130924;

import java.util.Arrays;
import java.util.Scanner;

public class turtle {
    public static void debug(Object... obs) {
        System.out.println(Arrays.deepToString(obs));
    }

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        
        String s=sc.next();
        int k=sc.nextInt();
        int n=s.length();
        
        int[][][][]dp=new int[n+1][k+1][2][2];
        boolean[][][]reach=new boolean[n+1][k+1][2];
        final int[]sg={1,-1};
        
        for(int i=0;i<=n;i++)
        {
            for(int j=0;j<=k;j++)
            {
                for(int l=0;l<sg.length;l++)
                {
                    dp[i][j][l][0]=Integer.MIN_VALUE;
                    dp[i][j][l][1]=Integer.MAX_VALUE;
                }
            }
        }
        dp[0][0][0][0]=0;
        dp[0][0][0][1]=0;
        reach[0][0][0]=true;
        
        for(int i=1;i<=n;i++)
        {
            int trn=0;
            int inc=1;
            if(s.charAt(i-1)=='T')
            {
                trn=1;
            }
            for(int j=0;j<=k;j++)
            {
                for(int f=0;f<=j;f++)
                {
                    int d=(j-f+trn)%2;
                    for(int l=0;l<sg.length;l++)
                    {
                        if(reach[i-1][f][l])
                        {
                            dp[i][j][(l+d)%2][0]=Math.max(dp[i][j][(l+d)%2][0],dp[i-1][f][l][0]+sg[l]*(1-d)*inc);
                            dp[i][j][(l+d)%2][0]=Math.max(dp[i][j][(l+d)%2][0],dp[i-1][f][l][1]+sg[l]*(1-d)*inc);
                            dp[i][j][(l+d)%2][1]=Math.min(dp[i][j][(l+d)%2][1],dp[i-1][f][l][0]+sg[l]*(1-d)*inc);
                            dp[i][j][(l+d)%2][1]=Math.min(dp[i][j][(l+d)%2][1],dp[i-1][f][l][1]+sg[l]*(1-d)*inc);
                            reach[i][j][(l+d)%2]=true;
                        }
                    }
                }
            }
        }

        int ma=Integer.MIN_VALUE;
        for(int i=0;i<2;i++)
            for(int j=0;j<2;j++)
                if(dp[n][k][i][j]!=Integer.MAX_VALUE && dp[n][k][i][j]!=Integer.MIN_VALUE)
                    ma = Math.max(ma,dp[n][k][i][j]);
        System.out.println(ma);
    }
}