package java_6.problem_40C.subId_473374;

import java.io.PrintWriter;
import java.util.Scanner;

public class Main {
		Scanner in;
		PrintWriter pw;
		
		public void run () throws Exception {
            in = new Scanner(System.in);
            pw = new PrintWriter(System.out);

            int n = in.nextInt();
            int x = in.nextInt();
            int m = in.nextInt();
            int y = in.nextInt();
            
            int r = Math.abs(x-y);
            if(n<m){
            	int t = n;
            	n = m;
            	m = t; 
            }
            long res = 1 + n;
            
            if(r<=m) res++;
            
            for(int i=1;i<=m;i++) if(r+i>n) res++;
            for(int i=2;i<=n;i++){
            	int num = 1;
            	
            	if(r+i<=m) num++;
            	if(r<=i && i-r<=m) num++;
            	if(r-i+1<=m && r>i) num++;
            	
            	int k = 0;
            	
            	int f = i - r + 1;
            	f = Math.max(f, 1);
            	
            	int t = m;
            	
            	//[r-x,r-x+1 <= i-1
            	//x>=r-i+2
            	f = Math.max(f, r-i+2);
            	//r+i-1>=x
            	//x<=r+i-1
            	t = Math.min(t, r+i-1);
            	
            	if(f<=t) k = t - f + 1;
            	
            	num += 2*k;
            	//[-i,-(i-1)]..[i-1,i]
            	
            	res += (num - 1);
            }

            

            pw.println(res);
            pw.close();
        }
        public static void main(String[] args) throws Exception {
                new Main ().run();
        }
}