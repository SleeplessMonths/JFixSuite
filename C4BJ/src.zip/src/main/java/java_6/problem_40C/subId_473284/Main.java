package java_6.problem_40C.subId_473284;

import java.io.PrintWriter;
import java.util.Scanner;

public class Main {
		Scanner in;
		PrintWriter pw;
		
		public void run () throws Exception {
            in = new Scanner(System.in);
            pw = new PrintWriter(System.out);

            int n = in.nextInt();
            int x = in.nextInt();
            int m = in.nextInt();
            int y = in.nextInt();
            
            int r = Math.abs(x-y);
            if(n<m){
            	int t = n;
            	n = m;
            	m = t; 
            }
            long res = 1 + n;
            for(int i=1;i<=m;i++){
            	if(r >= i + n) res++;
            	else{
            		if(r+i>n) res++;
            		
            		int num = 2 * i;
            		int sub = 2;
            		if(r+i>n){
            			num -= (r+i-n);
            			sub--;
            		}
            		
            		res += (2*num-sub);
            		
            	}
            }
            
            pw.println(res);
            pw.close();
        }
        public static void main(String[] args) throws Exception {
                new Main ().run();
        }
}