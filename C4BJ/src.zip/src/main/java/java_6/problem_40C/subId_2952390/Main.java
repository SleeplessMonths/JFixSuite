package java_6.problem_40C.subId_2952390;

import java.util.Scanner;

public class Main {

  public static void main(String args[]) {
    (new Main()).solve();
  }

  void solve() {

    Scanner cin = new Scanner(System.in);

    while( cin.hasNext() ) {

      int N = cin.nextInt();
      int x = cin.nextInt();
      int M = cin.nextInt();
      int y = cin.nextInt();

      solve(N, M, Math.abs(x - y));

    }

  }

  void solve(int N, int M, int D) {

    int ret = M + 1;

    for(int i=1; i<=N; ++i) {
      int tri = (Math.min(M, i + D - 1) - Math.abs(D - i)) * 2;
      if( i > D && i - D <= M ) { ++tri; }
      if( tri > 0 ) { ret += tri; }
      else { ret += 1; }
    }

    System.out.println(ret);

  }

}