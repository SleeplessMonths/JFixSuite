package java_6.problem_39E.subId_860468;

import java.util.Scanner;

public class Sh1E {

	static final int N = 35000, M = 33;
	static Scanner in;
	static int n, a, b;
	static boolean[][] game = new boolean[N][M];

	public static void main(String[] args) {
		in = new Scanner(System.in);
		a = in.nextInt();
		b = in.nextInt();
		n = in.nextInt();
		long pow;
		for (int i = 2; i < N; ++i) {
			pow = (long) i * (long) i;
			for (int j = 2; j < M; ++j) {
				if (pow >= n) {
					game[i][j] = true;
				} else {
					pow *= (long) i;
				}
			}
		}
		game[N - 1][1] = true;
		if (n % 2 == 0)
			game[N - 2][1] = true;
		for (int j = M - 2; j >= 1; --j)
			for (int i = N - 2; i >= 2; --i)
				if (!game[i][j]) {
					if (!game[i + 1][j] || !game[i][j + 1])
						game[i][j] = true;
				}
		if (a == 1) {
			if (!game[2][b])
				System.out.println("Masha");
			else if (!game[2][b + 1])
				System.out.println("Stas");
			else
				System.out.println("Missing");
		} else {
			if (game[a][b])
				System.out.println("Masha");
			else
				System.out.println("Stas");
		}
	}
}