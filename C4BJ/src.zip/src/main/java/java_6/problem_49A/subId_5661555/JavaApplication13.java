package java_6.problem_49A.subId_5661555;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class JavaApplication13 {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

            String x = reader.readLine();
            x=x.replaceAll("[?]", "");
             x=x.replaceAll(" ", "");
             x=x.toLowerCase();
             if (x.charAt(x.length()-1)=='e'||
                   x.charAt(x.length()-1)=='o'||  
                 x.charAt(x.length()-1)=='a' ||
                     x.charAt(x.length()-1)=='u'||
                     x.charAt(x.length()-1)=='i'){
                       System.out.println("YES");
                   } else {
                 System.out.println("NO");
                 
             }
        
    }
    
}