package java_6.problem_49A.subId_5703936;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Ahmed
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String a = reader.readLine().trim();
        a=a.toLowerCase();
        if(a.endsWith("a?")||a.endsWith("e?")||a.endsWith("u?")||a.endsWith("i?")||a.endsWith("y?")||a.endsWith("o?"))
            System.out.println("YES");
        else
            System.out.println("NO");
    }
}