package java_6.problem_49A.subId_5686888;

import java.io.BufferedReader;
import java.io.InputStreamReader;
public class Sleuth {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		try {
			
			String s=br.readLine();
			for (int i = s.length()-1; i >0; i--) {
			if(s.charAt(i)!=' ' &&s.charAt(i)!='?'){
				if(voule(s.charAt(i))){
					System.out.println("YES");
					
				}
				else
					System.out.println("NO");
				break;
			}
			
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

	}
	
	
public static boolean voule(char c){
		
		if(c=='A' || c=='a')
			return true;
		else
			if(c=='O' || c=='o')
				return true;
			else
				if(c=='Y' || c=='y')
					return true;
				else
					if(c=='E' || c=='e')
						return true;
					else
						if(c=='U' || c=='u')
							return true;
						else
							if(c=='I' || c=='i')
								return true;
			
		
		return false;
			
		
	}

}