package java_6.problem_49A.subId_5661544;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class JavaApplication13 {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

            String x = reader.readLine();
            x=x.replaceAll("[?]", "");
             x=x.replaceAll(" ", "");
             
             if (x.charAt(x.lastIndexOf(x))=='e'||
                   x.charAt(x.lastIndexOf(x))=='o'||  
                 x.charAt(x.lastIndexOf(x))=='a' ||
                     x.charAt(x.lastIndexOf(x))=='u'||
                     x.charAt(x.lastIndexOf(x))=='i'){
                       System.out.println("YES");
                   } else {
                 System.out.println("NO");
                 
             }
        
    }
    
}