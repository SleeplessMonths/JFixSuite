package java_6.problem_216A.subId_4047677;

import java.util.Scanner;
public class A216 {
    public static void main(String[] args){
        Scanner br = new Scanner(System.in);
        int a = br.nextInt();
        int b = br.nextInt();
        int c = br.nextInt();
        int ans = 0;
        while(a > 0 && b > 0 && c > 0){
            ans+=(a+b+c)*2 - 6;
            a--;
            b--;
            c--;
        }
        if(ans == 0){
            ans++;
        }
        System.out.println(ans);
    }
}