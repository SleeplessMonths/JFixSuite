package java_6.problem_216A.subId_3731224;

import java.util.Scanner;


public class A_216 {
	
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		
		int sum = 0;
		while(Math.min(a, Math.min(b, c)) >= 1){
			sum += 2 * (a + b + c) - 6;
			a--;
			b--;
			c--;
		}
		
		System.out.println(sum);
		
		sc.close();
	}

}