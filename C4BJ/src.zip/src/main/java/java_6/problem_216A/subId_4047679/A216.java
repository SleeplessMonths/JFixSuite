package java_6.problem_216A.subId_4047679;

import java.util.Scanner;
public class A216 {
    public static void main(String[] args){
        Scanner br = new Scanner(System.in);
        int a = br.nextInt();
        int b = br.nextInt();
        int c = br.nextInt();
        int ans = 0;
        while(a > 0 && b > 0 && c > 0){
            ans+=(a+b+c)*2 - 6;
            if(a == 1 && b == 1 && c == 1){
                ans++;
            }
            a--;
            b--;
            c--;
        }
        System.out.println(ans);
    }
}