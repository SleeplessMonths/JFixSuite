package java_6.problem_185A.subId_8796363;

import java.math.BigInteger;
import java.util.Scanner;

public class Plant185A
{
    public static long twopower(long exp)
    {
        if (exp == 0)
        {
            return 0;
        }
        if (exp == 1)
        {
            return 2;
        }
        if (exp % 2 == 0)
        {
            long recurs = twopower(exp/2);
            return (recurs * recurs)%1000000007;
        }
        else   // exp % 2 == 1
        {
            long recurs = twopower(exp/2);
            long onemult = (recurs * recurs) % 1000000007;
            return (onemult * 2)%1000000007;
        }
    }
            
    public static void main(String[] args) 
    {
        
        // Set up scanner
        Scanner sc = new Scanner(System.in); 
        // System.out.println("Enter n");
        long n = sc.nextLong();
        
        if (n==1)
        {
            System.out.println(3);
            return;
        }
        
        long firstpart = twopower(n) + 1;
        long secondpart = twopower(n-1);
        BigInteger bigfirst = new BigInteger(String.valueOf(firstpart));
        // System.out.println(bigfirst);
        BigInteger bigsecond = new BigInteger(String.valueOf(secondpart));
        // System.out.println(bigsecond);
        BigInteger bigmod = new BigInteger("1000000007");
        // System.out.println(bigmod);
        BigInteger bigproduct = bigfirst.multiply(bigsecond);
        // System.out.println(bigproduct);
        BigInteger biganswer = bigproduct.mod(bigmod);

        System.out.println(biganswer);
    }
}