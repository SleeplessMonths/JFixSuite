package java_6.problem_175A.subId_5035683;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            String str = br.readLine();
            int answer = -1;
            for (int i = 1; i < str.length(); i++) {
                for (int j = i + 1; j < str.length(); j++) {
                    String first = str.substring(0, i);
                    String med = str.substring(i, j);
                    String last = str.substring(j);
                    if (first.charAt(0) == '0' && first.length() != 1
                            || med.charAt(0) == '0' && med.length() != 1
                            || last.charAt(0) == '0' && last.length() != 1)
                        continue;
                    if (first.length() > 7 || med.length() > 7
                            || last.length() > 7)
                        continue;
                    if (first.length() > 1000000 || med.length() > 1000000
                            || last.length() > 1000000)
                        continue;
                    answer = Math.max(answer,
                            Integer.parseInt(first) + Integer.parseInt(med)
                                    + Integer.parseInt(last));
                }
            }
            System.out.println(answer);
            br.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}