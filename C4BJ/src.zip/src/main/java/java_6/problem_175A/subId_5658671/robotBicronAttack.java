package java_6.problem_175A.subId_5658671;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class robotBicronAttack {

    
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s=(br.readLine().trim());
        String ss="";int c=0;boolean f=true;
        if(s.length()%2==1)
            s=s+"0";
        for(int i=0;i<s.length();i+=2){
            int sum=Integer.parseInt(""+s.charAt(i))+Integer.parseInt(""+s.charAt(i+1));
            
            if(c==0)
                if(sum==0){
                    System.out.println(-1);f=false;break;}
                else
                    c++;
            ss +=""+sum;
        }
if(f)           
System.out.println(ss);
    }

}