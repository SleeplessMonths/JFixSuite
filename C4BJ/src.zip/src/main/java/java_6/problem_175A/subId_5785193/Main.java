package java_6.problem_175A.subId_5785193;

import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String w=s.next();String n1=w.charAt(0)+"",n2="0",n3="0";boolean p=false;
        if(w.length()<2 || (w.charAt(0)=='0'&&w.charAt(1)=='0'&&w.charAt(2)=='0'&&w.length()>2))
            System.out.println(-1);
        else if(w.charAt(0)=='0'&&w.charAt(1)=='0'&&w.charAt(2)!='0')
        System.out.println(w.substring(2));
        else {
           for(int i=1;i<w.length();i++){
          if(w.charAt(i)=='0')
            n1+=w.charAt(i);
          else{
              p=true;
              break;}
           }
           if(p){
               p=false;
           n2=w.charAt(n1.length())+"";
           for(int i=n1.length()+1;i<w.length();i++){
          if(w.charAt(i)=='0')
            n2+=w.charAt(i);
          else{p=true;
              break;
           }}
             if(p)
                 n3=w.substring(n1.length()+n2.length());
             else
                 n2=n2.substring(0, n2.length()-1);
           }
          else
            n1=n1.substring(0,n1.length()-2);
           int g=Integer.parseInt(n1)+Integer.parseInt(n2)+Integer.parseInt(n3);
           System.out.println(g);
        }
    }
}