package java_6.problem_29B.subId_7618820;

//package Codeforces_29_082014;

import java.util.Locale;
import java.util.Scanner;

public class B {
	public static void main(String[] args) {
		Locale.setDefault(Locale.US);
		Scanner sc=new Scanner(System.in);
		double l=sc.nextDouble();
		double d=sc.nextDouble();
		double v=sc.nextDouble();
		double g=sc.nextDouble();
		double r=sc.nextDouble();
		
		double svetVaqt=(double) (d/v);
		double davr=g+r;
		svetVaqt=svetVaqt-((int)(svetVaqt/davr))*davr;
		if(svetVaqt<=g){
			System.out.printf("%.6f",(l/v));
		} else {
			double qosh=davr-svetVaqt;
			System.out.printf("%.6f",((l/v)+qosh));
		}
	}
}