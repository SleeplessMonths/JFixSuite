package java_6.problem_290A.subId_5947547;

import java.util.Scanner;

public class Mysteriousstrings
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		--n;
		String[] res = new String[40];
		res[0] = "Washington";
		res[1] = "Adams";
		res[2] = "Jefferson";
		res[7] = "Van Buren";
		res[28] = "Harding";
		
		System.out.println(res[n]);
	}
}