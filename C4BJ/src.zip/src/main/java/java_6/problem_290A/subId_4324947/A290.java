package java_6.problem_290A.subId_4324947;

import java.util.Scanner;
public class A290 {
	public static String[] dumb = {"Washington", "Adams", "Jefferson", "Madison", "Monrow", "Adams", "Jackson", "Van Buren", "Harrison", "Tyler", "Polk", "Taylor", "Fillmore", "Pierce", "Buchanan", "Lincoln", "Johnson", "Grant", "Hayes", "Garfield", "Arthur", "Cleveland", "Harrison", "Cleveland", "McKinley", "Roosevelt", "Taft", "Wilson", "Harding", "Coolidge", "Hoover", "Roosevelt", "Truman", "Eisenhower", "Kennedy", "Johnson", "Nixon", "Ford", "Carter", "Reagan"}; 
	public static void main(String[] args){
		Scanner br = new Scanner(System.in);
		System.out.println(dumb[br.nextInt()-1]);
	}
}