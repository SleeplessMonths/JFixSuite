package java_6.problem_290A.subId_5947525;

import java.util.Scanner;

public class Mysteriousstrings
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		if (n == 2)
		{
			System.out.println("Adams");
		}
		else if (n == 8)
		{
			System.out.println("Van Buren");
		}
		else if (n == 29)
		{
			System.out.println("Harding");
		}
	}
}