package java_6.problem_290A.subId_3466185;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class P290A_MysteriousString {

    public static String[] presidents = new String[] {
        "Washington",
        "Adams",
        "Jefferson",
        "Madison",
        "Monroe",
        "Adams",
        "Jackson",
        "Van Buren",
        "Harrison",
        "Tyler",
        "Polk",
        "Taylor",
        "Fillmore",
        "Pierce",
        "Buchanan",
        "Lincoln",
        "Johnson",
        "Grant",
        "Heyes",
        "Garfield",
        "Arthur",
        "Cleveland",
        "Harrison",
        "Cleveland",
        "McKinley",
        "Roosevelt",
        "Taft",
        "Wilson",
        "Harding",
        "Coolidge",
        "Hoover",
        "Roosevelt",
        "Truman",
        "Eisenhower",
        "Kennedy",
        "Johnson",
        "Nixon",
        "Ford",
        "Carter",
        "Reagan"
    };
    
    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int a = Integer.parseInt(in.readLine());
        System.out.println(presidents[a-1]);
    }

}