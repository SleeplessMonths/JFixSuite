package java_6.problem_290A.subId_5947573;

import java.util.Scanner;

public class Mysteriousstrings
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		--n;
		String[] res = new String[40];
		res[0] = "Washington";
		res[1] = "Adams";
		res[2] = "Jefferson";
		res[3] = "Madison";
		res[4] = "Monroe";
		res[5] = "Adams";
		res[6] = "Jackson";
		res[7] = "Van Buren";
		res[8] = "Harrison";
		res[9] = "Tyler";
		res[28] = "Harding";
		
		System.out.println(res[n]);
	}
}