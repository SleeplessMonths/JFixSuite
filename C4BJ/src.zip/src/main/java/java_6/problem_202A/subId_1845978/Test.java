package java_6.problem_202A.subId_1845978;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class Test {
	static BufferedReader reader;
	static StringTokenizer tokenizer;
	static PrintWriter writer;

	static int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	static long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	static double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	static String nextToken() throws IOException {
		while (tokenizer == null || !tokenizer.hasMoreTokens()) {
			tokenizer = new StringTokenizer(reader.readLine());
		}
		return tokenizer.nextToken();
	}

	public static void main(String[] args) throws IOException {
		reader = new BufferedReader(new InputStreamReader(System.in));
		tokenizer = null;
		writer = new PrintWriter(System.out);
		solve();
		reader.close();
		writer.close();
	}

	private static void solve() throws IOException {
		String s = nextToken();
		String res="";
		for(int i=0;i<1024;i++)
		{
			StringBuilder curr = new StringBuilder();
			for(int j=0;j<s.length();j++)
			{
				if((i&(1<<j))==(1<<j))
				{
					curr.append(s.charAt(j));
				}
			}
			if(curr.toString().compareTo(res)>0)
			{
				res=curr.toString();
			}
		}
		writer.println(res);
	}
}