package java_6.problem_202A.subId_2769007;

import java.util.Scanner;


public class LLPS {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String inputStr = sc.next();
		String llps = "";
		for (int i = 0; i < ((1<<inputStr.length()) - 1); i++) {
			String newStr = "";
			for (int j = 0; j < inputStr.length(); j++) {
				if((i & (1<<j)) > 0){
					newStr += inputStr.charAt(j);
				}
			}
			if(!isPalindrome(newStr)){
				continue;
			}
			if(llps.compareTo(newStr) < 0){
				llps = newStr;
			}
		}
		System.out.println(llps);
	}
	
	public static boolean isPalindrome(String a){
		for (int i = 0; i < a.length()/2; i++) {
			if(a.charAt(i) != a.charAt(a.length()-1-i)){
				return false;
			}
		}
		return true;
	}
}