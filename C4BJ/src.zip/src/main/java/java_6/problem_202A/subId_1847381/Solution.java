package java_6.problem_202A.subId_1847381;

import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class Solution {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        char[] s = scanner.next().toCharArray();
        Arrays.sort(s);
        char[] pal = "***********".toCharArray();
        int k = 0;
        char c = ' ';
        for (int i = s.length - 1; i > 0; --i) {
            if (s[i] >= c) {
                if (s[i] == s[i - 1]) {
                    pal[k] = pal[9 - k] = s[i];
                    k++;
                    i--;
                    c = s[i];
                } else  {
                    pal[5] = s[i];
                    break;
                }
            }
        }

        for (char p : pal) {
            if (p != '*') System.out.print(p);
        }
    }
}