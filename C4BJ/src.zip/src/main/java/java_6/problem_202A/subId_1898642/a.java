package java_6.problem_202A.subId_1898642;

public class a {
    public static void main(String args[]) {
        String s = "";
        try {
            int c = System.in.read();
            while (c != -1) {
                s += (char)c;
                c = System.in.read();
            }
        } catch (Exception e) {}
        int n = s.length();
        char mx = s.charAt(0);
        for (int i = 1; i < n; ++i) if (s.charAt(i) > mx) mx = s.charAt(i);
        String ans = "";
        for (int i = 1; i < n; ++i) if (s.charAt(i) == mx) ans += mx;
        System.out.println(ans);
    }
}