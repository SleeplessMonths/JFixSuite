package java_6.problem_79A.subId_1074524;

import java.util.Scanner;
public class LOL {
    public static void main(String[] args) throws Exception {
        Scanner in = new Scanner(System.in);
        int X = in.nextInt();
        int Y = in.nextInt();
        boolean max = true;
        while(true) {
            int chX = 0;
            int chY = 0;
            if (max) {
                chX = Math.min(2,X);
                chY = Math.min(Y,22-chX*10);
            } else {
                chX = Math.min(2,X);
                chY = Math.min(Y,22-chX*10);
                while(Y-chY > 10 && chX > 0) {
                    chY += 10;
                    chX -= 1;
                }
            }
            if (chX*10+chY < 22)
                break;
            else {
                X-=chX;
                Y-=chY;
            }
            max = !max;
        }
        if (!max)
            System.out.println("Ciel");
        else
            System.out.println("Hanako");
    }
}