package java_6.problem_79A.subId_935852;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//package codeforces;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class BusGame {
    public static void solve(){
        Scanner nera = new Scanner(System.in);
        
        long x= nera.nextLong();
        long y=nera.nextLong();
        
        while(true){
            
            if(x>=2 && y>=2){
                x-=2;
                y-=2;
            }else if(x>=1 && y>=12){
                x-=1;
                y-=12;
            }else if(x==0 && y>=22){
                y-=22;
            }else{
                System.out.println("Hanako");
                break;
            }
            
            if(y>=22){
                y-=22;
            }else if(x>=1 && y>=12){
                x-=1;
                y-=12;
            }else if(x>=2 && y>=2){
                x-=2;
                y-=12;
            }else{
                System.out.println("Ciel");
                break;
            }
        }
        
        
    }
    public static void main(String[] args) {
        
        solve();
    }
}