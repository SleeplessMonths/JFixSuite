package java_6.problem_79A.subId_603022;

import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner r = new Scanner(System.in);
		
		int x = r.nextInt();
		int y = r.nextInt();
		
		int w = 1;
		
		while(true){
			if(w == 1){//Ciel playing;
				if(x >= 2 && y >= 2){
					x -= 2;
					y -= 2;
				}else if(x >= 1 && y >= 12){
					x -= 1;
					y -= 12;
				}else if(x == 0 && y >= 22){
					y -= 22;
				}else{
					break;
				}
			}else{
				if(x == 0 && y >= 22){
					y -= 22;					
				}else if(x >= 1 && y >= 12){
					x -= 1;
					y -= 12;
				}else if(x >= 2 && y >= 2){
					x -= 2;
					y -= 2;
				}else{
					break;
				}
			}
			w = 1-w;
		}
		
		if(w == 1)System.out.println("Hanako");
		else System.out.println("Ciel");
	}
}