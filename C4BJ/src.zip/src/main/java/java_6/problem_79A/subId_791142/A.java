package java_6.problem_79A.subId_791142;

import java.util.Scanner;


   public class A {
            public static void main(String[] args){
                Scanner in = new Scanner(System.in);

                int n1 =in.nextInt(),n2 =in.nextInt();

                boolean f = true;
                boolean hod = true;

                while (f){
                    if (hod){
                        if (n1>1&&n2>1){
                            n1-=2;
                            n2-=2;
                            hod = false;
                        } else
                        if(n1==1&&n2>11){
                              n1=0;
                              n2-=12;
                            hod = false;
                            }
                        else
                        if(n1==0&&n2>21){
                            n1=0;
                            n2-=22;
                            hod = false;
                        }
                        else
                        {
                            f=false;
                            System.out.print("Hanako");
                        }


                    } else

                        if (n2>21){
                            n2-=22;
                            hod = true;
                        } else
                        if(n2>11&&n1>0){
                              n1-=1;
                                n2-=12;
                            hod = true;
                            }
                        else
                        if(n2>1&&n1>1){
                            n1-=2;
                            n2-=2;
                        }
                        else
                        {
                            f=false;
                            System.out.print("Ciel");
                        }


                }
            }
   }