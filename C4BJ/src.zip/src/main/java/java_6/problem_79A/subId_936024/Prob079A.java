package java_6.problem_79A.subId_936024;

import java.io.IOException;
import java.util.Scanner;


public class Prob079A
{
    public static void main( String[] Args ) throws IOException
    {
        Scanner in = new Scanner( System.in );

        int h = in.nextInt();
        int t = in.nextInt();

        boolean winc = false;

        for ( int x = 0;; x++ )
        {
            if ( x % 2 == 0 )
            {
                if ( h >= 2 )
                {
                    t -= 2;
                    h -= 2;
                }
                else if ( t >= 12 && h >= 1 )
                {
                    t -= 12;
                    h -= 1;
                }
                else if ( t >= 22)
                    t -= 22;
                else
                    break;
                winc = true;
            }
            else if ( x % 2 == 1 )
            {
                if ( t >= 22 )
                    t -= 22;
                else if ( t >= 12 && h >= 1 )
                {
                    t -= 12;
                    h -= 1;
                }
                else if ( t >= 2 && h >= 2 )
                {
                    t -= 2;
                    h -= 2;
                }
                else
                    break;
                winc = false;
            }
        }

        if ( winc )
            System.out.println( "Ciel" );
        else
            System.out.println( "Hanako" );
    }
}