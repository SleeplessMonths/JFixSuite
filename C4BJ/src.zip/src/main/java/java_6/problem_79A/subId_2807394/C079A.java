package java_6.problem_79A.subId_2807394;

import java.io.BufferedInputStream;
import java.util.Arrays;

public class C079A {

	public void solve() throws Exception {
		int x = nextInt();
		int y = nextInt();
		boolean ciel = true;
		while (x * 100 + y * 10 >= 220) {
			if (ciel) {
				if (x >= 2) {
					x -= 2;
					y -= 2;
				} else {
					if (x == 1) {
						x -= 1;
						y -= 12;
					} else {
						y -= 22;
					}
				}
			} else {
				if (y >= 22) {
					y -= 22;
				} else if (y >= 12) {
					y -= 12;
					x -= 1;
				} else {
					x -= 2;
					y -= 2;
				}

			}
			ciel = !ciel;
		}
		if (ciel) {
			println("Hanako");
		} else {
			println("Ciel");
		}

	}

	// ------------------------------------------------------

	void debug(Object... os) {
		System.err.println(Arrays.deepToString(os));
	}

	void print(Object... os) {
		if (os != null && os.length > 0)
			System.out.print(os[0].toString());
		for (int i = 1; i < os.length; ++i)
			System.out.print(" " + os[i].toString());
	}

	void println(Object... os) {
		print(os);
		System.out.println();
	}

	BufferedInputStream bis = new BufferedInputStream(System.in);

	String nextWord() throws Exception {
		char c = (char) bis.read();
		while (c <= ' ')
			c = (char) bis.read();
		StringBuilder sb = new StringBuilder();
		while (c > ' ') {
			sb.append(c);
			c = (char) bis.read();
		}
		return new String(sb);
	}

	String nextLine() throws Exception {
		char c = (char) bis.read();
		while (c <= ' ')
			c = (char) bis.read();
		StringBuilder sb = new StringBuilder();
		while (c != '\n' && c != '\r') {
			sb.append(c);
			c = (char) bis.read();
		}
		return new String(sb);
	}

	int nextInt() throws Exception {
		return Integer.parseInt(nextWord());
	}

	long nextLong() throws Exception {
		return Long.parseLong(nextWord());
	}

	public static void main(String[] args) throws Exception {
		new C079A().solve();
	}
}