package java_6.problem_57C.subId_956728;

import java.util.Scanner;

public class C {
    static int mod;
    public static long binExp(long base,long pow){
        long res=1L;
        long cur=base;
        while(pow>0){
            if((pow&1)==1){
                res=(res*cur)%mod;
            }
            pow>>=1;
            cur=(cur*cur)%mod;
        }
        return res;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        long n=sc.nextLong();
        long up=2*n-1;
        long down=n;
        long res=1;
        mod=1000000007;
        while(down>0){
            res= ((res*up)%mod*binExp(down, mod-2))%mod;
            up--;
            down--;
        }
        System.out.println(2L*res-n);
    }
}