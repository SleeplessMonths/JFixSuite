package java_6.problem_57C.subId_265948;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StreamTokenizer;

public class Main {
//	static Scanner in;
	static PrintWriter out;
	static StreamTokenizer in; static int next() throws Exception {in.nextToken(); return (int) in.nval;}
	static final int mod = 1000000007;

	static int pow(int k, int p) {
		if (p <= 1) {
			if (p == 1) return k;
			else return 1;
		}
		int pp = pow(k, p/2);
		int answ = (int)((long)pp*pp % mod);
		if ((p & 1) == 0) return answ;
		else return (int)(((long)answ * k) % mod);
	}


	public static void main(String[] args) throws Exception {
//		in = new Scanner(System.in);
		in = new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
		out = new PrintWriter(System.out);

		int n = next();
		long answ = 1;
		for (int i = 1; i <= n; i++)
			answ = answ * (n + i - 1) % mod * pow(i, mod - 2) % mod;

		out.println(answ * 2 - n);

//		for (int i = 0; i < 11; i++) out.println(pow(2, i));

		out.close();
	}

}