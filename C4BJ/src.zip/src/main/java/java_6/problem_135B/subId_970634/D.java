package java_6.problem_135B.subId_970634;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class D {

    class Point {

        int idx;
        long x, y;

        Point(int idx, long x, long y) {
            this.idx = idx;
            this.x = x;
            this.y = y;
        }
    }

    int ccw(Point A, Point B, Point C) {
        long dx1 = B.x - A.x, dy1 = B.y - A.y;
        long dx2 = C.x - A.x, dy2 = C.y - A.y;
        return Long.signum(dx1 * dy2 - dx2 * dy1);
    }

    Point[] sort(Point[] a) {
        int imin = 0;
        for (int i = 0; i < 4; ++i) {
            if (a[i].y < a[imin].y || (a[i].y == a[imin].y && a[i].x < a[imin].x)) {
                imin = i;
            }
        }        
        final Point O = new Point(a[imin].idx, a[imin].x, a[imin].y);
        Arrays.sort(a, new Comparator<Point>() {

            @Override
            public int compare(Point A, Point B) {
                int c = ccw(O, A, B);
                if (c != 0) {
                    return -c;
                }
                return Long.signum(sqr(A.x - O.x) + sqr(A.y - O.y) - sqr(B.x - O.x) - sqr(B.y - O.y));
            }
        });
        return a;
    }

    boolean isPerpendicular(Point A, Point B, Point C) {
        long x1 = A.x - B.x, y1 = A.y - B.y;
        long x2 = C.x - B.x, y2 = C.y - B.y;
        return x1 * x2 + y1 * y2 == 0;
    }

    long sqr(long x) {
        return x * x;
    }

    boolean isRectangle(Point[] a) {
        a = sort(a);
        for (int i = 0; i < 4; ++i) {
            System.out.println(a[i].x + " " + a[i].y);
        }
              
        for (int i = 0; i < 4; ++i) {
            if (!isPerpendicular(a[i], a[(i + 1) % 4], a[(i + 2) % 4])) {
                return false;
            }
        }
        return true;
    }

    boolean isSquare(Point[] a) {
        a = sort(a);

        if (!isRectangle(a)) {
            return false;
        }

        long side = sqr(a[0].x - a[1].x) + sqr(a[0].y - a[1].y);
        for (int i = 0; i < 4; ++i) {
            long now = sqr(a[i].x - a[(i + 1) % 4].x) + sqr(a[i].y - a[(i + 1) % 4].y);
            if (now != side) {
                return false;
            }
        }

        return true;
    }

    public void run() {
//        Point[] X = new Point[]{
//            new Point(0, 0, 0),
//            new Point(0, 1, -3),
//            new Point(0, -1, -1),
//            new Point(0, 2, -2)
//        };
//        
//        System.out.println(isRectangle(X));


        Scanner scanner = new Scanner(System.in);

        Point[] a = new Point[8];
        long x, y;
        for (int i = 0; i < 8; ++i) {
            x = scanner.nextLong();
            y = scanner.nextLong();
            a[i] = new Point(i + 1, x, y);
        }

        boolean found = false;
        for (int state = 0; state < (1 << 8); ++state) {
            if (Integer.bitCount(state) == 4) {
                Point[] square = new Point[4];
                Point[] rectangle = new Point[4];

                int ns = 0, nr = 0;
                for (int i = 0; i < 8; ++i) {
                    if (((state >> i) & 1) == 1) {
                        square[ns++] = new Point(a[i].idx, a[i].x, a[i].y);
                    } else {
                        rectangle[nr++] = new Point(a[i].idx, a[i].x, a[i].y);
                    }
                }

                if (isSquare(square) && isRectangle(rectangle)) {
                    found = true;
                    System.out.println("YES");
                    for (int i = 0; i < 4; ++i) {
                        System.out.print(square[i].idx + " ");
                    }
                    System.out.println();
                    for (int i = 0; i < 4; ++i) {
                        System.out.print(rectangle[i].idx + " ");
                    }
                    System.out.println();
                    break;
                }
            }
        }
        if (!found) {
            System.out.println("NO");
        }

        scanner.close();
    }

    public static void main(String[] args) {
        new D().run();
    }
}